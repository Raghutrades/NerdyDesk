package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class StartMenu(private val act: MainActivity) : FrameLayout(act) {

    class Entry(
        val label: String,
        val icon: Drawable?,
        val emoji: String?,
        val pkg: String?,
        val action: () -> Unit
    )

    var isOpen = false
        private set
    private val panel = LinearLayout(act)
    private val search = EditText(act)
    private val grid = GridLayout(act)
    private var installed: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()

    init {
        visibility = View.GONE
        isClickable = true
        setOnClickListener { close() }

        panel.orientation = LinearLayout.VERTICAL
        panel.background = Ui.rect(c(0xF4202020), dp(10).toFloat(), Ui.border, 1)
        panel.setPadding(dp(14), dp(14), dp(14), dp(10))
        panel.isClickable = true
        panel.elevation = dp(16).toFloat()

        search.hint = "\uD83D\uDD0D  Type here to search apps"
        search.setHintTextColor(Ui.textDim)
        search.setTextColor(Ui.text)
        search.textSize = 14f
        search.setSingleLine()
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = Ui.rect(c(0xFF333333), dp(18).toFloat())
        search.setPadding(dp(14), 0, dp(14), 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuild(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            shown.firstOrNull()?.let { e ->
                close()
                e.action()
            }
            true
        }
        panel.addView(search, lp(MATCH, dp(36)))

        val sv = ScrollView(act)
        grid.columnCount = 5
        sv.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
        val sl = lp(MATCH, 0, 1f)
        sl.topMargin = dp(10)
        panel.addView(sv, sl)

        val bottom = LinearLayout(act)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(act)
        name.text = "NerdyDesk"
        name.textSize = 13f
        name.setTextColor(Ui.textDim)
        bottom.addView(name, lp(0, WRAP, 1f))
        bottom.addView(iconBtn("\u2699\uFE0F") { close(); act.open(AppKind.SETTINGS, null) }, lp(dp(40), dp(36)))
        bottom.addView(iconBtn("\u23FB") { showPower(it) }, lp(dp(40), dp(36)))
        val bl = lp(MATCH, WRAP)
        bl.topMargin = dp(6)
        panel.addView(bottom, bl)

        addView(panel, FrameLayout.LayoutParams(dp(480), dp(460), Gravity.BOTTOM or Gravity.START))
    }

    private fun iconBtn(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    private fun showPower(anchor: View) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Choose default home app")
        m.menu.add(0, 2, 1, "Android settings")
        m.setOnMenuItemClickListener {
            close()
            when (it.itemId) {
                1 -> act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS))
                2 -> act.startSafely(Intent(Settings.ACTION_SETTINGS))
            }
            true
        }
        m.show()
    }

    private fun loadApps() {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        installed = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != act.packageName }
            .map { ri ->
                Entry(ri.loadLabel(pm).toString(), ri.loadIcon(pm), null, ri.activityInfo.packageName) { launch(ri) }
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(ri: ResolveInfo) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (!act.startSafely(i)) act.toast("Can't open this app")
    }

    private fun builtins(): List<Entry> = AppKind.values().map { k ->
        Entry(k.title, null, k.icon, null) { act.open(k, null) }
    }

    private fun rebuild(filter: String) {
        val q = filter.trim().lowercase()
        shown = (builtins() + installed).filter { q.isEmpty() || it.label.lowercase().contains(q) }
        grid.removeAllViews()
        for (e in shown) grid.addView(cell(e))
    }

    private fun cell(e: Entry): View {
        val cellView = LinearLayout(act)
        cellView.orientation = LinearLayout.VERTICAL
        cellView.gravity = Gravity.CENTER_HORIZONTAL
        cellView.setPadding(dp(2), dp(8), dp(2), dp(6))
        cellView.isClickable = true
        cellView.background = Ui.stateBg(dp(6).toFloat())
        if (e.icon != null) {
            val iv = ImageView(act)
            iv.setImageDrawable(e.icon)
            cellView.addView(iv, lp(dp(40), dp(40)))
        } else {
            val t = TextView(act)
            t.text = e.emoji
            t.textSize = 28f
            t.gravity = Gravity.CENTER
            cellView.addView(t, lp(dp(40), dp(40)))
        }
        val l = TextView(act)
        l.text = e.label
        l.textSize = 11f
        l.setTextColor(Ui.text)
        l.gravity = Gravity.CENTER
        l.maxLines = 2
        l.ellipsize = android.text.TextUtils.TruncateAt.END
        cellView.addView(l, lp(MATCH, WRAP))
        cellView.setOnClickListener {
            close()
            e.action()
        }
        val menu = {
            e.pkg?.let { p ->
                val m = PopupMenu(act, cellView)
                m.menu.add(0, 1, 0, "App info")
                m.setOnMenuItemClickListener {
                    close()
                    act.startSafely(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))
                    )
                    true
                }
                m.show()
            }
            Unit
        }
        cellView.setOnLongClickListener { menu(); true }
        cellView.setOnContextClickListener { menu(); true }
        cellView.hand()
        val g = GridLayout.LayoutParams()
        g.width = dp(88)
        g.height = dp(92)
        cellView.layoutParams = g
        return cellView
    }

    fun open() {
        val par = parent as View
        val lpn = panel.layoutParams as FrameLayout.LayoutParams
        lpn.height = minOf(dp(460), par.height - dp(48) - dp(16))
        lpn.width = minOf(dp(480), par.width - dp(16))
        lpn.leftMargin = dp(8)
        lpn.bottomMargin = dp(8)
        panel.layoutParams = lpn
        loadApps()
        search.setText("")
        rebuild("")
        visibility = View.VISIBLE
        isOpen = true
        search.requestFocus()
        act.onStartToggled()
    }

    fun focusSearch2() {
        search.requestFocus()
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    fun close() {
        if (!isOpen) return
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
        visibility = View.GONE
        isOpen = false
        act.onStartToggled()
    }
}
