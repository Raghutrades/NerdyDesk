package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class StartMenu(private val act: MainActivity) : FrameLayout(act) {

    class Entry(val key: String, val label: String, val icon: Drawable?, val emoji: String?, val action: () -> Unit)

    var isOpen = false
        private set
    private val panel = LinearLayout(act)
    private val search = EditText(act)
    private val listBox = LinearLayout(act)
    private val tiles = GridLayout(act)
    private lateinit var tileCol: ScrollView
    private var installed: List<Entry> = emptyList()
    private var shown: List<Entry> = emptyList()
    private var webQuery: String? = null

    init {
        visibility = View.GONE
        isClickable = true
        setOnClickListener { close() }

        panel.orientation = LinearLayout.HORIZONTAL
        panel.background = Ui.rect(c(0xF5202020), dp(10).toFloat(), Ui.border, 1)
        panel.isClickable = true
        panel.elevation = dp(16).toFloat()

        // left rail
        val rail = LinearLayout(act)
        rail.orientation = LinearLayout.VERTICAL
        rail.setPadding(dp(4), dp(8), dp(4), dp(8))
        rail.addView(railBtn("\uD83D\uDC64") { close(); act.open(AppKind.SETTINGS, null) }, lp(dp(44), dp(44)))
        val sp = View(act)
        rail.addView(sp, lp(dp(44), 0, 1f))
        rail.addView(railBtn("\uD83D\uDCC4") { close(); act.open(AppKind.FILES, "/storage/emulated/0/Documents") }, lp(dp(44), dp(44)))
        rail.addView(railBtn("\uD83D\uDDBC\uFE0F") { close(); act.open(AppKind.PHOTOS, null) }, lp(dp(44), dp(44)))
        rail.addView(railBtn("\u2699\uFE0F") { close(); act.open(AppKind.SETTINGS, null) }, lp(dp(44), dp(44)))
        rail.addView(railBtn("\u23FB") { showPower(it) }, lp(dp(44), dp(44)))
        panel.addView(rail, lp(dp(52), MATCH))

        // app list + search
        val mid = LinearLayout(act)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(dp(4), dp(12), dp(8), dp(8))
        search.hint = "\uD83D\uDD0D  Type here to search"
        search.setHintTextColor(Ui.textDim)
        search.setTextColor(Ui.text)
        search.textSize = 14f
        search.setSingleLine()
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = Ui.rect(c(0xFF333333), dp(18).toFloat())
        search.setPadding(dp(14), 0, dp(14), 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuild(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val q = search.text.toString().trim()
            val first = shown.firstOrNull()
            close()
            if (first != null) first.action() else if (q.isNotEmpty()) act.open(AppKind.BROWSER, q)
            true
        }
        mid.addView(search, lp(MATCH, dp(36)))
        val sv = ScrollView(act)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(listBox, FrameLayout.LayoutParams(MATCH, WRAP))
        listBox.orientation = LinearLayout.VERTICAL
        val sl = lp(MATCH, 0, 1f)
        sl.topMargin = dp(8)
        mid.addView(sv, sl)
        panel.addView(mid, lp(dp(270), MATCH))

        // tiles
        tileCol = ScrollView(act)
        tileCol.isVerticalScrollBarEnabled = false
        val tc = LinearLayout(act)
        tc.orientation = LinearLayout.VERTICAL
        tc.setPadding(dp(8), dp(14), dp(10), dp(8))
        val th = context.label("Pinned", 14f, Ui.text, true)
        th.setPadding(dp(4), 0, 0, dp(8))
        tc.addView(th)
        tiles.columnCount = 3
        tc.addView(tiles)
        tileCol.addView(tc, FrameLayout.LayoutParams(MATCH, WRAP))
        panel.addView(tileCol, lp(dp(330), MATCH))

        addView(panel, FrameLayout.LayoutParams(dp(652), dp(500), Gravity.BOTTOM or Gravity.START))
    }

    private fun railBtn(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 17f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    private fun showPower(anchor: View) {
        MenuPopup.show(
            act, anchor,
            listOf(
                MI("Lock") { close(); act.lockNow() },
                MI("Restart desktop (boot animation)") { close(); act.restartDesktop() },
                MI("", sep = true),
                MI("Choose default home app") { close(); act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS)) },
                MI("Android settings") { close(); act.startSafely(Intent(Settings.ACTION_SETTINGS)) }
            )
        )
    }

    private fun loadApps() {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        installed = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != act.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                Entry("p:$pkg", ri.loadLabel(pm).toString(), ri.loadIcon(pm), null) { act.launchApp(pkg) }
            }
    }

    private fun builtins(): List<Entry> = AppKind.values().map { k ->
        Entry("b:" + k.name, k.title, null, k.icon) { act.open(k, null) }
    }

    private fun entryMenu(e: Entry) {
        val onTask = act.isPinned("pins_task", e.key)
        val onDesk = act.isPinned("pins_desk", e.key)
        val items = ArrayList<MI>()
        items.add(MI("Open") { close(); e.action() })
        items.add(MI(if (onTask) "Unpin from taskbar" else "Pin to taskbar") { act.togglePin("pins_task", e.key); rebuildTiles() })
        items.add(MI(if (onDesk) "Remove from desktop" else "Pin to desktop") { act.togglePin("pins_desk", e.key) })
        if (e.key.startsWith("p:")) {
            items.add(MI("", sep = true))
            items.add(MI("App info") {
                close()
                act.startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.key.substring(2))))
            })
        }
        MenuPopup.show(act, null, items)
    }

    private fun rebuild(filter: String) {
        val q = filter.trim().lowercase()
        val all = (builtins() + installed).sortedBy { it.label.lowercase() }
        shown = all.filter { q.isEmpty() || it.label.lowercase().contains(q) }
        listBox.removeAllViews()
        webQuery = null
        if (q.isNotEmpty()) {
            val v = CalcEngine.eval(filter.trim())
            if (v != null && filter.trim().any { it in "+-*/^%" }) {
                val txt = CalcEngine.fmt(v)
                listBox.addView(simpleRow("\uD83E\uDDEE", "= $txt   (tap to copy)") {
                    val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("result", txt))
                    act.toast("Copied $txt")
                    close()
                })
            }
        }
        var letter = ' '
        for (e in shown) {
            if (q.isEmpty()) {
                val l = e.label.firstOrNull()?.uppercaseChar() ?: '#'
                val h = if (l.isLetter()) l else '#'
                if (h != letter) {
                    letter = h
                    val hv = context.label(h.toString(), 13f, Ui.accent, true)
                    hv.setPadding(dp(10), dp(8), 0, dp(2))
                    listBox.addView(hv)
                }
            }
            listBox.addView(appRow(e))
        }
        if (q.isNotEmpty()) {
            webQuery = filter.trim()
            listBox.addView(simpleRow("\uD83C\uDF10", "Search the web for \u201C${filter.trim()}\u201D") {
                close()
                act.open(AppKind.BROWSER, filter.trim())
            })
        }
    }

    private fun simpleRow(emoji: String, text: String, action: () -> Unit): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(8), dp(8), dp(8), dp(8))
        r.isClickable = true
        r.background = Ui.stateBg(dp(5).toFloat())
        r.addView(context.label(emoji, 18f), lp(dp(34), WRAP))
        r.addView(context.label(text, 13f), lp(0, WRAP, 1f))
        r.setOnClickListener { action() }
        r.hand()
        return r
    }

    private fun appRow(e: Entry): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(8), dp(6), dp(8), dp(6))
        r.isClickable = true
        r.background = Ui.stateBg(dp(5).toFloat())
        if (e.icon != null) {
            val iv = ImageView(act)
            iv.setImageDrawable(e.icon)
            r.addView(iv, lp(dp(28), dp(28)))
        } else {
            val t = context.label(e.emoji ?: "", 20f)
            t.gravity = Gravity.CENTER
            r.addView(t, lp(dp(28), dp(28)))
        }
        val l = context.label(e.label, 13f)
        l.setSingleLine()
        l.ellipsize = android.text.TextUtils.TruncateAt.END
        l.setPadding(dp(12), 0, 0, 0)
        r.addView(l, lp(0, WRAP, 1f))
        r.setOnClickListener {
            close()
            e.action()
        }
        r.setOnLongClickListener { entryMenu(e); true }
        r.setOnContextClickListener { entryMenu(e); true }
        r.hand()
        return r
    }

    private fun rebuildTiles() {
        tiles.removeAllViews()
        val pins = act.pins("pins_task")
        val all = builtins() + installed
        val list = ArrayList<Entry>()
        for (e in builtins()) list.add(e)
        for (k in pins) if (k.startsWith("p:")) all.firstOrNull { it.key == k }?.let { list.add(it) }
        val tints = intArrayOf(c(0xFF0063B1), c(0xFF8764B8), c(0xFF038387), c(0xFFCA5010), c(0xFF107C10), c(0xFF744DA9), c(0xFF0078D4), c(0xFFB146C2))
        list.forEachIndexed { i, e ->
            val t = LinearLayout(act)
            t.orientation = LinearLayout.VERTICAL
            t.setPadding(dp(8), dp(8), dp(6), dp(6))
            t.isClickable = true
            t.background = Ui.stateBg(dp(2).toFloat(), tints[i % tints.size], c(0xFF4F8FD0), c(0xFF2A6BA8), c(0xFF4F8FD0))
            if (e.icon != null) {
                val iv = ImageView(act)
                iv.setImageDrawable(e.icon)
                t.addView(iv, lp(dp(34), dp(34)))
            } else {
                t.addView(context.label(e.emoji ?: "", 28f), lp(WRAP, dp(40)))
            }
            val sp = View(act)
            t.addView(sp, lp(1, 0, 1f))
            val l = context.label(e.label, 11f)
            l.setSingleLine()
            l.ellipsize = android.text.TextUtils.TruncateAt.END
            t.addView(l, lp(MATCH, WRAP))
            t.setOnClickListener {
                close()
                e.action()
            }
            t.setOnLongClickListener { entryMenu(e); true }
            t.setOnContextClickListener { entryMenu(e); true }
            t.hand()
            val g = GridLayout.LayoutParams()
            g.width = dp(96)
            g.height = dp(96)
            g.setMargins(dp(3), dp(3), dp(3), dp(3))
            tiles.addView(t, g)
        }
    }

    fun open() {
        act.quick.close()
        val par = parent as View
        val lpn = panel.layoutParams as FrameLayout.LayoutParams
        val wide = par.width >= dp(700)
        tileCol.visibility = if (wide) View.VISIBLE else View.GONE
        lpn.width = if (wide) dp(652) else minOf(dp(322), par.width - dp(16))
        lpn.height = minOf(dp(500), par.height - dp(48) - dp(16))
        lpn.leftMargin = dp(8)
        lpn.bottomMargin = dp(8)
        panel.layoutParams = lpn
        loadApps()
        search.setText("")
        rebuild("")
        rebuildTiles()
        visibility = View.VISIBLE
        isOpen = true
        panel.alpha = 0f
        panel.translationY = dp(36).toFloat()
        panel.animate().alpha(1f).translationY(0f).setDuration(170).start()
        search.requestFocus()
        act.onStartToggled()
    }

    fun focusSearch2() {
        search.requestFocus()
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    fun close() {
        if (!isOpen) return
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
        visibility = View.GONE
        isOpen = false
        act.onStartToggled()
    }
}
