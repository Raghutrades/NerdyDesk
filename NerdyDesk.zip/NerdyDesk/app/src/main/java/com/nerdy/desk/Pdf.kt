package com.nerdy.desk

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

class PdfApp(act: MainActivity, private val arg: String?) : App(act) {
    override val title = "PDF Reader"
    override val icon = "\uD83D\uDCD5"

    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var sizes: List<IntArray> = emptyList()
    private val lock = Any()
    private val exec = Executors.newSingleThreadExecutor()
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 5).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private var zoom = 1f
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var list: ListView
    private lateinit var hs: HorizontalScrollView
    private lateinit var pageTv: TextView
    private lateinit var zoomTv: TextView
    private lateinit var msg: LinearLayout
    private lateinit var msgText: TextView
    private var closed = false

    private fun baseWidth(): Int = maxOf(act.dp(360), hs.width - act.dp(24))

    private val adapter = object : BaseAdapter() {
        override fun getCount() = sizes.size
        override fun getItem(position: Int): Any = position
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val box = (convertView as? FrameLayout) ?: FrameLayout(act)
            box.removeAllViews()
            val w = (baseWidth() * zoom).toInt()
            val s = sizes[position]
            val h = (w.toLong() * s[1] / maxOf(1, s[0])).toInt()
            box.layoutParams = AbsListView.LayoutParams(w + act.dp(24), h + act.dp(12))
            val iv = ImageView(act)
            iv.setBackgroundColor(Color.WHITE)
            iv.scaleType = ImageView.ScaleType.FIT_XY
            box.addView(iv, FrameLayout.LayoutParams(w, h, Gravity.CENTER_HORIZONTAL).also { it.topMargin = act.dp(6) })
            val key = "$position@$w"
            iv.tag = key
            val hit = cache.get(key)
            if (hit != null) iv.setImageBitmap(hit) else {
                exec.execute {
                    if (closed) return@execute
                    val b = render(position, w, h)
                    if (b != null) {
                        cache.put(key, b)
                        ui.post { if (iv.tag == key) iv.setImageBitmap(b) }
                    }
                }
            }
            return box
        }
    }

    private fun render(i: Int, w: Int, h: Int): Bitmap? {
        synchronized(lock) {
            val r = renderer ?: return null
            return try {
                val page = r.openPage(i)
                val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                b.eraseColor(Color.WHITE)
                page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                b
            } catch (e: Throwable) {
                null
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c(0xFF3A3A3A))
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(c(0xFF2B2B2B))
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        fun b(label: String, a: () -> Unit) {
            bar.addView(Ui.button(act, label, a), lp(WRAP, WRAP).also { it.rightMargin = act.dp(4) })
        }
        b("\u2212") { setZoom(zoom / 1.25f) }
        zoomTv = act.label("100%", 12f)
        zoomTv.setPadding(act.dp(4), 0, act.dp(8), 0)
        bar.addView(zoomTv)
        b("+") { setZoom(zoom * 1.25f) }
        b("Fit width") { setZoom(1f) }
        val go = EditText(act)
        go.setSingleLine()
        go.hint = "Page"
        go.textSize = 12f
        go.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        go.setTextColor(Ui.text)
        go.setHintTextColor(Ui.textDim)
        go.background = Ui.rect(c(0xFF1B1B1B), act.dp(6).toFloat())
        go.setPadding(act.dp(8), 0, act.dp(8), 0)
        go.imeOptions = EditorInfo.IME_ACTION_GO
        go.setOnEditorActionListener { v, _, _ ->
            val n = v.text.toString().toIntOrNull()
            if (n != null && n in 1..sizes.size) list.setSelection(n - 1)
            true
        }
        bar.addView(go, lp(act.dp(64), act.dp(30)))
        pageTv = act.label("", 12f, Ui.textDim)
        pageTv.setPadding(act.dp(10), 0, 0, 0)
        bar.addView(pageTv, lp(0, WRAP, 1f))
        b("Open elsewhere") { arg?.let { act.openExternal(File(it)) } }
        root.addView(bar, lp(MATCH, WRAP))

        val frame = FrameLayout(act)
        hs = HorizontalScrollView(act)
        list = ListView(act)
        list.divider = null
        list.adapter = adapter
        list.setBackgroundColor(0)
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, s: Int) {}
            override fun onScroll(v: AbsListView?, first: Int, vis: Int, total: Int) {
                if (sizes.isNotEmpty()) pageTv.text = "Page ${first + 1} of ${sizes.size}"
            }
        })
        list.setOnGenericMotionListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_SCROLL && (ev.metaState and KeyEvent.META_CTRL_ON) != 0) {
                setZoom(if (ev.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0) zoom * 1.12f else zoom / 1.12f)
                true
            } else false
        }
        hs.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(hs, FrameLayout.LayoutParams(MATCH, MATCH))
        msg = LinearLayout(act)
        msg.orientation = LinearLayout.VERTICAL
        msg.gravity = Gravity.CENTER
        msgText = act.label("Open a PDF from File Explorer to read it here.", 14f, Ui.textDim)
        msgText.gravity = Gravity.CENTER
        msg.addView(msgText)
        msg.addView(Ui.button(act, "\uD83D\uDCC1 Browse files") { act.open(AppKind.FILES, "/storage/emulated/0/Documents") }, lp(WRAP, WRAP).also { it.topMargin = act.dp(12) })
        frame.addView(msg, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(frame, lp(MATCH, 0, 1f))

        frame.post { if (arg != null) openFile(File(arg)) }
        return root
    }

    private fun openFile(f: File) {
        if (!f.exists()) {
            msgText.text = "File not found."
            return
        }
        try {
            val p = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            pfd = p
            renderer = PdfRenderer(p)
        } catch (e: SecurityException) {
            msgText.text = "This PDF is password protected and can't be opened here."
            return
        } catch (e: Exception) {
            msgText.text = "Couldn't open this PDF."
            return
        }
        msg.visibility = View.GONE
        window?.setTitle(f.name + " - PDF Reader")
        Thread {
            val out = ArrayList<IntArray>()
            synchronized(lock) {
                val r = renderer ?: return@Thread
                for (i in 0 until r.pageCount) {
                    try {
                        val pg = r.openPage(i)
                        out.add(intArrayOf(pg.width, pg.height))
                        pg.close()
                    } catch (e: Exception) {
                        out.add(intArrayOf(595, 842))
                    }
                }
            }
            act.runOnUiThread {
                if (closed) return@runOnUiThread
                sizes = out
                applyWidth()
                adapter.notifyDataSetChanged()
                pageTv.text = "Page 1 of ${out.size}"
            }
        }.start()
    }

    private fun applyWidth() {
        val lpn = list.layoutParams as FrameLayout.LayoutParams
        lpn.width = ((baseWidth() * zoom).toInt() + act.dp(24)).coerceAtLeast(hs.width)
        lpn.height = MATCH
        list.layoutParams = lpn
    }

    private fun setZoom(z: Float) {
        zoom = z.coerceIn(0.5f, 3f)
        zoomTv.text = (zoom * 100).toInt().toString() + "%"
        applyWidth()
        adapter.notifyDataSetChanged()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (act.currentFocus is EditText) return false
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS, KeyEvent.KEYCODE_NUMPAD_ADD -> { setZoom(zoom * 1.25f); return true }
                KeyEvent.KEYCODE_MINUS, KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> { setZoom(zoom / 1.25f); return true }
                KeyEvent.KEYCODE_0 -> { setZoom(1f); return true }
            }
        }
        when (e.keyCode) {
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_SPACE -> { list.smoothScrollBy(list.height - act.dp(40), 200); return true }
            KeyEvent.KEYCODE_PAGE_UP -> { list.smoothScrollBy(-(list.height - act.dp(40)), 200); return true }
            KeyEvent.KEYCODE_MOVE_HOME -> { list.setSelection(0); return true }
            KeyEvent.KEYCODE_MOVE_END -> { list.setSelection(maxOf(0, sizes.size - 1)); return true }
        }
        return false
    }

    override fun onClose() {
        closed = true
        exec.shutdown()
        synchronized(lock) {
            try {
                renderer?.close()
                pfd?.close()
            } catch (e: Exception) {
            }
            renderer = null
        }
    }
}
