package com.nerdy.desk

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.PI
import kotlin.math.E

/** Small recursive-descent expression evaluator: + - * / ^ % ! ( ) and sin cos tan asin acos atan ln log sqrt abs pi e. */
object CalcEngine {
    private class P(val s: String, var i: Int = 0)

    fun eval(expr: String): Double? {
        return try {
            val p = P(expr.replace("\u00D7", "*").replace("\u00F7", "/").replace("\u2212", "-").replace(" ", "").lowercase(Locale.ROOT))
            if (p.s.isEmpty()) return null
            val v = parseExpr(p)
            if (p.i != p.s.length) null else if (v.isNaN()) null else v
        } catch (e: Exception) {
            null
        }
    }

    fun fmt(v: Double): String {
        if (v.isInfinite()) return if (v > 0) "\u221E" else "-\u221E"
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        var t = String.format(Locale.US, "%.10g", v)
        if (t.contains("e")) return String.format(Locale.US, "%.8e", v)
        if (t.contains(".")) t = t.trimEnd('0').trimEnd('.')
        return t
    }

    private fun parseExpr(p: P): Double {
        var v = parseTerm(p)
        while (p.i < p.s.length) {
            val c = p.s[p.i]
            if (c == '+') { p.i++; v += parseTerm(p) } else if (c == '-') { p.i++; v -= parseTerm(p) } else break
        }
        return v
    }

    private fun parseTerm(p: P): Double {
        var v = parsePow(p)
        while (p.i < p.s.length) {
            val c = p.s[p.i]
            if (c == '*') { p.i++; v *= parsePow(p) }
            else if (c == '/') { p.i++; v /= parsePow(p) }
            else if (c == '%') { p.i++; v %= parsePow(p) }
            else if (c == '(' || c.isLetter()) { v *= parsePow(p) } // implicit multiply: 2(3), 2pi
            else break
        }
        return v
    }

    private fun parsePow(p: P): Double {
        val base = parseUnary(p)
        if (p.i < p.s.length && p.s[p.i] == '^') {
            p.i++
            return Math.pow(base, parsePow(p))
        }
        return base
    }

    private fun parseUnary(p: P): Double {
        if (p.i < p.s.length && p.s[p.i] == '-') { p.i++; return -parseUnary(p) }
        if (p.i < p.s.length && p.s[p.i] == '+') { p.i++; return parseUnary(p) }
        return parsePostfix(p)
    }

    private fun parsePostfix(p: P): Double {
        var v = parseAtom(p)
        while (p.i < p.s.length && p.s[p.i] == '!') {
            p.i++
            var r = 1.0
            val n = v.toInt()
            if (n < 0 || n > 170) return Double.NaN
            for (k in 2..n) r *= k
            v = r
        }
        return v
    }

    private fun parseAtom(p: P): Double {
        if (p.i >= p.s.length) throw IllegalStateException()
        val c = p.s[p.i]
        if (c == '(') {
            p.i++
            val v = parseExpr(p)
            if (p.i >= p.s.length || p.s[p.i] != ')') throw IllegalStateException()
            p.i++
            return v
        }
        if (c.isDigit() || c == '.') {
            val st = p.i
            while (p.i < p.s.length && (p.s[p.i].isDigit() || p.s[p.i] == '.')) p.i++
            return p.s.substring(st, p.i).toDouble()
        }
        if (c.isLetter()) {
            val st = p.i
            while (p.i < p.s.length && p.s[p.i].isLetter()) p.i++
            val name = p.s.substring(st, p.i)
            if (name == "pi") return PI
            if (name == "e") return E
            val arg = parseAtom(p)
            return when (name) {
                "sin" -> Math.sin(Math.toRadians(arg))
                "cos" -> Math.cos(Math.toRadians(arg))
                "tan" -> Math.tan(Math.toRadians(arg))
                "asin" -> Math.toDegrees(Math.asin(arg))
                "acos" -> Math.toDegrees(Math.acos(arg))
                "atan" -> Math.toDegrees(Math.atan(arg))
                "ln" -> Math.log(arg)
                "log" -> Math.log10(arg)
                "sqrt" -> Math.sqrt(arg)
                "abs" -> Math.abs(arg)
                else -> throw IllegalStateException()
            }
        }
        throw IllegalStateException()
    }
}

class CalcApp(act: MainActivity) : App(act) {
    override val title = "Calculator"
    override val icon = "\uD83E\uDDEE"
    private val sb = StringBuilder()
    private lateinit var disp: TextView
    private lateinit var result: TextView
    private lateinit var hist: LinearLayout
    private lateinit var histScroll: ScrollView
    private var sci = false
    private lateinit var keys: GridLayout

    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c(0xFF1C1C1C))
        root.isFocusableInTouchMode = true
        root.setOnKeyListener { _, code, ev ->
            if (ev.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            val ch = ev.unicodeChar.toChar()
            when {
                code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER || ch == '=' -> { equals(); true }
                code == KeyEvent.KEYCODE_DEL -> { back(); true }
                code == KeyEvent.KEYCODE_ESCAPE -> { clear(); true }
                ch.isDigit() || ch in "+-*/().^%!" -> { add(ch.toString()); true }
                else -> false
            }
        }
        val top = LinearLayout(act)
        top.orientation = LinearLayout.VERTICAL
        top.setPadding(act.dp(14), act.dp(8), act.dp(14), act.dp(4))
        hist = LinearLayout(act)
        hist.orientation = LinearLayout.VERTICAL
        histScroll = ScrollView(act)
        histScroll.addView(hist, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        top.addView(histScroll, lp(MATCH, act.dp(60)))
        disp = act.label("", 20f, Ui.textDim)
        disp.gravity = Gravity.END
        disp.setSingleLine()
        top.addView(disp, lp(MATCH, WRAP))
        result = act.label("0", 40f, Ui.text)
        result.gravity = Gravity.END
        result.setSingleLine()
        top.addView(result, lp(MATCH, WRAP))
        root.addView(top, lp(MATCH, WRAP))

        keys = GridLayout(act)
        root.addView(keys, lp(MATCH, 0, 1f))
        layoutKeys()
        root.post { root.requestFocus() }
        return root
    }

    private fun layoutKeys() {
        keys.removeAllViews()
        val std = listOf(
            "C", "(", ")", "\u232B",
            "7", "8", "9", "\u00F7",
            "4", "5", "6", "\u00D7",
            "1", "2", "3", "\u2212",
            "0", ".", "=", "+"
        )
        val scf = listOf("sin(", "cos(", "tan(", "ln(", "log(", "\u221A(", "^", "!", "\u03C0", "e", "%", "SCI")
        keys.columnCount = if (sci) 4 else 4
        val all = ArrayList<String>()
        if (sci) all.addAll(scf)
        all.addAll(std)
        if (!sci) all.add("SCI")
        keys.rowCount = (all.size + 3) / 4
        for (k in all) {
            val isOp = k in listOf("\u00F7", "\u00D7", "\u2212", "+", "=")
            val b = TextView(act)
            b.text = k
            b.textSize = 18f
            b.gravity = Gravity.CENTER
            b.setTextColor(Ui.text)
            b.isClickable = true
            val base = if (k == "=") Ui.accent else if (isOp) c(0xFF3A3A3A) else if (k[0].isDigit() || k == ".") c(0xFF2D2D2D) else c(0xFF262626)
            b.background = Ui.stateBg(act.dp(4).toFloat(), base, c(0xFF4A4A4A), c(0xFF5A5A5A), base)
            b.setOnClickListener { press(k) }
            b.hand()
            val g = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            g.width = 0
            g.height = 0
            g.setMargins(act.dp(2), act.dp(2), act.dp(2), act.dp(2))
            keys.addView(b, g)
        }
    }

    private fun press(k: String) {
        when (k) {
            "C" -> clear()
            "\u232B" -> back()
            "=" -> equals()
            "SCI" -> { sci = !sci; layoutKeys() }
            "\u221A(" -> add("sqrt(")
            "\u03C0" -> add("pi")
            "\u00F7" -> add("/")
            "\u00D7" -> add("*")
            "\u2212" -> add("-")
            else -> add(k)
        }
    }

    private fun add(s: String) {
        sb.append(s)
        refresh()
    }

    private fun back() {
        if (sb.isNotEmpty()) sb.setLength(sb.length - 1)
        refresh()
    }

    private fun clear() {
        sb.setLength(0)
        refresh()
    }

    private fun equals() {
        val v = CalcEngine.eval(sb.toString())
        if (v == null) {
            result.text = "Error"
            return
        }
        val line = act.label(sb.toString() + " = " + CalcEngine.fmt(v), 12f, Ui.textDim)
        line.gravity = Gravity.END
        line.isClickable = true
        line.setOnClickListener { sb.setLength(0); sb.append(CalcEngine.fmt(v)); refresh() }
        hist.addView(line)
        histScroll.post { histScroll.fullScroll(View.FOCUS_DOWN) }
        sb.setLength(0)
        sb.append(CalcEngine.fmt(v))
        disp.text = ""
        result.text = CalcEngine.fmt(v)
    }

    private fun refresh() {
        disp.text = sb.toString()
        val v = CalcEngine.eval(sb.toString())
        result.text = if (sb.isEmpty()) "0" else if (v != null) CalcEngine.fmt(v) else result.text
    }
}
