package com.nerdy.desk

import android.app.ActivityManager
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.os.BatteryManager
import android.os.Debug
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.content.res.ColorStateList

class TaskMgrApp(act: MainActivity) : App(act) {
    override val title = "Task Manager"
    override val icon = "\uD83D\uDCCA"
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var col: LinearLayout
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            fill()
            handler.postDelayed(this, 2000)
        }
    }

    override fun build(): View {
        val sv = ScrollView(act)
        sv.setBackgroundColor(Ui.bgDark)
        col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(16))
        sv.addView(col, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        running = true
        fill()
        handler.postDelayed(tick, 2000)
        return sv
    }

    private fun bar(name: String, pct: Int, detail: String): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, act.dp(6), 0, act.dp(6))
        val top = LinearLayout(act)
        top.addView(act.label(name, 13f), lp(0, WRAP, 1f))
        top.addView(act.label(detail, 12f, Ui.textDim))
        box.addView(top)
        val pb = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        pb.progress = pct.coerceIn(0, 100)
        pb.progressTintList = ColorStateList.valueOf(if (pct > 85) c(0xFFE81123) else Ui.accent)
        box.addView(pb, lp(MATCH, act.dp(6)))
        return box
    }

    private fun fill() {
        col.removeAllViews()
        col.addView(act.label("Performance", 17f))
        val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedMem = mi.totalMem - mi.availMem
        col.addView(bar("Memory (phone)", (usedMem * 100 / maxOf(1L, mi.totalMem)).toInt(), Files.humanSize(usedMem) + " / " + Files.humanSize(mi.totalMem)))
        val pm = Debug.MemoryInfo()
        Debug.getMemoryInfo(pm)
        col.addView(act.label("NerdyDesk itself: " + Files.humanSize(pm.totalPss * 1024L), 12f, Ui.textDim))
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            col.addView(bar("Storage", ((total - free) * 100 / maxOf(1L, total)).toInt(), Files.humanSize(total - free) + " used of " + Files.humanSize(total)))
        } catch (e: Exception) {
        }
        val b = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (lvl >= 0 && sc > 0) col.addView(bar("Battery", lvl * 100 / sc, "$temp\u00B0C"))
        col.addView(act.label("Up since boot: " + Files.fmtTime(SystemClock.elapsedRealtime()), 12f, Ui.textDim))

        val h = act.label("Open windows", 17f)
        h.setPadding(0, act.dp(18), 0, act.dp(4))
        col.addView(h)
        if (act.windows.isEmpty()) col.addView(act.label("Nothing is open.", 13f, Ui.textDim))
        for (w in act.windows.toList().reversed()) {
            val r = LinearLayout(act)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
            r.addView(act.label(w.kind.icon, 16f), lp(act.dp(30), WRAP))
            val t = act.label(w.app.title + if (w.minimized) "  (minimised)" else "", 13f)
            t.setSingleLine()
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            r.addView(t, lp(0, WRAP, 1f))
            r.addView(Ui.button(act, "Switch") { act.focusWindow(w) }, lp(WRAP, WRAP))
            val lend = lp(WRAP, WRAP)
            lend.leftMargin = act.dp(6)
            r.addView(Ui.button(act, "End task") { act.closeWindow(w); fill() }, lend)
            col.addView(r)
        }
    }

    override fun onClose() {
        running = false
        handler.removeCallbacks(tick)
    }
}
