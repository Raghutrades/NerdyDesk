package com.nerdy.desk

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsApp(act: MainActivity) : App(act) {
    override val title = "Settings"
    override val icon = "\u2699\uFE0F"

    override fun build(): View {
        val sv = ScrollView(act)
        sv.setBackgroundColor(Ui.bgDark)
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(act.dp(18), act.dp(14), act.dp(18), act.dp(18))
        sv.addView(col, lp(MATCH, WRAP))

        col.addView(header("Personalization"))
        col.addView(label("Background"))
        val wr = LinearLayout(act)
        wr.orientation = LinearLayout.HORIZONTAL
        Ui.wallpapers.forEachIndexed { i, cols ->
            val sw = View(act)
            sw.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
                cornerRadius = act.dp(6).toFloat()
            }
            sw.isClickable = true
            sw.setOnClickListener { act.setWallpaper(i) }
            sw.hand()
            val l = lp(act.dp(64), act.dp(40))
            l.setMargins(0, act.dp(6), act.dp(8), act.dp(6))
            wr.addView(sw, l)
        }
        col.addView(wr)
        col.addView(label("Accent colour"))
        val ar = LinearLayout(act)
        ar.orientation = LinearLayout.HORIZONTAL
        Ui.accents.forEachIndexed { i, colr ->
            val sw = View(act)
            sw.background = Ui.rect(colr, act.dp(6).toFloat())
            sw.isClickable = true
            sw.setOnClickListener { act.setAccent(i) }
            sw.hand()
            val l = lp(act.dp(40), act.dp(40))
            l.setMargins(0, act.dp(6), act.dp(8), act.dp(6))
            ar.addView(sw, l)
        }
        col.addView(ar)

        col.addView(header("Display"))
        col.addView(toggle("Hide status bar (full screen)", "fullscreen", true))
        col.addView(toggle("24-hour clock", "clock24", false))

        col.addView(header("System"))
        col.addView(Ui.button(act, "Set NerdyDesk as my home app") {
            act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS))
        }, rowLp())
        col.addView(Ui.button(act, "Allow access to all files") {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                act.startSafely(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + act.packageName)
                    )
                )
            }
        }, rowLp())
        val grid = LinearLayout(act)
        grid.orientation = LinearLayout.HORIZONTAL
        grid.addView(Ui.button(act, "Wi\u2011Fi") { act.startSafely(Intent(Settings.ACTION_WIFI_SETTINGS)) }, rowLp())
        grid.addView(Ui.button(act, "Bluetooth") { act.startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, rowLp())
        grid.addView(Ui.button(act, "Display") { act.startSafely(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }, rowLp())
        grid.addView(Ui.button(act, "Sound") { act.startSafely(Intent(Settings.ACTION_SOUND_SETTINGS)) }, rowLp())
        grid.addView(Ui.button(act, "Android settings") { act.startSafely(Intent(Settings.ACTION_SETTINGS)) }, rowLp())
        col.addView(grid)

        col.addView(header("Keyboard & mouse shortcuts"))
        col.addView(
            label(
                "Win key \u2013 Start menu\nWin+E \u2013 File Explorer\nWin+D \u2013 Show desktop\n" +
                    "Win+I \u2013 Settings\nAlt+F4 \u2013 Close window\nAlt+Tab \u2013 Next window\n" +
                    "Browser: Ctrl+T new tab, Ctrl+W close tab, Ctrl+L address bar, F5 reload\n" +
                    "Files: Ctrl+C / X / V, Del, F2 rename, Enter open, Backspace up\n" +
                    "Notepad: Ctrl+S save\n" +
                    "Mouse: double-click opens icons, right-click for menus, drag title bars"
            )
        )
        col.addView(header("About"))
        col.addView(label("NerdyDesk 1.0 \u2013 a Windows-style desktop for Android."))
        return sv
    }

    private fun rowLp(): LinearLayout.LayoutParams {
        val l = lp(WRAP, WRAP)
        l.setMargins(0, act.dp(4), act.dp(8), act.dp(4))
        return l
    }

    private fun header(t: String): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = 17f
        v.setTextColor(Ui.text)
        v.setPadding(0, act.dp(18), 0, act.dp(4))
        return v
    }

    private fun label(t: String): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = 13f
        v.setTextColor(Ui.textDim)
        v.setPadding(0, act.dp(4), 0, act.dp(2))
        return v
    }

    private fun toggle(text: String, key: String, def: Boolean): Switch {
        val s = Switch(act)
        s.text = text
        s.textSize = 14f
        s.setTextColor(Ui.text)
        s.gravity = Gravity.CENTER_VERTICAL
        s.setPadding(0, act.dp(6), 0, act.dp(6))
        s.isChecked = act.prefs.getBoolean(key, def)
        s.setOnCheckedChangeListener { _, v ->
            act.prefs.edit().putBoolean(key, v).apply()
            act.applyDisplayPrefs()
        }
        return s
    }
}
