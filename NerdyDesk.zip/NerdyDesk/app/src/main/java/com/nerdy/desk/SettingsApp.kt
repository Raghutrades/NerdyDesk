package com.nerdy.desk

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsApp(act: MainActivity, private val startSection: String?) : App(act) {
    override val title = "Settings"
    override val icon = "\u2699\uFE0F"

    private val sections = listOf(
        "personalize" to "\uD83C\uDFA8  Personalization",
        "display" to "\uD83D\uDDA5\uFE0F  Display",
        "apps" to "\uD83D\uDCF1  Windows & apps",
        "system" to "\uD83D\uDD27  System",
        "keys" to "\u2328\uFE0F  Shortcuts",
        "about" to "\u2139\uFE0F  About"
    )
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var side: LinearLayout
    private var current = "personalize"

    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.bgDark)
        side = LinearLayout(act)
        side.orientation = LinearLayout.VERTICAL
        side.setBackgroundColor(c(0xFF191919))
        side.setPadding(act.dp(6), act.dp(10), act.dp(6), act.dp(6))
        root.addView(side, lp(act.dp(190), MATCH))
        scroll = ScrollView(act)
        content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(act.dp(20), act.dp(14), act.dp(20), act.dp(20))
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, lp(0, MATCH, 1f))
        goto(startSection ?: "personalize")
        return root
    }

    override fun handleArg(arg: String?) {
        if (arg != null) goto(arg)
    }

    private fun goto(key: String) {
        current = if (sections.any { it.first == key }) key else "personalize"
        side.removeAllViews()
        for ((k, label) in sections) {
            val t = act.label(label, 13f)
            t.setPadding(act.dp(12), act.dp(10), act.dp(8), act.dp(10))
            t.isClickable = true
            t.background = Ui.stateBg(act.dp(6).toFloat(), if (k == current) c(0x33FFFFFF) else 0)
            t.setOnClickListener { goto(k) }
            t.hand()
            side.addView(t, lp(MATCH, WRAP))
        }
        content.removeAllViews()
        when (current) {
            "personalize" -> personalize()
            "display" -> display()
            "apps" -> apps()
            "system" -> system()
            "keys" -> keys()
            else -> about()
        }
        scroll.scrollTo(0, 0)
    }

    private fun h(t: String): TextView {
        val v = act.label(t, 20f)
        v.setPadding(0, act.dp(2), 0, act.dp(10))
        return v
    }

    private fun sub(t: String): TextView {
        val v = act.label(t, 13f, Ui.textDim)
        v.setPadding(0, act.dp(12), 0, act.dp(4))
        return v
    }

    private fun note(t: String): TextView {
        val v = act.label(t, 13f, Ui.textDim)
        v.setPadding(0, act.dp(4), 0, act.dp(4))
        return v
    }

    private fun rowLp(): LinearLayout.LayoutParams {
        val l = lp(WRAP, WRAP)
        l.setMargins(0, act.dp(4), act.dp(8), act.dp(4))
        return l
    }

    private fun swatch(bg: android.graphics.drawable.Drawable, label: String?, w: Int, onClick: () -> Unit): View {
        val box = FrameLayout(act)
        box.background = bg
        box.isClickable = true
        box.setOnClickListener { onClick() }
        box.hand()
        if (label != null) {
            val t = act.label(label, 11f)
            t.gravity = Gravity.CENTER
            box.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        val l = lp(act.dp(w), act.dp(42))
        l.setMargins(0, act.dp(4), act.dp(8), act.dp(4))
        box.layoutParams = l
        return box
    }

    private fun toggle(text: String, key: String, def: Boolean, after: () -> Unit = {}): Switch {
        val s = Switch(act)
        s.text = text
        s.textSize = 14f
        s.setTextColor(Ui.text)
        s.gravity = Gravity.CENTER_VERTICAL
        s.setPadding(0, act.dp(8), 0, act.dp(8))
        s.isChecked = act.prefs.getBoolean(key, def)
        s.setOnCheckedChangeListener { _, v ->
            act.prefs.edit().putBoolean(key, v).apply()
            after()
        }
        return s
    }

    private fun personalize() {
        content.addView(h("Personalization"))
        content.addView(sub("Background"))
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        Ui.wallpapers.forEachIndexed { i, cols ->
            val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols)
            d.cornerRadius = act.dp(6).toFloat()
            r.addView(swatch(d, null, 62) { act.setWallpaper(i) })
        }
        content.addView(r)
        val r2 = LinearLayout(act)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(swatch(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c(0xFF050A18), c(0xFF7C3AED), c(0xFF20D8A8))).also { it.cornerRadius = act.dp(6).toFloat() }, "Aurora (live)", 120) { act.setWallpaper(101) })
        r2.addView(swatch(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c(0xFF02040C), c(0xFF1B2A55))).also { it.cornerRadius = act.dp(6).toFloat() }, "Starfield (live)", 120) { act.setWallpaper(102) })
        content.addView(r2)
        content.addView(Ui.button(act, "Choose your own picture\u2026") { act.pickWallpaper() }, rowLp())
        content.addView(sub("Accent colour"))
        val ar = LinearLayout(act)
        ar.orientation = LinearLayout.HORIZONTAL
        Ui.accents.forEachIndexed { i, colr ->
            ar.addView(swatch(Ui.rect(colr, act.dp(6).toFloat()), null, 42) { act.setAccent(i) })
        }
        content.addView(ar)
        content.addView(sub("Start-up"))
        content.addView(toggle("Boot animation when NerdyDesk starts", "boot", true))
        content.addView(toggle("Lock screen after boot", "lock", true))
        content.addView(toggle("Window animations", "anim", true))
        content.addView(toggle("24-hour clock", "clock24", false) { act.applyDisplayPrefs() })
        content.addView(Ui.button(act, "Replay boot animation") { act.restartDesktop() }, rowLp())
    }

    private fun display() {
        content.addView(h("Display"))
        content.addView(toggle("Hide the status bar (full-screen desktop)", "fullscreen", true) { act.applyDisplayPrefs() })
        content.addView(toggle("Night light (warm tint)", "night", false) { act.setNightLight(act.prefs.getBoolean("night", false)) })
        content.addView(note("Brightness and volume sliders are in the action centre (click the clock)."))
        content.addView(sub("Using a monitor"))
        content.addView(note("Plug in a monitor with USB-C/HDMI, or cast wirelessly. The desktop fills whatever screen it is on, and a mouse or keyboard works straight away."))
        content.addView(Ui.button(act, "Screen cast / external display settings") { act.startSafely(Intent(Settings.ACTION_CAST_SETTINGS)) }, rowLp())
        content.addView(Ui.button(act, "Android display settings") { act.startSafely(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }, rowLp())
    }

    private fun apps() {
        content.addView(h("Windows & apps"))
        content.addView(toggle("Open other phone apps in windows", "freeform", true))
        content.addView(note(act.freeformStatus()))
        content.addView(sub("How to get real app windows"))
        content.addView(
            note(
                "Android only lets the system put other apps in resizable windows. NerdyDesk's own apps (browser, files, photos, video, music, PDF, notes, habit tracker) always run as windows. " +
                    "To make apps like WhatsApp or Chrome open as windows too:\n\n" +
                    "1. Settings \u2192 About phone \u2192 tap Build number 7 times.\n" +
                    "2. Settings \u2192 Developer options \u2192 turn on \u201CEnable freeform windows\u201D and \u201CForce activities to be resizable\u201D.\n" +
                    "3. Restart the phone, then open apps from the start menu.\n\n" +
                    "If those options are missing, connect with wireless debugging and run:\n" +
                    "adb shell settings put global enable_freeform_support 1\n" +
                    "adb shell settings put global force_resizable_activities 1\n\n" +
                    "Some phones (Samsung DeX, Android desktop mode) already do this when a monitor is attached."
            )
        )
        content.addView(Ui.button(act, "Open Developer options") { if (!act.startSafely(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) act.toast("Enable Developer options first") }, rowLp())
        content.addView(sub("Taskbar & desktop"))
        content.addView(note("Right-click (or long-press) any app in the start menu to pin it to the taskbar or desktop."))
        content.addView(Ui.button(act, "Reset taskbar and desktop icons") { act.resetPins() }, rowLp())
    }

    private fun system() {
        content.addView(h("System"))
        content.addView(note(if (act.hasAllFiles()) "File access: allowed" else "File access: not allowed yet (needed for File Explorer, Photos, Music, Video)"))
        content.addView(Ui.button(act, "Allow access to files & media") { act.requestStorage() }, rowLp())
        content.addView(Ui.button(act, "Set NerdyDesk as my home app") { act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS)) }, rowLp())
        content.addView(sub("Android settings"))
        val g = LinearLayout(act)
        g.orientation = LinearLayout.HORIZONTAL
        g.addView(Ui.button(act, "Wi\u2011Fi") { act.startSafely(Intent(Settings.ACTION_WIFI_SETTINGS)) }, rowLp())
        g.addView(Ui.button(act, "Bluetooth") { act.startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, rowLp())
        g.addView(Ui.button(act, "Sound") { act.startSafely(Intent(Settings.ACTION_SOUND_SETTINGS)) }, rowLp())
        content.addView(g)
        val g2 = LinearLayout(act)
        g2.orientation = LinearLayout.HORIZONTAL
        g2.addView(Ui.button(act, "Apps") { act.startSafely(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }, rowLp())
        g2.addView(Ui.button(act, "Battery") { act.startSafely(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }, rowLp())
        g2.addView(Ui.button(act, "All settings") { act.startSafely(Intent(Settings.ACTION_SETTINGS)) }, rowLp())
        content.addView(g2)
    }

    private fun keys() {
        content.addView(h("Keyboard & mouse shortcuts"))
        content.addView(
            note(
                "Desktop\n" +
                    "Win \u2013 Start menu         Win+S \u2013 Search\n" +
                    "Win+E \u2013 File Explorer     Win+I \u2013 Settings\n" +
                    "Win+D / Win+M \u2013 Show desktop\n" +
                    "Win+L \u2013 Lock             Win+Tab \u2013 Task view\n" +
                    "Alt+Tab \u2013 Switch windows   Alt+F4 \u2013 Close window\n" +
                    "Win+\u2190 / \u2192 \u2013 Snap left / right   Win+\u2191 \u2013 Maximise   Win+\u2193 \u2013 Restore / minimise\n" +
                    "Ctrl+Shift+Esc \u2013 Task Manager\n\n" +
                    "Windows\n" +
                    "Drag a title bar to an edge to snap; to a corner for quarter snap; to the top to maximise.\n" +
                    "Double-click a title bar to maximise. Right-click it for the window menu.\n\n" +
                    "Browser\n" +
                    "Ctrl+T / W / Shift+T \u2013 new / close / reopen tab    Ctrl+Shift+N \u2013 private tab\n" +
                    "Ctrl+L \u2013 address bar   Ctrl+F \u2013 find   Ctrl+D \u2013 bookmark   Ctrl+H \u2013 history   Ctrl+J \u2013 downloads\n" +
                    "Ctrl+Tab, Ctrl+1\u20139 \u2013 switch tabs   Ctrl +/\u2212/0 or Ctrl+scroll \u2013 zoom   F5 \u2013 reload\n\n" +
                    "Files\n" +
                    "Ctrl+A / C / X / V, Del, F2, Enter, Backspace, Alt+\u2190/\u2192/\u2191, Ctrl+click and Shift+click to select\n\n" +
                    "Video & music\n" +
                    "Space \u2013 play/pause   \u2190/\u2192 \u2013 seek   \u2191/\u2193 \u2013 volume   F \u2013 full screen   M \u2013 mute   N / P \u2013 next / previous"
            )
        )
    }

    private fun about() {
        content.addView(h("About"))
        content.addView(note("NerdyDesk 2.0\nA desktop PC experience for your Android phone.\n\nBuilt by Raghu \u2022 NerdyIntruder"))
        content.addView(Ui.button(act, "Restart desktop") { act.restartDesktop() }, rowLp())
    }
}
