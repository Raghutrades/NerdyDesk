package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class FileApp(act: MainActivity, startPath: String?) : App(act) {
    override val title = "File Explorer"
    override val icon = "\uD83D\uDCC1"

    private val root: File = Environment.getExternalStorageDirectory()
    private var dir: File = startPath?.let { File(it) }?.takeIf { it.isDirectory } ?: root
    private val back = ArrayList<File>()
    private val fwd = ArrayList<File>()
    private var all: List<File> = emptyList()
    private var items: List<File> = emptyList()
    private val sel = LinkedHashSet<File>()
    private var anchor: File? = null
    private var clip: List<File> = emptyList()
    private var clipCut = false
    private var showHidden = false
    private var grid = false
    private var sortKey = 0 // 0 name, 1 date, 2 size, 3 type
    private var sortAsc = true
    private var filter = ""
    private var searching = false
    private var denied = false
    private var selectMode = false
    private var lastTool = MotionEvent.TOOL_TYPE_FINGER
    private var lastMeta = 0
    private var lastClickAt = 0L
    private var lastClickFile: File? = null
    private val df = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    private lateinit var gridView: GridView
    private lateinit var pathBar: EditText
    private lateinit var status: TextView
    private lateinit var banner: LinearLayout
    private lateinit var cmdBar: LinearLayout
    private lateinit var storageBar: ProgressBar
    private lateinit var storageText: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val f = items[position]
            val row = if (grid) makeTile() else makeRow()
            bind(row, f)
            return row
        }
    }

    // ------------------------------------------------------------ UI

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        val rootView = LinearLayout(act)
        rootView.orientation = LinearLayout.VERTICAL
        rootView.setBackgroundColor(Ui.bgDark)

        val tb = LinearLayout(act)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.gravity = Gravity.CENTER_VERTICAL
        tb.setBackgroundColor(c(0xFF2B2B2B))
        tb.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        tb.addView(tool("\u2190") { goBack() }, lp(act.dp(32), act.dp(32)))
        tb.addView(tool("\u2192") { goForward() }, lp(act.dp(32), act.dp(32)))
        tb.addView(tool("\u2191") { goUp() }, lp(act.dp(32), act.dp(32)))
        tb.addView(tool("\u27F3") { load() }, lp(act.dp(32), act.dp(32)))
        pathBar = EditText(act)
        pathBar.setSingleLine()
        pathBar.textSize = 13f
        pathBar.setTextColor(Ui.text)
        pathBar.background = Ui.rect(c(0xFF1B1B1B), act.dp(6).toFloat())
        pathBar.setPadding(act.dp(10), 0, act.dp(10), 0)
        pathBar.imeOptions = EditorInfo.IME_ACTION_GO
        pathBar.setOnEditorActionListener { v, _, _ ->
            val f = File(v.text.toString().trim())
            if (f.isDirectory) navigate(f) else act.toast("Folder not found")
            true
        }
        tb.addView(pathBar, lp(0, act.dp(32), 1f).also { it.setMargins(act.dp(4), 0, act.dp(4), 0) })
        val search = EditText(act)
        search.setSingleLine()
        search.textSize = 13f
        search.hint = "Search"
        search.setTextColor(Ui.text)
        search.setHintTextColor(Ui.textDim)
        search.background = Ui.rect(c(0xFF1B1B1B), act.dp(6).toFloat())
        search.setPadding(act.dp(10), 0, act.dp(10), 0)
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filter = s?.toString()?.trim() ?: ""
                if (filter.isEmpty()) searching = false
                applyFilter()
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            if (filter.isNotEmpty()) deepSearch(filter)
            true
        }
        tb.addView(search, lp(act.dp(150), act.dp(32)))
        tb.addView(tool("\u21C5") { sortMenu(it) }, lp(act.dp(32), act.dp(32)))
        tb.addView(tool("\u25A6") { grid = !grid; setupGrid() }, lp(act.dp(32), act.dp(32)))
        rootView.addView(tb, lp(MATCH, WRAP))

        cmdBar = LinearLayout(act)
        cmdBar.orientation = LinearLayout.HORIZONTAL
        cmdBar.gravity = Gravity.CENTER_VERTICAL
        cmdBar.setBackgroundColor(c(0xFF242424))
        cmdBar.setPadding(act.dp(6), act.dp(2), act.dp(6), act.dp(2))
        rootView.addView(cmdBar, lp(MATCH, WRAP))

        banner = LinearLayout(act)
        banner.orientation = LinearLayout.HORIZONTAL
        banner.gravity = Gravity.CENTER_VERTICAL
        banner.setBackgroundColor(c(0xFF5A3A00))
        banner.setPadding(act.dp(10), act.dp(6), act.dp(10), act.dp(6))
        banner.addView(act.label("File access is off. Allow it to see your files.", 12f), lp(0, WRAP, 1f))
        banner.addView(Ui.button(act, "Allow") { act.requestStorage() }, lp(WRAP, WRAP))
        rootView.addView(banner, lp(MATCH, WRAP))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.HORIZONTAL
        val side = LinearLayout(act)
        side.orientation = LinearLayout.VERTICAL
        side.setBackgroundColor(c(0xFF191919))
        val sideScroll = ScrollView(act)
        val sideCol = LinearLayout(act)
        sideCol.orientation = LinearLayout.VERTICAL
        sideCol.setPadding(act.dp(4), act.dp(6), act.dp(4), act.dp(6))
        sideScroll.addView(sideCol, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        fun quick(label: String, f: File) {
            val t = act.label(label, 13f)
            t.setPadding(act.dp(10), act.dp(8), act.dp(6), act.dp(8))
            t.isClickable = true
            t.background = Ui.stateBg(act.dp(5).toFloat())
            t.setOnClickListener { navigate(f) }
            t.setOnLongClickListener { true }
            t.hand()
            sideCol.addView(t, lp(MATCH, WRAP))
        }
        quick("\uD83D\uDCBE  This PC", root)
        quick("\u2B07\uFE0F  Downloads", File(root, "Download"))
        quick("\uD83D\uDCC4  Documents", File(root, "Documents"))
        quick("\uD83D\uDDBC\uFE0F  Pictures", File(root, "Pictures"))
        quick("\uD83D\uDCF7  Camera", File(root, "DCIM"))
        quick("\uD83C\uDFB5  Music", File(root, "Music"))
        quick("\uD83C\uDFAC  Movies", File(root, "Movies"))
        quick("\uD83D\uDCF1  Screenshots", File(root, "Pictures/Screenshots"))
        side.addView(sideScroll, lp(MATCH, 0, 1f))
        storageText = act.label("", 11f, Ui.textDim)
        storageText.setPadding(act.dp(10), act.dp(4), act.dp(6), 0)
        side.addView(storageText)
        storageBar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        storageBar.max = 100
        side.addView(storageBar, lp(MATCH, act.dp(6)).also { it.setMargins(act.dp(10), act.dp(4), act.dp(10), act.dp(10)) })
        body.addView(side, lp(act.dp(136), MATCH))

        gridView = GridView(act)
        gridView.adapter = adapter
        gridView.selector = android.graphics.drawable.ColorDrawable(0)
        gridView.setOnContextClickListener { emptyMenu(); true }
        gridView.setOnLongClickListener { emptyMenu(); true }
        gridView.setOnClickListener { sel.clear(); selectMode = false; refreshSel() }
        body.addView(gridView, lp(0, MATCH, 1f))
        rootView.addView(body, lp(MATCH, 0, 1f))

        status = act.label("", 11f, Ui.textDim)
        status.setBackgroundColor(c(0xFF191919))
        status.setPadding(act.dp(10), act.dp(3), act.dp(10), act.dp(3))
        rootView.addView(status, lp(MATCH, WRAP))

        setupGrid()
        load()
        return rootView
    }

    private fun tool(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 15f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    private fun setupGrid() {
        if (grid) {
            gridView.numColumns = GridView.AUTO_FIT
            gridView.columnWidth = act.dp(104)
        } else {
            gridView.numColumns = 1
        }
        gridView.adapter = adapter
    }

    private fun makeRow(): LinearLayout {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.isClickable = true
        row.background = Ui.stateBg(act.dp(4).toFloat())
        row.setPadding(act.dp(8), act.dp(2), act.dp(8), act.dp(2))
        val box = android.widget.FrameLayout(act)
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        box.addView(iv, android.widget.FrameLayout.LayoutParams(act.dp(28), act.dp(28), Gravity.CENTER))
        val em = TextView(act)
        em.textSize = 17f
        em.gravity = Gravity.CENTER
        box.addView(em, android.widget.FrameLayout.LayoutParams(MATCH, MATCH))
        row.addView(box, lp(act.dp(34), act.dp(32)))
        val name = act.label("", 13f)
        name.setSingleLine()
        name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        row.addView(name, lp(0, WRAP, 1f))
        val date = act.label("", 11f, Ui.textDim)
        date.setSingleLine()
        row.addView(date, lp(act.dp(110), WRAP))
        val size = act.label("", 11f, Ui.textDim)
        size.gravity = Gravity.END
        size.setSingleLine()
        row.addView(size, lp(act.dp(66), WRAP))
        return row
    }

    private fun makeTile(): LinearLayout {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER_HORIZONTAL
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setPadding(act.dp(4), act.dp(6), act.dp(4), act.dp(6))
        val box = android.widget.FrameLayout(act)
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        box.addView(iv, android.widget.FrameLayout.LayoutParams(act.dp(64), act.dp(64), Gravity.CENTER))
        val em = TextView(act)
        em.textSize = 34f
        em.gravity = Gravity.CENTER
        box.addView(em, android.widget.FrameLayout.LayoutParams(MATCH, MATCH))
        t.addView(box, lp(act.dp(72), act.dp(68)))
        val name = act.label("", 12f)
        name.maxLines = 2
        name.gravity = Gravity.CENTER
        name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        t.addView(name, lp(MATCH, WRAP))
        return t
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bind(row: LinearLayout, f: File) {
        val box = row.getChildAt(0) as android.widget.FrameLayout
        val iv = box.getChildAt(0) as ImageView
        val em = box.getChildAt(1) as TextView
        val e = Files.ext(f)
        val isImg = !f.isDirectory && e in Files.imageExts
        val isVid = !f.isDirectory && e in Files.videoExts
        em.text = iconFor(f)
        if (isImg || isVid) {
            em.visibility = View.GONE
            iv.visibility = View.VISIBLE
            Thumbs.load("f:" + f.path + f.lastModified(), iv) {
                if (isImg) Thumbs.decodeImage(f.path, 160) else Thumbs.decodeVideo(f.path, 160)
            }
        } else {
            em.visibility = View.VISIBLE
            iv.visibility = View.GONE
            iv.tag = null
        }
        (row.getChildAt(1) as TextView).text = f.name
        if (!grid) {
            (row.getChildAt(2) as TextView).text = if (searching) (f.parent ?: "").removePrefix(root.path) else df.format(Date(f.lastModified()))
            (row.getChildAt(3) as TextView).text = if (f.isDirectory) "" else Files.humanSize(f.length())
        }
        row.isSelected = sel.contains(f)
        row.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                lastTool = ev.getToolType(0)
                lastMeta = ev.metaState
            }
            false
        }
        row.setOnClickListener { rowClick(f) }
        row.setOnLongClickListener { if (!sel.contains(f)) { sel.add(f); selectMode = true; refreshSel() }; itemMenu(); true }
        row.setOnContextClickListener {
            if (!sel.contains(f)) {
                sel.clear()
                sel.add(f)
                refreshSel()
            }
            itemMenu()
            true
        }
    }

    private fun iconFor(f: File): String {
        if (f.isDirectory) return "\uD83D\uDCC1"
        val e = Files.ext(f)
        return when {
            e in Files.imageExts -> "\uD83D\uDDBC\uFE0F"
            e in Files.audioExts -> "\uD83C\uDFB5"
            e in Files.videoExts -> "\uD83C\uDFAC"
            e == "pdf" -> "\uD83D\uDCD5"
            e in Files.archiveExts -> "\uD83D\uDDDC\uFE0F"
            e == "apk" -> "\uD83D\uDCE6"
            e in Files.textExts -> "\uD83D\uDCDD"
            else -> "\uD83D\uDCC4"
        }
    }

    // ------------------------------------------------------------ selection & clicks

    private fun rowClick(f: File) {
        val ctrl = (lastMeta and KeyEvent.META_CTRL_ON) != 0
        val shift = (lastMeta and KeyEvent.META_SHIFT_ON) != 0
        if (lastTool == MotionEvent.TOOL_TYPE_MOUSE) {
            val now = SystemClock.uptimeMillis()
            if (!ctrl && !shift && lastClickFile == f && now - lastClickAt < 450) {
                lastClickAt = 0
                open(f)
                return
            }
            lastClickAt = now
            lastClickFile = f
            if (ctrl) {
                if (!sel.remove(f)) sel.add(f)
                anchor = f
            } else if (shift && anchor != null) {
                val a = items.indexOf(anchor)
                val b = items.indexOf(f)
                if (a >= 0 && b >= 0) {
                    sel.clear()
                    for (i in minOf(a, b)..maxOf(a, b)) sel.add(items[i])
                }
            } else {
                sel.clear()
                sel.add(f)
                anchor = f
            }
            selectMode = sel.size > 1
            refreshSel()
        } else {
            if (selectMode) {
                if (!sel.remove(f)) sel.add(f)
                if (sel.isEmpty()) selectMode = false
                refreshSel()
            } else {
                open(f)
            }
        }
    }

    private fun refreshSel() {
        adapter.notifyDataSetChanged()
        buildCmdBar()
        updateStatus()
    }

    private fun buildCmdBar() {
        cmdBar.removeAllViews()
        fun cb(label: String, enabled: Boolean, a: () -> Unit) {
            val b = Ui.button(act, label, a)
            b.textSize = 12f
            b.setPadding(act.dp(10), act.dp(5), act.dp(10), act.dp(5))
            b.alpha = if (enabled) 1f else 0.4f
            b.isEnabled = enabled
            cmdBar.addView(b, lp(WRAP, WRAP).also { it.rightMargin = act.dp(4) })
        }
        val has = sel.isNotEmpty()
        cb("\uFF0B New", true) { newMenu(cmdBar.getChildAt(0)) }
        cb("\u2702 Cut", has) { copySel(true) }
        cb("\u29C9 Copy", has) { copySel(false) }
        cb("\uD83D\uDCCB Paste", clip.isNotEmpty()) { paste(dir) }
        cb("\u270E Rename", sel.size == 1) { sel.firstOrNull()?.let { rename(it) } }
        cb("\uD83D\uDDD1 Delete", has) { deleteSel() }
        cb("\u2197 Share", has) { shareSel() }
        if (sel.isNotEmpty()) {
            val l = act.label("${sel.size} selected", 11f, Ui.textDim)
            l.setPadding(act.dp(8), 0, 0, 0)
            cmdBar.addView(l)
        }
    }

    private fun updateStatus() {
        status.text = when {
            denied -> "Can't open this folder"
            sel.isNotEmpty() -> "${items.size} items   \u2022   ${sel.size} selected" +
                (if (sel.all { !it.isDirectory }) "   \u2022   " + Files.humanSize(sel.sumOf { it.length() }) else "")
            searching -> "${items.size} search results"
            else -> "${items.size} items"
        }
    }

    // ------------------------------------------------------------ navigation & listing

    private fun navigate(f: File, push: Boolean = true) {
        if (!f.isDirectory) {
            act.toast("${f.name} isn't available")
            return
        }
        if (push && f != dir) {
            back.add(dir)
            fwd.clear()
        }
        dir = f
        sel.clear()
        selectMode = false
        searching = false
        load()
    }

    private fun goBack() {
        if (back.isNotEmpty()) {
            fwd.add(dir)
            navigate(back.removeAt(back.size - 1), false)
        }
    }

    private fun goForward() {
        if (fwd.isNotEmpty()) {
            back.add(dir)
            navigate(fwd.removeAt(fwd.size - 1), false)
        }
    }

    private fun goUp() {
        dir.parentFile?.let { navigate(it) }
    }

    fun load() {
        val arr = dir.listFiles()
        denied = arr == null
        all = (arr ?: emptyArray<File>()).filter { showHidden || !it.name.startsWith(".") }
        searching = false
        applyFilter()
        pathBar.setText(dir.absolutePath)
        banner.visibility = if (act.hasStorage()) View.GONE else View.VISIBLE
        val n = if (dir.name.isEmpty()) "/" else dir.name
        window?.setTitle("$n - File Explorer")
        try {
            val st = StatFs(root.path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            storageText.text = Files.humanSize(free) + " free of " + Files.humanSize(total)
            storageBar.progress = ((total - free) * 100 / maxOf(1L, total)).toInt()
        } catch (e: Exception) {
        }
        buildCmdBar()
    }

    private fun applyFilter() {
        val q = filter.lowercase(Locale.ROOT)
        val base = if (searching) all else all
        val filtered = if (q.isEmpty() || searching) base else base.filter { it.name.lowercase(Locale.ROOT).contains(q) }
        items = filtered.sortedWith(Comparator { a, b ->
            if (a.isDirectory != b.isDirectory) return@Comparator if (a.isDirectory) -1 else 1
            val r = when (sortKey) {
                1 -> a.lastModified().compareTo(b.lastModified())
                2 -> a.length().compareTo(b.length())
                3 -> Files.ext(a).compareTo(Files.ext(b))
                else -> a.name.lowercase(Locale.ROOT).compareTo(b.name.lowercase(Locale.ROOT))
            }
            if (sortAsc) r else -r
        })
        sel.retainAll(items.toSet())
        adapter.notifyDataSetChanged()
        updateStatus()
    }

    private fun deepSearch(q: String) {
        val low = q.lowercase(Locale.ROOT)
        status.text = "Searching\u2026"
        val start = dir
        Thread {
            val out = ArrayList<File>()
            try {
                start.walkTopDown().onEnter { d -> d.name != "Android" && !d.name.startsWith(".") }.forEach { f ->
                    if (out.size < 3000 && f != start && f.name.lowercase(Locale.ROOT).contains(low)) out.add(f)
                }
            } catch (e: Exception) {
            }
            act.runOnUiThread {
                all = out
                searching = true
                applyFilter()
            }
        }.start()
    }

    private fun open(f: File) {
        if (f.isDirectory) navigate(f) else act.openFile(f)
    }

    // ------------------------------------------------------------ menus

    private fun sortMenu(anchor: View) {
        fun mk(n: String, k: Int) = MI(n, "", sortKey == k) { sortKey = k; applyFilter() }
        MenuPopup.show(
            act, anchor,
            listOf(
                mk("Name", 0), mk("Date modified", 1), mk("Size", 2), mk("Type", 3), MI("", sep = true),
                MI("Ascending", "", sortAsc) { sortAsc = true; applyFilter() },
                MI("Descending", "", !sortAsc) { sortAsc = false; applyFilter() }
            )
        )
    }

    private fun newMenu(anchor: View) {
        MenuPopup.show(
            act, anchor,
            listOf(
                MI("Folder", "Ctrl+Shift+N") { askText("New folder", "New folder") { n -> newFolder(n) } },
                MI("Text document") { askText("New text file", "New file.txt") { n -> newFile(n) } }
            )
        )
    }

    private fun emptyMenu() {
        MenuPopup.show(
            act, null,
            listOf(
                MI("New folder") { askText("New folder", "New folder") { n -> newFolder(n) } },
                MI("New text document") { askText("New text file", "New file.txt") { n -> newFile(n) } },
                MI("Paste", "Ctrl+V") { if (clip.isNotEmpty()) paste(dir) },
                MI("", sep = true),
                MI("Select all", "Ctrl+A") { selectAll() },
                MI(if (grid) "Details view" else "Icons view") { grid = !grid; setupGrid() },
                MI("Show hidden files", "", showHidden) { showHidden = !showHidden; load() },
                MI("Refresh", "F5") { load() }
            )
        )
    }

    private fun itemMenu() {
        val one = sel.size == 1
        val f = sel.firstOrNull() ?: return
        val e = Files.ext(f)
        val items = ArrayList<MI>()
        items.add(MI("Open", "Enter") { open(f) })
        if (one && !f.isDirectory) items.add(MI("Open with other app\u2026") { act.openExternal(f) })
        if (one && !f.isDirectory && e !in Files.textExts) items.add(MI("Open in Notepad") { act.open(AppKind.NOTEPAD, f.path) })
        if (one && e in Files.imageExts) items.add(MI("Set as desktop background") {
            try {
                f.copyTo(File(act.filesDir, "wall.jpg"), true)
                act.setWallpaper(100)
            } catch (x: Exception) {
                act.toast("Couldn't set background")
            }
        })
        if (one && e == "zip") items.add(MI("Extract here") { extract(f) })
        items.add(MI("", sep = true))
        items.add(MI("Cut", "Ctrl+X") { copySel(true) })
        items.add(MI("Copy", "Ctrl+C") { copySel(false) })
        if (one && f.isDirectory && clip.isNotEmpty()) items.add(MI("Paste into folder") { paste(f) })
        items.add(MI("Compress to ZIP") { zipSel() })
        items.add(MI("Share") { shareSel() })
        items.add(MI("", sep = true))
        if (one) items.add(MI("Rename", "F2") { rename(f) })
        items.add(MI("Delete", "Del") { deleteSel() })
        if (one) items.add(MI("Properties") { properties(f) })
        MenuPopup.show(act, null, items)
    }

    // ------------------------------------------------------------ operations

    private fun selectAll() {
        sel.clear()
        sel.addAll(items)
        selectMode = true
        refreshSel()
    }

    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val input = EditText(act)
        input.setSingleLine()
        input.setText(initial)
        input.selectAll()
        AlertDialog.Builder(act).setTitle(title).setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() && !n.contains("/")) ok(n)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun newFolder(n: String) {
        if (File(dir, n).mkdirs()) load() else act.toast("Couldn't create folder")
    }

    private fun newFile(n: String) {
        try {
            if (File(dir, n).createNewFile()) load() else act.toast("Couldn't create file")
        } catch (e: Exception) {
            act.toast("Couldn't create file")
        }
    }

    private fun copySel(cut: Boolean) {
        if (sel.isEmpty()) return
        clip = sel.toList()
        clipCut = cut
        act.toast((if (cut) "Cut " else "Copied ") + clip.size + " item(s)")
        buildCmdBar()
    }

    private fun uniqueName(target: File, src: File): File {
        val base = src.nameWithoutExtension
        val ext = if (src.isDirectory || src.extension.isEmpty()) "" else "." + src.extension
        var n = 1
        var dst = File(target, "$base - Copy$ext")
        while (dst.exists()) {
            n++
            dst = File(target, "$base - Copy ($n)$ext")
        }
        return dst
    }

    private fun paste(target: File) {
        val files = clip
        val cut = clipCut
        act.toast("Pasting\u2026")
        Thread {
            var err = 0
            for (src in files) {
                try {
                    if (src.isDirectory && target.absolutePath.startsWith(src.absolutePath)) {
                        err++
                        continue
                    }
                    var dst = File(target, src.name)
                    if (dst.exists()) dst = uniqueName(target, src)
                    if (cut) {
                        if (!src.renameTo(dst)) {
                            src.copyRecursively(dst)
                            src.deleteRecursively()
                        }
                    } else {
                        src.copyRecursively(dst)
                    }
                } catch (e: Exception) {
                    err++
                }
            }
            act.runOnUiThread {
                if (cut) clip = emptyList()
                load()
                if (err > 0) act.toast("$err item(s) failed")
            }
        }.start()
    }

    private fun rename(f: File) {
        askText("Rename", f.name) { n ->
            if (!f.renameTo(File(f.parentFile, n))) act.toast("Rename failed")
            sel.clear()
            load()
        }
    }

    private fun deleteSel() {
        val list = sel.toList()
        if (list.isEmpty()) return
        AlertDialog.Builder(act).setTitle("Delete")
            .setMessage(if (list.size == 1) "Delete \"${list[0].name}\"? This can't be undone." else "Delete ${list.size} items? This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                Thread {
                    list.forEach { it.deleteRecursively() }
                    act.runOnUiThread {
                        sel.clear()
                        selectMode = false
                        load()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shareSel() {
        val uris = ArrayList<Uri>()
        for (f in sel) if (f.isFile) uris.add(Uri.Builder().scheme("content").authority(act.packageName + ".files").path(f.absolutePath).build())
        if (uris.isEmpty()) {
            act.toast("Select files to share")
            return
        }
        val i = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE)
        i.type = "*/*"
        if (uris.size == 1) i.putExtra(Intent.EXTRA_STREAM, uris[0]) else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        act.startSafely(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun zipSel() {
        val list = sel.toList()
        if (list.isEmpty()) return
        val out = Files.unique(dir, (if (list.size == 1) list[0].nameWithoutExtension else "Archive") + ".zip")
        act.toast("Compressing\u2026")
        Thread {
            try {
                ZipOutputStream(FileOutputStream(out)).use { z ->
                    fun add(f: File, prefix: String) {
                        if (f.isDirectory) {
                            f.listFiles()?.forEach { add(it, prefix + f.name + "/") }
                        } else {
                            z.putNextEntry(ZipEntry(prefix + f.name))
                            FileInputStream(f).use { it.copyTo(z) }
                            z.closeEntry()
                        }
                    }
                    list.forEach { add(it, "") }
                }
            } catch (e: Exception) {
                act.runOnUiThread { act.toast("Compression failed") }
            }
            act.runOnUiThread { load() }
        }.start()
    }

    private fun extract(zip: File) {
        val target = Files.unique(dir, zip.nameWithoutExtension)
        act.toast("Extracting\u2026")
        Thread {
            try {
                target.mkdirs()
                ZipInputStream(FileInputStream(zip)).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val f = File(target, e.name)
                        if (f.canonicalPath.startsWith(target.canonicalPath)) {
                            if (e.isDirectory) f.mkdirs() else {
                                f.parentFile?.mkdirs()
                                FileOutputStream(f).use { z.copyTo(it) }
                            }
                        }
                        e = z.nextEntry
                    }
                }
            } catch (x: Exception) {
                act.runOnUiThread { act.toast("Extract failed") }
            }
            act.runOnUiThread { load() }
        }.start()
    }

    private fun properties(f: File) {
        val sb = StringBuilder()
        sb.append("Name: ").append(f.name).append("\n")
        sb.append("Location: ").append(f.parent ?: "").append("\n")
        if (f.isDirectory) sb.append("Items: ").append(f.listFiles()?.size ?: 0).append("\n")
        else sb.append("Size: ").append(Files.humanSize(f.length())).append("\n")
        sb.append("Type: ").append(if (f.isDirectory) "Folder" else (MimeTypeMap.getSingleton().getMimeTypeFromExtension(Files.ext(f)) ?: "File")).append("\n")
        sb.append("Modified: ").append(df.format(Date(f.lastModified())))
        AlertDialog.Builder(act).setTitle("Properties").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }

    // ------------------------------------------------------------ lifecycle & keys

    override fun handleArg(arg: String?) {
        if (arg != null) File(arg).takeIf { it.isDirectory }?.let { navigate(it) }
    }

    override fun onResume() {
        if (this::gridView.isInitialized) load()
    }

    override fun onBack(): Boolean {
        if (back.isNotEmpty()) {
            goBack()
            return true
        }
        return false
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (k == KeyEvent.KEYCODE_F5) { load(); return true }
        if (act.currentFocus is EditText) return false
        if (e.isAltPressed) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { goBack(); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { goForward(); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { goUp(); return true }
            }
        }
        if (e.isCtrlPressed) {
            when (k) {
                KeyEvent.KEYCODE_A -> { selectAll(); return true }
                KeyEvent.KEYCODE_C -> { copySel(false); return true }
                KeyEvent.KEYCODE_X -> { copySel(true); return true }
                KeyEvent.KEYCODE_V -> { if (clip.isNotEmpty()) paste(dir); return true }
                KeyEvent.KEYCODE_N -> { if (e.isShiftPressed) { askText("New folder", "New folder") { n -> newFolder(n) }; return true } }
            }
            return false
        }
        when (k) {
            KeyEvent.KEYCODE_FORWARD_DEL -> { deleteSel(); return true }
            KeyEvent.KEYCODE_F2 -> { sel.firstOrNull()?.let { rename(it) }; return true }
            KeyEvent.KEYCODE_ENTER -> { sel.firstOrNull()?.let { open(it) }; return true }
            KeyEvent.KEYCODE_DEL -> { goUp(); return true }
        }
        return false
    }
}
