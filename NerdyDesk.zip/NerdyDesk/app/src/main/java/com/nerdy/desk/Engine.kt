package com.nerdy.desk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import java.util.Random

class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val dur: Long,
    val path: String,
    val albumId: Long
)

/** App-wide audio player: survives closing the Music window and keeps going in the background. */
object MusicEngine {
    private var app: Context? = null
    private var mp: MediaPlayer? = null
    var queue: List<Track> = emptyList()
        private set
    var index = -1
        private set
    var shuffle = false
    var repeat = 0 // 0 off, 1 all, 2 one
    var volume = 1f
    val listeners = ArrayList<() -> Unit>()
    private var focusReq: AudioFocusRequest? = null
    private var pausedByFocus = false
    private val rnd = Random()

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    fun current(): Track? = queue.getOrNull(index)

    fun isPlaying(): Boolean = try {
        mp?.isPlaying == true
    } catch (e: Exception) {
        false
    }

    fun pos(): Int = try {
        mp?.currentPosition ?: 0
    } catch (e: Exception) {
        0
    }

    fun dur(): Int = try {
        mp?.duration ?: 0
    } catch (e: Exception) {
        0
    }

    private fun changed() {
        for (l in listeners.toList()) l()
    }

    private fun requestFocus() {
        val ctx = app ?: return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { ch ->
                when (ch) {
                    AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        if (isPlaying()) {
                            pausedByFocus = true
                            mp?.pause()
                            app?.let { PlaybackService.sync(it) }
                            changed()
                        }
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> {
                        if (pausedByFocus) {
                            pausedByFocus = false
                            mp?.start()
                            app?.let { PlaybackService.sync(it) }
                            changed()
                        }
                    }
                }
            }.build()
        focusReq = req
        am.requestAudioFocus(req)
    }

    fun play(list: List<Track>, i: Int) {
        queue = list
        index = i
        start()
    }

    private fun start() {
        val t = current() ?: return
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        val m = MediaPlayer()
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            m.setDataSource(t.path)
            m.setOnCompletionListener { ended() }
            m.setOnErrorListener { _, _, _ ->
                next()
                true
            }
            m.prepare()
            m.setVolume(volume, volume)
            requestFocus()
            m.start()
            mp = m
        } catch (e: Exception) {
            try {
                m.release()
            } catch (x: Exception) {
            }
        }
        app?.let { PlaybackService.sync(it) }
        changed()
    }

    fun toggle() {
        val m = mp ?: return
        if (m.isPlaying) {
            m.pause()
        } else {
            requestFocus()
            m.start()
        }
        app?.let { PlaybackService.sync(it) }
        changed()
    }

    fun next() {
        if (queue.isEmpty()) return
        index = if (shuffle && queue.size > 1) rnd.nextInt(queue.size) else (index + 1) % queue.size
        start()
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (pos() > 3000) {
            seek(0)
            return
        }
        index = (index - 1 + queue.size) % queue.size
        start()
    }

    fun seek(ms: Int) {
        try {
            mp?.seekTo(ms)
        } catch (e: Exception) {
        }
        changed()
    }

    fun setVol(v: Float) {
        volume = v
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
    }

    private fun ended() {
        when {
            repeat == 2 -> start()
            !shuffle && repeat == 0 && index >= queue.size - 1 -> {
                app?.let { PlaybackService.sync(it) }
                changed()
            }
            else -> next()
        }
    }

    fun scan(ctx: Context): List<Track>? {
        val out = ArrayList<Track>()
        try {
            val cur = ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.ALBUM_ID
                ),
                MediaStore.Audio.Media.DURATION + " > 8000", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE"
            ) ?: return null
            cur.use {
                while (it.moveToNext()) {
                    val path = it.getString(5) ?: continue
                    val artist = it.getString(2)
                    out.add(
                        Track(
                            it.getLong(0), it.getString(1) ?: "Unknown", if (artist == null || artist == "<unknown>") "Unknown artist" else artist,
                            it.getString(3) ?: "Unknown album", it.getLong(4), path, it.getLong(6)
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            return null
        } catch (e: Exception) {
            return null
        }
        return out
    }
}

class PlaybackService : Service() {
    companion object {
        fun sync(ctx: Context) {
            try {
                val i = Intent(ctx, PlaybackService::class.java)
                if (MusicEngine.isPlaying()) ctx.startForegroundService(i) else ctx.stopService(i)
            } catch (e: Exception) {
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("play", "Music playback", NotificationManager.IMPORTANCE_LOW))
        val t = MusicEngine.current()
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "play")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: "NerdyDesk")
            .setContentText(t?.artist ?: "Playing")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(7, n)
        return START_NOT_STICKY
    }
}
