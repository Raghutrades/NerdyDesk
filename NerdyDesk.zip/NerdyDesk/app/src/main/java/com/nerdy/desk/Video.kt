package com.nerdy.desk

import android.annotation.SuppressLint
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import java.util.Locale

class Cue(val s: Long, val e: Long, val t: String)

object Subs {
    private fun time(x: String): Long {
        val p = x.trim().replace(',', '.').split(":")
        val sec = p.last().toDouble()
        val min = if (p.size >= 2) p[p.size - 2].toLong() else 0L
        val hr = if (p.size >= 3) p[p.size - 3].toLong() else 0L
        return ((hr * 3600 + min * 60 + sec) * 1000).toLong()
    }

    fun parse(f: File): List<Cue> {
        val out = ArrayList<Cue>()
        try {
            val text = f.readText().replace("\r\n", "\n").replace("\r", "\n")
            for (block in text.split(Regex("\n\\s*\n"))) {
                val lines = block.trim().split("\n")
                val i = lines.indexOfFirst { it.contains("-->") }
                if (i < 0) continue
                val parts = lines[i].split("-->")
                val s = time(parts[0])
                val e = time(parts[1].trim().split(" ")[0])
                val t = lines.drop(i + 1).joinToString("\n").replace(Regex("<[^>]+>"), "").trim()
                if (t.isNotEmpty()) out.add(Cue(s, e, t))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun find(video: File): File? {
        val dir = video.parentFile ?: return null
        val base = video.nameWithoutExtension
        val c = dir.listFiles() ?: return null
        return c.firstOrNull { (Files.ext(it) == "srt" || Files.ext(it) == "vtt") && it.name.startsWith(base) }
    }
}

class VideoApp(act: MainActivity, private val arg: String?) : App(act) {
    override val title = "Video Player"
    override val icon = "\uD83C\uDFAC"
    override val previewable = false

    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var path: String? = null
    private var playlist: List<String> = emptyList()
    private var idx = -1
    private var vw = 0
    private var vh = 0
    private var fill = false
    private var speed = 1f
    private var vol = 1f
    private var muted = false
    private var cues: List<Cue> = emptyList()
    private var subsOn = true
    private var prepared = false
    private var pendingStart = false
    private var dragging = false
    private var panelOpen = false
    private val h = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var tv: TextureView
    private lateinit var controls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var playBtn: TextView
    private lateinit var bigPlay: TextView
    private lateinit var osd: TextView
    private lateinit var subTv: TextView
    private lateinit var msg: LinearLayout
    private lateinit var msgText: TextView
    private lateinit var panel: LinearLayout
    private lateinit var panelList: LinearLayout
    private var running = true

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val m = mp
            if (m != null && prepared) {
                try {
                    val p = m.currentPosition
                    if (!dragging) {
                        seek.progress = p
                        timeTv.text = Files.fmtTime(p.toLong()) + " / " + Files.fmtTime(m.duration.toLong())
                    }
                    val cue = if (subsOn) cues.firstOrNull { p >= it.s && p <= it.e } else null
                    subTv.text = cue?.t ?: ""
                    subTv.visibility = if (cue != null) View.VISIBLE else View.GONE
                    if (m.isPlaying && p % 5 < 2) savePos()
                } catch (e: Exception) {
                }
            }
            h.postDelayed(this, 250)
        }
    }
    private val hideCtl = Runnable {
        if (mp?.isPlaying == true && !panelOpen) controls.visibility = View.GONE
    }
    private val hideOsd = Runnable { osd.visibility = View.GONE }

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        root = FrameLayout(act)
        root.setBackgroundColor(0xFF000000.toInt())
        root.isFocusable = true
        tv = TextureView(act)
        root.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, hh: Int) {
                surface = Surface(st)
                if (pendingStart) startPlayback()
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, hh: Int) {
                applyTransform()
            }

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                try {
                    mp?.setSurface(null)
                } catch (e: Exception) {
                }
                surface?.release()
                surface = null
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        subTv = act.label("", 18f, 0xFFFFFFFF.toInt())
        subTv.gravity = Gravity.CENTER
        subTv.setShadowLayer(6f, 0f, 1f, 0xFF000000.toInt())
        subTv.setBackgroundColor(c(0x66000000))
        subTv.setPadding(act.dp(10), act.dp(4), act.dp(10), act.dp(4))
        subTv.visibility = View.GONE
        root.addView(subTv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = act.dp(92) })

        osd = act.label("", 20f)
        osd.setBackgroundColor(c(0x99000000))
        osd.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(8))
        osd.visibility = View.GONE
        root.addView(osd, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = act.dp(24) })

        bigPlay = act.label("\u25B6", 40f)
        bigPlay.gravity = Gravity.CENTER
        bigPlay.background = Ui.rect(c(0x88000000), act.dp(40).toFloat())
        bigPlay.visibility = View.GONE
        root.addView(bigPlay, FrameLayout.LayoutParams(act.dp(80), act.dp(80), Gravity.CENTER))

        msg = LinearLayout(act)
        msg.orientation = LinearLayout.VERTICAL
        msg.gravity = Gravity.CENTER
        msgText = act.label("Open a video from File Explorer, or pick one from your library.", 14f, Ui.textDim)
        msgText.gravity = Gravity.CENTER
        msg.addView(msgText, lp(WRAP, WRAP))
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER
        row.addView(Ui.button(act, "\uD83D\uDCDA Library") { openLibrary() }, lp(WRAP, WRAP).also { it.setMargins(act.dp(4), act.dp(12), act.dp(4), 0) })
        row.addView(Ui.button(act, "\uD83D\uDCC1 Browse files") { act.open(AppKind.FILES, "/storage/emulated/0/Movies") }, lp(WRAP, WRAP).also { it.setMargins(act.dp(4), act.dp(12), act.dp(4), 0) })
        msg.addView(row)
        root.addView(msg, FrameLayout.LayoutParams(MATCH, MATCH))

        // controls
        controls = LinearLayout(act)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(c(0xAA000000))
        controls.setPadding(act.dp(10), act.dp(4), act.dp(10), act.dp(6))
        val sr = LinearLayout(act)
        sr.gravity = Gravity.CENTER_VERTICAL
        seek = SeekBar(act)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) timeTv.text = Files.fmtTime(p.toLong()) + " / " + Files.fmtTime(seek.max.toLong())
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                try {
                    mp?.seekTo(seek.progress)
                } catch (e: Exception) {
                }
            }
        })
        sr.addView(seek, lp(0, WRAP, 1f))
        timeTv = act.label("0:00 / 0:00", 12f)
        timeTv.setPadding(act.dp(10), 0, 0, 0)
        sr.addView(timeTv)
        controls.addView(sr, lp(MATCH, WRAP))
        val br = LinearLayout(act)
        br.gravity = Gravity.CENTER_VERTICAL
        playBtn = cbtn("\u25B6") { toggle() }
        br.addView(cbtn("\u23EE") { step(-1) }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\u23EA") { seekBy(-10000) }, lp(act.dp(40), act.dp(36)))
        br.addView(playBtn, lp(act.dp(46), act.dp(36)))
        br.addView(cbtn("\u23E9") { seekBy(10000) }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\u23ED") { step(1) }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\uD83D\uDD0A") { toggleMute() }, lp(act.dp(40), act.dp(36)))
        val vs = SeekBar(act)
        vs.max = 100
        vs.progress = 100
        vs.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) setVol(p / 100f)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        br.addView(vs, lp(act.dp(90), WRAP))
        br.addView(View(act), lp(0, 1, 1f))
        br.addView(cbtn("1x") { speedMenu(it) }, lp(act.dp(44), act.dp(36)))
        br.addView(cbtn("CC") { subsOn = !subsOn; osd("Subtitles " + (if (subsOn) "on" else "off")) }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\u2922") { fill = !fill; applyTransform(); osd(if (fill) "Fill" else "Fit") }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\u2630") { togglePanel() }, lp(act.dp(40), act.dp(36)))
        br.addView(cbtn("\u26F6") { toggleFullscreen() }, lp(act.dp(40), act.dp(36)))
        controls.addView(br, lp(MATCH, WRAP))
        root.addView(controls, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // playlist panel
        panel = LinearLayout(act)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(c(0xEE1A1A1A))
        panel.visibility = View.GONE
        val ph = LinearLayout(act)
        ph.gravity = Gravity.CENTER_VERTICAL
        ph.setPadding(act.dp(10), act.dp(8), act.dp(6), act.dp(4))
        ph.addView(act.label("Playlist", 14f, Ui.text, true), lp(0, WRAP, 1f))
        ph.addView(Ui.button(act, "Library") { openLibrary() }, lp(WRAP, WRAP))
        panel.addView(ph, lp(MATCH, WRAP))
        panelList = LinearLayout(act)
        panelList.orientation = LinearLayout.VERTICAL
        val psv = ScrollView(act)
        psv.addView(panelList, FrameLayout.LayoutParams(MATCH, WRAP))
        panel.addView(psv, lp(MATCH, 0, 1f))
        root.addView(panel, FrameLayout.LayoutParams(act.dp(290), MATCH, Gravity.END).also { it.bottomMargin = act.dp(78) })

        // gestures: tap = play/pause, double tap = full screen (edges seek), wheel = volume
        val gd = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (path != null && !panelOpen) toggle()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = root.width
                when {
                    e.x < w * 0.25f -> seekBy(-10000)
                    e.x > w * 0.75f -> seekBy(10000)
                    else -> toggleFullscreen()
                }
                return true
            }
        })
        tv.setOnTouchListener { _, ev ->
            showControls()
            gd.onTouchEvent(ev)
            true
        }
        root.setOnHoverListener { _, _ ->
            showControls()
            false
        }
        root.setOnGenericMotionListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_SCROLL) {
                setVol((vol + (if (ev.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0) 0.05f else -0.05f)).coerceIn(0f, 1f))
                true
            } else false
        }

        h.post(tick)
        if (arg != null) openPath(arg) else {
            controls.visibility = View.VISIBLE
        }
        return root
    }

    private fun cbtn(label: String, onClick: (View) -> Unit): TextView {
        val t = act.label(label, 15f)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    private fun osd(s: String) {
        osd.text = s
        osd.visibility = View.VISIBLE
        h.removeCallbacks(hideOsd)
        h.postDelayed(hideOsd, 1300)
    }

    private fun showControls() {
        controls.visibility = View.VISIBLE
        h.removeCallbacks(hideCtl)
        h.postDelayed(hideCtl, 3000)
    }

    // ---------------------------------------------------------------- playback

    private fun openPath(p: String) {
        val f = File(p)
        val sibs = (f.parentFile?.listFiles() ?: emptyArray()).filter { Files.ext(it) in Files.videoExts }.sortedBy { it.name.lowercase() }.map { it.path }
        playlist = if (sibs.contains(p)) sibs else listOf(p) + sibs
        idx = playlist.indexOf(p)
        path = p
        startPlayback()
        fillPanel()
    }

    private fun startPlayback() {
        val p = path ?: return
        if (surface == null) {
            pendingStart = true
            return
        }
        pendingStart = false
        savePos()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        prepared = false
        msg.visibility = View.GONE
        bigPlay.visibility = View.GONE
        if (MusicEngine.isPlaying()) MusicEngine.toggle()
        val m = MediaPlayer()
        mp = m
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
            m.setSurface(surface)
            m.setDataSource(p)
            m.setOnVideoSizeChangedListener { _, w, hh ->
                vw = w
                vh = hh
                applyTransform()
            }
            m.setOnPreparedListener {
                prepared = true
                vw = it.videoWidth
                vh = it.videoHeight
                seek.max = it.duration
                val saved = act.prefs.getInt("vpos_" + p.hashCode(), 0)
                if (saved > 5000 && saved < it.duration - 10000) it.seekTo(saved)
                it.setVolume(if (muted) 0f else vol, if (muted) 0f else vol)
                it.start()
                applySpeed()
                applyTransform()
                root.keepScreenOn = true
                updatePlayIcon()
                showControls()
            }
            m.setOnCompletionListener {
                act.prefs.edit().remove("vpos_" + p.hashCode()).apply()
                root.keepScreenOn = false
                if (idx < playlist.size - 1) step(1) else {
                    updatePlayIcon()
                    controls.visibility = View.VISIBLE
                    bigPlay.visibility = View.VISIBLE
                }
            }
            m.setOnErrorListener { _, _, _ ->
                showError()
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            showError()
        }
        val f = File(p)
        window?.setTitle(f.name + " - Video Player")
        val sf = Subs.find(f)
        cues = if (sf != null) Subs.parse(sf) else emptyList()
        subTv.text = ""
        fillPanel()
    }

    private fun showError() {
        msg.visibility = View.VISIBLE
        msgText.text = "This video can't be played here (unsupported format or missing file)."
        controls.visibility = View.VISIBLE
        path?.let { p ->
            val b = Ui.button(act, "Open with another app") { act.openExternal(File(p)) }
            if (msg.childCount < 3) msg.addView(b, lp(WRAP, WRAP).also { it.topMargin = act.dp(10) })
        }
    }

    private fun savePos() {
        val p = path ?: return
        val m = mp ?: return
        if (!prepared) return
        try {
            act.prefs.edit().putInt("vpos_" + p.hashCode(), m.currentPosition).apply()
        } catch (e: Exception) {
        }
    }

    private fun toggle() {
        val m = mp
        if (m == null || !prepared) {
            if (path != null) startPlayback()
            return
        }
        try {
            if (m.isPlaying) {
                m.pause()
                bigPlay.visibility = View.VISIBLE
                controls.visibility = View.VISIBLE
                root.keepScreenOn = false
                savePos()
            } else {
                m.start()
                applySpeed()
                bigPlay.visibility = View.GONE
                root.keepScreenOn = true
                showControls()
            }
        } catch (e: Exception) {
        }
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        playBtn.text = if (mp?.isPlaying == true) "\u23F8" else "\u25B6"
    }

    private fun seekBy(ms: Int) {
        val m = mp ?: return
        if (!prepared) return
        try {
            val t = (m.currentPosition + ms).coerceIn(0, m.duration)
            m.seekTo(t)
            osd((if (ms > 0) "\u23E9 +" else "\u23EA \u2212") + Math.abs(ms / 1000) + "s")
        } catch (e: Exception) {
        }
    }

    private fun step(d: Int) {
        if (playlist.isEmpty()) return
        val n = idx + d
        if (n < 0 || n >= playlist.size) return
        idx = n
        path = playlist[n]
        startPlayback()
    }

    private fun setVol(v: Float) {
        vol = v
        muted = false
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
        osd("Volume " + (v * 100).toInt() + "%")
    }

    private fun toggleMute() {
        muted = !muted
        try {
            mp?.setVolume(if (muted) 0f else vol, if (muted) 0f else vol)
        } catch (e: Exception) {
        }
        osd(if (muted) "Muted" else "Volume " + (vol * 100).toInt() + "%")
    }

    private fun applySpeed() {
        try {
            val m = mp ?: return
            if (speed != 1f && m.isPlaying) m.playbackParams = PlaybackParams().setSpeed(speed)
        } catch (e: Exception) {
        }
    }

    private fun speedMenu(anchor: View) {
        MenuPopup.show(
            act, anchor,
            listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).map { s ->
                MI(String.format(Locale.US, "%.2gx", s).replace("1x", "1x"), "", speed == s) {
                    speed = s
                    try {
                        val m = mp
                        if (m != null && m.isPlaying) m.playbackParams = PlaybackParams().setSpeed(s)
                    } catch (e: Exception) {
                    }
                    (anchor as? TextView)?.text = (if (s == 1f) "1x" else s.toString() + "x")
                    osd("Speed " + s + "x")
                }
            }
        )
    }

    private fun applyTransform() {
        if (vw <= 0 || vh <= 0 || tv.width <= 0) return
        val w = tv.width.toFloat()
        val hh = tv.height.toFloat()
        val s = if (fill) maxOf(w / vw, hh / vh) else minOf(w / vw, hh / vh)
        val m = Matrix()
        m.setScale(vw * s / w, vh * s / hh, w / 2f, hh / 2f)
        tv.setTransform(m)
    }

    private fun toggleFullscreen() {
        if (act.inFullscreen) act.exitFullscreen() else window?.let { act.enterFullscreen(it) }
    }

    // ---------------------------------------------------------------- playlist panel

    private fun togglePanel() {
        panelOpen = !panelOpen
        panel.visibility = if (panelOpen) View.VISIBLE else View.GONE
        if (panelOpen) {
            fillPanel()
            controls.visibility = View.VISIBLE
        } else showControls()
    }

    private fun fillPanel() {
        if (!this::panelList.isInitialized) return
        panelList.removeAllViews()
        if (playlist.isEmpty()) {
            val e = act.label("No videos yet. Tap Library to load your phone's videos.", 12f, Ui.textDim)
            e.setPadding(act.dp(12), act.dp(10), act.dp(12), 0)
            panelList.addView(e)
            return
        }
        for ((i, p) in playlist.withIndex()) {
            val r = LinearLayout(act)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(8), act.dp(4), act.dp(8), act.dp(4))
            r.isClickable = true
            r.background = Ui.stateBg(act.dp(5).toFloat(), if (i == idx) c(0x33FFFFFF) else 0)
            val iv = ImageView(act)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setBackgroundColor(c(0xFF2A2A2A))
            r.addView(iv, lp(act.dp(64), act.dp(40)))
            Thumbs.load("v:$p", iv) { Thumbs.decodeVideo(p, 160) }
            val n = act.label(File(p).name, 12f, if (i == idx) Ui.accent else Ui.text)
            n.maxLines = 2
            n.ellipsize = android.text.TextUtils.TruncateAt.END
            n.setPadding(act.dp(8), 0, 0, 0)
            r.addView(n, lp(0, WRAP, 1f))
            r.setOnClickListener {
                idx = i
                path = p
                startPlayback()
            }
            panelList.addView(r)
        }
    }

    private fun openLibrary() {
        if (!act.hasStorage()) {
            act.requestStorage()
            return
        }
        Thread {
            val out = ArrayList<String>()
            try {
                val cur = act.contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media.DATA), null, null,
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )
                cur?.use {
                    while (it.moveToNext() && out.size < 600) it.getString(0)?.let { s -> out.add(s) }
                }
            } catch (e: Exception) {
            }
            act.runOnUiThread {
                if (out.isEmpty()) {
                    act.toast("No videos found")
                } else {
                    playlist = out
                    idx = path?.let { out.indexOf(it) } ?: -1
                    if (!panelOpen) togglePanel() else fillPanel()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- lifecycle & keys

    override fun handleArg(arg: String?) {
        if (arg != null) openPath(arg)
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (act.currentFocus is EditText) return false
        when (e.keyCode) {
            KeyEvent.KEYCODE_SPACE -> { toggle(); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(if (e.isShiftPressed) 30000 else 5000); showControls(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(if (e.isShiftPressed) -30000 else -5000); showControls(); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { setVol((vol + 0.05f).coerceAtMost(1f)); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { setVol((vol - 0.05f).coerceAtLeast(0f)); return true }
            KeyEvent.KEYCODE_F -> { toggleFullscreen(); return true }
            KeyEvent.KEYCODE_M -> { toggleMute(); return true }
            KeyEvent.KEYCODE_N -> { step(1); return true }
            KeyEvent.KEYCODE_P -> { step(-1); return true }
        }
        return false
    }

    override fun onPause() {
        savePos()
        try {
            if (mp?.isPlaying == true) {
                mp?.pause()
                updatePlayIcon()
                bigPlay.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
        }
    }

    override fun onBack(): Boolean {
        if (act.inFullscreen) {
            act.exitFullscreen()
            return true
        }
        if (panelOpen) {
            togglePanel()
            return true
        }
        return false
    }

    override fun onClose() {
        running = false
        savePos()
        h.removeCallbacksAndMessages(null)
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }
}
