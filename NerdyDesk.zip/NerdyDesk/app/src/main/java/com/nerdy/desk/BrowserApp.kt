package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class BrowserApp(act: MainActivity, private val startUrl: String?) : App(act) {
    override val title = "Browser"
    override val icon = "\uD83C\uDF10"

    private class Tab(val web: WebView, var title: String = "New tab")

    private val tabs = ArrayList<Tab>()
    private var current: Tab? = null
    private lateinit var tabStrip: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView

    private val desktopUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val homeBase = "https://nerdydesk.local/"
    private val homeHtml = "<!doctype html><html><head><title>New tab</title>" +
        "<meta name=viewport content=\"width=device-width,initial-scale=1\"><style>" +
        "body{margin:0;background:#202020;color:#fff;font-family:Segoe UI,Roboto,sans-serif;display:flex;" +
        "flex-direction:column;align-items:center;justify-content:center;height:100vh}" +
        "h1{font-weight:300;font-size:42px;margin:0 0 24px}form{width:min(560px,86vw)}" +
        "input{width:100%;box-sizing:border-box;padding:14px 20px;border-radius:26px;border:1px solid #444;" +
        "background:#2b2b2b;color:#fff;font-size:16px;outline:none}input:focus{border-color:#0078d4}" +
        "</style></head><body><h1>NerdyDesk</h1><form action=\"https://www.google.com/search\" method=\"get\">" +
        "<input name=\"q\" placeholder=\"Search the web\"></form></body></html>"

    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bgDark)

        val scroll = HorizontalScrollView(act)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.setBackgroundColor(c(0xFF171717))
        tabStrip = LinearLayout(act)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(tabStrip, FrameLayout.LayoutParams(WRAP, MATCH))
        root.addView(scroll, lp(MATCH, act.dp(34)))

        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.setBackgroundColor(c(0xFF2B2B2B))
        backBtn = tool("\u2190") { current?.web?.let { if (it.canGoBack()) it.goBack() } }
        fwdBtn = tool("\u2192") { current?.web?.let { if (it.canGoForward()) it.goForward() } }
        val reload = tool("\u27F3") { current?.web?.reload() }
        val home = tool("\u2302") { current?.web?.let { loadHome(it) } }
        bar.addView(backBtn, lp(act.dp(36), act.dp(32)))
        bar.addView(fwdBtn, lp(act.dp(36), act.dp(32)))
        bar.addView(reload, lp(act.dp(36), act.dp(32)))
        bar.addView(home, lp(act.dp(36), act.dp(32)))

        address = EditText(act)
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.setSingleLine()
        address.textSize = 14f
        address.setTextColor(Ui.text)
        address.setHintTextColor(Ui.textDim)
        address.hint = "Search or enter address"
        address.background = Ui.rect(c(0xFF1B1B1B), act.dp(16).toFloat())
        address.setPadding(act.dp(14), 0, act.dp(14), 0)
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.setOnEditorActionListener { v, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO ||
                (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
            ) {
                go(v.text.toString())
                true
            } else false
        }
        address.setOnFocusChangeListener { v, has -> if (has) (v as EditText).selectAll() }
        val lpAddr = lp(0, act.dp(32), 1f)
        lpAddr.setMargins(act.dp(4), 0, act.dp(4), 0)
        bar.addView(address, lpAddr)
        root.addView(bar, lp(MATCH, act.dp(40)))

        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(Ui.accent)
        progress.visibility = View.GONE
        root.addView(progress, lp(MATCH, act.dp(3)))

        holder = FrameLayout(act)
        root.addView(holder, lp(MATCH, 0, 1f))

        newTab(startUrl)
        return root
    }

    private fun tool(label: String, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 17f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?) {
        val web = WebView(act)
        val tab = Tab(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.userAgentString = desktopUa
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val sc = u.scheme ?: return false
                if (sc == "http" || sc == "https" || sc == "about" || sc == "data" || sc == "blob") return false
                try {
                    act.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (tab === current) {
                    setAddress(url)
                    updateNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (tab === current) {
                    progress.visibility = View.GONE
                    updateNav()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === current) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, t: String?) {
                tab.title = if (t.isNullOrBlank()) "New tab" else t
                refreshTabs()
                if (tab === current) window?.setTitle(tab.title + " - Browser")
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                act.filePathCallback?.onReceiveValue(null)
                act.filePathCallback = filePathCallback
                return try {
                    act.startActivityForResult(fileChooserParams!!.createIntent(), MainActivity.REQ_FILE)
                    true
                } catch (e: Exception) {
                    act.filePathCallback = null
                    false
                }
            }
        }
        web.setDownloadListener { dlUrl, agent, disposition, mime, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(dlUrl))
                req.setMimeType(mime)
                CookieManager.getInstance().getCookie(dlUrl)?.let { req.addRequestHeader("cookie", it) }
                req.addRequestHeader("User-Agent", agent)
                val name = URLUtil.guessFileName(dlUrl, disposition, mime)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(act, "Downloading $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(act, "Download failed", Toast.LENGTH_SHORT).show()
            }
        }

        tabs.add(tab)
        selectTab(tab)
        if (url.isNullOrBlank()) loadHome(web) else web.loadUrl(normalize(url))
    }

    private fun loadHome(web: WebView) {
        web.loadDataWithBaseURL(homeBase, homeHtml, "text/html", "utf-8", null)
    }

    private fun selectTab(t: Tab) {
        current = t
        holder.removeAllViews()
        (t.web.parent as? android.view.ViewGroup)?.removeView(t.web)
        holder.addView(t.web, FrameLayout.LayoutParams(MATCH, MATCH))
        setAddress(t.web.url)
        updateNav()
        refreshTabs()
        window?.setTitle(t.title + " - Browser")
        t.web.requestFocus()
    }

    private fun closeTab(t: Tab) {
        if (tabs.size <= 1) {
            window?.let { act.closeWindow(it) }
            return
        }
        val idx = tabs.indexOf(t)
        tabs.remove(t)
        holder.removeView(t.web)
        t.web.destroy()
        if (current === t) selectTab(tabs[(idx - 1).coerceAtLeast(0)]) else refreshTabs()
    }

    private fun refreshTabs() {
        tabStrip.removeAllViews()
        for (t in tabs.toList()) {
            val item = LinearLayout(act)
            item.orientation = LinearLayout.HORIZONTAL
            item.gravity = Gravity.CENTER_VERTICAL
            item.isClickable = true
            item.background = Ui.stateBg(act.dp(6).toFloat(), if (t === current) c(0xFF2B2B2B) else 0)
            item.setOnClickListener { selectTab(t) }
            item.hand()
            val label = TextView(act)
            label.text = t.title
            label.textSize = 12f
            label.setTextColor(if (t === current) Ui.text else Ui.textDim)
            label.setSingleLine()
            label.ellipsize = android.text.TextUtils.TruncateAt.END
            label.maxWidth = act.dp(150)
            label.setPadding(act.dp(10), 0, act.dp(4), 0)
            item.addView(label, lp(WRAP, WRAP))
            val x = TextView(act)
            x.text = "\u2715"
            x.textSize = 11f
            x.setTextColor(Ui.textDim)
            x.gravity = Gravity.CENTER
            x.isClickable = true
            x.background = Ui.stateBg(act.dp(10).toFloat())
            x.setOnClickListener { closeTab(t) }
            x.hand()
            item.addView(x, lp(act.dp(22), act.dp(22)))
            val ilp = lp(WRAP, act.dp(28))
            ilp.setMargins(act.dp(2), act.dp(3), act.dp(2), act.dp(3))
            tabStrip.addView(item, ilp)
        }
        val plus = tool("+") { newTab(null) }
        plus.textSize = 18f
        tabStrip.addView(plus, lp(act.dp(32), act.dp(28)))
    }

    private fun setAddress(url: String?) {
        address.setText(if (url == null || url.startsWith(homeBase) || url == "about:blank") "" else url)
    }

    private fun updateNav() {
        val w = current?.web ?: return
        backBtn.alpha = if (w.canGoBack()) 1f else 0.4f
        fwdBtn.alpha = if (w.canGoForward()) 1f else 0.4f
    }

    private fun normalize(raw: String): String {
        val t = raw.trim()
        val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            ip.matches(t) || t.startsWith("localhost") -> "http://$t"
            t.contains(" ") || !t.contains(".") -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
    }

    private fun go(raw: String) {
        if (raw.isBlank()) return
        current?.web?.loadUrl(normalize(raw))
        current?.web?.requestFocus()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (e.isCtrlPressed) {
            when (k) {
                KeyEvent.KEYCODE_T -> { newTab(null); return true }
                KeyEvent.KEYCODE_W -> { current?.let { closeTab(it) }; return true }
                KeyEvent.KEYCODE_L -> { address.requestFocus(); return true }
                KeyEvent.KEYCODE_R -> { current?.web?.reload(); return true }
            }
        }
        if (k == KeyEvent.KEYCODE_F5) {
            current?.web?.reload()
            return true
        }
        if (e.isAltPressed && k == KeyEvent.KEYCODE_DPAD_LEFT) {
            current?.web?.let { if (it.canGoBack()) it.goBack() }
            return true
        }
        return false
    }

    override fun onBack(): Boolean {
        val w = current?.web ?: return false
        if (w.canGoBack()) {
            w.goBack()
            return true
        }
        return false
    }

    override fun onClose() {
        holder.removeAllViews()
        for (t in tabs) t.web.destroy()
        tabs.clear()
    }
}
