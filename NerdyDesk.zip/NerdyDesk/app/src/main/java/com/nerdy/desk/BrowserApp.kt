package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.HttpAuthHandler
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Host-based ad / tracker blocking, using the same list as NerdyBrowser. */
object Blocker {
    private val hosts = HashSet<String>()
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            ctx.assets.open("browser/hosts.txt").bufferedReader().useLines { seq ->
                for (l in seq) {
                    val t = l.trim().lowercase(Locale.ROOT)
                    if (t.isNotEmpty() && !t.startsWith("#")) hosts.add(t)
                }
            }
        } catch (e: Exception) {
        }
    }

    fun blocked(host: String?): Boolean {
        if (host == null) return false
        var h = host.lowercase(Locale.ROOT)
        while (true) {
            if (hosts.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}

/** Bookmarks, history and download records, kept as JSON in preferences. */
class BStore(private val act: MainActivity) {
    fun list(key: String): JSONArray = try {
        JSONArray(act.prefs.getString(key, "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun save(key: String, a: JSONArray) {
        act.prefs.edit().putString(key, a.toString()).apply()
    }

    fun addFront(key: String, o: JSONObject, cap: Int, uniqueUrl: Boolean) {
        val old = list(key)
        val out = JSONArray()
        out.put(o)
        for (i in 0 until old.length()) {
            if (out.length() >= cap) break
            val x = old.getJSONObject(i)
            if (uniqueUrl && x.optString("u") == o.optString("u")) continue
            out.put(x)
        }
        save(key, out)
    }

    fun removeUrl(key: String, url: String) {
        val old = list(key)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val x = old.getJSONObject(i)
            if (x.optString("u") != url) out.put(x)
        }
        save(key, out)
    }

    fun clear(key: String) = save(key, JSONArray())

    fun has(key: String, url: String): Boolean {
        val a = list(key)
        for (i in 0 until a.length()) if (a.getJSONObject(i).optString("u") == url) return true
        return false
    }
}

class BrowserApp(act: MainActivity, private val startArg: String?) : App(act) {
    override val title = "Browser"
    override val icon = "\uD83C\uDF10"
    override val previewable = false

    class Tab(val web: WebView, val priv: Boolean) {
        var title = "New tab"
        var url = ""
        var icon: Bitmap? = null
        var blocked = 0
        var desktop = true
        var dark = false
        var zoom = 1f
        var loading = false
    }

    private val store = BStore(act)
    private val tabs = ArrayList<Tab>()
    private var cur: Tab? = null
    private val closedUrls = ArrayList<String>()
    private lateinit var frame: FrameLayout
    private lateinit var tabStrip: LinearLayout
    private lateinit var address: EditText
    private lateinit var lockView: TextView
    private lateinit var starBtn: TextView
    private lateinit var shieldBtn: TextView
    private lateinit var reloadBtn: TextView
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView
    private lateinit var progress: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var sugg: LinearLayout
    private var panel: View? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var suppress = false
    private val ui = Handler(Looper.getMainLooper())
    private var shieldQueued = false

    private val engines = linkedMapOf(
        "Google" to "https://www.google.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "Brave" to "https://search.brave.com/search?q=",
        "Startpage" to "https://www.startpage.com/do/search?q="
    )
    private val homeBase = "https://nerdydesk.local/newtab"

    private val mobileUa: String by lazy {
        WebSettings.getDefaultUserAgent(act).replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
    }
    private val desktopUa: String by lazy {
        val m = Regex("Chrome/[\\d.]+").find(mobileUa)?.value ?: "Chrome/124.0.0.0"
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) $m Safari/537.36"
    }
    private val shieldJs: String by lazy {
        try {
            act.assets.open("browser/inject.js").bufferedReader().readText()
        } catch (e: Exception) {
            ""
        }
    }

    private fun engineUrl(): String = engines[act.prefs.getString("br_engine", "Google")] ?: engines["Google"]!!
    private fun shieldEnabled(): Boolean = act.prefs.getBoolean("br_shield", true)

    private fun allowList(): MutableList<String> {
        val a = try {
            JSONArray(act.prefs.getString("br_allow", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        return MutableList(a.length()) { a.getString(it) }
    }

    private fun hostOf(u: String): String = try {
        Uri.parse(u).host ?: ""
    } catch (e: Exception) {
        ""
    }

    private fun shieldOn(t: Tab): Boolean {
        if (!shieldEnabled()) return false
        val h = hostOf(t.url)
        return h.isEmpty() || !allowList().contains(h)
    }

    // ---------------------------------------------------------------- UI

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        Blocker.load(act)
        frame = FrameLayout(act)
        frame.setBackgroundColor(Ui.bgDark)
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        frame.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = HorizontalScrollView(act)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.setBackgroundColor(c(0xFF171717))
        tabStrip = LinearLayout(act)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(tabStrip, FrameLayout.LayoutParams(WRAP, MATCH))
        col.addView(scroll, lp(MATCH, act.dp(34)))

        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.setBackgroundColor(c(0xFF2B2B2B))
        backBtn = tool("\u2190") { cur?.web?.let { if (it.canGoBack()) it.goBack() } }
        fwdBtn = tool("\u2192") { cur?.web?.let { if (it.canGoForward()) it.goForward() } }
        reloadBtn = tool("\u27F3") {
            val t = cur
            if (t != null) if (t.loading) t.web.stopLoading() else t.web.reload()
        }
        val home = tool("\u2302") { cur?.let { loadHome(it) } }
        for (b in listOf(backBtn, fwdBtn, reloadBtn, home)) bar.addView(b, lp(act.dp(34), act.dp(32)))

        val addrBox = LinearLayout(act)
        addrBox.orientation = LinearLayout.HORIZONTAL
        addrBox.gravity = Gravity.CENTER_VERTICAL
        addrBox.background = Ui.rect(c(0xFF1B1B1B), act.dp(16).toFloat())
        lockView = act.label("", 12f, Ui.textDim)
        lockView.gravity = Gravity.CENTER
        addrBox.addView(lockView, lp(act.dp(30), WRAP))
        address = EditText(act)
        address.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        address.setSingleLine()
        address.textSize = 14f
        address.setTextColor(Ui.text)
        address.setHintTextColor(Ui.textDim)
        address.hint = "Search or enter address"
        address.background = null
        address.setPadding(0, 0, act.dp(6), 0)
        address.imeOptions = EditorInfo.IME_ACTION_GO
        address.setOnEditorActionListener { v, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)) {
                go(v.text.toString())
                true
            } else false
        }
        address.setOnFocusChangeListener { v, has ->
            if (has) (v as EditText).selectAll() else ui.postDelayed({ hideSugg() }, 150)
        }
        address.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!suppress && address.hasFocus()) showSugg(s?.toString() ?: "")
            }
        })
        addrBox.addView(address, lp(0, MATCH, 1f))
        shieldBtn = act.label("\uD83D\uDEE1 0", 11f, Ui.textDim)
        shieldBtn.gravity = Gravity.CENTER
        shieldBtn.isClickable = true
        shieldBtn.setPadding(act.dp(6), 0, act.dp(6), 0)
        shieldBtn.setOnClickListener { shieldMenu() }
        shieldBtn.hand()
        addrBox.addView(shieldBtn, lp(WRAP, MATCH))
        starBtn = tool("\u2606") { toggleBookmark() }
        starBtn.textSize = 16f
        addrBox.addView(starBtn, lp(act.dp(32), MATCH))
        val al = lp(0, act.dp(32), 1f)
        al.setMargins(act.dp(4), 0, act.dp(4), 0)
        bar.addView(addrBox, al)
        bar.addView(tool("\u22EE") { mainMenu(it) }, lp(act.dp(34), act.dp(32)))
        col.addView(bar, lp(MATCH, act.dp(40)))

        findBar = LinearLayout(act)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setBackgroundColor(c(0xFF262626))
        findBar.setPadding(act.dp(10), act.dp(3), act.dp(6), act.dp(3))
        findBar.visibility = View.GONE
        findInput = EditText(act)
        findInput.setSingleLine()
        findInput.textSize = 13f
        findInput.setTextColor(Ui.text)
        findInput.hint = "Find in page"
        findInput.setHintTextColor(Ui.textDim)
        findInput.background = Ui.rect(c(0xFF1B1B1B), act.dp(6).toFloat())
        findInput.setPadding(act.dp(10), 0, act.dp(10), 0)
        findInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q.isEmpty()) {
                    cur?.web?.clearMatches()
                    findCount.text = ""
                } else cur?.web?.findAllAsync(q)
            }
        })
        findInput.setOnEditorActionListener { _, _, _ -> cur?.web?.findNext(true); true }
        findCount = act.label("", 12f, Ui.textDim)
        findCount.setPadding(act.dp(8), 0, act.dp(8), 0)
        findBar.addView(findInput, lp(act.dp(240), act.dp(30)))
        findBar.addView(findCount, lp(WRAP, WRAP))
        findBar.addView(tool("\u2191") { cur?.web?.findNext(false) }, lp(act.dp(32), act.dp(30)))
        findBar.addView(tool("\u2193") { cur?.web?.findNext(true) }, lp(act.dp(32), act.dp(30)))
        findBar.addView(tool("\u2715") { closeFind() }, lp(act.dp(32), act.dp(30)))
        col.addView(findBar, lp(MATCH, WRAP))

        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(Ui.accent)
        progress.visibility = View.GONE
        col.addView(progress, lp(MATCH, act.dp(3)))

        holder = FrameLayout(act)
        col.addView(holder, lp(MATCH, 0, 1f))

        sugg = LinearLayout(act)
        sugg.orientation = LinearLayout.VERTICAL
        sugg.background = Ui.rect(c(0xFA262626), act.dp(8).toFloat(), Ui.border, 1)
        sugg.elevation = act.dp(12).toFloat()
        sugg.visibility = View.GONE
        val sl = FrameLayout.LayoutParams(act.dp(480), WRAP)
        sl.leftMargin = act.dp(150)
        sl.topMargin = act.dp(76)
        frame.addView(sugg, sl)

        newTab(startArg)
        return frame
    }

    private fun tool(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 17f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    // ---------------------------------------------------------------- tabs

    private fun newTab(arg: String?, priv: Boolean = false, background: Boolean = false, web0: WebView? = null): Tab {
        val web = web0 ?: WebView(act)
        val tab = Tab(web, priv)
        tab.desktop = act.prefs.getBoolean("br_desktop", true)
        setup(tab)
        tabs.add(tab)
        if (!background) select(tab) else refreshTabs()
        if (web0 == null) {
            if (arg.isNullOrBlank()) loadHome(tab) else web.loadUrl(normalize(arg))
        }
        return tab
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setup(tab: Tab) {
        val web = tab.web
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.userAgentString = if (tab.desktop) desktopUa else mobileUa
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        if (tab.priv) s.cacheMode = WebSettings.LOAD_NO_CACHE
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(NDBridge(act, true), "NDBridge")
        web.setBackgroundColor(Ui.bgDark)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val r = request ?: return null
                val u = r.url
                if (u.host == WebKit.HOST) return WebKit.assetResponse(act, u)
                if (!r.isForMainFrame && shieldOn(tab) && Blocker.blocked(u.host)) {
                    tab.blocked++
                    scheduleShield()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val sc = u.scheme ?: return false
                if (sc == "http" || sc == "https" || sc == "about" || sc == "data" || sc == "blob" || sc == "javascript") return false
                try {
                    val i = if (sc == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    act.startActivity(i)
                } catch (e: Exception) {
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.url = url ?: ""
                tab.loading = true
                tab.blocked = 0
                if (tab === cur) {
                    setAddress(tab.url)
                    updateNav()
                    updateShield()
                }
                view?.evaluateJavascript(WebKit.SHIM, null)
                injectShield(tab)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                view?.evaluateJavascript(WebKit.SHIM, null)
                injectShield(tab)
                if (tab.dark) view?.evaluateJavascript("window.__nbDark&&window.__nbDark(true)", null)
                val u = url ?: ""
                if (!tab.priv && (u.startsWith("http://") || u.startsWith("https://"))) {
                    val o = JSONObject()
                    o.put("t", tab.title)
                    o.put("u", u)
                    o.put("ts", System.currentTimeMillis())
                    store.addFront("br_hist", o, 800, true)
                }
                if (tab === cur) {
                    updateNav()
                    updateStar()
                    progress.visibility = View.GONE
                }
                refreshTabs()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                tab.url = url ?: tab.url
                if (tab === cur) {
                    setAddress(tab.url)
                    updateStar()
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    val u = request.url.toString()
                    val msg = error?.description?.toString() ?: "Unknown error"
                    val html = "<html><body style='background:#202020;color:#eee;font-family:sans-serif;padding:8vw'>" +
                        "<h1 style='font-weight:300'>Can\u2019t reach this page</h1><p>" + android.text.Html.escapeHtml(u) + "</p>" +
                        "<p style='color:#aaa'>" + android.text.Html.escapeHtml(msg) + "</p>" +
                        "<button style='padding:10px 22px;border:0;border-radius:6px;background:#0078d4;color:#fff;font-size:16px' " +
                        "onclick='location.href=\"" + u.replace("\"", "") + "\"'>Try again</button></body></html>"
                    view?.loadDataWithBaseURL(u, html, "text/html", "utf-8", u)
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                AlertDialog.Builder(act).setTitle("Connection is not private")
                    .setMessage("The certificate for " + hostOf(error?.url ?: "") + " can\u2019t be trusted. Continue anyway?")
                    .setPositiveButton("Continue") { _, _ -> handler?.proceed() }
                    .setNegativeButton("Go back") { _, _ -> handler?.cancel() }
                    .setOnCancelListener { handler?.cancel() }.show()
            }

            override fun onReceivedHttpAuthRequest(view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?) {
                val box = LinearLayout(act)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
                val u = EditText(act)
                u.hint = "User name"
                val p = EditText(act)
                p.hint = "Password"
                p.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                box.addView(u)
                box.addView(p)
                AlertDialog.Builder(act).setTitle("Sign in to $host").setView(box)
                    .setPositiveButton("Sign in") { _, _ -> handler?.proceed(u.text.toString(), p.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> handler?.cancel() }
                    .setOnCancelListener { handler?.cancel() }.show()
            }
        }

        web.webChromeClient = object : BaseChrome(act) {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === cur) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                    reloadBtn.text = if (newProgress in 1..99) "\u2715" else "\u27F3"
                }
            }

            override fun onReceivedTitle(view: WebView?, t: String?) {
                tab.title = if (t.isNullOrBlank()) "New tab" else t
                refreshTabs()
                if (tab === cur) window?.setTitle(tab.title + " - Browser")
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                tab.icon = icon
                refreshTabs()
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                if (!isUserGesture || resultMsg == null) return false
                val nt = newTab(null, tab.priv, false, WebView(act))
                val tr = resultMsg.obj as WebView.WebViewTransport
                tr.webView = nt.web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                closeTab(tab)
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, false, false)
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                customView = view
                customCb = callback
                frame.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
                view.setBackgroundColor(0xFF000000.toInt())
                window?.let { act.enterFullscreen(it) }
            }

            override fun onHideCustomView() {
                customView?.let { frame.removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
                act.exitFullscreen()
            }
        }

        web.setDownloadListener { dlUrl, agent, disposition, mime, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(dlUrl))
                req.setMimeType(mime)
                CookieManager.getInstance().getCookie(dlUrl)?.let { req.addRequestHeader("cookie", it) }
                req.addRequestHeader("User-Agent", agent)
                val name = URLUtil.guessFileName(dlUrl, disposition, mime)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                val o = JSONObject()
                o.put("t", name)
                o.put("u", dlUrl)
                o.put("p", File(Files.downloads(), name).absolutePath)
                o.put("ts", System.currentTimeMillis())
                store.addFront("br_dl", o, 200, false)
                act.toast("Downloading $name")
            } catch (e: Exception) {
                act.toast("Download failed")
            }
        }

        web.setOnLongClickListener {
            val r = web.hitTestResult
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE, WebView.HitTestResult.IMAGE_TYPE -> {
                    val isImg = r.type != WebView.HitTestResult.SRC_ANCHOR_TYPE
                    val extra = r.extra
                    if (r.type == WebView.HitTestResult.IMAGE_TYPE) {
                        linkMenu(null, extra, tab)
                    } else {
                        val h = Handler(Looper.getMainLooper()) { msg ->
                            linkMenu(msg.data.getString("url") ?: (if (!isImg) extra else null), msg.data.getString("src") ?: (if (isImg) extra else null), tab)
                            true
                        }
                        web.requestFocusNodeHref(h.obtainMessage())
                    }
                    true
                }
                else -> false
            }
        }
        web.setOnGenericMotionListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_SCROLL && (ev.metaState and KeyEvent.META_CTRL_ON) != 0) {
                zoomBy(tab, if (ev.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0) 1.1f else 1f / 1.1f)
                true
            } else false
        }
    }

    private fun select(t: Tab) {
        cur = t
        holder.removeAllViews()
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        holder.addView(t.web, FrameLayout.LayoutParams(MATCH, MATCH))
        setAddress(t.url)
        updateNav()
        updateStar()
        updateShield()
        refreshTabs()
        window?.setTitle(t.title + " - Browser")
        reloadBtn.text = if (t.loading) "\u2715" else "\u27F3"
        t.web.requestFocus()
    }

    private fun closeTab(t: Tab) {
        if (t.url.isNotEmpty() && !t.url.startsWith(homeBase) && !t.priv) closedUrls.add(t.url)
        if (tabs.size <= 1) {
            window?.let { act.closeWindow(it) }
            return
        }
        val idx = tabs.indexOf(t)
        tabs.remove(t)
        holder.removeView(t.web)
        t.web.destroy()
        if (cur === t) select(tabs[(idx - 1).coerceAtLeast(0)]) else refreshTabs()
    }

    private fun refreshTabs() {
        tabStrip.removeAllViews()
        for (t in tabs.toList()) {
            val item = LinearLayout(act)
            item.orientation = LinearLayout.HORIZONTAL
            item.gravity = Gravity.CENTER_VERTICAL
            item.isClickable = true
            val base = if (t === cur) (if (t.priv) c(0xFF3B2A57) else c(0xFF2B2B2B)) else 0
            item.background = Ui.stateBg(act.dp(6).toFloat(), base)
            item.setOnClickListener { select(t) }
            val menu = {
                MenuPopup.show(
                    act, null,
                    listOf(
                        MI("Reload") { t.web.reload() },
                        MI("Duplicate tab") { newTab(t.url) },
                        MI("Close other tabs") { tabs.toList().filter { it !== t }.forEach { closeTab(it) }; select(t) },
                        MI("Close tab", "Ctrl+W") { closeTab(t) }
                    )
                )
            }
            item.setOnLongClickListener { menu(); true }
            item.setOnContextClickListener { menu(); true }
            item.hand()
            val ic = t.icon
            if (ic != null) {
                val iv = ImageView(act)
                iv.setImageBitmap(ic)
                iv.setPadding(act.dp(8), 0, 0, 0)
                item.addView(iv, lp(act.dp(24), act.dp(16)))
            } else if (t.priv) {
                item.addView(act.label("\uD83D\uDD76", 12f), lp(WRAP, WRAP).also { it.leftMargin = act.dp(8) })
            }
            val label = act.label(t.title, 12f, if (t === cur) Ui.text else Ui.textDim)
            label.setSingleLine()
            label.ellipsize = android.text.TextUtils.TruncateAt.END
            label.maxWidth = act.dp(150)
            label.setPadding(act.dp(8), 0, act.dp(4), 0)
            item.addView(label, lp(WRAP, WRAP))
            val x = act.label("\u2715", 11f, Ui.textDim)
            x.gravity = Gravity.CENTER
            x.isClickable = true
            x.background = Ui.stateBg(act.dp(10).toFloat())
            x.setOnClickListener { closeTab(t) }
            x.hand()
            item.addView(x, lp(act.dp(22), act.dp(22)))
            val il = lp(WRAP, act.dp(28))
            il.setMargins(act.dp(2), act.dp(3), act.dp(2), act.dp(3))
            tabStrip.addView(item, il)
        }
        val plus = tool("+") { newTab(null) }
        plus.textSize = 18f
        plus.setOnLongClickListener {
            MenuPopup.show(act, plus, listOf(MI("New tab", "Ctrl+T") { newTab(null) }, MI("New private tab", "Ctrl+Shift+N") { newTab(null, true) }))
            true
        }
        plus.setOnContextClickListener {
            MenuPopup.show(act, plus, listOf(MI("New tab", "Ctrl+T") { newTab(null) }, MI("New private tab", "Ctrl+Shift+N") { newTab(null, true) }))
            true
        }
        tabStrip.addView(plus, lp(act.dp(32), act.dp(28)))
    }

    // ---------------------------------------------------------------- navigation & address bar

    private fun normalize(raw: String): String {
        val t = raw.trim()
        val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")
        return when {
            t.startsWith("http://") || t.startsWith("https://") || t.startsWith("about:") -> t
            ip.matches(t) || t.startsWith("localhost") -> "http://$t"
            t.contains(" ") || !t.contains(".") -> engineUrl() + Uri.encode(t)
            else -> "https://$t"
        }
    }

    private fun go(raw: String) {
        if (raw.isBlank()) return
        hideSugg()
        cur?.web?.loadUrl(normalize(raw))
        cur?.web?.requestFocus()
    }

    private fun setAddress(url: String?) {
        suppress = true
        val u = url ?: ""
        address.setText(if (u.startsWith(homeBase) || u == "about:blank") "" else u)
        suppress = false
        lockView.text = when {
            u.startsWith("https://") && !u.startsWith("https://nerdydesk.local") -> "\uD83D\uDD12"
            u.startsWith("http://") -> "\u26A0"
            else -> ""
        }
        lockView.setTextColor(if (u.startsWith("http://")) c(0xFFFFB900) else Ui.textDim)
    }

    private fun updateNav() {
        val w = cur?.web ?: return
        backBtn.alpha = if (w.canGoBack()) 1f else 0.4f
        fwdBtn.alpha = if (w.canGoForward()) 1f else 0.4f
    }

    private fun updateStar() {
        val u = cur?.url ?: ""
        val on = u.isNotEmpty() && store.has("br_bm", u)
        starBtn.text = if (on) "\u2605" else "\u2606"
        starBtn.setTextColor(if (on) c(0xFFFFB900) else Ui.text)
    }

    private fun scheduleShield() {
        if (shieldQueued) return
        shieldQueued = true
        ui.postDelayed({
            shieldQueued = false
            updateShield()
        }, 400)
    }

    private fun updateShield() {
        val t = cur ?: return
        val on = shieldOn(t)
        shieldBtn.text = "\uD83D\uDEE1 " + (if (on) t.blocked.toString() else "off")
        shieldBtn.setTextColor(if (on) c(0xFF6CCB5F) else Ui.textDim)
    }

    private fun injectShield(t: Tab) {
        if (!shieldOn(t) || shieldJs.isEmpty()) return
        val cfg = JSONObject()
        cfg.put("allow", JSONArray(allowList()))
        cfg.put("signin", true)
        cfg.put("dark", t.dark)
        cfg.put("dw", 0)
        cfg.put("spoof", false)
        cfg.put("rtc", false)
        cfg.put("beacon", true)
        cfg.put("gpc", true)
        cfg.put("ref", "default")
        cfg.put("forceZoom", true)
        cfg.put("cosmetic", true)
        cfg.put("consent", true)
        cfg.put("hide", JSONArray())
        cfg.put("yt", true)
        t.web.evaluateJavascript(shieldJs.replace("__NB_CFG__", cfg.toString()), null)
    }

    private fun showSugg(q: String) {
        val text = q.trim()
        sugg.removeAllViews()
        if (text.isEmpty()) {
            sugg.visibility = View.GONE
            return
        }
        val low = text.lowercase(Locale.ROOT)
        val seen = HashSet<String>()
        fun add(icon: String, title: String, url: String) {
            if (sugg.childCount >= 7 || !seen.add(url)) return
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(10), act.dp(7), act.dp(10), act.dp(7))
            r.isClickable = true
            r.background = Ui.stateBg(act.dp(5).toFloat())
            r.addView(act.label(icon, 13f), lp(act.dp(26), WRAP))
            val tv = act.label(title, 13f)
            tv.setSingleLine()
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            r.addView(tv, lp(0, WRAP, 1f))
            val uv = act.label(url.removePrefix("https://").removePrefix("http://"), 11f, Ui.textDim)
            uv.setSingleLine()
            uv.ellipsize = android.text.TextUtils.TruncateAt.END
            uv.maxWidth = act.dp(190)
            r.addView(uv)
            r.setOnClickListener { go(url) }
            sugg.addView(r)
        }
        add("\uD83D\uDD0D", "Search for \u201C$text\u201D", engineUrl() + Uri.encode(text))
        for (key in listOf("br_bm", "br_hist")) {
            val a = store.list(key)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val u = o.optString("u")
                val t = o.optString("t")
                if (u.lowercase(Locale.ROOT).contains(low) || t.lowercase(Locale.ROOT).contains(low)) {
                    add(if (key == "br_bm") "\u2605" else "\uD83D\uDD52", if (t.isEmpty()) u else t, u)
                }
            }
        }
        sugg.visibility = View.VISIBLE
    }

    private fun hideSugg() {
        sugg.visibility = View.GONE
    }

    private fun loadHome(t: Tab) {
        t.web.loadDataWithBaseURL(homeBase, newTabHtml(t.priv), "text/html", "utf-8", null)
    }

    private fun newTabHtml(priv: Boolean): String {
        val sb = StringBuilder()
        val bg = if (priv) "radial-gradient(circle at 30% 20%,#3b2a57,#14101f)" else "radial-gradient(circle at 30% 20%,#18324f,#0b1020)"
        sb.append("<!doctype html><html><head><title>New tab</title><meta name=viewport content='width=device-width,initial-scale=1'><style>")
        sb.append("body{margin:0;min-height:100vh;background:$bg;color:#fff;font-family:Segoe UI,Roboto,sans-serif;display:flex;flex-direction:column;align-items:center;padding-top:9vh}")
        sb.append("#t{font-size:64px;font-weight:200}#d{opacity:.7;margin-bottom:26px}")
        sb.append("form{width:min(600px,88vw)}input{width:100%;box-sizing:border-box;padding:15px 22px;border-radius:28px;border:1px solid #ffffff33;background:#ffffff14;color:#fff;font-size:17px;outline:none}")
        sb.append("input:focus{border-color:#4cc2ff;background:#ffffff22}.g{display:flex;flex-wrap:wrap;justify-content:center;gap:14px;margin-top:36px;max-width:760px}")
        sb.append("a{width:96px;text-decoration:none;color:#fff;text-align:center;font-size:12px}a i{display:flex;width:56px;height:56px;margin:0 auto 8px;border-radius:16px;background:#ffffff1c;align-items:center;justify-content:center;font-style:normal;font-size:24px;font-weight:600}")
        sb.append("a:hover i{background:#ffffff33}</style></head><body>")
        sb.append("<div id=t></div><div id=d></div>")
        if (priv) sb.append("<div style='opacity:.8;margin-bottom:18px'>\uD83D\uDD76 Private tab \u2013 no history is saved</div>")
        sb.append("<form action='").append(engineUrl().substringBefore("?")).append("' method=get><input name=q placeholder='Search the web or type an address' autofocus></form><div class=g>")
        val seen = HashSet<String>()
        var n = 0
        for (key in listOf("br_bm", "br_hist")) {
            val a = store.list(key)
            for (i in 0 until a.length()) {
                if (n >= 10) break
                val o = a.getJSONObject(i)
                val u = o.optString("u")
                val host = hostOf(u).removePrefix("www.")
                if (host.isEmpty() || !seen.add(host)) continue
                val t = o.optString("t").ifEmpty { host }
                sb.append("<a href='").append(u.replace("'", "%27")).append("'><i>").append(host.take(1).uppercase(Locale.ROOT)).append("</i>")
                    .append(android.text.Html.escapeHtml(t.take(18))).append("</a>")
                n++
            }
        }
        sb.append("</div><script>function k(){var n=new Date();document.getElementById('t').textContent=n.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});")
        sb.append("document.getElementById('d').textContent=n.toLocaleDateString([],{weekday:'long',month:'long',day:'numeric'})}k();setInterval(k,15000)</script></body></html>")
        return sb.toString()
    }

    // ---------------------------------------------------------------- features

    private fun toggleBookmark() {
        val t = cur ?: return
        if (t.url.isEmpty() || t.url.startsWith(homeBase)) return
        if (store.has("br_bm", t.url)) {
            store.removeUrl("br_bm", t.url)
            act.toast("Bookmark removed")
        } else {
            val o = JSONObject()
            o.put("t", t.title)
            o.put("u", t.url)
            o.put("ts", System.currentTimeMillis())
            store.addFront("br_bm", o, 500, true)
            act.toast("Bookmarked")
        }
        updateStar()
    }

    private fun zoomBy(t: Tab, f: Float) {
        val nz = (t.zoom * f).coerceIn(0.5f, 3f)
        val real = nz / t.zoom
        try {
            t.web.zoomBy(real.coerceIn(0.5f, 2f))
            t.zoom = nz
            act.toast("Zoom " + (nz * 100).toInt() + "%")
        } catch (e: Exception) {
        }
    }

    private fun setDesktop(t: Tab, on: Boolean) {
        t.desktop = on
        t.web.settings.userAgentString = if (on) desktopUa else mobileUa
        t.web.reload()
    }

    private fun setDark(t: Tab, on: Boolean) {
        t.dark = on
        if (on) {
            if (shieldJs.isEmpty() || !shieldOn(t)) {
                t.web.evaluateJavascript("(function(){var e=document.getElementById('nb-dark');if(!e){e=document.createElement('style');e.id='nb-dark';e.textContent='html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important}';document.documentElement.appendChild(e)}})()", null)
            } else {
                injectShield(t)
                t.web.evaluateJavascript("window.__nbDark&&window.__nbDark(true)", null)
            }
        } else {
            t.web.evaluateJavascript("(function(){var e=document.getElementById('nb-dark');if(e)e.remove()})()", null)
            t.web.evaluateJavascript("window.__nbDark&&window.__nbDark(false)", null)
        }
    }

    private fun reader(t: Tab) {
        t.web.evaluateJavascript(
            "(function(){var best=null,bs=0;document.querySelectorAll('article,main,[role=main],div,section').forEach(function(e){var t=0;" +
                "e.querySelectorAll(':scope > p,:scope > div > p').forEach(function(p){t+=p.innerText.length});if(t>bs){bs=t;best=e}});" +
                "if(!best||bs<200){alert('Reader mode: no article found on this page');return}var h=document.title.replace(/</g,'&lt;');var html=best.innerHTML;" +
                "document.documentElement.innerHTML='<head><meta name=viewport content=\"width=device-width,initial-scale=1\"><style>body{max-width:720px;margin:40px auto;padding:0 20px;font:19px/1.7 Georgia,serif;background:#fafafa;color:#222}" +
                "img{max-width:100%;height:auto}a{color:#0b57d0}h1{font:700 30px sans-serif}pre{overflow:auto}</style></head><body><h1>'+h+'</h1>'+html+'</body>'})()",
            null
        )
    }

    private fun printPage(t: Tab) {
        try {
            val pm = act.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = t.title.ifEmpty { "page" }
            pm.print(name, t.web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            act.toast("Printing isn't available")
        }
    }

    private fun share(t: Tab) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, t.url)
        act.startSafely(Intent.createChooser(i, "Share page").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun copy(s: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", s))
        act.toast("Copied")
    }

    private fun downloadUrl(u: String) {
        val cur = cur ?: return
        try {
            val req = DownloadManager.Request(Uri.parse(u))
            CookieManager.getInstance().getCookie(u)?.let { req.addRequestHeader("cookie", it) }
            req.addRequestHeader("User-Agent", cur.web.settings.userAgentString)
            val name = URLUtil.guessFileName(u, null, null)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            val o = JSONObject()
            o.put("t", name)
            o.put("u", u)
            o.put("p", File(Files.downloads(), name).absolutePath)
            o.put("ts", System.currentTimeMillis())
            store.addFront("br_dl", o, 200, false)
            act.toast("Downloading $name")
        } catch (e: Exception) {
            act.toast("Download failed")
        }
    }

    private fun saveVideo(t: Tab) {
        t.web.evaluateJavascript("(function(){var v=document.querySelector('video');return v?(v.currentSrc||v.src||''):''})()") { r ->
            val u = (r ?: "").trim('"')
            if (u.startsWith("http")) downloadUrl(u) else act.toast("No directly downloadable video found on this page")
        }
    }

    private fun linkMenu(link: String?, img: String?, tab: Tab) {
        val items = ArrayList<MI>()
        if (link != null) {
            items.add(MI("Open in new tab") { newTab(link, tab.priv) })
            items.add(MI("Open in background tab") { newTab(link, tab.priv, true) })
            items.add(MI("Copy link address") { copy(link) })
        }
        if (img != null) {
            if (items.isNotEmpty()) items.add(MI("", sep = true))
            items.add(MI("Open image in new tab") { newTab(img, tab.priv) })
            items.add(MI("Download image") { downloadUrl(img) })
            items.add(MI("Copy image address") { copy(img) })
        }
        if (items.isNotEmpty()) MenuPopup.show(act, null, items)
    }

    private fun shieldMenu() {
        val t = cur ?: return
        val h = hostOf(t.url)
        val allowed = allowList().contains(h)
        MenuPopup.show(
            act, shieldBtn,
            listOf(
                MI("Blocked on this page: ${t.blocked}", "") {},
                MI("", sep = true),
                MI("Shield on for this site", "", !allowed && h.isNotEmpty()) {
                    val l = allowList()
                    if (allowed) l.remove(h) else l.add(h)
                    act.prefs.edit().putString("br_allow", JSONArray(l).toString()).apply()
                    t.web.reload()
                },
                MI("Ad & tracker blocker (all sites)", "", shieldEnabled()) {
                    act.prefs.edit().putBoolean("br_shield", !shieldEnabled()).apply()
                    t.web.reload()
                }
            )
        )
    }

    private fun mainMenu(anchor: View) {
        val t = cur ?: return
        MenuPopup.show(
            act, anchor,
            listOf(
                MI("New tab", "Ctrl+T") { newTab(null) },
                MI("New private tab", "Ctrl+Shift+N") { newTab(null, true) },
                MI("Reopen closed tab", "Ctrl+Shift+T") { reopen() },
                MI("", sep = true),
                MI("Bookmarks", "Ctrl+Shift+O") { openPanel("br_bm") },
                MI("History", "Ctrl+H") { openPanel("br_hist") },
                MI("Downloads", "Ctrl+J") { openPanel("br_dl") },
                MI("", sep = true),
                MI("Find in page", "Ctrl+F") { openFind() },
                MI("Desktop site", "", t.desktop) { setDesktop(t, !t.desktop) },
                MI("Dark pages", "", t.dark) { setDark(t, !t.dark) },
                MI("Reader mode") { reader(t) },
                MI("Zoom in", "Ctrl +") { zoomBy(t, 1.1f) },
                MI("Zoom out", "Ctrl \u2212") { zoomBy(t, 1f / 1.1f) },
                MI("Reset zoom", "Ctrl 0") { zoomBy(t, 1f / t.zoom) },
                MI("", sep = true),
                MI("Save video on this page") { saveVideo(t) },
                MI("Print / Save as PDF", "Ctrl+P") { printPage(t) },
                MI("Share page") { share(t) },
                MI("Copy page address") { copy(t.url) },
                MI("", sep = true),
                MI("Search engine: " + (act.prefs.getString("br_engine", "Google") ?: "Google") + " \u203A") { engineMenu(anchor) },
                MI("Clear browsing data\u2026") { clearData() }
            )
        )
    }

    private fun engineMenu(anchor: View) {
        val cur = act.prefs.getString("br_engine", "Google")
        MenuPopup.show(act, anchor, engines.keys.map { n ->
            MI(n, "", n == cur) { act.prefs.edit().putString("br_engine", n).apply() }
        })
    }

    private fun clearData() {
        AlertDialog.Builder(act).setTitle("Clear browsing data")
            .setMessage("Delete history, cookies and cached files?")
            .setPositiveButton("Clear") { _, _ ->
                store.clear("br_hist")
                CookieManager.getInstance().removeAllCookies(null)
                tabs.forEach { it.web.clearCache(true) }
                act.toast("Browsing data cleared")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun reopen() {
        if (closedUrls.isEmpty()) return
        newTab(closedUrls.removeAt(closedUrls.size - 1))
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        findInput.selectAll()
        cur?.web?.setFindListener { active, count, done ->
            if (done) findCount.text = if (count == 0) "No matches" else "${active + 1}/$count"
        }
    }

    private fun closeFind() {
        findBar.visibility = View.GONE
        cur?.web?.clearMatches()
        cur?.web?.requestFocus()
    }

    // ---------------------------------------------------------------- side panel (bookmarks / history / downloads)

    private fun openPanel(key: String) {
        closePanel()
        val p = LinearLayout(act)
        p.orientation = LinearLayout.VERTICAL
        p.setBackgroundColor(c(0xFA202020))
        p.elevation = act.dp(14).toFloat()
        p.isClickable = true
        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(act.dp(8), act.dp(6), act.dp(6), act.dp(6))
        fun tabBtn(label: String, k: String) {
            val b = Ui.button(act, label) { openPanel(k) }
            if (k == key) b.background = Ui.rect(Ui.accent, act.dp(6).toFloat())
            head.addView(b, lp(WRAP, WRAP).also { it.rightMargin = act.dp(4) })
        }
        tabBtn("\u2605 Bookmarks", "br_bm")
        tabBtn("\uD83D\uDD52 History", "br_hist")
        tabBtn("\u2B07 Downloads", "br_dl")
        head.addView(View(act), lp(0, 1, 1f))
        head.addView(tool("\u2715") { closePanel() }, lp(act.dp(32), act.dp(32)))
        p.addView(head, lp(MATCH, WRAP))
        val q = EditText(act)
        q.setSingleLine()
        q.hint = "Search"
        q.textSize = 13f
        q.setTextColor(Ui.text)
        q.setHintTextColor(Ui.textDim)
        q.background = Ui.rect(c(0xFF333333), act.dp(6).toFloat())
        q.setPadding(act.dp(10), 0, act.dp(10), 0)
        p.addView(q, lp(MATCH, act.dp(32)).also { it.setMargins(act.dp(8), 0, act.dp(8), act.dp(6)) })
        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(act)
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        p.addView(sv, lp(MATCH, 0, 1f))
        p.addView(
            Ui.button(act, if (key == "br_hist") "Clear history" else if (key == "br_dl") "Clear list" else "Remove all bookmarks") {
                store.clear(key)
                fillPanel(list, key, "")
            }, lp(MATCH, WRAP).also { it.setMargins(act.dp(8), act.dp(6), act.dp(8), act.dp(8)) }
        )
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                fillPanel(list, key, s?.toString() ?: "")
            }
        })
        fillPanel(list, key, "")
        panel = p
        frame.addView(p, FrameLayout.LayoutParams(act.dp(360), MATCH, Gravity.END))
    }

    private fun closePanel() {
        panel?.let { frame.removeView(it) }
        panel = null
    }

    private fun fillPanel(list: LinearLayout, key: String, filter: String) {
        list.removeAllViews()
        val a = store.list(key)
        val f = filter.trim().lowercase(Locale.ROOT)
        val df = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
        var shown = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val u = o.optString("u")
            val t = o.optString("t").ifEmpty { u }
            if (f.isNotEmpty() && !t.lowercase(Locale.ROOT).contains(f) && !u.lowercase(Locale.ROOT).contains(f)) continue
            shown++
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(10), act.dp(6), act.dp(4), act.dp(6))
            r.isClickable = true
            r.background = Ui.stateBg(act.dp(5).toFloat())
            val tx = LinearLayout(act)
            tx.orientation = LinearLayout.VERTICAL
            val tt = act.label(t, 13f)
            tt.setSingleLine()
            tt.ellipsize = android.text.TextUtils.TruncateAt.END
            tx.addView(tt)
            val sub = if (key == "br_dl") df.format(Date(o.optLong("ts"))) + "  \u2022  tap to open" else u.removePrefix("https://").removePrefix("http://")
            val uu = act.label(sub, 11f, Ui.textDim)
            uu.setSingleLine()
            uu.ellipsize = android.text.TextUtils.TruncateAt.END
            tx.addView(uu)
            r.addView(tx, lp(0, WRAP, 1f))
            val x = act.label("\u2715", 12f, Ui.textDim)
            x.gravity = Gravity.CENTER
            x.isClickable = true
            x.background = Ui.stateBg(act.dp(12).toFloat())
            x.setOnClickListener {
                store.removeUrl(key, u)
                fillPanel(list, key, filter)
            }
            r.addView(x, lp(act.dp(28), act.dp(28)))
            r.setOnClickListener {
                if (key == "br_dl") {
                    val p = File(o.optString("p"))
                    if (p.exists()) act.openFile(p) else act.toast("File not found")
                } else {
                    cur?.web?.loadUrl(u)
                    closePanel()
                }
            }
            r.setOnLongClickListener {
                if (key != "br_dl") { newTab(u); closePanel() }
                true
            }
            list.addView(r)
        }
        if (shown == 0) {
            val e = act.label("Nothing here yet.", 13f, Ui.textDim)
            e.setPadding(act.dp(14), act.dp(14), 0, 0)
            list.addView(e)
        }
    }

    // ---------------------------------------------------------------- keys & lifecycle

    override fun onShortcut(e: KeyEvent): Boolean {
        val k = e.keyCode
        val t = cur
        if (e.isCtrlPressed) {
            when (k) {
                KeyEvent.KEYCODE_T -> { if (e.isShiftPressed) reopen() else newTab(null); return true }
                KeyEvent.KEYCODE_N -> { if (e.isShiftPressed) { newTab(null, true); return true } }
                KeyEvent.KEYCODE_W -> { t?.let { closeTab(it) }; return true }
                KeyEvent.KEYCODE_L -> { address.requestFocus(); return true }
                KeyEvent.KEYCODE_R -> { t?.web?.reload(); return true }
                KeyEvent.KEYCODE_F -> { openFind(); return true }
                KeyEvent.KEYCODE_D -> { toggleBookmark(); return true }
                KeyEvent.KEYCODE_H -> { openPanel("br_hist"); return true }
                KeyEvent.KEYCODE_J -> { openPanel("br_dl"); return true }
                KeyEvent.KEYCODE_O -> { if (e.isShiftPressed) { openPanel("br_bm"); return true } }
                KeyEvent.KEYCODE_P -> { t?.let { printPage(it) }; return true }
                KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS, KeyEvent.KEYCODE_NUMPAD_ADD -> { t?.let { zoomBy(it, 1.1f) }; return true }
                KeyEvent.KEYCODE_MINUS, KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> { t?.let { zoomBy(it, 1f / 1.1f) }; return true }
                KeyEvent.KEYCODE_0 -> { t?.let { zoomBy(it, 1f / it.zoom) }; return true }
                KeyEvent.KEYCODE_TAB -> {
                    if (tabs.size > 1 && t != null) {
                        val i = tabs.indexOf(t)
                        select(tabs[(i + (if (e.isShiftPressed) tabs.size - 1 else 1)) % tabs.size])
                    }
                    return true
                }
            }
            if (k in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9) {
                val i = k - KeyEvent.KEYCODE_1
                if (i < tabs.size) select(tabs[if (k == KeyEvent.KEYCODE_9) tabs.size - 1 else i])
                return true
            }
        }
        if (k == KeyEvent.KEYCODE_F5) { t?.web?.reload(); return true }
        if (k == KeyEvent.KEYCODE_F6) { address.requestFocus(); return true }
        if (k == KeyEvent.KEYCODE_ESCAPE) {
            if (findBar.visibility == View.VISIBLE) { closeFind(); return true }
            if (panel != null) { closePanel(); return true }
            if (sugg.visibility == View.VISIBLE) { hideSugg(); return true }
        }
        if (e.isAltPressed && k == KeyEvent.KEYCODE_DPAD_LEFT) { t?.web?.let { if (it.canGoBack()) it.goBack() }; return true }
        if (e.isAltPressed && k == KeyEvent.KEYCODE_DPAD_RIGHT) { t?.web?.let { if (it.canGoForward()) it.goForward() }; return true }
        return false
    }

    override fun onBack(): Boolean {
        if (customView != null) {
            customCb?.onCustomViewHidden()
            customView?.let { frame.removeView(it) }
            customView = null
            act.exitFullscreen()
            return true
        }
        if (panel != null) { closePanel(); return true }
        val w = cur?.web ?: return false
        if (w.canGoBack()) { w.goBack(); return true }
        return false
    }

    override fun onPause() {
        tabs.forEach { it.web.onPause() }
    }

    override fun onResume() {
        tabs.forEach { it.web.onResume() }
    }

    override fun onClose() {
        holder.removeAllViews()
        for (t in tabs) t.web.destroy()
        tabs.clear()
    }
}
