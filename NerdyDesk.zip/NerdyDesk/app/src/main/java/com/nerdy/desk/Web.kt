package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import java.io.ByteArrayInputStream

object WebKit {
    const val HOST = "nerdydesk.local"

    /** Makes blob: downloads (backups, exports) land in Downloads instead of silently failing. */
    val SHIM = "(function(){if(window.__ndshim)return;window.__ndshim=1;" +
        "function send(n,u){fetch(u).then(function(r){return r.blob()}).then(function(b){var fr=new FileReader();" +
        "fr.onload=function(){try{NDBridge.saveBlob(n,b.type||'',String(fr.result))}catch(e){}};fr.readAsDataURL(b)})}" +
        "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;" +
        "if(a&&a.href&&a.href.indexOf('blob:')===0){e.preventDefault();e.stopPropagation();send(a.getAttribute('download')||'download',a.href)}},true);" +
        "var oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){" +
        "if(this.href&&this.href.indexOf('blob:')===0&&this.hasAttribute('download')){send(this.getAttribute('download')||'download',this.href);return}" +
        "return oc.apply(this,arguments)}})();"

    fun mimeOf(p: String): String = when (p.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js", "mjs" -> "application/javascript"
        "css" -> "text/css"
        "json", "webmanifest" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "woff2" -> "font/woff2"
        "woff" -> "font/woff"
        "ttf" -> "font/ttf"
        "mp3" -> "audio/mpeg"
        "txt" -> "text/plain"
        else -> "application/octet-stream"
    }

    /** Serves files bundled in the APK at https://nerdydesk.local/<asset path>. */
    fun assetResponse(ctx: Context, u: Uri): WebResourceResponse? {
        if (u.host != HOST) return null
        var p = (u.path ?: "").trimStart('/')
        if (p.isEmpty() || p.endsWith("/")) p += "index.html"
        return try {
            val r = WebResourceResponse(mimeOf(p), "utf-8", ctx.assets.open(p))
            r.responseHeaders = mapOf("Access-Control-Allow-Origin" to "*")
            r
        } catch (e: Exception) {
            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
    }
}

class NDBridge(private val act: MainActivity, private val confirm: Boolean = false) {
    @JavascriptInterface
    fun saveBlob(name: String, mime: String, dataUrl: String) {
        if (confirm) {
            act.runOnUiThread {
                AlertDialog.Builder(act).setTitle("Save file?")
                    .setMessage("A web page wants to save \"$name\" to your Downloads folder.")
                    .setPositiveButton("Save") { _, _ -> write(name, dataUrl) }
                    .setNegativeButton("Cancel", null).show()
            }
        } else write(name, dataUrl)
    }

    private fun write(name: String, dataUrl: String) {
        Thread {
            try {
                val i = dataUrl.indexOf(',')
                val bytes = Base64.decode(dataUrl.substring(i + 1), Base64.DEFAULT)
                val f = Files.saveToDownloads(act, name, bytes)
                act.runOnUiThread { act.toast(if (f != null) "Saved ${f.name} to Downloads" else "Couldn't save the file") }
            } catch (e: Exception) {
                act.runOnUiThread { act.toast("Couldn't save the file") }
            }
        }.start()
    }

    @JavascriptInterface
    fun copyText(t: String) {
        act.runOnUiThread {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", t))
        }
    }

    @JavascriptInterface
    fun toast(s: String) {
        act.runOnUiThread { act.toast(s) }
    }
}

/** JS dialogs, file chooser and camera/mic prompts shared by every WebView window. */
open class BaseChrome(val act: MainActivity) : WebChromeClient() {
    private fun host(url: String?): String = try {
        Uri.parse(url ?: "").host ?: "This page"
    } catch (e: Exception) {
        "This page"
    }

    override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
        AlertDialog.Builder(act).setTitle(host(url)).setMessage(message)
            .setPositiveButton("OK") { _, _ -> result?.confirm() }
            .setOnCancelListener { result?.cancel() }.show()
        return true
    }

    override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
        AlertDialog.Builder(act).setTitle(host(url)).setMessage(message)
            .setPositiveButton("OK") { _, _ -> result?.confirm() }
            .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
            .setOnCancelListener { result?.cancel() }.show()
        return true
    }

    override fun onJsPrompt(view: WebView?, url: String?, message: String?, def: String?, result: JsPromptResult?): Boolean {
        val input = EditText(act)
        input.setText(def ?: "")
        AlertDialog.Builder(act).setTitle(host(url)).setMessage(message).setView(input)
            .setPositiveButton("OK") { _, _ -> result?.confirm(input.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
            .setOnCancelListener { result?.cancel() }.show()
        return true
    }

    override fun onShowFileChooser(
        webView: WebView?,
        filePathCallback: ValueCallback<Array<Uri>>?,
        fileChooserParams: FileChooserParams?
    ): Boolean {
        act.filePathCallback?.onReceiveValue(null)
        act.filePathCallback = filePathCallback
        return try {
            act.startActivityForResult(fileChooserParams!!.createIntent(), MainActivity.REQ_FILE)
            true
        } catch (e: Exception) {
            act.filePathCallback = null
            false
        }
    }

    override fun onPermissionRequest(request: PermissionRequest?) {
        val r = request ?: return
        act.runOnUiThread {
            val wants = r.resources.map {
                when (it) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                    else -> "protected media"
                }
            }.joinToString(" and ")
            AlertDialog.Builder(act).setTitle(host(r.origin.toString()))
                .setMessage("Allow this site to use your $wants?")
                .setPositiveButton("Allow") { _, _ ->
                    act.requestPermissions(
                        arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO),
                        MainActivity.REQ_PERM
                    )
                    r.grant(r.resources)
                }
                .setNegativeButton("Block") { _, _ -> r.deny() }
                .setOnCancelListener { r.deny() }.show()
        }
    }
}

/** Hosts one of the user's own web apps (bundled in assets) as a desktop window. */
class HabitApp(act: MainActivity) : App(act) {
    override val title = "Neuro Orbit"
    override val icon = "\uD83E\uDDE0"
    override val previewable = false
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun build(): View {
        val box = FrameLayout(act)
        val w = WebView(act)
        web = w
        w.setBackgroundColor(c(0xFF0B0F1A))
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        w.addJavascriptInterface(NDBridge(act), "NDBridge")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return WebKit.assetResponse(act, u)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                view?.evaluateJavascript(WebKit.SHIM, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(WebKit.SHIM, null)
            }
        }
        w.webChromeClient = BaseChrome(act)
        w.loadUrl("https://" + WebKit.HOST + "/nos/index.html")
        box.addView(w, FrameLayout.LayoutParams(-1, -1))
        return box
    }

    override fun onPause() {
        web?.onPause()
    }

    override fun onResume() {
        web?.onResume()
    }

    override fun onBack(): Boolean {
        val w = web ?: return false
        if (w.canGoBack()) {
            w.goBack()
            return true
        }
        return false
    }

    override fun onClose() {
        web?.destroy()
        web = null
    }
}
