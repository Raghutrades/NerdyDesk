package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object Spin {
    private fun ease(x: Float): Float = if (x < 0.5f) 4f * x * x * x else 1f - Math.pow((-2.0 * x + 2.0), 3.0).toFloat() / 2f

    /** Windows-style ring of dots chasing each other. */
    fun draw(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, dot: Float, t: Long) {
        p.shader = null
        p.color = Color.WHITE
        for (i in 0 until 5) {
            val local = t - i * 150L
            if (local < 0) continue
            val tt = (local % 2400L) / 2400f
            val ang = (-90.0 + 360.0 * ease(tt)) * PI / 180.0
            val a = when {
                tt < 0.06f -> tt / 0.06f
                tt > 0.94f -> (1f - tt) / 0.06f
                else -> 1f
            }
            p.alpha = (255 * a).toInt().coerceIn(0, 255)
            cv.drawCircle(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat(), dot, p)
        }
    }
}

/** Windows-style boot: glowing logo, product name and the spinning dots. */
class BootView(private val act: MainActivity, private val onDone: () -> Unit) : View(act) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = SystemClock.uptimeMillis()
    private val total = 3900L
    private var finished = false
    private var glow: RadialGradient? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = minOf(w, h) * 0.16f
        glow = RadialGradient(w / 2f, h * 0.40f, s * 2.6f, c(0x552D9CFF), 0, Shader.TileMode.CLAMP)
    }

    private fun back(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val y = x - 1f
        return 1f + c3 * y * y * y + c1 * y * y
    }

    override fun onDraw(cv: Canvas) {
        val t = SystemClock.uptimeMillis() - t0
        cv.drawColor(Color.BLACK)
        val cx = width / 2f
        val cy = height * 0.40f
        val s = minOf(width, height) * 0.16f
        val pulse = 0.65f + 0.35f * sin(t / 420.0).toFloat()
        val fade = (t / 700f).coerceIn(0f, 1f)
        p.shader = glow
        p.alpha = (255 * fade * pulse).toInt()
        cv.drawCircle(cx, cy, s * 2.6f, p)
        p.shader = null
        val g = s * 0.05f
        val h = s / 2f
        val cols = intArrayOf(c(0xFF4CC2FF), c(0xFF2D9CFF), c(0xFF2D9CFF), c(0xFF0078D4))
        val rects = arrayOf(
            floatArrayOf(-h, -h, -g, -g), floatArrayOf(g, -h, h, -g),
            floatArrayOf(-h, g, -g, h), floatArrayOf(g, g, h, h)
        )
        for (i in 0 until 4) {
            val local = ((t - i * 130L) / 520f).coerceIn(0f, 1f)
            val sc = if (local <= 0f) 0f else back(local)
            p.color = cols[i]
            p.alpha = (255 * local).toInt()
            val r = rects[i]
            val pcx = cx + (r[0] + r[2]) / 2f
            val pcy = cy + (r[1] + r[3]) / 2f
            val hw = (r[2] - r[0]) / 2f * sc
            val hh = (r[3] - r[1]) / 2f * sc
            cv.drawRect(pcx - hw, pcy - hh, pcx + hw, pcy + hh, p)
        }
        val ta = ((t - 700f) / 600f).coerceIn(0f, 1f)
        p.color = Color.WHITE
        p.alpha = (230 * ta).toInt()
        p.textSize = s * 0.34f
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.18f
        cv.drawText("NERDYDESK", cx, cy + s * 1.75f, p)
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT
        if (t > 900) Spin.draw(cv, p, cx, height * 0.80f, s * 0.30f, s * 0.045f, t - 900)
        if (t >= total) {
            if (!finished) {
                finished = true
                animate().alpha(0f).setDuration(450).withEndAction { onDone() }.start()
            }
        }
        postInvalidateOnAnimation()
    }
}

/** Lock screen with big clock; tap, click or any key shows "Welcome" and reveals the desktop. */
@SuppressLint("ViewConstructor")
class LockView(private val act: MainActivity, private val onDone: () -> Unit) : FrameLayout(act) {
    private val time = TextView(act)
    private val date = TextView(act)
    private val hint = TextView(act)
    private val col = LinearLayout(act)
    private val handler = Handler(Looper.getMainLooper())
    private var unlocking = false
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            time.text = SimpleDateFormat(if (act.prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 1000)
        }
    }

    init {
        isClickable = true
        isFocusable = true
        addView(act.makeWallpaperView(), LayoutParams(MATCH, MATCH))
        val shade = View(act)
        shade.setBackgroundColor(c(0x55000000))
        addView(shade, LayoutParams(MATCH, MATCH))
        col.orientation = LinearLayout.VERTICAL
        time.textSize = 84f
        time.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        time.setTextColor(Color.WHITE)
        time.setShadowLayer(12f, 0f, 2f, Color.BLACK)
        date.textSize = 24f
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(8f, 0f, 2f, Color.BLACK)
        col.addView(time)
        col.addView(date)
        val cl = LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
        cl.leftMargin = dp(48)
        cl.bottomMargin = dp(60)
        addView(col, cl)
        hint.text = "Click, tap or press any key to sign in"
        hint.textSize = 13f
        hint.setTextColor(c(0xCCFFFFFF))
        val hl = LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hl.topMargin = dp(36)
        addView(hint, hl)
        setOnClickListener { unlock() }
        tick.run()
    }

    fun unlock() {
        if (unlocking) return
        unlocking = true
        handler.removeCallbacks(tick)
        removeAllViews()
        addView(act.makeWallpaperView(), LayoutParams(MATCH, MATCH))
        val shade = View(act)
        shade.setBackgroundColor(c(0xAA000000))
        addView(shade, LayoutParams(MATCH, MATCH))
        val w = object : View(act) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val t0 = SystemClock.uptimeMillis()
            override fun onDraw(cv: Canvas) {
                val t = SystemClock.uptimeMillis() - t0
                p.color = Color.WHITE
                p.alpha = 255
                p.textSize = dp(26).toFloat()
                p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                p.textAlign = Paint.Align.CENTER
                cv.drawText("Welcome", width / 2f, height / 2f, p)
                Spin.draw(cv, p, width / 2f, height / 2f + dp(70), dp(18).toFloat(), dp(3).toFloat(), t)
                postInvalidateOnAnimation()
            }
        }
        addView(w, LayoutParams(MATCH, MATCH))
        handler.postDelayed({
            animate().translationY(-height.toFloat()).alpha(0.4f).setDuration(380).withEndAction { onDone() }.start()
        }, 1100)
    }

    fun stop() {
        handler.removeCallbacks(tick)
    }

    val isUnlocking: Boolean get() = unlocking
}

/** Animated wallpapers. */
class AuroraView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bg: LinearGradient? = null
    private val shaders = ArrayList<RadialGradient>()
    private val cols = intArrayOf(c(0x883BA9FF), c(0x887C3AED), c(0x8820D8A8), c(0x88FF4D8D))
    var running = true
        set(v) {
            field = v
            if (v) postInvalidateOnAnimation()
        }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), c(0xFF050A18), c(0xFF0B1230), Shader.TileMode.CLAMP)
        shaders.clear()
        val r = maxOf(w, h) * 0.45f
        for (col in cols) shaders.add(RadialGradient(0f, 0f, r, col, 0, Shader.TileMode.CLAMP))
    }

    override fun onDraw(cv: Canvas) {
        p.shader = bg
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        val t = SystemClock.uptimeMillis() / 1000.0
        val r = maxOf(width, height) * 0.45f
        for (i in shaders.indices) {
            val x = width * (0.5 + 0.38 * sin(t * (0.11 + i * 0.045) + i * 1.7)).toFloat()
            val y = height * (0.5 + 0.34 * cos(t * (0.09 + i * 0.05) + i * 2.3)).toFloat()
            cv.save()
            cv.translate(x.toFloat(), y.toFloat())
            p.shader = shaders[i]
            cv.drawCircle(0f, 0f, r, p)
            cv.restore()
        }
        if (running) postInvalidateOnAnimation()
    }
}

class StarView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private val n = 170
    private val sx = FloatArray(n) { rnd.nextFloat() * 2f - 1f }
    private val sy = FloatArray(n) { rnd.nextFloat() * 2f - 1f }
    private val sz = FloatArray(n) { rnd.nextFloat() }
    private var last = SystemClock.uptimeMillis()
    var running = true
        set(v) {
            field = v
            if (v) postInvalidateOnAnimation()
        }

    override fun onDraw(cv: Canvas) {
        cv.drawColor(c(0xFF02040C))
        val now = SystemClock.uptimeMillis()
        val dt = (now - last) / 1000f
        last = now
        val cx = width / 2f
        val cy = height / 2f
        val sc = maxOf(width, height) * 0.7f
        for (i in 0 until n) {
            sz[i] -= dt * 0.18f
            if (sz[i] <= 0.02f) {
                sz[i] = 1f
                sx[i] = rnd.nextFloat() * 2f - 1f
                sy[i] = rnd.nextFloat() * 2f - 1f
            }
            val z = sz[i]
            val x = cx + sx[i] / z * sc * 0.25f
            val y = cy + sy[i] / z * sc * 0.25f
            val px = cx + sx[i] / (z + 0.06f) * sc * 0.25f
            val py = cy + sy[i] / (z + 0.06f) * sc * 0.25f
            p.color = Color.WHITE
            p.alpha = ((1f - z) * 255).toInt().coerceIn(30, 255)
            p.strokeWidth = (1f + (1f - z) * 2.2f)
            cv.drawLine(px, py, x, y, p)
        }
        if (running) postInvalidateOnAnimation()
    }
}
