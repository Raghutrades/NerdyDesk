package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Alt+Tab / Task View: cards for every open window. */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class TaskSwitcher(private val act: MainActivity) : FrameLayout(act) {
    private var list: List<WindowView> = emptyList()
    private var sel = 0
    var altMode = false
        private set
    val isOpen: Boolean get() = visibility == View.VISIBLE
    private val row = LinearLayout(act)

    init {
        visibility = View.GONE
        isClickable = true
        setBackgroundColor(c(0xCC000000.toLong() and 0xFFFFFFFFL))
        setOnClickListener { hide() }
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(dp(24), dp(24), dp(24), dp(24))
        sv.addView(row, FrameLayout.LayoutParams(WRAP, WRAP))
        sv.isFillViewport = true
        addView(sv, LayoutParams(MATCH, WRAP, Gravity.CENTER))
    }

    fun show(start: Int, alt: Boolean) {
        list = act.windows.reversed()
        altMode = alt
        sel = if (list.isEmpty()) 0 else start.coerceIn(0, list.size - 1)
        rebuild()
        visibility = View.VISIBLE
        alpha = 0f
        animate().alpha(1f).setDuration(120).start()
    }

    fun next(back: Boolean = false) {
        if (list.isEmpty()) return
        sel = (sel + (if (back) list.size - 1 else 1)) % list.size
        rebuild()
    }

    fun commit() {
        val w = list.getOrNull(sel)
        hide()
        if (w != null) act.focusWindow(w)
    }

    fun hide() {
        visibility = View.GONE
    }

    private fun preview(w: WindowView): Bitmap? {
        if (!w.app.previewable || w.minimized || w.width <= 0 || w.height <= 0) return null
        return try {
            val sc = dp(170).toFloat() / w.width
            val b = Bitmap.createBitmap(dp(170), maxOf(1, (w.height * sc).toInt()), Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            cv.scale(sc, sc)
            w.draw(cv)
            b
        } catch (e: Throwable) {
            null
        }
    }

    private fun rebuild() {
        row.removeAllViews()
        if (list.isEmpty()) {
            row.addView(context.label("No open windows", 16f, Ui.textDim))
            return
        }
        list.forEachIndexed { i, w ->
            val card = LinearLayout(act)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.setPadding(dp(8), dp(8), dp(8), dp(10))
            card.background = Ui.rect(if (i == sel) c(0x55FFFFFF) else c(0x22FFFFFF), dp(8).toFloat(), if (i == sel) Ui.accent else 0, if (i == sel) 3 else 0)
            val top = LinearLayout(act)
            top.orientation = LinearLayout.HORIZONTAL
            top.gravity = Gravity.CENTER_VERTICAL
            top.addView(context.label(w.kind.icon, 14f), lp(WRAP, WRAP))
            val tt = context.label(w.app.title, 12f)
            tt.setSingleLine()
            tt.ellipsize = android.text.TextUtils.TruncateAt.END
            tt.setPadding(dp(6), 0, 0, 0)
            top.addView(tt, lp(0, WRAP, 1f))
            val x = context.label("\u2715", 12f, Ui.textDim)
            x.gravity = Gravity.CENTER
            x.isClickable = true
            x.background = Ui.stateBg(dp(4).toFloat(), 0, c(0xFFE81123))
            x.setOnClickListener {
                act.closeWindow(w)
                list = list.filter { it !== w }
                if (sel >= list.size) sel = maxOf(0, list.size - 1)
                rebuild()
            }
            top.addView(x, lp(dp(24), dp(24)))
            card.addView(top, lp(dp(170), WRAP))
            val bmp = preview(w)
            if (bmp != null) {
                val iv = ImageView(act)
                iv.setImageBitmap(bmp)
                iv.background = Ui.rect(Ui.bgDark, 0f)
                card.addView(iv, lp(dp(170), minOf(dp(120), bmp.height)).also { it.topMargin = dp(6) })
            } else {
                val ic = context.label(w.kind.icon, 44f)
                ic.gravity = Gravity.CENTER
                ic.background = Ui.rect(Ui.bgDark, 0f)
                card.addView(ic, lp(dp(170), dp(110)).also { it.topMargin = dp(6) })
            }
            card.isClickable = true
            card.setOnClickListener {
                hide()
                act.focusWindow(w)
            }
            card.hand()
            val l = lp(WRAP, WRAP)
            l.setMargins(dp(8), 0, dp(8), 0)
            row.addView(card, l)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean = super.dispatchTouchEvent(ev)
}

/** Action centre: calendar, quick tiles, sliders and the now-playing strip. */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class QuickPanel(private val act: MainActivity) : FrameLayout(act) {
    val isOpen: Boolean get() = visibility == View.VISIBLE
    private val panel = LinearLayout(act)
    private var calMonth = Calendar.getInstance()

    init {
        visibility = View.GONE
        isClickable = true
        setOnClickListener { close() }
        panel.orientation = LinearLayout.VERTICAL
        panel.background = Ui.rect(c(0xF5202020), dp(10).toFloat(), Ui.border, 1)
        panel.setPadding(dp(14), dp(12), dp(14), dp(14))
        panel.isClickable = true
        panel.elevation = dp(16).toFloat()
        val l = LayoutParams(dp(372), WRAP, Gravity.BOTTOM or Gravity.END)
        l.rightMargin = dp(8)
        l.bottomMargin = dp(8)
        addView(panel, l)
    }

    fun toggle() {
        if (isOpen) close() else open()
    }

    fun open() {
        act.startMenu.close()
        calMonth = Calendar.getInstance()
        build()
        visibility = View.VISIBLE
        panel.alpha = 0f
        panel.translationY = dp(30).toFloat()
        panel.animate().alpha(1f).translationY(0f).setDuration(170).start()
    }

    fun close() {
        visibility = View.GONE
    }

    private fun tile(emoji: String, name: String, on: Boolean, action: () -> Unit): View {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(dp(6).toFloat(), if (on) Ui.accent else c(0xFF333333), if (on) Ui.accent else c(0xFF444444), c(0xFF555555), c(0xFF444444))
        t.addView(context.label(emoji, 18f))
        val n = context.label(name, 11f)
        n.setSingleLine()
        t.addView(n)
        t.setOnClickListener { action() }
        t.hand()
        return t
    }

    private fun build() {
        panel.removeAllViews()
        val now = Date()
        val head = LinearLayout(act)
        head.orientation = LinearLayout.VERTICAL
        head.addView(context.label(SimpleDateFormat(if (act.prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm a", Locale.getDefault()).format(now), 30f))
        head.addView(context.label(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now), 13f, Ui.textDim))
        panel.addView(head)

        // calendar
        val mh = LinearLayout(act)
        mh.orientation = LinearLayout.HORIZONTAL
        mh.gravity = Gravity.CENTER_VERTICAL
        mh.setPadding(0, dp(10), 0, dp(4))
        val title = context.label(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calMonth.time), 14f)
        mh.addView(title, lp(0, WRAP, 1f))
        val prev = Ui.button(act, "\u2039") { calMonth.add(Calendar.MONTH, -1); build() }
        val nxt = Ui.button(act, "\u203A") { calMonth.add(Calendar.MONTH, 1); build() }
        mh.addView(prev, lp(dp(40), dp(32)))
        mh.addView(nxt, lp(dp(40), dp(32)))
        panel.addView(mh)
        val grid = GridLayout(act)
        grid.columnCount = 7
        val days = arrayOf("S", "M", "T", "W", "T", "F", "S")
        for (d in days) grid.addView(dayCell(d, false, true))
        val first = calMonth.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = first.get(Calendar.DAY_OF_WEEK) - 1
        val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = Calendar.getInstance()
        val isThisMonth = today.get(Calendar.YEAR) == first.get(Calendar.YEAR) && today.get(Calendar.MONTH) == first.get(Calendar.MONTH)
        for (i in 0 until offset) grid.addView(dayCell("", false, false))
        for (d in 1..dim) grid.addView(dayCell(d.toString(), isThisMonth && d == today.get(Calendar.DAY_OF_MONTH), false))
        panel.addView(grid)

        // tiles
        val tiles = GridLayout(act)
        tiles.columnCount = 3
        val items = ArrayList<View>()
        items.add(tile("\uD83D\uDCF6", "Network", false) {
            close()
            val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            act.startSafely(i)
        })
        items.add(tile("\uD83D\uDD35", "Bluetooth", false) { close(); act.startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        items.add(tile("\uD83D\uDDA5\uFE0F", "Project", false) { close(); act.startSafely(Intent(Settings.ACTION_CAST_SETTINGS)) })
        items.add(tile("\uD83C\uDF19", "Night light", act.prefs.getBoolean("night", false)) {
            act.setNightLight(!act.prefs.getBoolean("night", false))
            build()
        })
        items.add(tile("\u26F6", "Full screen", act.prefs.getBoolean("fullscreen", true)) {
            act.prefs.edit().putBoolean("fullscreen", !act.prefs.getBoolean("fullscreen", true)).apply()
            act.applyDisplayPrefs()
            build()
        })
        items.add(tile("\u2728", "Animations", act.animations) {
            act.prefs.edit().putBoolean("anim", !act.animations).apply()
            build()
        })
        items.add(tile("\u2708\uFE0F", "Airplane", false) { close(); act.startSafely(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) })
        items.add(tile("\uD83D\uDD12", "Lock", false) { close(); act.lockNow() })
        items.add(tile("\u2699\uFE0F", "All settings", false) { close(); act.open(AppKind.SETTINGS, null) })
        for (v in items) {
            val g = GridLayout.LayoutParams()
            g.width = dp(112)
            g.height = dp(56)
            g.setMargins(dp(3), dp(3), dp(3), dp(3))
            tiles.addView(v, g)
        }
        val tl = lp(WRAP, WRAP)
        tl.topMargin = dp(10)
        panel.addView(tiles, tl)

        // sliders
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        panel.addView(sliderRow("\uD83D\uDD06", 100, (act.currentBrightness() * 100).toInt()) { act.setBrightness(it / 100f) })
        panel.addView(
            sliderRow("\uD83D\uDD0A", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
            }
        )

        // now playing
        val cur = MusicEngine.current()
        if (cur != null) {
            val np = LinearLayout(act)
            np.orientation = LinearLayout.HORIZONTAL
            np.gravity = Gravity.CENTER_VERTICAL
            np.setPadding(dp(10), dp(6), dp(6), dp(6))
            np.background = Ui.rect(c(0xFF2B2B2B), dp(8).toFloat())
            val info = LinearLayout(act)
            info.orientation = LinearLayout.VERTICAL
            val tt = context.label(cur.title, 13f)
            tt.setSingleLine()
            tt.ellipsize = android.text.TextUtils.TruncateAt.END
            info.addView(tt)
            info.addView(context.label(cur.artist, 11f, Ui.textDim))
            np.addView(info, lp(0, WRAP, 1f))
            np.addView(Ui.button(act, "\u23EE") { MusicEngine.prev() }, lp(WRAP, WRAP))
            np.addView(Ui.button(act, if (MusicEngine.isPlaying()) "\u23F8" else "\u25B6") { MusicEngine.toggle(); build() }, lp(WRAP, WRAP))
            np.addView(Ui.button(act, "\u23ED") { MusicEngine.next() }, lp(WRAP, WRAP))
            val nl = lp(MATCH, WRAP)
            nl.topMargin = dp(10)
            panel.addView(np, nl)
        }
    }

    private fun dayCell(t: String, today: Boolean, header: Boolean): View {
        val v = TextView(act)
        v.text = t
        v.textSize = 12f
        v.gravity = Gravity.CENTER
        v.setTextColor(if (today) Ui.text else if (header) Ui.textDim else Ui.text)
        if (today) v.background = Ui.rect(Ui.accent, dp(18).toFloat())
        val g = GridLayout.LayoutParams()
        g.width = dp(50)
        g.height = dp(32)
        v.layoutParams = g
        return v
    }

    private fun sliderRow(icon: String, max: Int, value: Int, onChange: (Int) -> Unit): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, 0)
        r.addView(context.label(icon, 16f), lp(dp(30), WRAP))
        val sb = SeekBar(act)
        sb.max = max
        sb.progress = value.coerceIn(0, max)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        r.addView(sb, lp(0, WRAP, 1f))
        return r
    }
}
