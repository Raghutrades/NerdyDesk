package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import kotlin.math.abs
import kotlin.math.sin

/** Animated equaliser bars shown while music plays. */
class EqView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val n = 32
    private val h = FloatArray(n)
    private val phase = FloatArray(n) { (it * 0.7f) }

    override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) {
        p.shader = LinearGradient(0f, hh.toFloat(), 0f, 0f, Ui.accent, c(0xFF7CE0FF), Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        val playing = MusicEngine.isPlaying()
        val t = SystemClock.uptimeMillis() / 1000f
        val bw = width / n.toFloat()
        for (i in 0 until n) {
            val target = if (playing) 0.18f + 0.78f * abs(sin(t * (2.1f + (i % 5) * 0.55f) + phase[i])) * (0.55f + 0.45f * sin(t * 0.9f + i * 0.3f)) else 0.04f
            h[i] += (target - h[i]) * 0.22f
            val bh = (height * h[i]).coerceAtLeast(2f)
            cv.drawRoundRect(i * bw + bw * 0.18f, height - bh, (i + 1) * bw - bw * 0.18f, height.toFloat(), bw * 0.3f, bw * 0.3f, p)
        }
        postInvalidateOnAnimation()
    }
}

class MusicApp(act: MainActivity, private val arg: String?) : App(act) {
    override val title = "Music"
    override val icon = "\uD83C\uDFB5"

    private var all: List<Track> = emptyList()
    private var rows: List<Any> = emptyList()
    private var mode = 0 // 0 songs, 1 albums, 2 artists
    private var group: String? = null
    private var query = ""
    private var loaded = false
    private var pendingPath: String? = arg
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var list: ListView
    private lateinit var msg: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var artFrame: FrameLayout
    private lateinit var art: ImageView
    private lateinit var tTitle: TextView
    private lateinit var tArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var playBtn: TextView
    private lateinit var shuffleBtn: TextView
    private lateinit var repeatBtn: TextView
    private var dragging = false
    private var running = true

    private val listener: () -> Unit = { act.runOnUiThread { refreshNow() } }
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!dragging) {
                val d = MusicEngine.dur()
                seek.max = maxOf(1, d)
                seek.progress = MusicEngine.pos()
                tCur.text = Files.fmtTime(MusicEngine.pos().toLong())
                tTot.text = Files.fmtTime(d.toLong())
            }
            ui.postDelayed(this, 500)
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val o = rows[position]
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(10), act.dp(6), act.dp(10), act.dp(6))
            r.isClickable = true
            r.background = Ui.stateBg(act.dp(5).toFloat())
            if (o is Track) {
                val playing = MusicEngine.current()?.path == o.path
                r.addView(act.label(if (playing) "\u25B6" else "\u266A", 13f, if (playing) Ui.accent else Ui.textDim), lp(act.dp(24), WRAP))
                val col = LinearLayout(act)
                col.orientation = LinearLayout.VERTICAL
                val t = act.label(o.title, 13f, if (playing) Ui.accent else Ui.text)
                t.setSingleLine()
                t.ellipsize = android.text.TextUtils.TruncateAt.END
                col.addView(t)
                val s = act.label(o.artist + "  \u2022  " + o.album, 11f, Ui.textDim)
                s.setSingleLine()
                s.ellipsize = android.text.TextUtils.TruncateAt.END
                col.addView(s)
                r.addView(col, lp(0, WRAP, 1f))
                r.addView(act.label(Files.fmtTime(o.dur), 11f, Ui.textDim))
                r.setOnClickListener { playRow(o) }
                r.setOnContextClickListener { trackMenu(o); true }
                r.setOnLongClickListener { trackMenu(o); true }
            } else if (o is Pair<*, *>) {
                r.addView(act.label(if (mode == 1) "\uD83D\uDCBF" else "\uD83C\uDFA4", 16f), lp(act.dp(30), WRAP))
                r.addView(act.label(o.first.toString(), 13f), lp(0, WRAP, 1f))
                r.addView(act.label(o.second.toString() + " songs", 11f, Ui.textDim))
                r.setOnClickListener { group = o.first.toString(); mode = 0; buildTabs(); refreshRows() }
            }
            return r
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(c(0xFF181818))

        // ----- library (left)
        val left = LinearLayout(act)
        left.orientation = LinearLayout.VERTICAL
        tabs = LinearLayout(act)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(act.dp(8), act.dp(8), act.dp(8), act.dp(4))
        left.addView(tabs, lp(MATCH, WRAP))
        val q = EditText(act)
        q.setSingleLine()
        q.hint = "Search music"
        q.textSize = 13f
        q.setTextColor(Ui.text)
        q.setHintTextColor(Ui.textDim)
        q.background = Ui.rect(c(0xFF2B2B2B), act.dp(16).toFloat())
        q.setPadding(act.dp(14), 0, act.dp(14), 0)
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                refreshRows()
            }
        })
        left.addView(q, lp(MATCH, act.dp(34)).also { it.setMargins(act.dp(8), act.dp(4), act.dp(8), act.dp(4)) })
        msg = act.label("", 13f, Ui.textDim)
        msg.setPadding(act.dp(14), act.dp(10), act.dp(14), 0)
        left.addView(msg, lp(MATCH, WRAP))
        list = ListView(act)
        list.divider = null
        list.adapter = adapter
        left.addView(list, lp(MATCH, 0, 1f))
        root.addView(left, lp(0, MATCH, 1.1f))

        // ----- now playing (right)
        val right = LinearLayout(act)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.CENTER_HORIZONTAL
        right.setPadding(act.dp(16), act.dp(14), act.dp(16), act.dp(10))
        right.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c(0xFF1F2A44), c(0xFF111111)))
        artFrame = FrameLayout(act)
        artFrame.background = Ui.rect(c(0xFF2A3A5E), act.dp(12).toFloat())
        artFrame.addView(act.label("\u266B", 64f, c(0x66FFFFFF)).also { it.gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
        art = ImageView(act)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        artFrame.addView(art, FrameLayout.LayoutParams(MATCH, MATCH))
        right.addView(artFrame, lp(act.dp(190), act.dp(190)))
        tTitle = act.label("Nothing playing", 17f, Ui.text, true)
        tTitle.setSingleLine()
        tTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        tTitle.gravity = Gravity.CENTER
        right.addView(tTitle, lp(MATCH, WRAP).also { it.topMargin = act.dp(12) })
        tArtist = act.label("", 13f, Ui.textDim)
        tArtist.gravity = Gravity.CENTER
        tArtist.setSingleLine()
        right.addView(tArtist, lp(MATCH, WRAP))
        right.addView(EqView(act), lp(MATCH, act.dp(46)).also { it.topMargin = act.dp(10) })
        seek = SeekBar(act)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tCur.text = Files.fmtTime(p.toLong())
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                MusicEngine.seek(seek.progress)
            }
        })
        right.addView(seek, lp(MATCH, WRAP).also { it.topMargin = act.dp(6) })
        val times = LinearLayout(act)
        tCur = act.label("0:00", 11f, Ui.textDim)
        tTot = act.label("0:00", 11f, Ui.textDim)
        tTot.gravity = Gravity.END
        times.addView(tCur, lp(0, WRAP, 1f))
        times.addView(tTot, lp(0, WRAP, 1f))
        right.addView(times, lp(MATCH, WRAP))
        val ctl = LinearLayout(act)
        ctl.gravity = Gravity.CENTER
        shuffleBtn = ctlBtn("\uD83D\uDD00") { MusicEngine.shuffle = !MusicEngine.shuffle; refreshNow() }
        playBtn = ctlBtn("\u25B6") { startOrToggle() }
        playBtn.textSize = 24f
        repeatBtn = ctlBtn("\uD83D\uDD01") { MusicEngine.repeat = (MusicEngine.repeat + 1) % 3; refreshNow() }
        ctl.addView(shuffleBtn, lp(act.dp(40), act.dp(40)))
        ctl.addView(ctlBtn("\u23EE") { MusicEngine.prev() }, lp(act.dp(44), act.dp(44)))
        ctl.addView(playBtn, lp(act.dp(54), act.dp(54)))
        ctl.addView(ctlBtn("\u23ED") { MusicEngine.next() }, lp(act.dp(44), act.dp(44)))
        ctl.addView(repeatBtn, lp(act.dp(40), act.dp(40)))
        right.addView(ctl, lp(MATCH, WRAP).also { it.topMargin = act.dp(4) })
        val vr = LinearLayout(act)
        vr.gravity = Gravity.CENTER_VERTICAL
        vr.addView(act.label("\uD83D\uDD08", 14f), lp(act.dp(28), WRAP))
        val vs = SeekBar(act)
        vs.max = 100
        vs.progress = (MusicEngine.volume * 100).toInt()
        vs.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) MusicEngine.setVol(p / 100f)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        vr.addView(vs, lp(0, WRAP, 1f))
        right.addView(vr, lp(MATCH, WRAP))
        root.addView(right, lp(0, MATCH, 1f))

        buildTabs()
        MusicEngine.listeners.add(listener)
        refreshNow()
        ui.post(tick)
        load()
        return root
    }

    private fun ctlBtn(label: String, onClick: () -> Unit): TextView {
        val t = act.label(label, 18f)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(26).toFloat())
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    private fun buildTabs() {
        tabs.removeAllViews()
        val names = listOf("Songs", "Albums", "Artists")
        for (i in names.indices) {
            val b = Ui.button(act, names[i]) { mode = i; group = null; buildTabs(); refreshRows() }
            if (i == mode && group == null) b.background = Ui.rect(Ui.accent, act.dp(6).toFloat())
            tabs.addView(b, lp(WRAP, WRAP).also { it.rightMargin = act.dp(4) })
        }
        val g = group
        if (g != null) {
            val chip = Ui.button(act, "\u2190 $g") { group = null; buildTabs(); refreshRows() }
            tabs.addView(chip, lp(WRAP, WRAP))
        }
    }

    private fun load() {
        if (!act.hasStorage()) {
            msg.text = "Allow access to your music to build the library."
            msg.visibility = View.VISIBLE
            msg.setOnClickListener { act.requestStorage() }
            pendingPath?.let { playPath(it) }
            pendingPath = null
            return
        }
        msg.text = "Scanning music\u2026"
        Thread {
            val t = MusicEngine.scan(act)
            act.runOnUiThread {
                loaded = true
                all = t ?: emptyList()
                msg.text = if (all.isEmpty()) "No music found on this phone." else ""
                msg.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
                refreshRows()
                pendingPath?.let { playPath(it) }
                pendingPath = null
            }
        }.start()
    }

    private fun refreshRows() {
        val q = query.lowercase()
        var base = all
        val g = group
        if (g != null) base = base.filter { if (mode == 1) it.album == g else if (mode == 2) it.artist == g else (it.album == g || it.artist == g) }
        if (q.isNotEmpty()) base = base.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q) }
        rows = if (group == null && mode == 1) base.groupBy { it.album }.map { Pair(it.key, it.value.size) }.sortedBy { it.first.lowercase() }
        else if (group == null && mode == 2) base.groupBy { it.artist }.map { Pair(it.key, it.value.size) }.sortedBy { it.first.lowercase() }
        else base
        adapter.notifyDataSetChanged()
    }

    private fun visibleTracks(): List<Track> = rows.filterIsInstance<Track>()

    private fun playRow(t: Track) {
        val v = visibleTracks()
        MusicEngine.play(v, v.indexOf(t).coerceAtLeast(0))
    }

    private fun startOrToggle() {
        if (MusicEngine.current() == null) {
            val v = visibleTracks()
            if (v.isNotEmpty()) MusicEngine.play(v, 0)
        } else MusicEngine.toggle()
    }

    private fun trackMenu(t: Track) {
        MenuPopup.show(
            act, null,
            listOf(
                MI("Play") { playRow(t) },
                MI("Show in File Explorer") { act.open(AppKind.FILES, File(t.path).parent) },
                MI("Share") { act.openExternal(File(t.path)) }
            )
        )
    }

    override fun handleArg(arg: String?) {
        if (arg != null) {
            if (loaded) playPath(arg) else pendingPath = arg
        }
    }

    private fun playPath(path: String) {
        val inLib = all.indexOfFirst { it.path == path }
        if (inLib >= 0) {
            MusicEngine.play(all, inLib)
            return
        }
        val f = File(path)
        var title = f.nameWithoutExtension
        var artist = "Unknown artist"
        var dur = 0L
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let { if (it.isNotBlank()) title = it }
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let { if (it.isNotBlank()) artist = it }
            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
        } catch (e: Exception) {
        }
        val siblings = (f.parentFile?.listFiles() ?: emptyArray()).filter { Files.ext(it) in Files.audioExts }.sortedBy { it.name.lowercase() }
        val tracks = siblings.map { s -> if (s.path == path) Track(0, title, artist, "Unknown album", dur, s.path, 0) else Track(0, s.nameWithoutExtension, "Unknown artist", "Unknown album", 0, s.path, 0) }
        val idx = tracks.indexOfFirst { it.path == path }
        MusicEngine.play(if (tracks.isEmpty()) listOf(Track(0, title, artist, "Unknown album", dur, path, 0)) else tracks, idx.coerceAtLeast(0))
    }

    private fun refreshNow() {
        val t = MusicEngine.current()
        tTitle.text = t?.title ?: "Nothing playing"
        tArtist.text = if (t != null) t.artist + " \u2022 " + t.album else ""
        playBtn.text = if (MusicEngine.isPlaying()) "\u23F8" else "\u25B6"
        shuffleBtn.alpha = if (MusicEngine.shuffle) 1f else 0.4f
        repeatBtn.text = if (MusicEngine.repeat == 2) "\uD83D\uDD02" else "\uD83D\uDD01"
        repeatBtn.alpha = if (MusicEngine.repeat == 0) 0.4f else 1f
        window?.setTitle((t?.title ?: "Music") + " - Music")
        if (t != null) {
            Thumbs.load("art:" + t.path, art) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(t.path)
                    val b = r.embeddedPicture
                    if (b != null) {
                        val o = BitmapFactory.Options()
                        o.inSampleSize = 2
                        BitmapFactory.decodeByteArray(b, 0, b.size, o)
                    } else null
                } catch (e: Exception) {
                    null
                } finally {
                    try {
                        r.release()
                    } catch (e: Exception) {
                    }
                }
            }
        } else art.setImageDrawable(null)
        adapter.notifyDataSetChanged()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (act.currentFocus is EditText) return false
        when (e.keyCode) {
            KeyEvent.KEYCODE_SPACE -> { startOrToggle(); return true }
            KeyEvent.KEYCODE_N -> { MusicEngine.next(); return true }
            KeyEvent.KEYCODE_P -> { MusicEngine.prev(); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { MusicEngine.seek(MusicEngine.pos() + 10000); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { MusicEngine.seek((MusicEngine.pos() - 10000).coerceAtLeast(0)); return true }
        }
        return false
    }

    override fun onResume() {
        if (this::list.isInitialized && !loaded) load()
        refreshNow()
    }

    override fun onClose() {
        running = false
        ui.removeCallbacks(tick)
        MusicEngine.listeners.remove(listener)
    }
}
