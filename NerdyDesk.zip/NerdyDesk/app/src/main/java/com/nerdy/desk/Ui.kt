package com.nerdy.desk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

fun c(v: Long): Int = v.toInt()

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

object Ui {
    val bgDark = c(0xFF202020)
    val taskbar = c(0xF0161616)
    val text = c(0xFFFFFFFF)
    val textDim = c(0xFFB5B5B5)
    val hover = c(0x30FFFFFF)
    val press = c(0x18FFFFFF)
    val selected = c(0x44FFFFFF)
    val border = c(0xFF3A3A3A)
    var accent = c(0xFF0078D4)

    val accents = listOf(
        c(0xFF0078D4), c(0xFF107C10), c(0xFFE81123),
        c(0xFF8E44AD), c(0xFFFF8C00), c(0xFF00B7C3)
    )
    val wallpapers = listOf(
        intArrayOf(c(0xFF0F2027), c(0xFF203A43), c(0xFF2C5364)),
        intArrayOf(c(0xFF141E30), c(0xFF243B55), c(0xFF0078D4)),
        intArrayOf(c(0xFF200122), c(0xFF4A1550), c(0xFF6F0000)),
        intArrayOf(c(0xFF0B3D2E), c(0xFF145A32), c(0xFF1E8449)),
        intArrayOf(c(0xFF232526), c(0xFF414345), c(0xFF232526)),
        intArrayOf(c(0xFF1A2980), c(0xFF26D0CE), c(0xFF1A2980))
    )

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rect(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun stateBg(
        radius: Float,
        normal: Int = 0,
        hov: Int = hover,
        prs: Int = press,
        sel: Int = selected
    ): StateListDrawable {
        fun shape(col: Int) = GradientDrawable().apply { setColor(col); cornerRadius = radius }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(prs))
            addState(intArrayOf(android.R.attr.state_selected), shape(sel))
            addState(intArrayOf(android.R.attr.state_hovered), shape(hov))
            addState(intArrayOf(), shape(normal))
        }
    }

    fun button(ctx: Context, label: String, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(text_color())
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            background = stateBg(dp(ctx, 6).toFloat(), c(0x22FFFFFF))
            isClickable = true
            setOnClickListener { onClick() }
            hand()
        }

    private fun text_color() = text
}

fun Context.dp(v: Int): Int = Ui.dp(this, v)
fun View.dp(v: Int): Int = Ui.dp(context, v)

fun View.hand() {
    if (Build.VERSION.SDK_INT >= 24) {
        pointerIcon = PointerIcon.getSystemIcon(context, PointerIcon.TYPE_HAND)
    }
}

/** Touch: single tap runs the action. Mouse: single click selects, double click runs it. */
fun View.activate(onSelect: () -> Unit = {}, action: () -> Unit) {
    var tool = MotionEvent.TOOL_TYPE_FINGER
    var last = 0L
    isClickable = true
    setOnTouchListener { _, e ->
        if (e.actionMasked == MotionEvent.ACTION_DOWN) tool = e.getToolType(0)
        false
    }
    setOnClickListener {
        if (tool == MotionEvent.TOOL_TYPE_MOUSE) {
            val now = SystemClock.uptimeMillis()
            if (now - last < 450) {
                last = 0
                action()
            } else {
                last = now
                onSelect()
                isSelected = true
            }
        } else {
            action()
        }
    }
}

class WinLogo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var color: Int = Color.WHITE

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) * 0.40f
        val g = s * 0.05f
        val cx = width / 2f
        val cy = height / 2f
        val h = s / 2f
        p.color = color
        canvas.drawRect(cx - h, cy - h, cx - g, cy - g, p)
        canvas.drawRect(cx + g, cy - h, cx + h, cy - g, p)
        canvas.drawRect(cx - h, cy + g, cx - g, cy + h, p)
        canvas.drawRect(cx + g, cy + g, cx + h, cy + h, p)
    }
}
