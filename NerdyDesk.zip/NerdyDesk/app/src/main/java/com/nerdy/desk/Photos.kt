package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.ExifInterface
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pinch / wheel / drag zoomable image. */
@SuppressLint("ClickableViewAccessibility")
class ZoomImageView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private val m = Matrix()
    private val v = FloatArray(9)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var minScale = 1f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    var onSwipe: ((Int) -> Unit)? = null

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomAt(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })
    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale() > minScale * 1.1f) fit() else zoomAt(2.6f, e.x, e.y)
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (scale() <= minScale * 1.05f && Math.abs(vx) > 900 && Math.abs(vx) > Math.abs(vy)) {
                onSwipe?.invoke(if (vx < 0) 1 else -1)
                return true
            }
            return false
        }
    })

    private fun scale(): Float {
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    fun setBitmap(b: Bitmap?) {
        bmp = b
        fit()
    }

    fun bitmap(): Bitmap? = bmp

    fun fit() {
        val b = bmp
        if (b == null || width == 0 || height == 0) {
            invalidate()
            return
        }
        val s = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        minScale = s
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
        invalidate()
    }

    fun zoomAt(f: Float, x: Float, y: Float) {
        val cur = scale()
        val target = (cur * f).coerceIn(minScale * 0.8f, minScale * 10f)
        val k = target / cur
        m.postScale(k, k, x, y)
        fixTrans()
        invalidate()
    }

    fun zoomCenter(f: Float) = zoomAt(f, width / 2f, height / 2f)

    fun rotate90() {
        val b = bmp ?: return
        val r = Matrix()
        r.postRotate(90f)
        setBitmap(Bitmap.createBitmap(b, 0, 0, b.width, b.height, r, true))
    }

    private fun fixTrans() {
        val b = bmp ?: return
        val r = RectF(0f, 0f, b.width.toFloat(), b.height.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left else {
            if (r.left > 0) dx = -r.left
            if (r.right < width) dx = width - r.right
        }
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top else {
            if (r.top > 0) dy = -r.top
            if (r.bottom < height) dy = height - r.bottom
        }
        m.postTranslate(dx, dy)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fit()
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.drawBitmap(b, m, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        gestures.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                dragging = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !scaler.isInProgress && e.pointerCount == 1) {
                    m.postTranslate(e.x - lastX, e.y - lastY)
                    fixTrans()
                    invalidate()
                    lastX = e.x
                    lastY = e.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(i)
                lastY = e.getY(i)
            }
        }
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_SCROLL) {
            zoomAt(if (e.getAxisValue(MotionEvent.AXIS_VSCROLL) > 0) 1.15f else 1f / 1.15f, e.x, e.y)
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}

class Pic(val path: String, val name: String, val bucket: String, val date: Long)

class PhotosApp(act: MainActivity, private val arg: String?) : App(act) {
    override val title = "Photos"
    override val icon = "\uD83D\uDDBC\uFE0F"

    private var all: List<Pic> = emptyList()
    private var shown: List<Pic> = emptyList()
    private var album: String? = null
    private var viewList: List<Pic> = emptyList()
    private var cur = -1
    private var loadToken = 0
    private var slideshow = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var rootFrame: FrameLayout
    private lateinit var browse: LinearLayout
    private lateinit var viewer: FrameLayout
    private lateinit var zoom: ZoomImageView
    private lateinit var vTitle: TextView
    private lateinit var grid: GridView
    private lateinit var albums: LinearLayout
    private lateinit var msg: TextView
    private lateinit var count: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val p = shown[position]
            val iv = (convertView as? ImageView) ?: ImageView(act)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setBackgroundColor(c(0xFF2A2A2A))
            iv.layoutParams = AbsListView.LayoutParams(MATCH, act.dp(118))
            Thumbs.load("f:" + p.path + p.date, iv) { Thumbs.decodeImage(p.path, 160) }
            iv.isClickable = true
            iv.setOnClickListener { openViewer(shown, position) }
            iv.setOnLongClickListener { picMenu(p); true }
            iv.setOnContextClickListener { picMenu(p); true }
            return iv
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun build(): View {
        rootFrame = FrameLayout(act)
        rootFrame.setBackgroundColor(c(0xFF141414))

        browse = LinearLayout(act)
        browse.orientation = LinearLayout.HORIZONTAL
        val side = LinearLayout(act)
        side.orientation = LinearLayout.VERTICAL
        side.setBackgroundColor(c(0xFF191919))
        val sh = act.label("Albums", 14f, Ui.text, true)
        sh.setPadding(act.dp(14), act.dp(12), 0, act.dp(6))
        side.addView(sh)
        val sv = ScrollView(act)
        albums = LinearLayout(act)
        albums.orientation = LinearLayout.VERTICAL
        albums.setPadding(act.dp(4), 0, act.dp(4), act.dp(6))
        sv.addView(albums, FrameLayout.LayoutParams(MATCH, WRAP))
        side.addView(sv, lp(MATCH, 0, 1f))
        browse.addView(side, lp(act.dp(150), MATCH))
        val main = LinearLayout(act)
        main.orientation = LinearLayout.VERTICAL
        count = act.label("", 12f, Ui.textDim)
        count.setPadding(act.dp(12), act.dp(8), 0, act.dp(4))
        main.addView(count)
        msg = act.label("", 13f, Ui.textDim)
        msg.setPadding(act.dp(14), act.dp(6), act.dp(14), 0)
        main.addView(msg)
        grid = GridView(act)
        grid.numColumns = GridView.AUTO_FIT
        grid.columnWidth = act.dp(118)
        grid.horizontalSpacing = act.dp(3)
        grid.verticalSpacing = act.dp(3)
        grid.setPadding(act.dp(6), 0, act.dp(6), act.dp(6))
        grid.adapter = adapter
        main.addView(grid, lp(MATCH, 0, 1f))
        browse.addView(main, lp(0, MATCH, 1f))
        rootFrame.addView(browse, FrameLayout.LayoutParams(MATCH, MATCH))

        viewer = FrameLayout(act)
        viewer.setBackgroundColor(0xFF000000.toInt())
        viewer.visibility = View.GONE
        zoom = ZoomImageView(act)
        zoom.onSwipe = { d -> go(d) }
        viewer.addView(zoom, FrameLayout.LayoutParams(MATCH, MATCH))
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(c(0x99000000))
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        fun b(label: String, a: () -> Unit) = bar.addView(vbtn(label, a), lp(act.dp(36), act.dp(34)))
        b("\u2190") { closeViewer() }
        vTitle = act.label("", 13f)
        vTitle.setSingleLine()
        vTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        vTitle.setPadding(act.dp(8), 0, act.dp(8), 0)
        bar.addView(vTitle, lp(0, WRAP, 1f))
        b("\u2039") { go(-1) }
        b("\u203A") { go(1) }
        b("\u2212") { zoom.zoomCenter(1f / 1.3f) }
        b("+") { zoom.zoomCenter(1.3f) }
        b("\u2922") { zoom.fit() }
        b("\u27F3") { zoom.rotate90() }
        b("\u25B6") { toggleSlideshow() }
        b("\u24D8") { cur.takeIf { it >= 0 }?.let { info(viewList[it]) } }
        b("\u2197") { cur.takeIf { it >= 0 }?.let { act.openExternal(File(viewList[it].path)) } }
        b("\uD83D\uDDD1") { cur.takeIf { it >= 0 }?.let { delete(viewList[it]) } }
        b("\u26F6") { window?.let { w -> if (act.inFullscreen) act.exitFullscreen() else act.enterFullscreen(w) } }
        viewer.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        rootFrame.addView(viewer, FrameLayout.LayoutParams(MATCH, MATCH))

        load()
        return rootFrame
    }

    private fun vbtn(label: String, onClick: () -> Unit): TextView {
        val t = act.label(label, 16f)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(act.dp(6).toFloat())
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    // ---------------------------------------------------------------- library

    private fun load() {
        val token = ++loadToken
        msg.text = "Loading photos\u2026"
        Thread {
            val out = ArrayList<Pic>()
            try {
                val cur = act.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media.DATA, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED),
                    null, null, MediaStore.Images.Media.DATE_ADDED + " DESC"
                )
                cur?.use {
                    while (it.moveToNext() && out.size < 6000) {
                        val p = it.getString(0) ?: continue
                        out.add(Pic(p, it.getString(1) ?: File(p).name, it.getString(2) ?: "Other", it.getLong(3)))
                    }
                }
            } catch (e: Exception) {
            }
            if (out.isEmpty()) {
                val root = android.os.Environment.getExternalStorageDirectory()
                for (d in listOf("DCIM", "Pictures", "Download")) {
                    try {
                        File(root, d).walkTopDown().maxDepth(4).forEach { f ->
                            if (f.isFile && Files.ext(f) in Files.imageExts && out.size < 4000) out.add(Pic(f.path, f.name, f.parentFile?.name ?: d, f.lastModified() / 1000))
                        }
                    } catch (e: Exception) {
                    }
                }
                out.sortByDescending { it.date }
            }
            act.runOnUiThread {
                if (token != loadToken) return@runOnUiThread
                all = out
                msg.text = if (out.isEmpty()) {
                    if (act.hasStorage()) "No photos found." else "Allow access to your photos (tap here)."
                } else ""
                msg.setOnClickListener { if (!act.hasStorage()) act.requestStorage() }
                refreshAlbums()
                applyAlbum()
                arg?.let { a ->
                    if (viewer.visibility != View.VISIBLE) {
                        val f = File(a)
                        if (f.exists()) {
                            val sibs = (f.parentFile?.listFiles() ?: emptyArray()).filter { Files.ext(it) in Files.imageExts }.sortedBy { it.name.lowercase() }
                                .map { Pic(it.path, it.name, it.parentFile?.name ?: "", it.lastModified() / 1000) }
                            val i = sibs.indexOfFirst { it.path == a }
                            if (i >= 0) openViewer(sibs, i)
                        }
                    }
                }
            }
        }.start()
    }

    private fun refreshAlbums() {
        albums.removeAllViews()
        fun row(label: String, n: Int, key: String?) {
            val t = act.label("$label  ($n)", 13f, if (album == key) Ui.accent else Ui.text)
            t.setPadding(act.dp(10), act.dp(8), act.dp(6), act.dp(8))
            t.setSingleLine()
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            t.isClickable = true
            t.background = Ui.stateBg(act.dp(5).toFloat(), if (album == key) c(0x33FFFFFF) else 0)
            t.setOnClickListener { album = key; refreshAlbums(); applyAlbum() }
            t.hand()
            albums.addView(t, lp(MATCH, WRAP))
        }
        row("All photos", all.size, null)
        for ((k, v) in all.groupBy { it.bucket }.entries.sortedByDescending { it.value.size }) row(k, v.size, k)
    }

    private fun applyAlbum() {
        shown = if (album == null) all else all.filter { it.bucket == album }
        count.text = (album ?: "All photos") + " \u2022 " + shown.size + " photos"
        adapter.notifyDataSetChanged()
    }

    // ---------------------------------------------------------------- viewer

    private fun openViewer(list: List<Pic>, i: Int) {
        viewList = list
        cur = i
        browse.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        showCurrent()
    }

    private fun showCurrent() {
        if (cur < 0 || cur >= viewList.size) return
        val p = viewList[cur]
        vTitle.text = p.name + "   (" + (cur + 1) + "/" + viewList.size + ")"
        window?.setTitle(p.name + " - Photos")
        val want = cur
        Thread {
            val b = Thumbs.decodeImage(p.path, 1900)
            act.runOnUiThread { if (want == cur) zoom.setBitmap(b) }
        }.start()
    }

    private fun go(d: Int) {
        if (viewer.visibility != View.VISIBLE || viewList.isEmpty()) return
        cur = (cur + d + viewList.size) % viewList.size
        showCurrent()
    }

    private fun closeViewer() {
        slideshow = false
        ui.removeCallbacksAndMessages(null)
        if (act.inFullscreen) act.exitFullscreen()
        viewer.visibility = View.GONE
        browse.visibility = View.VISIBLE
        zoom.setBitmap(null)
        window?.setTitle("Photos")
    }

    private fun toggleSlideshow() {
        slideshow = !slideshow
        act.toast(if (slideshow) "Slideshow started" else "Slideshow stopped")
        if (slideshow) {
            ui.postDelayed(object : Runnable {
                override fun run() {
                    if (!slideshow) return
                    go(1)
                    ui.postDelayed(this, 3500)
                }
            }, 3500)
        }
    }

    private fun picMenu(p: Pic) {
        MenuPopup.show(
            act, null,
            listOf(
                MI("Open") { openViewer(shown, shown.indexOf(p)) },
                MI("Set as desktop background") {
                    try {
                        File(p.path).copyTo(File(act.filesDir, "wall.jpg"), true)
                        act.setWallpaper(100)
                    } catch (e: Exception) {
                        act.toast("Couldn't set background")
                    }
                },
                MI("Share") { act.openExternal(File(p.path)) },
                MI("Show in File Explorer") { act.open(AppKind.FILES, File(p.path).parent) },
                MI("", sep = true),
                MI("Properties") { info(p) },
                MI("Delete", "Del") { delete(p) }
            )
        )
    }

    private fun info(p: Pic) {
        val f = File(p.path)
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(p.path, o)
        val sb = StringBuilder()
        sb.append("Name: ").append(p.name).append("\n")
        sb.append("Folder: ").append(f.parent ?: "").append("\n")
        sb.append("Size: ").append(Files.humanSize(f.length())).append("\n")
        sb.append("Dimensions: ").append(o.outWidth).append(" \u00D7 ").append(o.outHeight).append("\n")
        sb.append("Modified: ").append(SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(f.lastModified())))
        try {
            val ex = ExifInterface(p.path)
            val make = ex.getAttribute(ExifInterface.TAG_MAKE)
            val model = ex.getAttribute(ExifInterface.TAG_MODEL)
            if (make != null || model != null) sb.append("\nCamera: ").append(listOfNotNull(make, model).joinToString(" "))
            ex.getAttribute(ExifInterface.TAG_DATETIME)?.let { sb.append("\nTaken: ").append(it) }
            ex.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)?.let { sb.append("\nExposure: ").append(it).append(" s") }
            ex.getAttribute(ExifInterface.TAG_F_NUMBER)?.let { sb.append("\nAperture: f/").append(it) }
            ex.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS)?.let { sb.append("\nISO: ").append(it) }
        } catch (e: Exception) {
        }
        AlertDialog.Builder(act).setTitle("Photo info").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }

    private fun delete(p: Pic) {
        AlertDialog.Builder(act).setTitle("Delete photo").setMessage("Delete \"${p.name}\"? This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                val ok = File(p.path).delete()
                if (!ok) {
                    act.toast("Couldn't delete (is file access allowed?)")
                    return@setPositiveButton
                }
                MediaScannerConnection.scanFile(act, arrayOf(p.path), null, null)
                all = all.filter { it.path != p.path }
                if (viewer.visibility == View.VISIBLE) {
                    viewList = viewList.filter { it.path != p.path }
                    if (viewList.isEmpty()) closeViewer() else {
                        cur = cur.coerceAtMost(viewList.size - 1)
                        showCurrent()
                    }
                }
                refreshAlbums()
                applyAlbum()
            }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (viewer.visibility != View.VISIBLE) return false
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> { go(1); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { go(-1); return true }
            KeyEvent.KEYCODE_ESCAPE -> { closeViewer(); return true }
            KeyEvent.KEYCODE_SPACE -> { toggleSlideshow(); return true }
            KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS, KeyEvent.KEYCODE_NUMPAD_ADD -> { zoom.zoomCenter(1.3f); return true }
            KeyEvent.KEYCODE_MINUS, KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> { zoom.zoomCenter(1f / 1.3f); return true }
            KeyEvent.KEYCODE_0 -> { zoom.fit(); return true }
            KeyEvent.KEYCODE_R -> { zoom.rotate90(); return true }
            KeyEvent.KEYCODE_F -> { window?.let { w -> if (act.inFullscreen) act.exitFullscreen() else act.enterFullscreen(w) }; return true }
            KeyEvent.KEYCODE_FORWARD_DEL -> { cur.takeIf { it >= 0 }?.let { delete(viewList[it]) }; return true }
        }
        return false
    }

    override fun onBack(): Boolean {
        if (viewer.visibility == View.VISIBLE) {
            closeViewer()
            return true
        }
        return false
    }

    override fun onResume() {
        if (this::grid.isInitialized && all.isEmpty()) load()
    }

    override fun onClose() {
        slideshow = false
        ui.removeCallbacksAndMessages(null)
    }
}
