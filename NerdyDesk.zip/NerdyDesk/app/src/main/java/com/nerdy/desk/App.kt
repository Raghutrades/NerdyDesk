package com.nerdy.desk

import android.view.KeyEvent
import android.view.View

abstract class App(val act: MainActivity) {
    var window: WindowView? = null
    abstract val title: String
    abstract val icon: String
    abstract fun build(): View
    /** false for apps that draw with WebView/TextureView (they can't be snapshotted for Task View). */
    open val previewable: Boolean = true
    open fun onClose() {}
    open fun onResume() {}
    open fun onPause() {}
    open fun onShortcut(e: KeyEvent): Boolean = false
    open fun onBack(): Boolean = false
    /** Called when a single-instance window is re-opened with a new argument (e.g. a file path). */
    open fun handleArg(arg: String?) {}
}

enum class AppKind(val title: String, val icon: String, val w: Int, val h: Int) {
    FILES("File Explorer", "\uD83D\uDCC1", 820, 520),
    BROWSER("Browser", "\uD83C\uDF10", 980, 600),
    PHOTOS("Photos", "\uD83D\uDDBC\uFE0F", 900, 580),
    VIDEO("Video Player", "\uD83C\uDFAC", 900, 560),
    MUSIC("Music", "\uD83C\uDFB5", 860, 540),
    PDF("PDF Reader", "\uD83D\uDCD5", 760, 600),
    HABIT("Neuro Orbit", "\uD83E\uDDE0", 1000, 620),
    NOTEPAD("Notepad", "\uD83D\uDCDD", 640, 440),
    CALC("Calculator", "\uD83E\uDDEE", 360, 560),
    TASKMGR("Task Manager", "\uD83D\uDCCA", 640, 460),
    SETTINGS("Settings", "\u2699\uFE0F", 860, 560);

    fun create(act: MainActivity, arg: String?): App = when (this) {
        FILES -> FileApp(act, arg)
        BROWSER -> BrowserApp(act, arg)
        PHOTOS -> PhotosApp(act, arg)
        VIDEO -> VideoApp(act, arg)
        MUSIC -> MusicApp(act, arg)
        PDF -> PdfApp(act, arg)
        HABIT -> HabitApp(act)
        NOTEPAD -> NotepadApp(act, arg)
        CALC -> CalcApp(act)
        TASKMGR -> TaskMgrApp(act)
        SETTINGS -> SettingsApp(act, arg)
    }
}
