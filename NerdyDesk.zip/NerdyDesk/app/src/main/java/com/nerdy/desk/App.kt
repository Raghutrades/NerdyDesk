package com.nerdy.desk

import android.view.KeyEvent
import android.view.View

abstract class App(val act: MainActivity) {
    var window: WindowView? = null
    abstract val title: String
    abstract val icon: String
    abstract fun build(): View
    open fun onClose() {}
    open fun onResume() {}
    open fun onShortcut(e: KeyEvent): Boolean = false
    open fun onBack(): Boolean = false
}

enum class AppKind(val title: String, val icon: String) {
    FILES("File Explorer", "\uD83D\uDCC1"),
    BROWSER("Browser", "\uD83C\uDF10"),
    NOTEPAD("Notepad", "\uD83D\uDCDD"),
    SETTINGS("Settings", "\u2699\uFE0F");

    fun create(act: MainActivity, arg: String?): App = when (this) {
        FILES -> FileApp(act, arg)
        BROWSER -> BrowserApp(act, arg)
        NOTEPAD -> NotepadApp(act, arg)
        SETTINGS -> SettingsApp(act)
    }
}
