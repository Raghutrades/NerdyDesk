package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("ClickableViewAccessibility")
class MainActivity : Activity() {
    companion object {
        const val REQ_FILE = 42
        const val TASKBAR_DP = 48
    }

    lateinit var prefs: SharedPreferences
    lateinit var desktop: FrameLayout
    lateinit var startMenu: StartMenu
    private lateinit var rootLayout: FrameLayout
    private lateinit var pinnedBox: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var batteryView: TextView
    private lateinit var startBtn: FrameLayout
    private lateinit var iconGrid: GridLayout

    val windows = ArrayList<WindowView>()
    var focused: WindowView? = null
    var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val handler = Handler(Looper.getMainLooper())
    private var cascade = 0
    private var winUsed = false
    private var lastX = 0
    private var lastY = 0
    private var lastRows = -1

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 20000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nerdydesk", MODE_PRIVATE)
        Ui.accent = Ui.accents[prefs.getInt("accent", 0).coerceIn(0, Ui.accents.size - 1)]
        buildUi()
        applyDisplayPrefs()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        rootLayout = FrameLayout(this)
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = FrameLayout(this)
        desktop.isClickable = true
        desktop.setOnTouchListener { _, e ->
            lastX = e.x.toInt()
            lastY = e.y.toInt()
            false
        }
        desktop.setOnClickListener { clearIconSelection() }
        desktop.setOnContextClickListener { desktopMenu(); true }
        desktop.setOnLongClickListener { desktopMenu(); true }
        column.addView(desktop, lp(MATCH, 0, 1f))
        column.addView(buildTaskbar(), lp(MATCH, dp(TASKBAR_DP)))
        rootLayout.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        startMenu = StartMenu(this)
        val sl = FrameLayout.LayoutParams(MATCH, MATCH)
        sl.bottomMargin = dp(TASKBAR_DP)
        rootLayout.addView(startMenu, sl)
        setContentView(rootLayout)

        iconGrid = GridLayout(this)
        iconGrid.orientation = GridLayout.VERTICAL
        iconGrid.setPadding(dp(8), dp(8), dp(8), dp(8))
        desktop.addView(iconGrid, FrameLayout.LayoutParams(WRAP, MATCH))
        desktop.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop || lastRows < 0) buildIcons()
        }
        applyWallpaper()
        refreshTaskbar()
    }

    private fun buildTaskbar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.taskbar)
        bar.elevation = dp(8).toFloat()

        startBtn = FrameLayout(this)
        startBtn.isClickable = true
        startBtn.background = Ui.stateBg(0f)
        startBtn.addView(WinLogo(this), FrameLayout.LayoutParams(MATCH, MATCH))
        startBtn.setOnClickListener { toggleStart() }
        startBtn.hand()
        bar.addView(startBtn, lp(dp(52), MATCH))

        val search = TextView(this)
        search.text = "\uD83D\uDD0D  Type here to search"
        search.textSize = 12f
        search.setTextColor(Ui.textDim)
        search.gravity = Gravity.CENTER_VERTICAL
        search.setPadding(dp(14), 0, dp(14), 0)
        search.background = Ui.stateBg(dp(17).toFloat(), c(0x22FFFFFF))
        search.isClickable = true
        search.setOnClickListener {
            if (!startMenu.isOpen) startMenu.open()
            startMenu.focusSearch2()
        }
        search.hand()
        val sl = lp(dp(190), dp(34))
        sl.setMargins(dp(2), 0, dp(8), 0)
        bar.addView(search, sl)

        pinnedBox = LinearLayout(this)
        pinnedBox.orientation = LinearLayout.HORIZONTAL
        bar.addView(pinnedBox, lp(0, MATCH, 1f))

        batteryView = TextView(this)
        batteryView.textSize = 11f
        batteryView.setTextColor(Ui.text)
        batteryView.gravity = Gravity.CENTER
        batteryView.setPadding(dp(8), 0, dp(8), 0)
        bar.addView(batteryView, lp(WRAP, MATCH))

        clockView = TextView(this)
        clockView.textSize = 11f
        clockView.setTextColor(Ui.text)
        clockView.gravity = Gravity.CENTER
        clockView.setPadding(dp(10), 0, dp(10), 0)
        clockView.isClickable = true
        clockView.background = Ui.stateBg(0f)
        bar.addView(clockView, lp(WRAP, MATCH))

        val sliver = View(this)
        sliver.isClickable = true
        sliver.background = Ui.stateBg(0f, c(0x22FFFFFF))
        sliver.setOnClickListener { showDesktop() }
        bar.addView(sliver, lp(dp(8), MATCH))
        return bar
    }

    private fun buildIcons() {
        val h = desktop.height
        if (h <= 0) return
        val rows = maxOf(1, (h - dp(16)) / dp(92))
        if (rows == lastRows && iconGrid.childCount > 0) return
        lastRows = rows
        iconGrid.removeAllViews()
        iconGrid.rowCount = rows
        val defs = listOf(
            Triple("\uD83D\uDCBB", "This PC", { open(AppKind.FILES, null) }),
            Triple("\u2B07\uFE0F", "Downloads", { open(AppKind.FILES, "/storage/emulated/0/Download") }),
            Triple("\uD83C\uDF10", "Browser", { open(AppKind.BROWSER, null) }),
            Triple("\uD83D\uDCDD", "Notepad", { open(AppKind.NOTEPAD, null) }),
            Triple("\u2699\uFE0F", "Settings", { open(AppKind.SETTINGS, null) })
        )
        for ((emoji, label, action) in defs) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(6), dp(2), dp(4))
            cell.background = Ui.stateBg(dp(4).toFloat(), 0, c(0x22FFFFFF), c(0x33FFFFFF), c(0x40FFFFFF))
            val e = TextView(this)
            e.text = emoji
            e.textSize = 30f
            e.gravity = Gravity.CENTER
            cell.addView(e, lp(MATCH, dp(40)))
            val t = TextView(this)
            t.text = label
            t.textSize = 12f
            t.setTextColor(Color.WHITE)
            t.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            cell.addView(t, lp(MATCH, WRAP))
            cell.activate(onSelect = { clearIconSelection() }) { action() }
            cell.hand()
            val g = GridLayout.LayoutParams()
            g.width = dp(84)
            g.height = dp(88)
            iconGrid.addView(cell, g)
        }
    }

    private fun clearIconSelection() {
        for (i in 0 until iconGrid.childCount) iconGrid.getChildAt(i).isSelected = false
    }

    fun applyWallpaper() {
        val i = prefs.getInt("wall", 0).coerceIn(0, Ui.wallpapers.size - 1)
        desktop.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, Ui.wallpapers[i])
    }

    fun setWallpaper(i: Int) {
        prefs.edit().putInt("wall", i).apply()
        applyWallpaper()
    }

    fun setAccent(i: Int) {
        prefs.edit().putInt("accent", i).apply()
        Ui.accent = Ui.accents[i]
        windows.forEach { it.setActive(it === focused) }
        refreshTaskbar()
    }

    @Suppress("DEPRECATION")
    fun applyDisplayPrefs() {
        if (prefs.getBoolean("fullscreen", true)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        updateClock()
    }

    private fun updateClock() {
        val now = Date()
        val tf = if (prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm a"
        clockView.text = SimpleDateFormat(tf, Locale.getDefault()).format(now) + "\n" +
            SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(now)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        batteryView.text = if (lvl >= 0 && sc > 0) "\uD83D\uDD0B ${lvl * 100 / sc}%" else ""
    }

    fun refreshTaskbar() {
        pinnedBox.removeAllViews()
        for (kind in AppKind.values()) {
            val ws = windows.filter { it.kind == kind }
            val cell = FrameLayout(this)
            cell.isClickable = true
            cell.background = Ui.stateBg(0f)
            cell.isSelected = ws.isNotEmpty() && ws.any { it === focused }
            val ic = TextView(this)
            ic.text = kind.icon
            ic.textSize = 20f
            ic.gravity = Gravity.CENTER
            cell.addView(ic, FrameLayout.LayoutParams(MATCH, MATCH))
            if (ws.isNotEmpty()) {
                val u = View(this)
                u.setBackgroundColor(Ui.accent)
                val w = if (ws.any { it === focused }) dp(22) else dp(10)
                cell.addView(u, FrameLayout.LayoutParams(w, dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            }
            cell.setOnClickListener { onTaskClick(kind) }
            val menu = { taskMenu(cell, kind) }
            cell.setOnLongClickListener { menu(); true }
            cell.setOnContextClickListener { menu(); true }
            cell.hand()
            pinnedBox.addView(cell, lp(dp(50), MATCH))
        }
    }

    private fun taskMenu(anchor: View, kind: AppKind) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "New " + kind.title + " window")
        if (windows.any { it.kind == kind }) m.menu.add(0, 2, 1, "Close all windows")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> open(kind, null)
                2 -> windows.filter { w -> w.kind == kind }.forEach { w -> closeWindow(w) }
            }
            true
        }
        m.show()
    }

    private fun onTaskClick(kind: AppKind) {
        val ws = windows.filter { it.kind == kind }
        when {
            ws.isEmpty() -> open(kind, null)
            ws.size == 1 -> {
                val w = ws[0]
                if (!w.minimized && focused === w) minimizeWindow(w) else focusWindow(w)
            }
            else -> {
                val idx = ws.indexOf(focused)
                focusWindow(ws[(idx + 1) % ws.size])
            }
        }
    }

    private fun desktopMenu() {
        popupAt(lastX, lastY, listOf("Open File Explorer", "Open Browser", "Settings", "Refresh")) {
            when (it) {
                0 -> open(AppKind.FILES, null)
                1 -> open(AppKind.BROWSER, null)
                2 -> open(AppKind.SETTINGS, null)
                3 -> { lastRows = -1; buildIcons() }
            }
        }
    }

    private fun popupAt(x: Int, y: Int, items: List<String>, onPick: (Int) -> Unit) {
        val anchor = View(this)
        val l = FrameLayout.LayoutParams(1, 1)
        l.leftMargin = x
        l.topMargin = y
        desktop.addView(anchor, l)
        val m = PopupMenu(this, anchor)
        items.forEachIndexed { i, s -> m.menu.add(0, i, i, s) }
        m.setOnMenuItemClickListener {
            onPick(it.itemId)
            true
        }
        m.setOnDismissListener { desktop.removeView(anchor) }
        m.show()
    }

    // ---------------------------------------------------------------- windows

    fun open(kind: AppKind, arg: String?): WindowView {
        startMenu.close()
        val app = kind.create(this, arg)
        val w = WindowView(this, kind, app)
        app.window = w
        val dw = desktop.width
        val dh = desktop.height
        val ww = minOf((dw * 0.78f).toInt(), dp(820))
        val wh = minOf((dh * 0.84f).toInt(), dp(520))
        val x = minOf(dp(24) + cascade * dp(28), maxOf(0, dw - ww))
        val y = minOf(dp(12) + cascade * dp(24), maxOf(0, dh - wh))
        cascade = (cascade + 1) % 6
        val l = FrameLayout.LayoutParams(ww, wh)
        l.leftMargin = x
        l.topMargin = y
        desktop.addView(w, l)
        windows.add(w)
        if (dw < dp(560)) w.toggleMax()
        focusWindow(w)
        return w
    }

    fun focusWindow(w: WindowView?) {
        if (startMenu.isOpen) startMenu.close()
        if (w != null) {
            if (w.minimized) w.restore()
            windows.remove(w)
            windows.add(w)
            if (desktop.indexOfChild(w) != desktop.childCount - 1) w.bringToFront()
        }
        focused = w
        windows.forEach { it.setActive(it === w) }
        refreshTaskbar()
    }

    fun minimizeWindow(w: WindowView) {
        w.minimize()
        if (focused === w) focusWindow(windows.lastOrNull { !it.minimized }) else refreshTaskbar()
    }

    fun closeWindow(w: WindowView) {
        try {
            w.app.onClose()
        } catch (e: Exception) {
        }
        desktop.removeView(w)
        windows.remove(w)
        if (focused === w) focused = null
        focusWindow(windows.lastOrNull { !it.minimized })
    }

    private fun showDesktop() {
        if (windows.any { !it.minimized }) {
            windows.forEach { it.minimize() }
            focusWindow(null)
        } else {
            windows.forEach { it.restore() }
            focusWindow(windows.lastOrNull())
        }
    }

    fun toggleStart() {
        if (startMenu.isOpen) startMenu.close() else startMenu.open()
    }

    fun onStartToggled() {
        startBtn.isSelected = startMenu.isOpen
    }

    // ---------------------------------------------------------------- helpers

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun startSafely(i: Intent): Boolean = try {
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    // ---------------------------------------------------------------- input

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code == KeyEvent.KEYCODE_META_LEFT || code == KeyEvent.KEYCODE_META_RIGHT) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) winUsed = false
            if (e.action == KeyEvent.ACTION_UP && !winUsed) toggleStart()
            return true
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.isMetaPressed) {
                when (code) {
                    KeyEvent.KEYCODE_E -> { winUsed = true; open(AppKind.FILES, null); return true }
                    KeyEvent.KEYCODE_D -> { winUsed = true; showDesktop(); return true }
                    KeyEvent.KEYCODE_I -> { winUsed = true; open(AppKind.SETTINGS, null); return true }
                }
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_F4) {
                focused?.let { closeWindow(it) }
                return true
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_TAB) {
                if (windows.size > 1) focusWindow(windows.first())
                return true
            }
            val f = focused
            if (f != null && !f.minimized && !startMenu.isOpen && f.app.onShortcut(e)) return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (startMenu.isOpen) {
            startMenu.close()
            return
        }
        focused?.app?.onBack()
        // As a launcher, Back never leaves the desktop.
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCallback = null
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (startMenu.isOpen) startMenu.close()
    }

    override fun onResume() {
        super.onResume()
        applyDisplayPrefs()
        handler.post(tick)
        windows.toList().forEach { it.app.onResume() }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
