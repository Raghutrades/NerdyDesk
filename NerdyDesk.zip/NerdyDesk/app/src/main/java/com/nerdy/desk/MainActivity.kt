package com.nerdy.desk

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("ClickableViewAccessibility")
class MainActivity : Activity() {
    companion object {
        const val REQ_FILE = 42
        const val REQ_WALL = 43
        const val REQ_PERM = 44
        const val TASKBAR_DP = 48
    }

    lateinit var prefs: SharedPreferences
    lateinit var desktop: FrameLayout
    lateinit var startMenu: StartMenu
    lateinit var quick: QuickPanel
    lateinit var switcher: TaskSwitcher
    lateinit var overlay: FrameLayout
    private lateinit var rootLayout: FrameLayout
    private lateinit var wallLayer: FrameLayout
    private lateinit var taskbarView: View
    private lateinit var pinnedBox: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var trayView: TextView
    private lateinit var startBtn: FrameLayout
    private lateinit var iconGrid: GridLayout
    private lateinit var snapPreview: View
    private lateinit var nightTint: View
    private var wallLive: View? = null

    val windows = ArrayList<WindowView>()
    var focused: WindowView? = null
    var filePathCallback: ValueCallback<Array<Uri>>? = null
    var lastX = 0
    var lastY = 0
    val animations: Boolean get() = prefs.getBoolean("anim", true)

    private val handler = Handler(Looper.getMainLooper())
    private val recentApps = ArrayList<String>()
    private var cascade = 0
    private var cascadeExt = 0
    private var winUsed = false
    private var lastRows = -1
    private var fsWindow: WindowView? = null
    private var fsFromNormal = false
    private var lock: LockView? = null
    private var boot: BootView? = null

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 20000)
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nerdydesk", MODE_PRIVATE)
        MusicEngine.init(this)
        Ui.accent = Ui.accents[prefs.getInt("accent", 0).coerceIn(0, Ui.accents.size - 1)]
        ensureDefaultPins()
        buildUi()
        applyDisplayPrefs()
        MusicEngine.listeners.add { runOnUiThread { updateTray() } }
        if (savedInstanceState == null && prefs.getBoolean("boot", true)) startBoot()
    }

    override fun onResume() {
        super.onResume()
        applyDisplayPrefs()
        handler.post(tick)
        setLive(true)
        windows.toList().forEach { it.app.onResume() }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        setLive(false)
        windows.toList().forEach { it.app.onPause() }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeOverlays()
    }

    private fun setLive(on: Boolean) {
        (wallLive as? AuroraView)?.running = on
        (wallLive as? StarView)?.running = on
    }

    // ------------------------------------------------------------ UI

    private fun buildUi() {
        rootLayout = FrameLayout(this)
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = FrameLayout(this)
        desktop.isClickable = true
        desktop.setOnClickListener {
            clearIconSelection()
            closeOverlays()
        }
        desktop.setOnContextClickListener { desktopMenu(); true }
        desktop.setOnLongClickListener { desktopMenu(); true }
        wallLayer = FrameLayout(this)
        desktop.addView(wallLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        iconGrid = GridLayout(this)
        iconGrid.orientation = GridLayout.VERTICAL
        iconGrid.setPadding(dp(8), dp(8), dp(8), dp(8))
        desktop.addView(iconGrid, FrameLayout.LayoutParams(WRAP, MATCH))
        snapPreview = View(this)
        snapPreview.background = Ui.rect(c(0x330078D4), dp(8).toFloat(), c(0xAA4CC2FF), 3)
        snapPreview.visibility = View.GONE
        desktop.addView(snapPreview, FrameLayout.LayoutParams(10, 10))
        desktop.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop || lastRows < 0) buildIcons()
        }
        column.addView(desktop, lp(MATCH, 0, 1f))
        taskbarView = buildTaskbar()
        column.addView(taskbarView, lp(MATCH, dp(TASKBAR_DP)))
        rootLayout.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        val abovebar = { FrameLayout.LayoutParams(MATCH, MATCH).also { it.bottomMargin = dp(TASKBAR_DP) } }
        startMenu = StartMenu(this)
        rootLayout.addView(startMenu, abovebar())
        quick = QuickPanel(this)
        rootLayout.addView(quick, abovebar())
        switcher = TaskSwitcher(this)
        rootLayout.addView(switcher, FrameLayout.LayoutParams(MATCH, MATCH))
        nightTint = View(this)
        nightTint.isClickable = false
        rootLayout.addView(nightTint, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = FrameLayout(this)
        rootLayout.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(rootLayout)

        applyWallpaper()
        setNightLight(prefs.getBoolean("night", false))
        refreshTaskbar()
    }

    private fun buildTaskbar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.taskbar)
        bar.elevation = dp(8).toFloat()

        startBtn = FrameLayout(this)
        startBtn.isClickable = true
        startBtn.background = Ui.stateBg(0f)
        startBtn.addView(WinLogo(this), FrameLayout.LayoutParams(MATCH, MATCH))
        startBtn.setOnClickListener { toggleStart() }
        startBtn.hand()
        bar.addView(startBtn, lp(dp(52), MATCH))

        val search = TextView(this)
        search.text = "\uD83D\uDD0D  Type here to search"
        search.textSize = 12f
        search.setTextColor(Ui.textDim)
        search.gravity = Gravity.CENTER_VERTICAL
        search.setPadding(dp(14), 0, dp(14), 0)
        search.background = Ui.stateBg(dp(17).toFloat(), c(0x22FFFFFF))
        search.isClickable = true
        search.setOnClickListener {
            if (!startMenu.isOpen) startMenu.open()
            startMenu.focusSearch2()
        }
        search.hand()
        val sl = lp(dp(180), dp(34))
        sl.setMargins(dp(2), 0, dp(4), 0)
        bar.addView(search, sl)

        val tv = TextView(this)
        tv.text = "\u29C9"
        tv.textSize = 20f
        tv.setTextColor(Ui.text)
        tv.gravity = Gravity.CENTER
        tv.isClickable = true
        tv.background = Ui.stateBg(0f)
        tv.setOnClickListener { toggleSwitcher() }
        tv.hand()
        bar.addView(tv, lp(dp(44), MATCH))

        pinnedBox = LinearLayout(this)
        pinnedBox.orientation = LinearLayout.HORIZONTAL
        bar.addView(pinnedBox, lp(0, MATCH, 1f))

        trayView = TextView(this)
        trayView.textSize = 12f
        trayView.setTextColor(Ui.text)
        trayView.gravity = Gravity.CENTER
        trayView.setPadding(dp(8), 0, dp(4), 0)
        trayView.isClickable = true
        trayView.background = Ui.stateBg(0f)
        trayView.setOnClickListener { quick.toggle() }
        trayView.hand()
        bar.addView(trayView, lp(WRAP, MATCH))

        clockView = TextView(this)
        clockView.textSize = 11f
        clockView.setTextColor(Ui.text)
        clockView.gravity = Gravity.CENTER
        clockView.setPadding(dp(10), 0, dp(10), 0)
        clockView.isClickable = true
        clockView.background = Ui.stateBg(0f)
        clockView.setOnClickListener { quick.toggle() }
        clockView.hand()
        bar.addView(clockView, lp(WRAP, MATCH))

        val sliver = View(this)
        sliver.isClickable = true
        sliver.background = Ui.stateBg(0f, c(0x22FFFFFF))
        sliver.setOnClickListener { showDesktop() }
        bar.addView(sliver, lp(dp(8), MATCH))
        return bar
    }

    // ------------------------------------------------------------ wallpaper & night light

    fun makeWallpaperView(): View {
        val w = prefs.getInt("wall", 101)
        if (w == 101) return AuroraView(this)
        if (w == 102) return StarView(this)
        if (w == 100) {
            val f = File(filesDir, "wall.jpg")
            if (f.exists()) {
                val bmp = Thumbs.decodeImage(f.path, 2200)
                if (bmp != null) {
                    val iv = ImageView(this)
                    iv.scaleType = ImageView.ScaleType.CENTER_CROP
                    iv.setImageBitmap(bmp)
                    return iv
                }
            }
        }
        val v = View(this)
        v.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, Ui.wallpapers[(if (w in 0..5) w else 1)])
        return v
    }

    fun applyWallpaper() {
        wallLayer.removeAllViews()
        val v = makeWallpaperView()
        wallLive = v
        wallLayer.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    fun setWallpaper(i: Int) {
        prefs.edit().putInt("wall", i).apply()
        applyWallpaper()
    }

    fun pickWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        if (!startActivityOk(i, REQ_WALL)) toast("No photo picker available")
    }

    private fun startActivityOk(i: Intent, req: Int): Boolean = try {
        startActivityForResult(i, req)
        true
    } catch (e: Exception) {
        false
    }

    fun setAccent(i: Int) {
        prefs.edit().putInt("accent", i).apply()
        Ui.accent = Ui.accents[i]
        windows.forEach { it.setActive(it === focused) }
        refreshTaskbar()
    }

    fun setNightLight(on: Boolean) {
        prefs.edit().putBoolean("night", on).apply()
        nightTint.setBackgroundColor(if (on) c(0x40FF8C00) else 0)
    }

    fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v.coerceIn(0.02f, 1f)
        window.attributes = lp
    }

    fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    @Suppress("DEPRECATION")
    fun applyDisplayPrefs() {
        if (prefs.getBoolean("fullscreen", true)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        updateClock()
    }

    // ------------------------------------------------------------ pins, desktop icons, taskbar

    private fun ensureDefaultPins() {
        if (!prefs.contains("pins_task")) {
            savePins(
                "pins_task", listOf("b:FILES", "b:BROWSER", "b:PHOTOS", "b:VIDEO", "b:MUSIC", "b:HABIT", "b:SETTINGS")
            )
        }
        if (!prefs.contains("pins_desk")) {
            savePins(
                "pins_desk",
                listOf(
                    "b:FILES", "d:downloads", "b:BROWSER", "b:HABIT", "b:PHOTOS", "b:VIDEO", "b:MUSIC", "b:NOTEPAD",
                    "b:CALC", "b:SETTINGS", "p:com.nerdyintruder.nerdybrowser", "p:com.nerdyintruder.nerdyplayer"
                )
            )
        }
    }

    fun resetPins() {
        prefs.edit().remove("pins_task").remove("pins_desk").apply()
        ensureDefaultPins()
        refreshTaskbar()
        lastRows = -1
        buildIcons()
    }

    private fun savePins(key: String, list: List<String>) {
        prefs.edit().putString(key, JSONArray(list).toString()).apply()
    }

    fun pins(key: String): MutableList<String> {
        val s = prefs.getString(key, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { a.getString(it) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun isPinned(key: String, k: String): Boolean = pins(key).contains(k)

    fun togglePin(key: String, k: String) {
        val l = pins(key)
        if (!l.remove(k)) l.add(k)
        savePins(key, l)
        refreshTaskbar()
        lastRows = -1
        buildIcons()
    }

    private class DeskItem(val key: String, val label: String, val emoji: String?, val icon: android.graphics.drawable.Drawable?, val action: () -> Unit)

    private fun resolve(key: String): DeskItem? {
        if (key.startsWith("b:")) {
            val k = try {
                AppKind.valueOf(key.substring(2))
            } catch (e: Exception) {
                return null
            }
            return DeskItem(key, if (k == AppKind.FILES) "This PC" else k.title, k.icon, null) { open(k, null) }
        }
        if (key == "d:downloads") {
            return DeskItem(key, "Downloads", "\u2B07\uFE0F", null) { open(AppKind.FILES, Files.downloads().absolutePath) }
        }
        if (key.startsWith("p:")) {
            val pkg = key.substring(2)
            return try {
                val pm = packageManager
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                DeskItem(key, label, null, pm.getApplicationIcon(pkg)) { launchApp(pkg) }
            } catch (e: Exception) {
                null
            }
        }
        return null
    }

    private fun buildIcons() {
        val h = desktop.height
        if (h <= 0) return
        val rows = maxOf(1, (h - dp(16)) / dp(92))
        lastRows = rows
        iconGrid.removeAllViews()
        iconGrid.rowCount = rows
        for (key in pins("pins_desk")) {
            val di = resolve(key) ?: continue
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(6), dp(2), dp(4))
            cell.background = Ui.stateBg(dp(4).toFloat(), 0, c(0x22FFFFFF), c(0x33FFFFFF), c(0x40FFFFFF))
            if (di.icon != null) {
                val iv = ImageView(this)
                iv.setImageDrawable(di.icon)
                cell.addView(iv, lp(dp(40), dp(40)))
            } else {
                val e = TextView(this)
                e.text = di.emoji
                e.textSize = 30f
                e.gravity = Gravity.CENTER
                cell.addView(e, lp(MATCH, dp(40)))
            }
            val t = TextView(this)
            t.text = di.label
            t.textSize = 12f
            t.setTextColor(Color.WHITE)
            t.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            cell.addView(t, lp(MATCH, WRAP))
            cell.activate(onSelect = { clearIconSelection() }) { di.action() }
            cell.setOnContextClickListener { iconMenu(di); true }
            cell.setOnLongClickListener { iconMenu(di); true }
            cell.hand()
            val g = GridLayout.LayoutParams()
            g.width = dp(84)
            g.height = dp(88)
            iconGrid.addView(cell, g)
        }
    }

    private fun iconMenu(it: DeskItem) {
        MenuPopup.show(
            this, null,
            listOf(
                MI("Open") { it.action() },
                MI("Remove from desktop") { togglePin("pins_desk", it.key) },
                MI(if (isPinned("pins_task", it.key)) "Unpin from taskbar" else "Pin to taskbar") { togglePin("pins_task", it.key) }
            )
        )
    }

    private fun clearIconSelection() {
        for (i in 0 until iconGrid.childCount) iconGrid.getChildAt(i).isSelected = false
    }

    fun refreshTaskbar() {
        if (!this::pinnedBox.isInitialized) return
        pinnedBox.removeAllViews()
        val pinned = pins("pins_task")
        val keys = LinkedHashSet<String>(pinned)
        windows.forEach { keys.add("b:" + it.kind.name) }
        recentApps.forEach { keys.add("p:$it") }
        for (k in keys) taskButton(k, pinned.contains(k))?.let { pinnedBox.addView(it, lp(dp(50), MATCH)) }
    }

    private fun taskButton(key: String, pinned: Boolean): View? {
        val cell = FrameLayout(this)
        cell.isClickable = true
        cell.background = Ui.stateBg(0f)
        var running = false
        var hasFocus = false
        if (key.startsWith("b:")) {
            val kind = try {
                AppKind.valueOf(key.substring(2))
            } catch (e: Exception) {
                return null
            }
            val ws = windows.filter { it.kind == kind }
            running = ws.isNotEmpty()
            hasFocus = ws.any { it === focused }
            val ic = TextView(this)
            ic.text = kind.icon
            ic.textSize = 20f
            ic.gravity = Gravity.CENTER
            cell.addView(ic, FrameLayout.LayoutParams(MATCH, MATCH))
            cell.setOnClickListener { onTaskClick(kind) }
            val menu = {
                MenuPopup.show(
                    this, cell,
                    listOf(
                        MI("New " + kind.title + " window") { open(kind, null, true) },
                        MI(if (pinned) "Unpin from taskbar" else "Pin to taskbar") { togglePin("pins_task", key) },
                        MI("Close all windows") { windows.filter { it.kind == kind }.forEach { closeWindow(it) } }
                    )
                )
            }
            cell.setOnLongClickListener { menu(); true }
            cell.setOnContextClickListener { menu(); true }
        } else {
            val pkg = key.substring(2)
            val d = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                return null
            }
            running = recentApps.contains(pkg)
            val iv = ImageView(this)
            iv.setImageDrawable(d)
            cell.addView(iv, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            cell.setOnClickListener { launchApp(pkg) }
            val menu = {
                MenuPopup.show(
                    this, cell,
                    listOf(
                        MI("Open") { launchApp(pkg) },
                        MI(if (pinned) "Unpin from taskbar" else "Pin to taskbar") { togglePin("pins_task", key) },
                        MI("Remove from taskbar") {
                            recentApps.remove(pkg)
                            if (pinned) togglePin("pins_task", key) else refreshTaskbar()
                        },
                        MI("App info") {
                            startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                        }
                    )
                )
            }
            cell.setOnLongClickListener { menu(); true }
            cell.setOnContextClickListener { menu(); true }
        }
        cell.isSelected = hasFocus
        if (running) {
            val u = View(this)
            u.setBackgroundColor(Ui.accent)
            cell.addView(u, FrameLayout.LayoutParams(if (hasFocus) dp(22) else dp(10), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        }
        cell.hand()
        return cell
    }

    private fun onTaskClick(kind: AppKind) {
        val ws = windows.filter { it.kind == kind }
        when {
            ws.isEmpty() -> open(kind, null)
            ws.size == 1 -> {
                val w = ws[0]
                if (!w.minimized && focused === w) minimizeWindow(w) else focusWindow(w)
            }
            else -> {
                val idx = ws.indexOf(focused)
                focusWindow(ws[(idx + 1) % ws.size])
            }
        }
    }

    fun updateTray() {
        if (!this::trayView.isInitialized) return
        val sb = StringBuilder()
        if (MusicEngine.isPlaying()) sb.append("\uD83C\uDFB5  ")
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        sb.append(
            when {
                caps == null -> "\u26A0"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "\uD83D\uDCF6"
                else -> "\uD83D\uDCE1"
            }
        )
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (lvl >= 0 && sc > 0) sb.append("  \uD83D\uDD0B ").append(lvl * 100 / sc).append("%")
        trayView.text = sb.toString()
    }

    private fun updateClock() {
        if (!this::clockView.isInitialized) return
        val now = Date()
        val tf = if (prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm a"
        clockView.text = SimpleDateFormat(tf, Locale.getDefault()).format(now) + "\n" +
            SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(now)
        updateTray()
    }

    private fun desktopMenu() {
        MenuPopup.show(
            this, null,
            listOf(
                MI("Open File Explorer", "Win+E") { open(AppKind.FILES, null) },
                MI("Open Browser") { open(AppKind.BROWSER, null) },
                MI("", sep = true),
                MI("Personalize") { open(AppKind.SETTINGS, "personalize") },
                MI("Refresh") { lastRows = -1; buildIcons(); applyWallpaper() },
                MI("", sep = true),
                MI("Task Manager", "Ctrl+Shift+Esc") { open(AppKind.TASKMGR, null) },
                MI("Lock screen", "Win+L") { lockNow() }
            )
        )
    }

    // ------------------------------------------------------------ boot / lock

    private fun startBoot() {
        val b = BootView(this) {
            boot?.let { overlay.removeView(it) }
            boot = null
            if (prefs.getBoolean("lock", true)) lockNow()
        }
        b.isClickable = true
        boot = b
        overlay.addView(b, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    fun lockNow() {
        if (lock != null || boot != null) return
        closeOverlays()
        val l = LockView(this) {
            lock?.let { overlay.removeView(it) }
            lock = null
        }
        lock = l
        overlay.addView(l, FrameLayout.LayoutParams(MATCH, MATCH))
        l.requestFocus()
    }

    fun restartDesktop() {
        windows.toList().forEach { closeWindow(it) }
        closeOverlays()
        startBoot()
    }

    fun closeOverlays() {
        if (this::startMenu.isInitialized) startMenu.close()
        if (this::quick.isInitialized) quick.close()
        if (this::switcher.isInitialized) switcher.hide()
    }

    // ------------------------------------------------------------ windows

    fun open(kind: AppKind, arg: String?, forceNew: Boolean = false): WindowView {
        closeOverlays()
        if (!forceNew && kind in setOf(AppKind.HABIT, AppKind.SETTINGS, AppKind.TASKMGR, AppKind.MUSIC, AppKind.CALC)) {
            val ex = windows.firstOrNull { it.kind == kind }
            if (ex != null) {
                focusWindow(ex)
                ex.app.handleArg(arg)
                return ex
            }
        }
        val app = kind.create(this, arg)
        val w = WindowView(this, kind, app)
        app.window = w
        val dw = desktop.width
        val dh = desktop.height
        val ww = minOf(dp(kind.w), (dw * 0.94f).toInt())
        val wh = minOf(dp(kind.h), (dh * 0.94f).toInt())
        val x = minOf(dp(24) + cascade * dp(28), maxOf(0, dw - ww))
        val y = minOf(dp(10) + cascade * dp(24), maxOf(0, dh - wh))
        cascade = (cascade + 1) % 6
        val l = FrameLayout.LayoutParams(ww, wh)
        l.leftMargin = x
        l.topMargin = y
        desktop.addView(w, l)
        windows.add(w)
        if (dw < dp(560)) w.toggleMax()
        focusWindow(w)
        w.animateIn()
        return w
    }

    fun focusWindow(w: WindowView?) {
        closeOverlays()
        if (w != null) {
            if (w.minimized) w.restore()
            windows.remove(w)
            windows.add(w)
            if (desktop.indexOfChild(w) != desktop.childCount - 1) w.bringToFront()
        }
        focused = w
        windows.forEach { it.setActive(it === w) }
        refreshTaskbar()
    }

    fun minimizeWindow(w: WindowView) {
        w.minimize()
        if (fsWindow === w) exitFullscreen()
        if (focused === w) focusWindow(windows.lastOrNull { !it.minimized }) else refreshTaskbar()
    }

    fun closeWindow(w: WindowView) {
        if (fsWindow === w) exitFullscreen()
        try {
            w.app.onClose()
        } catch (e: Exception) {
        }
        windows.remove(w)
        if (focused === w) focused = null
        w.animateOut { desktop.removeView(w) }
        focusWindow(windows.lastOrNull { !it.minimized })
    }

    fun showSnapPreview(zone: Int) {
        if (zone == 0) {
            snapPreview.visibility = View.GONE
            return
        }
        val w = desktop.width
        val h = desktop.height
        val hw = w / 2
        val hh = h / 2
        val r = when (zone) {
            WindowView.Z_LEFT -> intArrayOf(0, 0, hw, h)
            WindowView.Z_RIGHT -> intArrayOf(hw, 0, w - hw, h)
            WindowView.Z_TL -> intArrayOf(0, 0, hw, hh)
            WindowView.Z_TR -> intArrayOf(hw, 0, w - hw, hh)
            WindowView.Z_BL -> intArrayOf(0, hh, hw, h - hh)
            WindowView.Z_BR -> intArrayOf(hw, hh, w - hw, h - hh)
            else -> intArrayOf(0, 0, w, h)
        }
        val p = snapPreview.layoutParams as FrameLayout.LayoutParams
        p.leftMargin = r[0] + dp(4)
        p.topMargin = r[1] + dp(4)
        p.width = r[2] - dp(8)
        p.height = r[3] - dp(8)
        snapPreview.layoutParams = p
        snapPreview.visibility = View.VISIBLE
        snapPreview.bringToFront()
    }

    private fun showDesktop() {
        if (windows.any { !it.minimized }) {
            windows.forEach { it.minimize() }
            focusWindow(null)
        } else {
            windows.forEach { it.restore() }
            focusWindow(windows.lastOrNull())
        }
    }

    fun toggleStart() {
        if (startMenu.isOpen) startMenu.close() else {
            quick.close()
            startMenu.open()
        }
    }

    fun toggleSwitcher() {
        if (switcher.isOpen) switcher.hide() else {
            startMenu.close()
            quick.close()
            switcher.show(0, false)
        }
    }

    fun onStartToggled() {
        startBtn.isSelected = startMenu.isOpen
    }

    fun enterFullscreen(w: WindowView) {
        if (fsWindow != null) return
        fsWindow = w
        fsFromNormal = w.state == WindowView.NORMAL
        taskbarView.visibility = View.GONE
        w.setChrome(false)
        if (!w.maximized) w.toggleMax()
    }

    fun exitFullscreen() {
        val w = fsWindow ?: return
        fsWindow = null
        taskbarView.visibility = View.VISIBLE
        w.setChrome(true)
        if (fsFromNormal) w.restoreNormal()
    }

    val inFullscreen: Boolean get() = fsWindow != null

    // ------------------------------------------------------------ other apps & files

    private fun hasFreeform(): Boolean =
        packageManager.hasSystemFeature("android.software.freeform_window_management") ||
            Settings.Global.getInt(contentResolver, "enable_freeform_support", 0) == 1 ||
            Settings.Global.getInt(contentResolver, "force_resizable_activities", 0) == 1

    fun freeformStatus(): String =
        if (hasFreeform()) "Freeform windows are available: other apps open as resizable windows."
        else "Freeform windows are OFF on this phone, so other apps open full screen. See the guide below to switch them on."

    private fun freeformOptions(): Bundle? {
        return try {
            val o = ActivityOptions.makeBasic()
            val loc = IntArray(2)
            desktop.getLocationOnScreen(loc)
            val w = (desktop.width * 0.62f).toInt()
            val h = (desktop.height * 0.84f).toInt()
            val off = (cascadeExt % 5) * dp(34)
            cascadeExt++
            val l = loc[0] + dp(44) + off
            val t = loc[1] + dp(12) + off
            o.setLaunchBounds(Rect(l, t, l + w, t + h))
            if (hasFreeform()) {
                try {
                    ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(o, 5)
                } catch (e: Throwable) {
                }
            }
            o.toBundle()
        } catch (e: Throwable) {
            null
        }
    }

    fun launchApp(pkg: String) {
        closeOverlays()
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            toast("App not found")
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val b = if (prefs.getBoolean("freeform", true)) freeformOptions() else null
        try {
            startActivity(i, b)
        } catch (e: Exception) {
            try {
                startActivity(i)
            } catch (x: Exception) {
                toast("Can't open this app")
                return
            }
        }
        if (!recentApps.contains(pkg)) recentApps.add(pkg)
        refreshTaskbar()
    }

    fun openFile(f: File) {
        val e = Files.ext(f)
        when {
            e in Files.imageExts -> open(AppKind.PHOTOS, f.path)
            e in Files.videoExts -> open(AppKind.VIDEO, f.path)
            e in Files.audioExts -> open(AppKind.MUSIC, f.path)
            e == "pdf" -> open(AppKind.PDF, f.path)
            e in Files.textExts -> open(AppKind.NOTEPAD, f.path)
            else -> openExternal(f)
        }
    }

    fun openExternal(f: File) {
        val uri = Uri.Builder().scheme("content").authority("$packageName.files").path(f.absolutePath).build()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(Files.ext(f)) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!startSafely(i)) toast("No app can open this file")
    }

    // ------------------------------------------------------------ permissions

    fun hasAllFiles(): Boolean = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else hasMediaAccess()

    fun hasMediaAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun hasStorage(): Boolean = hasAllFiles() || hasMediaAccess()

    fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            if (!startSafely(i)) startSafely(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS
                ), REQ_PERM
            )
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        windows.toList().forEach { it.app.onResume() }
    }

    // ------------------------------------------------------------ helpers

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun startSafely(i: Intent): Boolean = try {
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------------------ input

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastX = ev.rawX.toInt()
        lastY = ev.rawY.toInt()
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        lastX = ev.rawX.toInt()
        lastY = ev.rawY.toInt()
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        if (boot != null) return true
        val l = lock
        if (l != null) {
            if (down) l.unlock()
            return true
        }
        if (down && code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { MusicEngine.toggle(); return true }
        if (down && code == KeyEvent.KEYCODE_MEDIA_NEXT) { MusicEngine.next(); return true }
        if (down && code == KeyEvent.KEYCODE_MEDIA_PREVIOUS) { MusicEngine.prev(); return true }
        if (code == KeyEvent.KEYCODE_ALT_LEFT || code == KeyEvent.KEYCODE_ALT_RIGHT) {
            if (!down && switcher.isOpen && switcher.altMode) switcher.commit()
            return super.dispatchKeyEvent(e)
        }
        if (code == KeyEvent.KEYCODE_META_LEFT || code == KeyEvent.KEYCODE_META_RIGHT) {
            if (down && e.repeatCount == 0) winUsed = false
            if (!down && !winUsed) toggleStart()
            return true
        }
        if (down) {
            if (code == KeyEvent.KEYCODE_ESCAPE) {
                if (switcher.isOpen) { switcher.hide(); return true }
                if (quick.isOpen) { quick.close(); return true }
                if (startMenu.isOpen) { startMenu.close(); return true }
                if (inFullscreen) { exitFullscreen(); return true }
            }
            if (e.isMetaPressed) {
                val f = focused
                var handled = true
                when (code) {
                    KeyEvent.KEYCODE_E -> open(AppKind.FILES, null)
                    KeyEvent.KEYCODE_D -> showDesktop()
                    KeyEvent.KEYCODE_I -> open(AppKind.SETTINGS, null)
                    KeyEvent.KEYCODE_L -> lockNow()
                    KeyEvent.KEYCODE_M -> showDesktop()
                    KeyEvent.KEYCODE_S -> {
                        if (!startMenu.isOpen) startMenu.open()
                        startMenu.focusSearch2()
                    }
                    KeyEvent.KEYCODE_TAB -> toggleSwitcher()
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (f != null) { if (f.state == WindowView.SNAP) f.restoreNormal() else f.snap(WindowView.Z_LEFT) }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (f != null) { if (f.state == WindowView.SNAP) f.restoreNormal() else f.snap(WindowView.Z_RIGHT) }
                    KeyEvent.KEYCODE_DPAD_UP -> if (f != null && !f.maximized) f.toggleMax()
                    KeyEvent.KEYCODE_DPAD_DOWN -> if (f != null) { if (f.state != WindowView.NORMAL) f.restoreNormal() else minimizeWindow(f) }
                    else -> handled = false
                }
                if (handled) {
                    winUsed = true
                    return true
                }
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_F4) {
                focused?.let { closeWindow(it) }
                return true
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_TAB) {
                if (switcher.isOpen) switcher.next(e.isShiftPressed) else switcher.show(1, true)
                return true
            }
            if (e.isCtrlPressed && e.isShiftPressed && code == KeyEvent.KEYCODE_ESCAPE) {
                open(AppKind.TASKMGR, null)
                return true
            }
            val f = focused
            if (f != null && !f.minimized && !startMenu.isOpen && !switcher.isOpen && f.app.onShortcut(e)) return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (switcher.isOpen) { switcher.hide(); return }
        if (quick.isOpen) { quick.close(); return }
        if (startMenu.isOpen) { startMenu.close(); return }
        if (inFullscreen) { exitFullscreen(); return }
        focused?.app?.onBack()
        // As a launcher, Back never leaves the desktop.
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCallback = null
        } else if (requestCode == REQ_WALL && resultCode == RESULT_OK && data?.data != null) {
            try {
                val bytes = contentResolver.openInputStream(data.data!!)!!.use { it.readBytes() }
                val o = android.graphics.BitmapFactory.Options()
                o.inJustDecodeBounds = true
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 2400) s *= 2
                val o2 = android.graphics.BitmapFactory.Options()
                o2.inSampleSize = s
                val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                if (bmp != null) {
                    File(filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    setWallpaper(100)
                }
            } catch (e: Exception) {
                toast("Couldn't use that picture")
            }
        }
    }
}
