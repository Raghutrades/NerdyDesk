package com.nerdy.desk

import android.app.AlertDialog
import android.os.Environment
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class NotepadApp(act: MainActivity, path: String?) : App(act) {
    override val title = "Notepad"
    override val icon = "\uD83D\uDCDD"

    private var file: File? = path?.let { File(it) }
    private lateinit var edit: EditText
    private lateinit var info: TextView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private var dirty = false
    private var loading = false
    private var wrap = true
    private var size = 14f

    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bgDark)

        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.setBackgroundColor(c(0xFF2B2B2B))
        val l = lp(WRAP, WRAP)
        l.setMargins(0, 0, act.dp(4), 0)
        bar.addView(Ui.button(act, "New") { newDoc() }, l)
        bar.addView(Ui.button(act, "Save") { save() }, l)
        bar.addView(Ui.button(act, "Save as\u2026") { saveAs() }, l)
        bar.addView(Ui.button(act, "Find") { toggleFind() }, l)
        bar.addView(Ui.button(act, "Wrap") { wrap = !wrap; edit.setHorizontallyScrolling(!wrap) }, l)
        bar.addView(Ui.button(act, "A\u2212") { size = (size - 1f).coerceAtLeast(9f); edit.textSize = size }, l)
        bar.addView(Ui.button(act, "A+") { size = (size + 1f).coerceAtMost(40f); edit.textSize = size }, l)
        root.addView(bar, lp(MATCH, WRAP))

        findBar = LinearLayout(act)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setBackgroundColor(c(0xFF262626))
        findBar.setPadding(act.dp(8), act.dp(3), act.dp(6), act.dp(3))
        findBar.visibility = View.GONE
        findInput = EditText(act)
        findInput.setSingleLine()
        findInput.textSize = 13f
        findInput.hint = "Find"
        findInput.setTextColor(Ui.text)
        findInput.setHintTextColor(Ui.textDim)
        findInput.background = Ui.rect(c(0xFF1B1B1B), act.dp(6).toFloat())
        findInput.setPadding(act.dp(10), 0, act.dp(10), 0)
        findInput.setOnEditorActionListener { _, _, _ -> findNext(true); true }
        findBar.addView(findInput, lp(act.dp(220), act.dp(30)))
        findBar.addView(Ui.button(act, "\u2191") { findNext(false) }, l)
        findBar.addView(Ui.button(act, "\u2193") { findNext(true) }, l)
        root.addView(findBar, lp(MATCH, WRAP))

        edit = EditText(act)
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.gravity = Gravity.TOP or Gravity.START
        edit.setTextColor(Ui.text)
        edit.textSize = size
        edit.typeface = android.graphics.Typeface.MONOSPACE
        edit.background = null
        edit.setPadding(act.dp(10), act.dp(8), act.dp(10), act.dp(8))
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!loading) {
                    dirty = true
                    updateTitle()
                }
                updateInfo()
            }
        })
        edit.setOnClickListener { updateInfo() }
        edit.setOnKeyListener { _, _, ev ->
            if (ev.action == KeyEvent.ACTION_UP) updateInfo()
            false
        }
        root.addView(edit, lp(MATCH, 0, 1f))

        info = act.label("", 11f, Ui.textDim)
        info.setBackgroundColor(c(0xFF191919))
        info.setPadding(act.dp(10), act.dp(3), act.dp(10), act.dp(3))
        root.addView(info, lp(MATCH, WRAP))

        loadFile(file)
        edit.post {
            updateTitle()
            updateInfo()
        }
        return root
    }

    private fun loadFile(f: File?) {
        if (f == null || !f.exists()) return
        if (f.length() > 3_000_000) {
            act.toast("File is too large for Notepad")
            file = null
            return
        }
        loading = true
        try {
            edit.setText(f.readText())
        } catch (e: Exception) {
            act.toast("Can't read this file")
        }
        loading = false
        dirty = false
    }

    override fun handleArg(arg: String?) {
        if (arg != null) {
            file = File(arg)
            loadFile(file)
            updateTitle()
        }
    }

    private fun updateTitle() {
        window?.setTitle((if (dirty) "\u25CF " else "") + (file?.name ?: "Untitled") + " - Notepad")
    }

    private fun updateInfo() {
        val pos = edit.selectionStart.coerceAtLeast(0)
        val lay = edit.layout
        val line = if (lay != null) lay.getLineForOffset(pos) + 1 else 1
        val col = if (lay != null) pos - lay.getLineStart(line - 1) + 1 else pos + 1
        info.text = "Ln $line, Col $col     ${edit.text.length} characters" + (file?.let { "     " + it.parent } ?: "")
    }

    private fun toggleFind() {
        findBar.visibility = if (findBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (findBar.visibility == View.VISIBLE) findInput.requestFocus() else edit.requestFocus()
    }

    private fun findNext(forward: Boolean) {
        val q = findInput.text.toString()
        if (q.isEmpty()) return
        val text = edit.text.toString()
        val from = if (forward) edit.selectionEnd.coerceAtLeast(0) else (edit.selectionStart - 1).coerceAtLeast(0)
        var i = if (forward) text.indexOf(q, from, true) else text.lastIndexOf(q, from, true)
        if (i < 0) i = if (forward) text.indexOf(q, 0, true) else text.lastIndexOf(q, text.length, true)
        if (i < 0) {
            act.toast("Not found")
            return
        }
        edit.requestFocus()
        edit.setSelection(i, i + q.length)
        updateInfo()
    }

    private fun newDoc() {
        file = null
        loading = true
        edit.setText("")
        loading = false
        dirty = false
        updateTitle()
    }

    private fun save() {
        val f = file
        if (f == null) saveAs() else write(f)
    }

    private fun write(f: File) {
        try {
            f.parentFile?.mkdirs()
            f.writeText(edit.text.toString())
            file = f
            dirty = false
            updateTitle()
            act.toast("Saved ${f.name}")
        } catch (e: Exception) {
            act.toast("Save failed - is file access allowed?")
        }
    }

    private fun saveAs() {
        val input = EditText(act)
        input.setSingleLine()
        input.setText(file?.name ?: "Note.txt")
        val dir = file?.parentFile ?: Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        AlertDialog.Builder(act).setTitle("Save as (in ${dir.name})").setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) write(File(dir, n))
            }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_S -> { if (e.isShiftPressed) saveAs() else save(); return true }
                KeyEvent.KEYCODE_F -> { toggleFind(); return true }
                KeyEvent.KEYCODE_N -> { newDoc(); return true }
            }
        }
        if (e.keyCode == KeyEvent.KEYCODE_F3) { findNext(!e.isShiftPressed); return true }
        return false
    }

    override fun onClose() {
        val f = file
        if (dirty && f != null) {
            try {
                f.writeText(edit.text.toString())
            } catch (e: Exception) {
            }
        }
    }
}
