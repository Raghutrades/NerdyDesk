package com.nerdy.desk

import android.os.Environment
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import android.app.AlertDialog
import java.io.File

class NotepadApp(act: MainActivity, path: String?) : App(act) {
    override val title = "Notepad"
    override val icon = "\uD83D\uDCDD"

    private var file: File? = path?.let { File(it) }
    private lateinit var edit: EditText
    private var dirty = false
    private var loading = false

    override fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.bgDark)

        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(act.dp(6), act.dp(4), act.dp(6), act.dp(4))
        bar.setBackgroundColor(c(0xFF2B2B2B))
        val l = lp(WRAP, WRAP)
        l.setMargins(0, 0, act.dp(6), 0)
        bar.addView(Ui.button(act, "New") { newDoc() }, l)
        bar.addView(Ui.button(act, "Save") { save() }, l)
        bar.addView(Ui.button(act, "Save as\u2026") { saveAs() }, l)
        root.addView(bar, lp(MATCH, WRAP))

        edit = EditText(act)
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.gravity = Gravity.TOP or Gravity.START
        edit.setTextColor(Ui.text)
        edit.textSize = 14f
        edit.typeface = android.graphics.Typeface.MONOSPACE
        edit.background = null
        edit.setPadding(act.dp(10), act.dp(8), act.dp(10), act.dp(8))
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!loading) {
                    dirty = true
                    updateTitle()
                }
            }
        })
        root.addView(edit, lp(MATCH, 0, 1f))

        val f = file
        if (f != null && f.exists()) {
            if (f.length() > 2_000_000) {
                Toast.makeText(act, "File is too large for Notepad", Toast.LENGTH_SHORT).show()
                file = null
            } else {
                loading = true
                try {
                    edit.setText(f.readText())
                } catch (e: Exception) {
                    Toast.makeText(act, "Can't read this file", Toast.LENGTH_SHORT).show()
                }
                loading = false
            }
        }
        edit.post { updateTitle() }
        return root
    }

    private fun updateTitle() {
        window?.setTitle((if (dirty) "\u25CF " else "") + (file?.name ?: "Untitled") + " - Notepad")
    }

    private fun newDoc() {
        file = null
        loading = true
        edit.setText("")
        loading = false
        dirty = false
        updateTitle()
    }

    private fun save() {
        val f = file
        if (f == null) {
            saveAs()
            return
        }
        write(f)
    }

    private fun write(f: File) {
        try {
            f.parentFile?.mkdirs()
            f.writeText(edit.text.toString())
            file = f
            dirty = false
            updateTitle()
            Toast.makeText(act, "Saved ${f.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(act, "Save failed (is file access allowed?)", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveAs() {
        val input = EditText(act)
        input.setSingleLine()
        input.setText(file?.name ?: "Note.txt")
        AlertDialog.Builder(act)
            .setTitle("Save as (in Documents)")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                    write(File(dir, n))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onShortcut(e: KeyEvent): Boolean {
        if (e.isCtrlPressed && e.keyCode == KeyEvent.KEYCODE_S) {
            save()
            return true
        }
        return false
    }

    override fun onClose() {
        val f = file
        if (dirty && f != null) {
            try {
                f.writeText(edit.text.toString())
            } catch (e: Exception) {
            }
        }
    }
}
