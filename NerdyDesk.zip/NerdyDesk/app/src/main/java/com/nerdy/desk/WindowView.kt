package com.nerdy.desk

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class WindowView(val act: MainActivity, val kind: AppKind, val app: App) : FrameLayout(act) {
    var minimized = false
    var maximized = false
    private var active = false
    private var rx = 0
    private var ry = 0
    private var rw = 0
    private var rh = 0
    private val bar = LinearLayout(act)
    private val titleView = TextView(act)
    private var maxBtn: TextView? = null
    private val grip = TextView(act)
    private var lastBarUp = 0L

    init {
        elevation = dp(12).toFloat()
        applyBg()

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL

        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val ic = TextView(act)
        ic.text = app.icon
        ic.textSize = 14f
        ic.setPadding(dp(10), 0, dp(6), 0)
        bar.addView(ic)
        titleView.text = app.title
        titleView.textSize = 12f
        titleView.setSingleLine()
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(winBtn("\u2014", false) { act.minimizeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        val mb = winBtn("\u25A2", false) { toggleMax() }
        maxBtn = mb
        bar.addView(mb, LinearLayout.LayoutParams(dp(46), MATCH))
        bar.addView(winBtn("\u2715", true) { act.closeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(36)))

        val body = FrameLayout(act)
        body.addView(app.build(), FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        grip.text = "\u25E2"
        grip.textSize = 12f
        grip.setTextColor(Ui.textDim)
        grip.gravity = Gravity.BOTTOM or Gravity.END
        grip.setPadding(0, 0, dp(3), dp(1))
        addView(grip, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.BOTTOM or Gravity.END))

        setActive(false)
        setupDrag()
        setupResize()
    }

    private fun applyBg() {
        val r = if (maximized) 0f else dp(8).toFloat()
        background = Ui.rect(Ui.bgDark, r, if (active) Ui.accent else Ui.border, 1)
    }

    private fun winBtn(label: String, isClose: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(0f, 0, if (isClose) c(0xFFE81123) else Ui.hover, Ui.press, Ui.hover)
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    fun setTitle(t: String) {
        titleView.text = t
    }

    fun setActive(a: Boolean) {
        active = a
        applyBg()
        bar.setBackgroundColor(if (a) c(0xFF2B2B2B) else c(0xFF1E1E1E))
        titleView.setTextColor(if (a) Ui.text else Ui.textDim)
    }

    fun minimize() {
        minimized = true
        visibility = View.GONE
    }

    fun restore() {
        minimized = false
        visibility = View.VISIBLE
    }

    fun toggleMax() {
        val p = layoutParams as FrameLayout.LayoutParams
        if (!maximized) {
            rx = p.leftMargin; ry = p.topMargin; rw = p.width; rh = p.height
            p.leftMargin = 0; p.topMargin = 0; p.width = MATCH; p.height = MATCH
            maximized = true
            grip.visibility = View.GONE
        } else {
            p.leftMargin = rx; p.topMargin = ry; p.width = rw; p.height = rh
            maximized = false
            grip.visibility = View.VISIBLE
        }
        maxBtn?.text = if (maximized) "\u2750" else "\u25A2"
        applyBg()
        layoutParams = p
    }

    private fun setupDrag() {
        var sx = 0f
        var sy = 0f
        var sl = 0
        var st = 0
        var moved = false
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    val p = layoutParams as FrameLayout.LayoutParams
                    sx = e.rawX; sy = e.rawY; sl = p.leftMargin; st = p.topMargin
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!maximized) {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true
                        val par = parent as View
                        val p = layoutParams as FrameLayout.LayoutParams
                        p.leftMargin = (sl + dx).toInt().coerceIn(-width + dp(90), par.width - dp(90))
                        p.topMargin = (st + dy).toInt().coerceIn(0, par.height - dp(36))
                        layoutParams = p
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - lastBarUp < 350) {
                            toggleMax()
                            lastBarUp = 0
                        } else {
                            lastBarUp = e.eventTime
                        }
                    }
                }
            }
            true
        }
    }

    private fun setupResize() {
        var sx = 0f
        var sy = 0f
        var sw = 0
        var sh = 0
        grip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    sx = e.rawX; sy = e.rawY; sw = width; sh = height
                }
                MotionEvent.ACTION_MOVE -> {
                    val par = parent as View
                    val p = layoutParams as FrameLayout.LayoutParams
                    p.width = (sw + e.rawX - sx).toInt().coerceIn(dp(320), par.width - p.leftMargin)
                    p.height = (sh + e.rawY - sy).toInt().coerceIn(dp(220), par.height - p.topMargin)
                    layoutParams = p
                }
            }
            true
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && act.focused !== this) act.focusWindow(this)
        return false
    }
}
