package com.nerdy.desk

import android.annotation.SuppressLint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class WindowView(val act: MainActivity, val kind: AppKind, val app: App) : FrameLayout(act) {
    companion object {
        const val NORMAL = 0
        const val MAX = 1
        const val SNAP = 2
        const val Z_LEFT = 1
        const val Z_RIGHT = 2
        const val Z_MAX = 3
        const val Z_TL = 4
        const val Z_TR = 5
        const val Z_BL = 6
        const val Z_BR = 7
    }

    var minimized = false
    var state = NORMAL
    val maximized: Boolean get() = state == MAX
    private var active = false
    private var chrome = true
    private var normal = intArrayOf(0, 0, 0, 0)
    private val bar = LinearLayout(act)
    private val titleView = TextView(act)
    private var maxBtn: TextView? = null
    private val hRight = View(act)
    private val hBottom = View(act)
    private val hCorner = View(act)
    private var lastBarUp = 0L

    init {
        elevation = dp(12).toFloat()
        applyBg()

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL

        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val ic = TextView(act)
        ic.text = kind.icon
        ic.textSize = 14f
        ic.setPadding(dp(10), 0, dp(6), 0)
        bar.addView(ic)
        titleView.text = app.title
        titleView.textSize = 12f
        titleView.setSingleLine()
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(winBtn("\u2014", false) { act.minimizeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        val mb = winBtn("\u25A2", false) { toggleMax() }
        maxBtn = mb
        bar.addView(mb, LinearLayout.LayoutParams(dp(46), MATCH))
        bar.addView(winBtn("\u2715", true) { act.closeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(36)))

        val body = FrameLayout(act)
        body.addView(app.build(), FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        addView(hRight, FrameLayout.LayoutParams(dp(7), MATCH, Gravity.END).also { it.topMargin = dp(36); it.bottomMargin = dp(16) })
        addView(hBottom, FrameLayout.LayoutParams(MATCH, dp(7), Gravity.BOTTOM).also { it.rightMargin = dp(16) })
        addView(hCorner, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.BOTTOM or Gravity.END))
        attachResize(hRight, true, false, PointerIcon.TYPE_HORIZONTAL_DOUBLE_ARROW)
        attachResize(hBottom, false, true, PointerIcon.TYPE_VERTICAL_DOUBLE_ARROW)
        attachResize(hCorner, true, true, PointerIcon.TYPE_TOP_LEFT_DIAGONAL_DOUBLE_ARROW)

        setActive(false)
        setupDrag()
    }

    private fun applyBg() {
        val r = if (state == MAX || !chrome) 0f else dp(8).toFloat()
        val d = GradientDrawable()
        d.setColor(Ui.bgDark)
        d.cornerRadius = r
        d.setStroke(1, if (active && chrome) Ui.accent else Ui.border)
        background = d
    }

    private fun winBtn(label: String, isClose: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(0f, 0, if (isClose) c(0xFFE81123) else Ui.hover, Ui.press, Ui.hover)
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    fun setTitle(t: String) {
        titleView.text = t
    }

    fun setActive(a: Boolean) {
        active = a
        applyBg()
        bar.setBackgroundColor(if (a) c(0xFF2B2B2B) else c(0xFF1E1E1E))
        titleView.setTextColor(if (a) Ui.text else Ui.textDim)
    }

    /** Hides the title bar and borders (used for full-screen video). */
    fun setChrome(on: Boolean) {
        chrome = on
        bar.visibility = if (on) View.VISIBLE else View.GONE
        updateHandles()
        applyBg()
    }

    private fun updateHandles() {
        val v = if (chrome && state != MAX) View.VISIBLE else View.GONE
        hRight.visibility = v
        hBottom.visibility = v
        hCorner.visibility = v
    }

    // ---- minimize / restore / close animations

    fun minimize() {
        if (minimized) return
        minimized = true
        if (!act.animations) {
            visibility = View.GONE
            return
        }
        animate().alpha(0f).translationY(dp(60).toFloat()).scaleX(0.9f).scaleY(0.9f).setDuration(140).withEndAction {
            visibility = View.GONE
            alpha = 1f
            translationY = 0f
            scaleX = 1f
            scaleY = 1f
        }.start()
    }

    fun restore() {
        if (!minimized) return
        minimized = false
        visibility = View.VISIBLE
        if (act.animations) {
            alpha = 0f
            translationY = dp(40).toFloat()
            animate().alpha(1f).translationY(0f).setDuration(160).start()
        }
    }

    fun animateIn() {
        if (!act.animations) return
        alpha = 0f
        scaleX = 0.94f
        scaleY = 0.94f
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).start()
    }

    fun animateOut(end: () -> Unit) {
        if (!act.animations) {
            end()
            return
        }
        animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(110).withEndAction { end() }.start()
    }

    // ---- maximize / snap

    private fun lp(): FrameLayout.LayoutParams = layoutParams as FrameLayout.LayoutParams

    private fun saveNormal() {
        val p = lp()
        normal = intArrayOf(p.leftMargin, p.topMargin, p.width, p.height)
    }

    private fun applyRect(l: Int, t: Int, w: Int, h: Int) {
        val p = lp()
        p.leftMargin = l
        p.topMargin = t
        p.width = w
        p.height = h
        layoutParams = p
    }

    private fun refreshState() {
        maxBtn?.text = if (state == MAX) "\u2750" else "\u25A2"
        updateHandles()
        applyBg()
    }

    fun toggleMax() {
        if (state == MAX) {
            restoreNormal()
        } else {
            if (state == NORMAL) saveNormal()
            applyRect(0, 0, MATCH, MATCH)
            state = MAX
            refreshState()
        }
    }

    fun restoreNormal() {
        if (state == NORMAL) return
        applyRect(normal[0], normal[1], normal[2], normal[3])
        state = NORMAL
        refreshState()
    }

    fun snap(zone: Int) {
        val par = parent as View
        val w = par.width
        val h = par.height
        if (zone == Z_MAX) {
            if (state != MAX) toggleMax()
            return
        }
        if (state == NORMAL) saveNormal()
        val hw = w / 2
        val hh = h / 2
        when (zone) {
            Z_LEFT -> applyRect(0, 0, hw, h)
            Z_RIGHT -> applyRect(hw, 0, w - hw, h)
            Z_TL -> applyRect(0, 0, hw, hh)
            Z_TR -> applyRect(hw, 0, w - hw, hh)
            Z_BL -> applyRect(0, hh, hw, h - hh)
            Z_BR -> applyRect(hw, hh, w - hw, h - hh)
            else -> return
        }
        state = SNAP
        refreshState()
    }

    fun showMenu(x: Int, y: Int) {
        MenuPopup.show(
            act, null,
            listOf(
                MI("Restore", "") { restoreNormal() },
                MI(if (state == MAX) "Restore size" else "Maximize", "Win+\u2191") { toggleMax() },
                MI("Minimize", "") { act.minimizeWindow(this) },
                MI("", sep = true),
                MI("Snap left", "Win+\u2190") { snap(Z_LEFT) },
                MI("Snap right", "Win+\u2192") { snap(Z_RIGHT) },
                MI("", sep = true),
                MI("Close", "Alt+F4") { act.closeWindow(this) }
            ), x, y
        )
    }

    // ---- touch / mouse

    private fun zoneAt(rawX: Float, rawY: Float): Int {
        val par = parent as View
        val loc = IntArray(2)
        par.getLocationOnScreen(loc)
        val px = rawX - loc[0]
        val py = rawY - loc[1]
        val edge = dp(10)
        val nl = px < edge
        val nr = px > par.width - edge
        val nt = py < edge
        return when {
            nt && nl -> Z_TL
            nt && nr -> Z_TR
            nl -> Z_LEFT
            nr -> Z_RIGHT
            nt -> Z_MAX
            else -> 0
        }
    }

    private fun setupDrag() {
        var sx = 0f
        var sy = 0f
        var sl = 0
        var st = 0
        var moved = false
        var zone = 0
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    if ((e.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                        showMenu(e.rawX.toInt(), e.rawY.toInt())
                        return@setOnTouchListener true
                    }
                    val p = lp()
                    sx = e.rawX
                    sy = e.rawY
                    sl = p.leftMargin
                    st = p.topMargin
                    moved = false
                    zone = 0
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5))) {
                        moved = true
                        if (state != NORMAL) {
                            // dragging a maximized/snapped window pulls it back to its old size
                            val bl = IntArray(2)
                            bar.getLocationOnScreen(bl)
                            val frac = ((e.rawX - bl[0]) / maxOf(1, bar.width)).coerceIn(0.1f, 0.9f)
                            restoreNormal()
                            val par = parent as View
                            val pl = IntArray(2)
                            par.getLocationOnScreen(pl)
                            val nw = normal[2]
                            sl = (e.rawX - pl[0] - frac * nw).toInt()
                            st = (e.rawY - pl[1] - dp(18)).toInt().coerceAtLeast(0)
                            sx = e.rawX
                            sy = e.rawY
                            applyRect(sl, st, normal[2], normal[3])
                        }
                    }
                    if (moved && state == NORMAL) {
                        val par = parent as View
                        val p = lp()
                        p.leftMargin = (sl + e.rawX - sx).toInt().coerceIn(-width + dp(90), par.width - dp(90))
                        p.topMargin = (st + e.rawY - sy).toInt().coerceIn(0, par.height - dp(36))
                        layoutParams = p
                        val z = zoneAt(e.rawX, e.rawY)
                        if (z != zone) {
                            zone = z
                            act.showSnapPreview(z)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    act.showSnapPreview(0)
                    if (moved) {
                        if (zone != 0 && e.actionMasked == MotionEvent.ACTION_UP) snap(zone)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (e.eventTime - lastBarUp < 350) {
                            toggleMax()
                            lastBarUp = 0
                        } else {
                            lastBarUp = e.eventTime
                        }
                    }
                }
            }
            true
        }
    }

    private fun attachResize(h: View, dxOn: Boolean, dyOn: Boolean, cursor: Int) {
        var sx = 0f
        var sy = 0f
        var sw = 0
        var sh = 0
        if (android.os.Build.VERSION.SDK_INT >= 24) h.pointerIcon = PointerIcon.getSystemIcon(act, cursor)
        h.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    sx = e.rawX
                    sy = e.rawY
                    sw = width
                    sh = height
                }
                MotionEvent.ACTION_MOVE -> {
                    val par = parent as View
                    val p = lp()
                    if (state == SNAP) state = NORMAL.also { refreshState() }
                    if (dxOn) p.width = (sw + e.rawX - sx).toInt().coerceIn(dp(320), par.width - p.leftMargin)
                    if (dyOn) p.height = (sh + e.rawY - sy).toInt().coerceIn(dp(220), par.height - p.topMargin)
                    layoutParams = p
                }
            }
            true
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && act.focused !== this) act.focusWindow(this)
        return false
    }
}
