package com.nerdy.desk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** One row of a popup menu. */
class MI(
    val label: String,
    val hint: String = "",
    val checked: Boolean? = null,
    val sep: Boolean = false,
    val action: () -> Unit = {}
)

object MenuPopup {
    /** Shows a dark, PC-style popup menu under [anchor], or at the pointer position when anchor is null. */
    fun show(act: MainActivity, anchor: View?, items: List<MI>, x: Int = act.lastX, y: Int = act.lastY) {
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.minimumWidth = act.dp(210)
        col.setPadding(act.dp(4), act.dp(4), act.dp(4), act.dp(4))
        col.background = Ui.rect(c(0xF2262626), act.dp(8).toFloat(), Ui.border, 1)
        val pw = PopupWindow(col, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(0))
        pw.isOutsideTouchable = true
        pw.elevation = act.dp(16).toFloat()
        for (m in items) {
            if (m.sep) {
                val d = View(act)
                d.setBackgroundColor(Ui.border)
                val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                l.setMargins(act.dp(8), act.dp(4), act.dp(8), act.dp(4))
                col.addView(d, l)
                continue
            }
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(act.dp(6), act.dp(8), act.dp(14), act.dp(8))
            row.isClickable = true
            row.background = Ui.stateBg(act.dp(5).toFloat())
            val chk = TextView(act)
            chk.text = if (m.checked == true) "\u2713" else ""
            chk.setTextColor(Ui.accent)
            chk.gravity = Gravity.CENTER
            row.addView(chk, LinearLayout.LayoutParams(act.dp(22), ViewGroup.LayoutParams.WRAP_CONTENT))
            val t = TextView(act)
            t.text = m.label
            t.textSize = 13f
            t.setTextColor(Ui.text)
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (m.hint.isNotEmpty()) {
                val h = TextView(act)
                h.text = m.hint
                h.textSize = 11f
                h.setTextColor(Ui.textDim)
                h.setPadding(act.dp(24), 0, 0, 0)
                row.addView(h)
            }
            row.setOnClickListener {
                pw.dismiss()
                m.action()
            }
            row.hand()
            col.addView(row)
        }
        col.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = col.measuredWidth
        val h = col.measuredHeight
        val decor = act.window.decorView
        val d = IntArray(2)
        decor.getLocationOnScreen(d)
        val sw = decor.width
        val sh = decor.height
        var px: Int
        var py: Int
        if (anchor != null) {
            val loc = IntArray(2)
            anchor.getLocationOnScreen(loc)
            px = loc[0] - d[0]
            py = loc[1] - d[1] + anchor.height
            if (py + h > sh) py = loc[1] - d[1] - h
        } else {
            px = x - d[0]
            py = y - d[1]
            if (py + h > sh) py -= h
        }
        px = px.coerceIn(0, maxOf(0, sw - w))
        py = py.coerceIn(0, maxOf(0, sh - h))
        pw.showAtLocation(decor, Gravity.NO_GRAVITY, px, py)
    }
}

object Files {
    val imageExts = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
    val videoExts = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts", "flv")
    val audioExts = setOf("mp3", "wav", "flac", "m4a", "ogg", "aac", "opus", "wma", "amr")
    val textExts = setOf(
        "txt", "md", "log", "json", "xml", "csv", "ini", "cfg", "conf", "yml", "yaml",
        "kt", "java", "py", "js", "html", "css", "sh", "gradle", "properties", "srt", "vtt"
    )
    val archiveExts = setOf("zip", "rar", "7z", "tar", "gz")

    fun downloads(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    fun ext(f: File): String = f.extension.lowercase(Locale.ROOT)

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = f.nameWithoutExtension
        val ex = if (f.extension.isEmpty()) "" else "." + f.extension
        var n = 1
        while (f.exists()) {
            f = File(dir, "$base ($n)$ex")
            n++
        }
        return f
    }

    /** Saves bytes to Downloads (falls back to the app's own folder when Android blocks it). */
    fun saveToDownloads(ctx: Context, name: String, bytes: ByteArray): File? {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val dirs = listOfNotNull(downloads(), ctx.getExternalFilesDir(null))
        for (d in dirs) {
            try {
                d.mkdirs()
                val f = unique(d, safe)
                f.writeBytes(bytes)
                return f
            } catch (e: Exception) {
            }
        }
        return null
    }

    fun humanSize(b: Long): String {
        if (b < 1024) return "$b B"
        val kb = b / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024)
    }

    fun fmtTime(ms: Long): String {
        val s = (ms / 1000).toInt()
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss) else String.format(Locale.US, "%d:%02d", m, ss)
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)

    fun load(key: String, view: ImageView, decode: () -> Bitmap?) {
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        pool.execute {
            val bmp = try {
                decode()
            } catch (e: Throwable) {
                null
            }
            if (bmp != null) cache.put(key, bmp)
            view.post { if (view.tag == key && bmp != null) view.setImageBitmap(bmp) }
        }
    }

    fun decodeImage(path: String, max: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        var b = BitmapFactory.decodeFile(path, o2) ?: return null
        try {
            val ori = ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            val deg = when (ori) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            }
        } catch (e: Exception) {
        }
        return b
    }

    fun decodeVideo(path: String, max: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            val f = r.getFrameAtTime(1_000_000L) ?: r.getFrameAtTime(0L) ?: return null
            val sc = max.toFloat() / maxOf(f.width, f.height)
            if (sc < 1f) Bitmap.createScaledBitmap(f, (f.width * sc).toInt(), (f.height * sc).toInt(), true) else f
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }
}

fun Context.label(text: String, size: Float = 13f, color: Int = Ui.text, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}
