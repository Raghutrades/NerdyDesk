/* ===== Board focus: tap a goal and its brainstorm map is written on the board itself (no pop-up). Scroll by dragging. ===== */
function wbData(g){const t=todayKey(),L=lenDays(g),day=clamp(diffD(g.start,t)+1,0,L),left=Math.max(0,L-day),q=isB(g),I=wallInsights(g),bs=g.bs||(g.bs={h:[],d:[],n:[]}),kind=wbKind(g);
 ['h','d','n'].forEach(k=>{if(!bs[k])bs[k]=[]});
 const plan=[['End goal',g.why||(q?'Free of this habit for the whole round':'Complete the full round of '+L+' days')+(g.metric?' · target: '+g.metric:'')],['Duration',L+' days · '+fmtD(g.start)+' to '+fmtD(g.end)+' · day '+day+' · '+left+' left'],['Schedule',schedText(g)+(g.cue?' · cue: '+g.cue:'')]];
 (g.tasks||[]).forEach(x=>{const tx=typeof x==='string'?x:(x.t||x.name||x.text||'');if(tx)plan.push(['Step',tx])});
 const own=k=>bs[k].map((x,i)=>({t:x,k,i})),sg=(k,list)=>list.filter(x=>!bs[k].includes(x)).slice(0,4);
 return[{k:null,name:'Plan',c:'#6f8cff',leaves:plan.map(p=>({t:p[0]+': '+p[1]}))},
  {k:'h',name:'Hurdles',c:'#ff6b81',leaves:own('h'),sug:sg('h',WB_SUG.h[kind]||WB_SUG.h.gen),ph:'What could get in the way?'},
  {k:'d',name:'Distractions',c:'#ffab5c',leaves:own('d'),sug:sg('d',q?WB_SUG.d.quit:WB_SUG.d.gen),ph:'What could pull me away?'},
  {k:null,name:'What is working',c:'#4fe3a5',leaves:I.work.map(x=>({t:x}))},
  {k:null,name:'What is not working',c:'#f58bc4',leaves:I.not.map(x=>({t:x}))},
  {k:'n',name:'Next move',c:'#b79cff',leaves:I.next.map(x=>({t:x})).concat(own('n')),sug:sg('n',WB_SUG.n),ph:'My own next step'}]}
function wbWrap(s,maxW){const w=String(s).split(' '),out=[];let cur='';w.forEach(x=>{const tt=cur?cur+' '+x:x;if(cx.measureText(tt).width>maxW&&cur){out.push(cur);cur=x}else cur=tt});if(cur)out.push(cur);return out}
function wallFocus(id){const g=gById(id);if(!g)return;UI.sel=null;sfx('open');WL.foc={id,t:0,sc:0,scT:0,max:0,closing:false,dirty:true,dt0:0,data:null};wbInClose()}
function wallBack(){if(WL.foc){WL.foc.closing=true;sfx('tick');wbInClose()}}
function wbInClose(){const e=document.getElementById('wbin');if(e)e.remove();if(WL.foc)WL.foc.inK=null}
function wbInOpen(k){const F=WL.foc,g=F&&gById(F.id);if(!g)return;const b=(F.data||[]).find(x=>x.k===k);F.inK=k;wbInClose();F.inK=k;const e=document.createElement('div');e.id='wbin';
 e.innerHTML=`<input id="wbinp" class="bsin" maxlength="120" autocomplete="off" placeholder="${esc(b?b.ph:'Write here')}" data-enter="wbfadd"><button class="btn pri sm" data-act="wbfadd">Add</button><button class="btn sm" data-act="wbfx">Done</button>`;
 (document.getElementById('mapwrap')||document.body).appendChild(e);setTimeout(()=>{const i=document.getElementById('wbinp');if(i)i.focus()},60)}
function wbAddLeaf(g,k,v){v=String(v||'').trim();if(!v)return false;g.bs=g.bs||{h:[],d:[],n:[]};g.bs[k]=g.bs[k]||[];if(g.bs[k].includes(v))return false;g.bs[k].push(v);const key=k+':'+(g.bs[k].length-1);WL.lw[key]=0;WL.hold[g.id]=WL.hold[g.id];WL.q.push({type:'leaf',id:g.id,key});if(WL.foc){WL.foc.dirty=true;WL.foc.want=key}save();sfx('tick');return true}
function wallHit(b){const F=WL.foc,g=F&&gById(F.id);if(!g)return;
 if(b.wb==='back')wallBack();
 else if(b.wb==='fire'){ACT.done({dataset:{id:g.id}});F.dirty=true}
 else if(b.wb==='full'){openDrawer(g.id)}
 else if(b.wb==='rep'){wallBack();wallReplay(g)}
 else if(b.wb==='sug'){wbAddLeaf(g,b.k,b.v)}
 else if(b.wb==='own'){wbInOpen(b.k)}
 else if(b.wb==='del'){if(g.bs&&g.bs[b.k]){g.bs[b.k].splice(b.i,1);Object.keys(WL.lw).forEach(x=>{if(x.indexOf(b.k+':')===0)delete WL.lw[x]});WL.q=WL.q.filter(x=>!(x.type==='leaf'&&x.key.indexOf(b.k+':')===0));F.dirty=true;save();sfx('tick')}}}
function wallFocusDraw(now,dt,t,rd,bx,by,bw,bh,CH,u){
 const F=WL.foc,g=F&&gById(F.id);if(!g){WL.foc=null;wbInClose();return}
 F.t+=((F.closing?0:1)-F.t)*Math.min(1,dt*(rd?40:7));if(rd)F.t=F.closing?0:1;if(F.closing&&F.t<.03){WL.foc=null;wbInClose();return}
 if(F.dirty||!F.data||now-F.dt0>3000){try{F.data=wbData(g)}catch(e){F.data=F.data||[]}F.dirty=false;F.dt0=now}
 const a=F.t,hf=clamp(bh*.05,11,18),fs=hf*.82,lh=fs*1.34,pad=bw*.04,left=bx+pad,right=bx+bw-pad,topY=by+bh*.135,botY=by+bh-6,q=isB(g),done=dueState(g).s==='done',live=a>.6&&!F.closing;
 cx.save();cx.globalAlpha=a;cx.lineCap='round';cx.lineJoin='round';cx.textAlign='left';
 const rr=(x,y,w,h,r)=>{cx.beginPath();cx.moveTo(x+r,y);cx.arcTo(x+w,y,x+w,y+h,r);cx.arcTo(x+w,y+h,x,y+h,r);cx.arcTo(x,y+h,x,y,r);cx.arcTo(x,y,x+w,y,r);cx.closePath()};
 /* header chips */
 {const items=[['back','‹ Back'],['fire',done?'Undo today':q?'Clean day':'Fire'],['full','Details'],['rep','Rewrite']];let f2=hf*.82;cx.font='400 '+f2+'px '+WL_FONT;let tot=items.reduce((s2,i)=>s2+cx.measureText(i[1]).width+f2*1.5,0)+(items.length-1)*6;const av=bw-pad*2;if(tot>av){f2*=av/tot;cx.font='400 '+f2+'px '+WL_FONT}
  let x=left;const y=by+bh*.03,h=f2*1.9;items.forEach(i=>{const w=cx.measureText(i[1]).width+f2*1.5;cx.strokeStyle=i[0]==='fire'?'rgba(120,255,170,.9)':'rgba(246,248,238,.65)';cx.lineWidth=1.5;rr(x,y,w,h,h/2);cx.stroke();if(i[0]==='fire'){cx.fillStyle='rgba(120,255,170,.1)';cx.fill()}cx.fillStyle=i[0]==='fire'?'rgba(150,255,190,.98)':CH;cx.fillText(i[1],x+f2*.75,y+h*.66);if(live)BHIT.push({wb:i[0],x,w,y0:y,y1:y+h,wall:true});x+=w+6})}
 cx.strokeStyle='rgba(246,248,238,.3)';cx.lineWidth=1.3;cx.beginPath();cx.moveTo(left,topY-hf*.5);cx.lineTo(right,topY-hf*.5);cx.stroke();
 /* scrolling content */
 cx.save();cx.beginPath();cx.rect(bx+2,topY-hf*.3,bw-4,botY-topY+hf*.3);cx.clip();
 let y=topY-F.sc;const vis=(y0,y1)=>y1>topY-hf*.3&&y0<botY;
 /* root */
 {const rh=hf*2.9;cx.strokeStyle=g.color;cx.lineWidth=2.2;rr(left,y,right-left,rh,hf*.7);cx.stroke();cx.fillStyle=rgba(g.color,.09);cx.fill();
  cx.font='400 '+hf*1.2+'px '+WL_FONT;cx.fillStyle=CH;let nm=g.name;const mw=right-left-hf*2;while(nm.length>3&&cx.measureText(nm).width>mw)nm=nm.slice(0,-2);cx.fillText(nm===g.name?nm:nm+'…',left+hf,y+hf*1.45);
  const L=lenDays(g),day=clamp(diffD(g.start,todayKey())+1,0,L);cx.font='400 '+fs*.85+'px '+WL_FONT;cx.fillStyle='rgba(246,248,238,.7)';cx.fillText((q?'Quit':'Build')+' · '+L+' days · day '+day+' · '+(done?(q?'clean day logged':'fired today'):'not logged today'),left+hf,y+hf*2.45);y+=rh+hf*.9}
 const spineX=left+pad*.8,sp0=y-hf*.9,lx=spineX+pad*1.7,lw=right-lx-pad*.2;
 (F.data||[]).forEach(b=>{
  cx.font='400 '+hf*.98+'px '+WL_FONT;const tw=cx.measureText(b.name).width,cw=tw+hf*1.5,chh=hf*1.75;
  cx.strokeStyle=b.c;cx.lineWidth=2;if(vis(y,y+chh)){rr(lx-pad*.6,y,cw,chh,chh/2);cx.stroke();cx.fillStyle=rgba(b.c,.14);cx.fill();cx.fillStyle=CH;cx.fillText(b.name,lx-pad*.6+hf*.75,y+chh*.68);
   cx.strokeStyle=rgba(b.c,.85);cx.beginPath();cx.moveTo(spineX,y+chh/2);cx.quadraticCurveTo(spineX+pad*.3,y+chh/2,lx-pad*.6,y+chh/2);cx.stroke()}
  y+=chh+hf*.55;
  cx.font='400 '+fs+'px '+WL_FONT;
  b.leaves.forEach(lf=>{const del=lf.k?hf*1.5:0,lines=wbWrap(lf.t,lw-del),hh=lines.length*lh,key=lf.k?lf.k+':'+lf.i:null,rv=key&&WL.lw[key]!=null?WL.lw[key]:1;
   if(key){let n=0;const ls=lines.map((s2,i)=>{n+=s2.length;return{s:s2,x:lx,y:y+i*lh+fs,w:cx.measureText(s2).width}});WL.lay[key]={lines:ls,n,fs,x:lx,nx:lx,w:lw};
    if(F.want===key){F.scT=clamp(F.sc+(y-(topY+(botY-topY)*.4)),0,F.max||1e9);F.want=null}}
   if(vis(y,y+hh)){let shown=Math.floor(rv*lines.reduce((s2,l)=>s2+l.length,0)),acc=0;cx.fillStyle=CH;
    lines.forEach((s2,i)=>{const k2=Math.max(0,Math.min(s2.length,shown-acc));acc+=s2.length;if(k2>0)cx.fillText(s2.slice(0,k2),lx,y+i*lh+fs)});
    cx.strokeStyle=rgba(b.c,.75);cx.lineWidth=1.4;cx.beginPath();cx.moveTo(lx,y+hh+fs*.15);cx.lineTo(right-del*.2,y+hh+fs*.15);cx.stroke();
    if(lf.k){cx.fillStyle='rgba(246,248,238,.55)';cx.font='400 '+fs*1.1+'px '+WL_FONT;cx.fillText('×',right-hf*.9,y+fs);cx.font='400 '+fs+'px '+WL_FONT;if(live)BHIT.push({wb:'del',k:lf.k,i:lf.i,x:right-hf*1.6,w:hf*1.8,y0:Math.max(y-4,topY),y1:Math.min(y+Math.max(hh,hf*1.6),botY),wall:true})}}
   y+=hh+fs*.6});
  if(b.k){/* suggestion chips and a way to write your own */
   const chips=b.sug.map(s2=>({t:'+ '+s2,v:s2,k:'sug'})).concat([{t:'✎ write my own',k:'own'}]);let cxp=lx,cy=y;const ch=fs*1.9,gap=6;cx.font='400 '+fs*.92+'px '+WL_FONT;
   chips.forEach(c2=>{let w=Math.min(cx.measureText(c2.t).width+fs*1.3,lw);if(cxp+w>right&&cxp>lx){cxp=lx;cy+=ch+gap}
    if(vis(cy,cy+ch)){cx.setLineDash([4,4]);cx.strokeStyle=rgba(b.c,.7);cx.lineWidth=1.3;rr(cxp,cy,w,ch,ch/2);cx.stroke();cx.setLineDash([]);cx.fillStyle=c2.k==='own'?CH:rgba(b.c,1);cx.save();cx.beginPath();cx.rect(cxp+2,cy,w-4,ch);cx.clip();cx.fillText(c2.t,cxp+fs*.65,cy+ch*.67);cx.restore();
     if(live)BHIT.push({wb:c2.k,k:b.k,v:c2.v,x:cxp,w,y0:Math.max(cy,topY),y1:Math.min(cy+ch,botY),wall:true})}
    cxp+=w+gap});y=cy+ch+fs*.4}
  y+=hf*.9});
 cx.strokeStyle='rgba(246,248,238,.25)';cx.lineWidth=1.6;cx.beginPath();cx.moveTo(spineX,sp0);cx.lineTo(spineX,y-hf*1.5);cx.stroke();
 F.ch=y+F.sc-topY;F.max=Math.max(0,F.ch-(botY-topY)+hf);cx.restore();
 F.scT=clamp(F.scT,0,F.max);F.sc+=(F.scT-F.sc)*Math.min(1,dt*(rd?40:16));
 if(F.max>4){cx.fillStyle='rgba(246,248,238,.3)';const th=Math.max(18,(botY-topY)*(botY-topY)/(F.ch||1));cx.fillRect(bx+bw-5,topY+(botY-topY-th)*(F.sc/F.max),2.5,th)}
 cx.restore()}
