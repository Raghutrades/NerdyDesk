/* ===== goal icon set (single-path line icons, 24 grid; used by SVG and by canvas Path2D) ===== */
const GI={
 chart:'M3 20h18M6 16v-5M10 16V8M14 16v-3M18 16V5',
 book:'M4 5c3-1 6-1 8 1 2-2 5-2 8-1v13c-3-1-6-1-8 1-2-2-5-2-8-1V5zM12 6v13',
 dumbbell:'M6 7v10M3 9.5v5M18 7v10M21 9.5v5M6 12h12',
 pulse:'M3 12h4l2-6 4 12 2-6h6',
 ball:'M12 3a9 9 0 100 18 9 9 0 000-18zM3.6 9c4 1.2 12.800 1.200 16.800 0M3.6 15c4-1.200 12.800-1.200 16.800 0M12 3v18',
 lotus:'M12 5c2 2 3 4 3 6s-1 4-3 5c-2-1-3-3-3-5s1-4 3-6zM4 10c3 0 5 2 6 5M20 10c-3 0-5 2-6 5M5 19h14',
 chat:'M4 5h16v11H10l-4 4v-4H4V5zM8 10h8',
 pot:'M5 11h14v6a3 3 0 01-3 3H8a3 3 0 01-3-3v-6zM3 11h18M9 4c0 2 2 2 0 4M14 4c0 2 2 2 0 4',
 sprout:'M12 21v-9M12 12c0-4-3-6-7-6 0 4 3 6 7 6zM12 14c0-3 2-5 6-5 0 3-2 5-6 5z',
 phones:'M4 15v-3a8 8 0 0116 0v3M4 15h3v5H5a1 1 0 01-1-1v-4zM20 15h-3v5h2a1 1 0 001-1v-4z',
 pen:'M4 20l1-4L16 5l3 3L8 19l-4 1zM14 7l3 3',
 cap:'M2 9l10-5 10 5-10 5L2 9zM6 11v5c3 2 9 2 12 0v-5',
 target:'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7.500a4.500 4.500 0 100 9 4.500 4.500 0 000-9zM12 11.500a.5.5 0 100 1 .5.5 0 000-1z',
 moon:'M20 14A8 8 0 0110 4a8 8 0 1010 10z',
 apple:'M12 8c-3-2-7 0-7 5 0 4 3 8 7 7 4 1 7-3 7-7 0-5-4-7-7-5zM12 8c0-2 1-3 3-4',
 notebook:'M6 3h12v18H6zM6 7H4M6 12H4M6 17H4M10 8h5M10 12h5',
 spark:'M12 3l2 6 6 3-6 3-2 6-2-6-6-3 6-3 2-6z',
 phone:'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2',
 smoke:'M3 15h13v3H3zM19 15v3M17 10c0-2 3-2 3-5M14 9c0-1.500 2-1.500 2-3.500',
 glass:'M6 3h12l-1 8a5 5 0 01-10 0L6 3zM12 16v5M8 21h8',
 candy:'M7 12a5 5 0 1010 0 5 5 0 00-10 0zM7 12L2 9v6l5-3zM17 12l5-3v6l-5-3z',
 pad:'M7 8h10a4 4 0 014 4v2a3 3 0 01-5.200 2L14 14h-4l-1.800 2A3 3 0 013 14v-2a4 4 0 014-4zM8 10v3M6.500 11.500h3',
 shield:'M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6l8-3zM9 12l2 2 4-4',
 heart:'M12 20s-8-5-8-11a4.500 4.500 0 018-2.500A4.500 4.500 0 0120 9c0 6-8 11-8 11z',
 bolt:'M13 3L5 13h6l-1 8 8-10h-6l1-8z',
 flame:'M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z',
 star:'M12 3l2.700 6 6.300.6-4.800 4.300 1.500 6.300L12 17l-5.700 3.200 1.500-6.300L3 9.600 9.300 9z',
 sun:'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2',
 brain:'M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 003 3V4zM15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-3 3V4z',
 music:'M9 18V5l11-2v13M9 18a3 3 0 11-6 0 3 3 0 016 0zM20 16a3 3 0 11-6 0 3 3 0 016 0z',
 code:'M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16',
 bike:'M5 17a3.500 3.500 0 100-7 3.500 3.500 0 000 7zM19 17a3.500 3.500 0 100-7 3.500 3.500 0 000 7zM5 13.500l4-6h6l4 6M9 7.500H7',
 drop:'M12 3s6 6.500 6 11a6 6 0 01-12 0c0-4.500 6-11 6-11z',
 wallet:'M3 7h16a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V7zM3 7l12-4v4M17 13.500h.01',
 walk:'M13 4.500a1.500 1.500 0 100 .01M12 8l-3 4 2 3-1 6M12 8l3 3h3M11 15l4 2v4',
 people:'M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3.500 2.500-6 6-6s6 2.500 6 6M16 5a3 3 0 010 6M18 14c2 .5 3.500 2.500 3.500 6',
 clock:'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2',
 leaf:'M5 19c0-9 5-14 15-14 0 10-5 15-14 15M5 19c3-5 6-8 10-10',
 paint:'M12 3a9 9 0 100 18c1.500 0 2-1 1.500-2s0-2 1.500-2h2a3 3 0 003-3c0-6-4-11-8-11zM7.500 11h.01M10 7.500h.01M15 8h.01',
 globe:'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
 trophy:'M7 4h10v5a5 5 0 01-10 0V4zM7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3M12 14v4M8 21h8',
 crown:'M3 8l4 4 5-7 5 7 4-4-2 11H5L3 8z',
 web:'M12 4a2 2 0 100 .01M5 18a2 2 0 100 .01M19 18a2 2 0 100 .01M12 6v5M12 11l-6 6M12 11l6 6M7 18h10',
 check:'M5 12l5 5 9-10',
 cut:'M6 6a2.500 2.500 0 100 5 2.500 2.500 0 000-5zM6 13a2.500 2.500 0 100 5 2.500 2.500 0 000-5zM8 10l12 9M8 14L20 5',
 save:'M5 4h12l3 3v13H5V4zM8 4v5h7V4M8 20v-6h8v6',
 flag:'M5 21V4M5 5h12l-2 4 2 4H5'
};
/* icons offered when creating a goal */
const GOAL_ICONS=['chart','book','dumbbell','pulse','walk','bike','ball','lotus','chat','pot','sprout','phones','pen','cap','target','moon','apple','notebook','drop','code','music','paint','wallet','people','globe','brain','sun','heart','bolt','flame','star','trophy','leaf','clock','spark','flag','phone','smoke','glass','candy','pad','shield','cut'];
const TPL_ICON={trading:'chart',reading:'book',workout:'dumbbell',running:'pulse',sport:'ball',meditation:'lotus',language:'chat',cooking:'pot',gardening:'sprout',listening:'phones',writing:'pen',study:'cap',deepwork:'target',sleep:'moon',nutrition:'apple',journal:'notebook',custom:'spark',q_scroll:'phone',q_smoke:'smoke',q_drink:'glass',q_sugar:'candy',q_game:'pad',q_custom:'shield'};
const EMOJI_ICON={'🧾':'chart','📖':'book','💪':'dumbbell','🏃':'pulse','⚽':'ball','🧘':'lotus','🗣':'chat','🍳':'pot','🌱':'sprout','🎧':'phones','✍':'pen','📚':'cap','🎯':'target','😴':'moon','🥗':'apple','📓':'notebook','✨':'spark','📱':'phone','🚬':'smoke','🍺':'glass','🍬':'candy','🎮':'pad','🛑':'shield','🚶':'walk','🏋':'dumbbell','🚴':'bike','💧':'drop','🔥':'flame','⭐':'star','❤':'heart','🧠':'brain','💰':'wallet','🎵':'music','🎨':'paint','💻':'code','☀':'sun','🌙':'moon','📈':'chart','🏆':'trophy','🌿':'leaf','⏰':'clock','🙏':'lotus','🏊':'drop','🍎':'apple','📝':'pen'};
const NAME_ICON=[[/walk|steps|stroll/i,'walk'],[/work\s?out|gym|lift|strength|exercise|fitness/i,'dumbbell'],[/run|jog|cardio/i,'pulse'],[/cycl|bike/i,'bike'],[/read|book/i,'book'],[/medit|breath|yoga|mindful/i,'lotus'],[/trad|market|stock|invest/i,'chart'],[/write|blog|essay/i,'pen'],[/study|learn|course/i,'cap'],[/sleep|bed/i,'moon'],[/water|hydrat/i,'drop'],[/code|program/i,'code'],[/music|guitar|piano|sing/i,'music'],[/cook|meal/i,'pot'],[/smok|cigar|vape/i,'smoke'],[/drink|alcohol|beer|wine/i,'glass'],[/scroll|phone|social|insta|youtube/i,'phone'],[/sugar|junk|sweet/i,'candy'],[/game|gaming/i,'pad'],[/money|save|budget/i,'wallet']];
function resolveIcon(g,tp){const ic=g.icon||g.emoji;if(ic&&GI[ic])return ic;
 const em=String(g.emoji||'').replace(/️/g,'').trim();if(EMOJI_ICON[em])return EMOJI_ICON[em];
 if(tp&&TPL_ICON[tp.id])return TPL_ICON[tp.id];
 for(const [re,n] of NAME_ICON)if(re.test(g.name||''))return n;
 return g.type==='break'?'shield':'spark'}
const ICO_ATTR='viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
const gico=(name,sz,col)=>`<svg ${ICO_ATTR} style="${sz?`width:${sz}px;height:${sz}px;`:''}${col?`color:${col}`:''}"><path d="${GI[name]||GI.spark}"/></svg>`;
const gI=(g,sz)=>gico(g.icon,sz,g.color);
/* canvas glyphs */
const P2D={};
function glyph(cx2,name,x,y,size,color,alpha){if(typeof Path2D==='undefined')return;const p=P2D[name]||(P2D[name]=new Path2D(GI[name]||GI.spark));cx2.save();cx2.translate(x-size/2,y-size/2);cx2.scale(size/24,size/24);cx2.globalAlpha=alpha==null?1:alpha;cx2.strokeStyle=color;cx2.lineWidth=2;cx2.lineCap='round';cx2.lineJoin='round';cx2.stroke(p);cx2.restore()}
