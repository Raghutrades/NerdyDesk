/* ===== sound engine: every effect is synthesized, no audio files ===== */
let AC=null,ambNode=null;
const NOTES=[262,294,330,392,440,523,588,659];
function ac(){try{if(!AC){const C=window.AudioContext||window.webkitAudioContext;try{AC=new C({latencyHint:'playback'})}catch(e){AC=new C()}}if(AC.state==='suspended')AC.resume()}catch(e){}return AC}
/* one master bus for every sound: headroom, then a fast limiter, then a soft clipper so loud volumes and headphones never crackle */
let MB=null;function mout(a){if(MB&&MB.ctx===a)return MB.n;const g=a.createGain();g.gain.value=.72;const c=a.createDynamicsCompressor();c.threshold.value=-18;c.knee.value=10;c.ratio.value=20;c.attack.value=.006;c.release.value=.25;const ws=a.createWaveShaper(),n=2048,cv=new Float32Array(n),k=1.4,nm=Math.tanh(k);for(let i=0;i<n;i++){const x=i/(n-1)*2-1;cv[i]=Math.tanh(x*k)/nm}ws.curve=cv;const o=a.createGain();o.gain.value=.9;g.connect(c);c.connect(ws);ws.connect(o);o.connect(a.destination);MB={ctx:a,n:g};return g}
function tone(f,d,o){o=o||{};if(!S.set.snd.on)return;const a=ac();if(!a)return;try{const t=a.currentTime+(o.at||0),os=a.createOscillator(),g=a.createGain(),v=Math.max(.0002,(o.v||.3)*S.set.snd.vol);
 os.type=o.type||'sine';os.frequency.setValueAtTime(f,t);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t+d);
 g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+(o.atk||.012));g.gain.exponentialRampToValueAtTime(.0001,t+d);
 let n=os;if(o.lp){const fl=a.createBiquadFilter();fl.type='lowpass';fl.frequency.value=o.lp;os.connect(fl);n=fl}
 n.connect(g);g.connect(mout(a));os.start(t);os.stop(t+d+.05)}catch(e){}}
function noise(d,o){o=o||{};if(!S.set.snd.on)return;const a=ac();if(!a)return;try{const len=Math.floor(a.sampleRate*d),b=a.createBuffer(1,len,a.sampleRate),c=b.getChannelData(0);for(let i=0;i<len;i++)c[i]=(Math.random()*2-1)*(1-i/len);
 const s=a.createBufferSource();s.buffer=b;const f=a.createBiquadFilter();f.type='bandpass';f.frequency.setValueAtTime(o.f||800,a.currentTime);if(o.to)f.frequency.exponentialRampToValueAtTime(o.to,a.currentTime+d);f.Q.value=o.q||1.2;
 const g=a.createGain();g.gain.value=(o.v||.15)*S.set.snd.vol;s.connect(f);f.connect(g);g.connect(mout(a));s.start()}catch(e){}}
const SFX={
 tap:()=>tone(520,.05,{type:'triangle',v:.08}),
 nav:()=>{tone(392,.07,{v:.12});tone(588,.1,{at:.05,v:.12})},
 open:()=>{tone(440,.08,{v:.1,type:'triangle'});tone(660,.1,{at:.06,v:.1,type:'triangle'})},
 close:()=>{tone(660,.06,{v:.08,type:'triangle'});tone(440,.09,{at:.05,v:.08,type:'triangle'})},
 tick:()=>{tone(880,.06,{type:'square',v:.06,lp:2400});tone(1320,.09,{at:.04,v:.09})},
 untick:()=>tone(330,.08,{type:'triangle',v:.1}),
 fire:i=>{const b=NOTES[(i||0)%NOTES.length];[1,1.25,1.5,2,2.5].forEach((m,j)=>tone(b*m,.28,{at:j*.07,v:.2}));tone(180,.6,{to:1400,type:'sawtooth',lp:1800,v:.06});noise(.5,{f:400,to:2000,v:.03})},
 clean:()=>{[523,659,784].forEach((f,i)=>tone(f,.7,{at:i*.05,v:.18}));noise(.4,{f:900,to:300,v:.02})},
 slip:()=>{tone(220,.5,{to:110,v:.22});tone(165,.6,{to:82,at:.08,v:.14})},
 skip:()=>tone(300,.18,{type:'triangle',v:.1}),
 badge:()=>[523,659,784,1047,1319].forEach((f,i)=>tone(f,.35,{at:i*.09,type:'triangle',v:.2})),
 start:()=>{tone(660,.1,{v:.18});tone(880,.14,{at:.12,v:.18})},
 bell:()=>{for(let i=0;i<3;i++){tone(880,1.1,{at:i*.9,v:.28});tone(1760,.8,{at:i*.9,v:.09})}},
 notify:()=>{tone(988,.18,{v:.22});tone(1319,.3,{at:.16,v:.22})},
 warn:()=>tone(180,.3,{type:'sawtooth',lp:600,v:.18}),
 create:()=>{tone(300,.4,{to:900,v:.18});tone(1200,.3,{at:.3,v:.1})},
 theme:()=>[659,880,1175].forEach((f,i)=>tone(f,.4,{at:i*.06,v:.1})),
 mode:()=>{noise(.7,{f:300,to:1800,v:.04,q:1.4});tone(220,.7,{to:660,v:.12,type:'triangle'})},
 splash:()=>{noise(1.4,{f:200,to:2200,v:.04,q:1.4});[196,294,392].forEach((f,i)=>tone(f,1.8,{at:.2+i*.25,v:.1,type:'triangle'}));tone(784,1.2,{at:1.5,v:.12})},
 zoom:()=>tone(700,.04,{v:.04,type:'triangle'})};
function sfx(n,a){try{(SFX[n]||SFX.tap)(a)}catch(e){}}
function ambience(on){const a=ac();if(!a||!S.set.snd.on)return;
 if(on&&!ambNode){const g=a.createGain();g.gain.value=0;const f=a.createBiquadFilter();f.type='lowpass';f.frequency.value=380;f.Q.value=.4;const os=[55,82.4,110.3].map((fr,i)=>{const o=a.createOscillator();o.type='sine';o.frequency.value=fr;const og=a.createGain();og.gain.value=[.5,.28,.16][i];o.connect(og);og.connect(f);o.start();return o});
  f.connect(g);g.connect(mout(a));g.gain.setTargetAtTime(.22*S.set.snd.vol,a.currentTime,1.2);ambNode={s:{stop:()=>os.forEach(o=>{try{o.stop()}catch(e){}})},g}}
 else if(!on&&ambNode){const n=ambNode;ambNode=null;try{n.g.gain.setTargetAtTime(0,a.currentTime,.2)}catch(e){}setTimeout(()=>{try{n.s.stop()}catch(e){}},1200)}}
