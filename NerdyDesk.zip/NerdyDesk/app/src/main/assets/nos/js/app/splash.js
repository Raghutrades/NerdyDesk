/* app/splash */
let SPDONE=false,SPSHORT=false;
function endSplash(){if(SPDONE)return;SPDONE=true;const s=$('#splash');s.classList.add('out');setTimeout(()=>s.remove(),900);afterSplash()}
function runSplash(){try{runSplash0()}catch(e){console.error(e);endSplash()}setTimeout(endSplash,15000)}
/* ===== cinematic neuroscience splash (scene in splash-scene.js). ~9s the first open of the day, ~3.7s on repeat opens ===== */
function runSplash0(){const sp=$('#splash'),k0=todayKey();if(!S.set.splash||new URLSearchParams(location.search).get('splash')==='0'){sp.remove();SPDONE=true;afterSplash();return}
 const shortRun=S.set.splashDay===k0;S.set.splashDay=k0;save();SPSHORT=shortRun&&!S.set.flags.fullSplash;
 const it=todayItems(k0).filter(i=>i.st.s==='due'),mx=S.goals.filter(g=>g.priority==='must'&&dueState(g,k0).s==='due'),tg=S.goals.find(g=>g.tpl==='trade'&&dueState(g,k0).s==='due'),h=new Date().getHours();
 const st=S.goals.length?(it.length?`${it.length} thing${it.length===1?'':'s'} due today${mx.length?', '+mx.length+' marked Must':''}${tg?'. Trading day: plan before the open':''}`:'Nothing due. Rest or get ahead.'):'Welcome. Plant your first neuron.';
 const nm=APPNAME.split('').map((c,i)=>`<i style="--i:${i}">${c}</i>`).join(''),rm=reduced(),K=rm?0:SPSHORT?.4:1;
 sp.className='v6 cin'+(SPSHORT?' short':'');
 sp.innerHTML=`${rm?'':'<canvas id="spcv"></canvas>'}<div class="v6c"><div class="v6logo">${logoSvg(124,true,'lgs')}</div><div class="v6name">${nm}</div><div class="v6tag">${esc(TAGLINE)}</div><div class="v6hi">${h<12?'Good morning':h<17?'Good afternoon':'Good evening'}${S.set.name?', '+esc(S.set.name):''}</div><div class="v6st">${esc(st)}</div></div><div class="spcap" id="spcap"></div><div class="v6bar"><i></i></div><button id="spskip" class="spb">Skip</button>`;
 const sk=$('#spskip');if(sk)sk.onclick=e=>{e.stopPropagation();endSplash()};sp.addEventListener('click',()=>{try{ac()}catch(e){}});
 const dur=rm?1300:Math.round(CIN.END*K*1000)+250;sp.style.setProperty('--d',dur+'ms');
 if(rm){Object.keys(CIN.at).forEach(c=>sp.classList.add(c));setTimeout(endSplash,dur);return}
 const cv=$('#spcv'),lg=sp.querySelector('.v6logo'),r=lg.getBoundingClientRect(),W=sp.clientWidth||innerWidth,H=sp.clientHeight||innerHeight;
 const sc=cinScene(cv,{w:W,h:H,target:{x:r.left+r.width/2,y:r.top+r.height/2},lite:(navigator.hardwareConcurrency||8)<=4}),cap=$('#spcap'),t0=performance.now();let ci=-1;
 const tick=now=>{if(SPDONE)return;const t=(now-t0)/1000/K;sc.draw(t);
  for(const c in CIN.at)if(t>=CIN.at[c])sp.classList.add(c);
  if(!SPSHORT){let n=-1;CIN.caps.forEach((c,i)=>{if(t>=c[0])n=i});if(n!==ci){ci=n;cap.classList.remove('on');setTimeout(()=>{if(SPDONE)return;const c=CIN.caps[ci];cap.textContent=c?c[1]:'';if(c&&c[1])cap.classList.add('on')},ci<0?0:260)}}
  else if(t>=CIN.caps[3][0]&&ci!==3){ci=3;cap.textContent=CIN.caps[3][1];cap.classList.add('on')}
  if(t<CIN.END)requestAnimationFrame(tick)};
 requestAnimationFrame(tick);
 /* sound: deep drone swell, heartbeat, spike sweep, synapse thump + pluck, a rain of pentatonic chimes while the forest lights up,
    a riser into the finale impact and a resolving chord. Only soft sines and low thumps, no noise, so nothing crackles. */
 try{const T=(f,d,at,v,o)=>tone(f,d,Object.assign({at:at*K,v,type:'sine'},o||{}));
  if(!SPSHORT){T(55,4.4,0,.09,{atk:1.8,lp:300});T(82.4,4,.5,.05,{atk:1.6,lp:300});
   [.9,1.9].forEach(a=>{T(92,.34,a,.15,{to:58,lp:400});T(84,.3,a+.2,.11,{to:54,lp:400})});
   T(260,2.0,2.35,.045,{to:1500,atk:.9});T(90,.9,4.45,.2,{to:40,lp:240,atk:.015});T(1397,.55,4.5,.05);T(2093,.4,4.58,.03);
   const PENT=[523,587,659,784,880,1047,1175,1319,1568];for(let i=0;i<22;i++)T(PENT[(i*5+Math.floor(i/3))%PENT.length],1.1,5.0+i*.17+(i%3)*.03,.03+(i%4)*.005);
   T(120,1.4,8.35,.06,{to:900,atk:.9})}
  T(70,1.8,CIN.TF-.02,.24,{to:34,lp:200,atk:.02});[523,659,784,988,1175].forEach((f,i)=>T(f,2.0,CIN.TF+.05+i*.12,.065))}catch(e){}
 setTimeout(endSplash,dur)}
