/* ===== v5 shell: five tabs. Board (home), Plan (today / week / month / goals), Insights, Journal, More. ===== */
IC.more='<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>';IC.book=IC.book||'<path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM8 4v13"/>';
const NAV5=[['home','Board','home'],['plan','Plan','cal'],['ins','Insights','ins'],['jour','Journal','jour'],['more','More','more']];
const ALIAS={goals:['plan','goals'],cal:['plan','cal']};
const SUBV=['guide','about','set'];
UI.plan=UI.plan||'goals';
function buildNav(){const cur=SUBV.includes(UI.view)?'more':UI.view;const mk=a=>a.map(v=>`<button data-act="nav" data-v="${v[0]}" class="${cur===v[0]?'on':''}">${ic(v[2])}<span>${v[1]}</span></button>`).join('');$('#nav').innerHTML=mk(NAV5);$('#bnav').innerHTML=mk(NAV5);
 $('#addbtn').innerHTML=ic('plus')+'<span>Add</span>';$('#sndbtn').innerHTML=ic(S.set.snd.on?'snd':'mute');$('#sndbtn').classList.toggle('on',S.set.snd.on);$('#musbtn').innerHTML=ic('music');$('#musbtn').classList.toggle('on',!!S.set.music.on);const pb=$('#pulbtn');if(pb)pb.innerHTML=ic('heart')}
function go(v){let sub=null;if(ALIAS[v]){sub=ALIAS[v][1];v='plan'}if(sub)UI.plan=sub;if(!['home','plan','ins','jour','more','guide','about','set'].includes(v))v='home';if(UI.fs)setFS(false);UI.view=v;S.set.view=v;
 $$('.view').forEach(s=>s.classList.toggle('on',s.id==='v-'+v));buildNav();closeDrawer(true);renderView();window.scrollTo(0,0);if(v==='home')setTimeout(size,30)}
function renderView(){const v=UI.view;try{({home:renderHome,plan:renderPlan,ins:renderIns,jour:renderJour,more:renderMore,guide:renderGuide,about:renderAbout,set:renderSet})[v]()}catch(e){console.error(e);showFail(e)}}
function renderPlan(){const T=[['today','Today'],['week','Week'],['cal','Month'],['goals','All goals']];if(!T.some(x=>x[0]===UI.plan))UI.plan='goals';
 $('#planhd').innerHTML=`<h1 class="pgt">Plan</h1><div class="seg5">${T.map(x=>`<button class="${UI.plan===x[0]?'on':''}" data-act="plansub" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;
 const g=$('#goalsc'),c=$('#calc');g.style.display=UI.plan==='goals'?'':'none';c.style.display=UI.plan==='cal'||UI.plan==='week'?'':'none';
 if(UI.plan==='goals')renderGoals();else if(UI.plan==='cal'){UI.cal.tab='month';renderCal()}else if(UI.plan==='week'){UI.cal.tab='week';renderCal()}else{g.style.display='';planToday(g)}
 [g,c].forEach(b=>{const h=b.querySelector('h1,h2');if(h&&/^(Goals|Calendar)$/.test(h.textContent.trim())){h.style.display='none';const n=h.nextElementSibling;if(n&&n.classList.contains('mute'))n.style.display='none'}})}
ACT.plansub=el=>{UI.plan=el.dataset.v;sfx('tick');renderPlan()};
function planToday(box){const t=todayKey(),its=trItems(),n=NOW();const rows=its.sort((a,b)=>(hmM(a.g.win&&a.g.win[0])??1e4)-(hmM(b.g.win&&b.g.win[0])??1e4));
 const mk=it=>{const g=it.g,l=it.l,st=it.st.s;return `<div class="pt ${st}"><button class="ptc" style="--c:${g.color}" data-act="done" data-id="${g.id}" aria-label="Mark done">${ic('check',14)}</button><div class="ptn" data-act="copen" data-id="${g.id}" data-k="${t}"><b>${esc(g.name)}</b><small>${g.win?g.win[0]+' to '+g.win[1]:'Any time'} · ${trKind(g)==='quit'?'Quit':trKind(g)==='task'?'Task':'Build'}${l&&l.at?' · done '+hm(new Date(l.at)):''}</small></div><button class="ibtn sm" data-act="slip" data-id="${g.id}" title="Log a slip" style="display:${trKind(g)==='quit'?'':'none'}">${ic('x',14)}</button></div>`};
 box.innerHTML=`<div class="moodbar plan">${moodBar()}</div><div class="card" style="margin-top:10px"><h3 style="margin:0 0 6px">Today</h3><div class="xs mute" style="margin-bottom:8px">${fmtLong(t)}. Tap a circle when it is done.</div>${rows.length?rows.map(mk).join(''):'<div class="mute sm">Nothing planned today. Add a habit, a quit goal or a daily task from the Add button.</div>'}</div><div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Coming up</h3>${[1,2,3,4,5,6].map(i=>{const k=addD(t,i),L=S.goals.filter(g=>!g.paused&&g.start<=k&&g.end>=k&&sched(g,k));return `<div class="row sm" style="padding:6px 0;border-top:1px solid var(--line)"><b style="width:86px">${fmtD(k)}</b><span class="mute" style="flex:1">${L.length?L.map(g=>esc(g.name)).join(', '):'free'}</span></div>`}).join('')}</div>`}
function renderMore(){const T=[['trade','Trading desk','pulse','Pre-market plan, live notes, trades and post-market review'],['music','Music','music','Stations: calm, focus, deep, bright, lo-fi'],['train','Train','train','Workouts with sets, timing and body animations'],['games','Games','games','Brain games and your scores'],['breath','Breathe','breathe','Breathing and meditation with insights'],['pulse','Pulse','pulse','How you feel right now'],['jour','Journal','jour','Moments, moods and photos'],['guide','Guide','guide','How everything works'],['set','Settings','set','Theme, sound, backup'],['about','About','about','About and credits']];
 const act={trade:'tdopen',music:'musicsheet',train:'train',games:'games',breath:'breath',pulse:'pulseopen'};
 $('#morec').innerHTML=`<h1 class="pgt">More</h1><div class="tiles5">${T.map(x=>`<button class="tile5" data-act="${act[x[0]]||'nav'}" data-v="${x[0]}">${ic(x[2],24)}<b>${x[1]}</b><small>${x[3]}</small></button>`).join('')}</div>`}
/* ===== v5 icon set: duotone (soft fill + clean stroke), thicker lines, rounder corners ===== */
const DT='fill="currentColor" fill-opacity=".2" stroke="none"';
Object.assign(IC,{
 home:`<path ${DT} d="M4 11l8-7 8 7v8a1 1 0 01-1 1H5a1 1 0 01-1-1z"/><path d="M4 11l8-7 8 7M6 10v9a1 1 0 001 1h10a1 1 0 001-1v-9M10 20v-5h4v5"/>`,
 cal:`<rect ${DT} x="3.5" y="5" width="17" height="15.500" rx="3.500"/><rect x="3.500" y="5" width="17" height="15.500" rx="3.500"/><path d="M8 3v4M16 3v4M3.500 10h17"/><circle cx="8.500" cy="14.500" r="1" fill="currentColor"/><circle cx="12" cy="14.500" r="1" fill="currentColor"/><circle cx="15.500" cy="14.500" r="1" fill="currentColor"/>`,
 ins:`<rect ${DT} x="4" y="11" width="4" height="9" rx="1.500"/><rect ${DT} x="10" y="4" width="4" height="16" rx="1.500"/><rect ${DT} x="16" y="8" width="4" height="12" rx="1.500"/><path d="M6 20v-9M12 20V4M18 20V8"/><path d="M3 20.500h18"/>`,
 jour:`<path ${DT} d="M6 3.500h10a3 3 0 013 3v13a1 1 0 01-1 1H7a3 3 0 01-3-3v-11a3 3 0 012-3z"/><path d="M6 3.500h10a3 3 0 013 3V20H7a3 3 0 01-3-3V6.500a3 3 0 012-3zM8 8.500h7M8 12.500h7M8 16.500h4"/>`,
 more:`<rect ${DT} x="3.500" y="3.500" width="7" height="7" rx="2.200"/><rect x="3.500" y="3.500" width="7" height="7" rx="2.200"/><rect x="13.500" y="3.500" width="7" height="7" rx="2.200"/><rect x="3.500" y="13.500" width="7" height="7" rx="2.200"/><rect ${DT} x="13.500" y="13.500" width="7" height="7" rx="2.200"/><rect x="13.500" y="13.500" width="7" height="7" rx="2.200"/>`,
 plus:'<path d="M12 5v14M5 12h14" stroke-width="2.400"/>',
 heart:`<path ${DT} d="M12 20s-7.500-4.500-7.500-10A4.300 4.300 0 0112 7.500 4.300 4.300 0 0119.500 10c0 5.500-7.500 10-7.500 10z"/><path d="M12 20s-7.500-4.500-7.500-10A4.300 4.300 0 0112 7.500 4.300 4.300 0 0119.500 10c0 5.500-7.500 10-7.500 10z"/>`,
 music:`<circle ${DT} cx="7.500" cy="17.500" r="3"/><circle ${DT} cx="17" cy="15.500" r="3"/><path d="M10.500 17.500V6l9.500-2v11.500M10.500 10l9.500-2"/><circle cx="7.500" cy="17.500" r="3"/><circle cx="17" cy="15.500" r="3"/>`,
 snd:`<path ${DT} d="M4 9.500h3.500L12 5.500v13l-4.500-4H4z"/><path d="M4 9.500h3.500L12 5.500v13l-4.500-4H4zM15.500 9a4 4 0 010 6M18 6.500a8 8 0 010 11"/>`,
 mute:`<path ${DT} d="M4 9.500h3.500L12 5.500v13l-4.500-4H4z"/><path d="M4 9.500h3.500L12 5.500v13l-4.500-4H4zM16 9.500l5 5M21 9.500l-5 5"/>`,
 check:'<path d="M5 12.500l4.500 4.500L19 7.500" stroke-width="2.400"/>',
 x:'<path d="M6 6l12 12M18 6L6 18" stroke-width="2.200"/>',
 set:`<circle ${DT} cx="12" cy="12" r="3.200"/><circle cx="12" cy="12" r="3.200"/><path d="M12 3v2.500M12 18.500V21M3 12h2.500M18.500 12H21M5.600 5.600l1.800 1.800M16.600 16.600l1.800 1.800M5.600 18.400l1.800-1.800M16.600 7.400l1.800-1.800"/>`,
 train:`<path d="M4 9v6M7 7v10M17 7v10M20 9v6M7 12h10"/><rect ${DT} x="7" y="7" width="3" height="10" rx="1"/><rect ${DT} x="14" y="7" width="3" height="10" rx="1"/>`,
 games:`<rect ${DT} x="3" y="7" width="18" height="11" rx="5.500"/><rect x="3" y="7" width="18" height="11" rx="5.500"/><path d="M8 10.500v4M6 12.500h4"/><circle cx="15" cy="11.500" r="1" fill="currentColor"/><circle cx="17.500" cy="13.500" r="1" fill="currentColor"/>`,
 breathe:`<circle ${DT} cx="12" cy="12" r="8.500"/><circle cx="12" cy="12" r="8.500"/><circle cx="12" cy="12" r="4.200"/><circle cx="12" cy="12" r="1" fill="currentColor"/>`,
 pulse:`<path ${DT} d="M3 12h4l2-6 4 12 2-6h6"/><path d="M3 12h4l2-6 4 12 2-6h6"/>`,
 guide:`<path ${DT} d="M5 4.500a2 2 0 012-2h11v16H7a2 2 0 00-2 2z"/><path d="M5 4.500a2 2 0 012-2h11v16H7a2 2 0 00-2 2zM5 20.500a2 2 0 002 2h11M9 7h6"/>`,
 about:`<circle ${DT} cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="9"/><path d="M12 11v5.500M12 7.800v.2" stroke-width="2.200"/>`
});
(function(){const T={train:'train',games:'games',breath:'breathe',pulse:'pulse',guide:'guide',about:'about'};window.__v5ic=T})();
/* ===== Music sheet: on/off, station, volume ===== */
ACT.musicsheet=()=>{sfx('open');FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');const m=S.set.music;
 $('#mbox').innerHTML=`<div class="row wrapr"><h2 class="vt" style="margin:0">Music</h2><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div><div class="xs mute" style="margin-top:4px">Generated live on your phone. Nothing downloads.</div>
 <div class="row" style="margin:14px 0;gap:10px"><button class="btn ${m.on?'':'pri'} big" data-act="musonoff" style="flex:1">${m.on?'Turn off':'Turn on'}</button></div>
 <label class="f">Station</label><div class="tiles5" style="margin-top:6px">${Object.entries(MST).map(([k,v])=>`<button class="tile5 ${(m.st||'auto')===k?'sel':''}" data-act="musst" data-v="${k}"><b>${v.n}</b><small>${v.d}</small></button>`).join('')}</div>
 <label class="f">Volume</label><input type="range" min="0" max="1" step=".05" value="${m.vol}" data-inp="mvol" style="width:100%">`};
ACT.musonoff=()=>{S.set.music.on=!S.set.music.on;save();musSync();buildNav();ACT.musicsheet()};
ACT.musst=el=>{S.set.music.st=el.dataset.v;save();sfx('tick');if(MUS.run)musRestart();ACT.musicsheet();toast(MST[el.dataset.v].n+' station')};
