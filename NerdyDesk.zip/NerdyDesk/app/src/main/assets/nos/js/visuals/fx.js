/* ===== screen-level fire effects: a burst wherever you tap, plus a bolt of light into the brand neuron ===== */
const FXC=$('#fxcv'),fxx=FXC.getContext('2d');let FXW=0,FXH=0,FXP=[],FXR=[],FXT=[],FXB=[],fxOn=false,fxLast=0;
function fxSize(){const d=Math.min(2,devicePixelRatio||1);FXW=innerWidth;FXH=innerHeight;FXC.width=Math.round(FXW*d);FXC.height=Math.round(FXH*d);FXC.style.width=FXW+'px';FXC.style.height=FXH+'px';fxx.setTransform(d,0,0,d,0,0)}
addEventListener('resize',fxSize);fxSize();
let LP={x:innerWidth/2,y:innerHeight*.45,t:0};
document.addEventListener('pointerdown',e=>{LP={x:e.clientX,y:e.clientY,t:performance.now(),ui:!!(e.target.closest&&e.target.closest('#drawer,#modal,#focus,#failbar,form'))}},true);
const fxOrigin=()=>performance.now()-LP.t<1500?LP:{x:innerWidth/2,y:innerHeight*.42};
const JF={};
function fxTarget(){const b=document.querySelector('.brand svg');if(!b)return null;const r=b.getBoundingClientRect();return r.width?{x:r.left+r.width/2,y:r.top+r.height/2}:null}
function screenBurst(g,o){o=o||{};if(!o.at&&performance.now()-LP.t<1500&&LP.ui)return;if(!FXW)fxSize();const p=o.at||fxOrigin(),quit=isB(g),col=quit?'#3ddc97':g.color,small=!!o.small,n=reduced()?10:Math.round((small?18:46)*Math.max(.5,QF));
 for(let i=0;i<n;i++){const a=Math.random()*6.283,sp=(quit?60:110)+Math.random()*(small?200:380),fl=!quit&&Math.random()<.42;
  FXP.push({x:p.x,y:p.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-(fl?90:0),g:fl?-170:(quit?-40:120),life:1,d:.65+Math.random()*.8,s:2+Math.random()*(small?2.5:4),c:fl?mix(col,'#ffd23f',.6):(Math.random()<.25?'#ffffff':col)})}
 FXR.push({x:p.x,y:p.y,r:6,max:small?90:150,life:1,c:col,dl:0});if(!small&&!reduced()){FXR.push({x:p.x,y:p.y,r:4,max:250,life:1,c:col,dl:.1});FXR.push({x:p.x,y:p.y,r:4,max:380,life:1,c:'#ffffff',dl:.2})}
 FXT.push({x:p.x,y:p.y-22,life:1,txt:o.txt||(quit?'Clean day':'+1 rep'),c:col,ic:g.icon});
 const tg=!small&&!quit&&!reduced()?fxTarget():null;if(tg)FXB.push({x0:p.x,y0:p.y,x1:tg.x,y1:tg.y,life:1,c:col});
 if(!fxOn){fxOn=true;fxLast=performance.now();requestAnimationFrame(fxLoop)}}
function screenBreak(g,at){if(!at&&performance.now()-LP.t<1500&&LP.ui)return;if(!FXW)fxSize();const p=at||fxOrigin(),n=reduced()?8:26;for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*2.6,sp=80+Math.random()*260;FXP.push({x:p.x,y:p.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,g:620,life:1,d:.8+Math.random()*.6,s:2+Math.random()*3,c:Math.random()<.5?'#ff5d73':'#ff9aa8'})}
 FXR.push({x:p.x,y:p.y,r:6,max:110,life:1,c:'#ff5d73',dl:0});FXT.push({x:p.x,y:p.y-22,life:1,txt:'Slip logged',c:'#ff5d73',ic:g.icon});document.body.classList.add('shk');setTimeout(()=>document.body.classList.remove('shk'),420);
 if(!fxOn){fxOn=true;fxLast=performance.now();requestAnimationFrame(fxLoop)}}
function fxLoop(now){try{fxFrame(now)}catch(e){FXP=[];FXR=[];FXT=[];FXB=[];fxOn=false;try{fxSize()}catch(_){}}}
function fxFrame(now){const dt=Math.min(.05,(now-fxLast)/1000||.016);fxLast=now;fxx.clearRect(0,0,FXW,FXH);
 fxx.globalCompositeOperation='lighter';
 for(let i=FXP.length-1;i>=0;i--){const q=FXP[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=q.g*dt;q.vx*=.985;q.life-=dt/q.d;if(q.life<=0){FXP.splice(i,1);continue}
  const rg=rgbOf(q.c),r=q.s*(.5+q.life)*3;fxx.globalAlpha=Math.min(1,q.life*1.2);fxx.drawImage(spr(rg),q.x-r,q.y-r,r*2,r*2)}
 fxx.globalAlpha=1;
 for(let i=FXR.length-1;i>=0;i--){const o=FXR[i];if(o.dl>0){o.dl-=dt;continue}o.r+=(o.max-o.r)*Math.min(1,dt*4.2)+dt*30;o.life-=dt*1.6;if(o.life<=0){FXR.splice(i,1);continue}fxx.strokeStyle=rgba(o.c,o.life*.85);fxx.lineWidth=1+3*o.life;fxx.beginPath();fxx.arc(o.x,o.y,o.r,0,6.283);fxx.stroke()}
 for(let i=FXB.length-1;i>=0;i--){const b=FXB[i];b.life-=dt*2;if(b.life<=0){FXB.splice(i,1);continue}const N=14,P=[],dx=b.x1-b.x0,dy=b.y1-b.y0,L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;
  for(let k=0;k<=N;k++){const f=k/N,off=k&&k<N?(Math.random()-.5)*34*Math.sin(Math.PI*f)*b.life:0;P.push([b.x0+dx*f+nx*off,b.y0+dy*f+ny*off])}
  [[8,.2,b.c],[2.4,.85,'#ffffff']].forEach(([w,a,c])=>{fxx.strokeStyle=c[0]==='#'&&c.length===7&&c!=='#ffffff'?rgba(c,a*b.life):`rgba(255,255,255,${a*b.life})`;fxx.lineWidth=w*b.life+.5;fxx.lineJoin='round';fxx.beginPath();P.forEach((p,k)=>k?fxx.lineTo(p[0],p[1]):fxx.moveTo(p[0],p[1]));fxx.stroke()});
  if(b.life>.5)glowFx(b.x1,b.y1,40*b.life,b.c,b.life)}
 fxx.globalCompositeOperation='source-over';
 for(let i=FXT.length-1;i>=0;i--){const t=FXT[i];t.y-=dt*34;t.life-=dt*.75;if(t.life<=0){FXT.splice(i,1);continue}
  fxx.globalAlpha=Math.min(1,t.life*2);fxx.font='700 15px Bricolage Grotesque,system-ui,sans-serif';const w=fxx.measureText(t.txt).width+46,h=30,x=t.x-w/2,y=t.y-h/2;
  fxx.fillStyle='rgba(8,10,18,.82)';fxx.beginPath();fxx.roundRect?fxx.roundRect(x,y,w,h,15):fxx.rect(x,y,w,h);fxx.fill();fxx.strokeStyle=rgba(t.c,.9);fxx.lineWidth=1.4;fxx.stroke();
  glyph(fxx,t.ic,x+17,t.y,16,t.c,1);fxx.fillStyle='#fff';fxx.textAlign='left';fxx.textBaseline='middle';fxx.fillText(t.txt,x+31,t.y+.5);fxx.globalAlpha=1}
 if(FXP.length||FXR.length||FXT.length||FXB.length)requestAnimationFrame(fxLoop);else{fxOn=false;fxx.clearRect(0,0,FXW,FXH)}}
function glowFx(x,y,r,c,a){fxx.globalAlpha=a*.8;fxx.drawImage(spr(rgbOf(c)),x-r,y-r,r*2,r*2);fxx.globalAlpha=1}
