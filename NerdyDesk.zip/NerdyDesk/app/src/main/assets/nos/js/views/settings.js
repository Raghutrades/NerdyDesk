/* ===== v5 Settings: grouped sections over the same controls ===== */
const SETG=[['look','Look','spark',['You','Theme']],['sound','Sound','music',['Sound','Background music','Pulse check']],['alerts','Alerts','bell',['Alerts and reminders']],['data','Data and app','dl',['Hard refresh','Install as an app','Your data']]];
function renderSet(){renderSetOld();const root=$('#setc'),tab=UI.setg||'look',cur=SETG.find(x=>x[0]===tab)||SETG[0];
 const title=root.querySelector('h2.vt');if(title)title.remove();
 [...root.children].forEach(c=>{const h=c.querySelector('h3'),n=h?h.textContent.trim():'';const grp=SETG.find(x=>x[3].includes(n));if(!grp||grp[0]!==cur[0])c.style.display='none';else c.style.marginTop='12px'});
 root.insertAdjacentHTML('afterbegin',`<h1 class="pgt">Settings</h1><div class="seg5 setseg">${SETG.map(x=>`<button class="${x[0]===cur[0]?'on':''}" data-act="setg" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`+(cur[0]==='data'?`<div class="card setlinks" style="margin-top:12px"><button class="btn" data-act="nav" data-v="about">${ic('heart',14)} About Raghu and the app</button><button class="btn" data-act="nav" data-v="guide">${ic('book',14)} Guide</button><button class="btn" data-act="tdopen">${ic('chart',14)} Trading desk setup</button></div>`:''))}
ACT.setg=el=>{UI.setg=el.dataset.v;sfx('tick');renderSet();window.scrollTo(0,0)};
