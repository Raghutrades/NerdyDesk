/* Board actions */
const wbRe=id=>{const m=$('#mbox'),st=m?m.scrollTop:0;wallOpen(id);if(m)m.scrollTop=st};
ACT.wallfire=el=>{closeModal();ACT.done(el)};
ACT.wallfull=el=>{closeModal();openDrawer(el.dataset.id)};
ACT.wallrep=el=>{closeModal();const g=gById(el.dataset.id);if(g)wallReplay(g)};
ACT.wbdel=el=>{const g=gById(el.dataset.id);if(!g||!g.bs)return;g.bs[el.dataset.k].splice(+el.dataset.i,1);save();sfx('tick');wbRe(g.id)};
ACT.wbadd=el=>{const g=gById(el.dataset.id);if(!g)return;g.bs=g.bs||{h:[],d:[],n:[]};const k=el.dataset.k,v=(el.dataset.v||'').trim();if(v&&!g.bs[k].includes(v))g.bs[k].push(v);save();sfx('tick');wbRe(g.id)};
ACT.wbaddin=el=>{const k=el.dataset.k,i=$('#wbi_'+k);if(!i)return;const v=i.value.trim();if(!v)return;const g=gById(el.dataset.id);if(!g)return;g.bs=g.bs||{h:[],d:[],n:[]};if(!g.bs[k].includes(v))g.bs[k].push(v);save();sfx('tick');wbRe(g.id);const j=$('#wbi_'+k);if(j)j.focus()};
ACT.wallty=el=>{if(el.dataset.v==='trade'){closeModal();TDV.tab='set';tdOpen();return}WL.nt=el.dataset.v;document.querySelectorAll('#wnt button').forEach(b=>b.classList.toggle('on',b.dataset.v===WL.nt));sfx('tick');wallFormSync()};
ACT.wallday=el=>{const d=$('#wnd');if(d)d.value=el.dataset.v;sfx('tick')};
ACT.wallmake=()=>{const nm=($('#wnn')||{}).value||'';if(!nm.trim()){toast('Type what the goal is first.');return}
 const dur=clamp(Math.round(+($('#wnd')||{}).value)||21,1,730),why=(($('#wnw')||{}).value||'').trim(),b=blankGoal(WL.nt==='quit'?'break':'build');if(WL.nt==='task')b.tk=true;b.eg=(($('#wne')||{}).value||'').trim().slice(0,160);
 const used=S.goals.map(g=>g.color),free=GCOLORS.filter(c=>!used.includes(c));b.color=(free.length?free:GCOLORS)[Math.floor(Math.random()*(free.length||GCOLORS.length))];
 b.name=nm.trim().slice(0,60);b.why=why;{const sc=WL.ns||{t:'daily'},ev=+($('#wnev')||{}).value,wk=+($('#wnwk')||{}).value;b.sched=Object.assign({},b.sched,{t:sc.t,days:sc.days&&sc.days.length?sc.days:[1,2,3,4,5]});if(sc.t==='every')b.sched.every=clamp(ev||2,2,30);if(sc.t==='weekly')b.sched.n=clamp(wk||3,1,7);const w1=($('#wnt1')||{}).value,w2=($('#wnt2')||{}).value;if(w1&&w2)b.win=[w1,w2]}b.start=todayKey();b.end=addD(b.start,dur-1);delete b.dur;delete b.isNew;
 const ng=normGoal(b);S.goals.push(ng);UI.sel=null;sfx('create');save();closeModal();checkBadges();S.set.mode='wall';save();renderAll();toast('Writing it on the board. Tap it to brainstorm.')};

ACT.wbfadd=el=>{const F=WL.foc,g=F&&gById(F.id),i=document.getElementById('wbinp');if(!g||!i||!F.inK)return;if(wbAddLeaf(g,F.inK,i.value)){i.value='';i.focus()}};
ACT.wbfx=()=>wbInClose();

ACT.wallsch=el=>{WL.ns.t=el.dataset.v;document.querySelectorAll('#wns button').forEach(b=>b.classList.toggle('on',b.dataset.v===WL.ns.t));sfx('tick');wallFormSync()};
ACT.wallday2=el=>{const i=+el.dataset.v,a=WL.ns.days,j=a.indexOf(i);if(j>=0)a.splice(j,1);else a.push(i);sfx('tick');wallFormSync()};
