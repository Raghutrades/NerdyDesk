/* ===== House view: one brick a day. The size follows the length of the goal: a kids tent (up to 30 days), a cottage, a house, a villa and a castle. The stick man throws each finished day onto it (quit goals: he tears the old wall down, brick by brick). ===== */
const HSE={},HGR={};
const HS_TIERS=[[30,'tent','Kids tent'],[59,'cottage','Cottage'],[90,'house','House'],[179,'villa','Villa'],[1e9,'castle','Castle']];
const hsTier=L=>HS_TIERS.find(x=>L<=x[0]);
function hsBuild(type,c){const set=new Map(),cuts=[];let rows=0,chim=null;
 const add=(i,j,role)=>{const k=i+','+j;if(!set.has(k))set.set(k,{i,j,role})};
 const box=(i0,w,j0,h,role,cren)=>{for(let j=j0;j<j0+h;j++)for(let i=0;i<w;i++){if(cren&&j===j0+h-1&&(i%2))continue;add(i0+i,j,role)}rows=Math.max(rows,j0+h)};
 const tri=(i0,w,j0,role)=>{let n=0;for(let w2=w,j=j0;w2>=1;w2-=2,j++){const o=(w-w2)/2;for(let i=0;i<w2;i++)add(i0+o+i,j,role);rows=Math.max(rows,j+1);n++}return n};
 const cut=(i,j,w,h,k)=>cuts.push({i,j,w,h,k});
 if(type==='tent'){const R=Math.max(4,Math.round(c*.95));for(let j=0;j<R;j++){const w=Math.max(1,Math.round(c*(1-j/R))),i0=Math.floor((c-w)/2);for(let i=0;i<w;i++)add(i0+i,j,'cloth')}rows=R;const dw=Math.max(2,Math.round(c*.3));cut(Math.floor((c-dw)/2),0,dw,Math.max(2,Math.round(R*.45)),'flap')}
 else if(type==='cottage'||type==='house'){const r=Math.max(3,Math.round(c*1.15));box(0,c,0,r,'wall');const rr=tri(1,c-2,r,'roof'),dw=Math.max(2,Math.round(c*.2)),dh=Math.max(2,Math.round(r*.6));
  if(type==='cottage'){cut(Math.round(c*.22),0,dw,dh,'door');if(c>=8){const ww=Math.max(2,Math.round(c*.2)),wh=Math.max(1,Math.round(r*.28)),wc=c-ww-Math.max(1,Math.round(c*.12));if(wc>=Math.round(c*.22)+dw+1)cut(wc,Math.min(r-wh,Math.max(1,Math.round(r*.45))),ww,wh,'win')}}
  else{const dc=Math.round((c-dw)/2);cut(dc,0,dw,dh,'door');const ww=Math.max(2,Math.round(c*.16)),wh=Math.max(1,Math.round(r*.3)),wy=Math.min(r-wh,Math.max(1,Math.round(r*.45))),w1=Math.max(1,Math.round(c*.08)),w2=c-ww-w1;if(dc-(w1+ww)>=1){cut(w1,wy,ww,wh,'win');cut(w2,wy,ww,wh,'win')}
   const ci=Math.floor(c*.68);for(let j=r,done=0;j<r+rr+3&&done<3;j++){const o=1+(j-r),w2b=c-2-2*(j-r),inside=ci>=o&&ci+1<o+w2b;add(ci,j,'wall');add(ci+1,j,'wall');chim={i:ci+1,j};rows=Math.max(rows,j+1);if(!inside||j>=r+rr)done++}}}
 else if(type==='villa'){const r1=Math.max(3,Math.round(c*.5));let uw=Math.max(4,Math.round(c*.6));if((c-uw)%2)uw--;const u0=(c-uw)/2,r2=Math.max(2,Math.round(c*.3));box(0,c,0,r1,'wall');box(u0,uw,r1,r2,'wall');tri(u0+1,uw-2,r1+r2,'roof');if(u0>0){box(0,u0,r1,1,'roof');box(u0+uw,u0,r1,1,'roof')}
  const dw=Math.max(2,Math.round(c*.14)),dc=Math.round((c-dw)/2);cut(dc,0,dw,Math.max(2,Math.round(r1*.65)),'door');const ww=Math.max(2,Math.round(c*.1)),wh=Math.max(1,Math.round(r1*.28)),wy=Math.max(1,Math.round(r1*.38));
  [[dc-ww-1],[dc+dw+1]].forEach(a=>{const x=a[0];if(x>=1&&x+ww<=c-1)cut(x,wy,ww,wh,'win')});[[Math.round(c*.06)],[c-ww-Math.round(c*.06)]].forEach(a=>{const x=a[0];if(x+ww<dc-1||x>dc+dw)if(x>=0&&x+ww<=c&&(x+ww<=dc-ww-1||x>=dc+dw+ww+1))cut(x,wy,ww,wh,'win')});
  if(uw>=6){const uww=Math.max(2,Math.round(uw*.22)),uwh=Math.max(1,Math.round(r2*.45));cut(u0+Math.round(uw*.15),r1+Math.max(0,Math.round(r2*.25)),uww,uwh,'win');cut(u0+uw-uww-Math.round(uw*.15),r1+Math.max(0,Math.round(r2*.25)),uww,uwh,'win')}}
 else{const tw=Math.max(3,Math.round(c*.26)),kh=Math.max(5,Math.round(c*1.0)),th=kh+Math.max(3,Math.round(c*.4)),kw=Math.max(3,c-2*tw);cols0=tw*2+kw;
  box(tw,kw,0,kh,'wall',true);box(0,tw,0,th,'tower',true);box(tw+kw,tw,0,th,'tower',true);c=cols0;
  const gw=Math.max(2,Math.round(kw*.4));cut(tw+Math.floor((kw-gw)/2),0,gw,Math.max(2,Math.round(kh*.55)),'gate');
  cut(Math.floor(tw/2),Math.round(th*.5),1,2,'slit');cut(tw+kw+Math.floor(tw/2),Math.round(th*.5),1,2,'slit');if(kw>=5){cut(tw+1,Math.round(kh*.62),1,2,'slit');cut(tw+kw-2,Math.round(kh*.62),1,2,'slit')}}
 const inCut=(i,j)=>cuts.some(q=>i>=q.i&&i<q.i+q.w&&j>=q.j&&j<q.j+q.h);
 const cells=[...set.values()].filter(q=>!inCut(q.i,q.j)).sort((a,b)=>a.j-b.j||a.i-b.i);
 let maxI=0;cells.forEach(q=>{maxI=Math.max(maxI,q.i+1)});cuts.forEach(q=>{maxI=Math.max(maxI,q.i+q.w)});
 const rs=[];let p=0;for(let j=0;j<=rows;j++){while(p<cells.length&&cells[p].j<j)p++;rs[j]=p}
 return{type,c,cols:Math.max(maxI,c),rows,cells,cuts,rs,chim,N:cells.length}}
let cols0=0;
function houseGrid(L){if(HGR[L])return HGR[L];const type=hsTier(L)[1];let best=null;
 for(let c=type==='castle'?8:type==='tent'?4:5;c<=64;c++){const b=hsBuild(type,c);if(!best||Math.abs(b.N-L)<Math.abs(best.N-L))best=b;if(b.N>L*1.6&&best)break}
 best.tier=hsTier(L)[2];return HGR[L]=best}
function hseSp(s,x,y,spc,al){const w=[...s].map(ch=>cx.measureText(ch).width),tot=w.reduce((a,b)=>a+b,0)+spc*(s.length-1);let p=al==='center'?x-tot/2:al==='right'?x-tot:x;const sv=cx.textAlign;cx.textAlign='left';[...s].forEach((ch,i)=>{cx.fillText(ch,p,y);p+=w[i]+spc});cx.textAlign=sv}
const HS_PAL={cloth:['#ef5b6b','#f7c04a','#4cc3e8','#7ad98f'],brick:['#d97a34','#c96a2b','#e58a40','#b95d27','#f0974a'],roof:['#b0432b','#9c3a25','#c24d30'],stone:['#8f98ab','#7f889c','#9ba4b6','#737c90'],quit:['#8d4a58','#7d4152','#99535f','#70394a']};
function drawHouse(now,dt){const t=now*.001,g=focusG(),rd=reduced();BHIT=[];
 if(!g){cx.fillStyle='rgba(235,240,255,.7)';cx.font='600 15px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText('Add a goal to build a house',W/2,H/2);return}
 cx.save();cx.translate(W/2+SH.x,H/2+SH.y);cx.scale(SH.s,SH.s);cx.translate(-W/2,-H/2);
 const P=pathStat(g),q=P.q,GRD=houseGrid(P.L),N=GRD.N,type=GRD.type,H0=HSE[g.id]||(HSE[g.id]={laid:null,fl:[],fa:{},x:W*.3,d:1,ph:0,v:0,T:{},sub:'stand',pt:2,m:'idle',f:0,rel:false,lit:0,cx:null,wh:0,sit:false});
 if(H0.type!==type+N){H0.type=type+N;H0.laid=null;H0.fl=[];H0.fa={}}
 const gy=H*.72,mh0=clamp(H*.22,64,140),u0=mh0/10,xc=W*.715;
 const rows=GRD.rows,hwMax=W*.54,availH=gy-H*.14,cw0=u0*2.4,fit=Math.min(1,hwMax/(GRD.cols*cw0),availH/(rows*cw0*.5)),cw=cw0*fit,bh=cw*.5,hl=xc-GRD.cols*cw/2;
 /* brick size is fixed against the man, so a longer goal means a truly bigger building and a smaller-looking man */
 const mh=mh0*Math.max(fit,.42),u=mh/10,xs=W*.4,deskX=W*.015,seatBase=deskX+.2*u;
 if(H0.cx==null)H0.cx=seatBase;
 const cellXY=ci=>{const c=GRD.cells[ci],off=(c.j%2?.18:-.18)*cw;return[hl+c.i*cw+off,gy-(c.j+1)*bh]};
 const tgt=clamp(Math.round(P.k/P.N*N),0,N);
 if(H0.laid==null||rd){H0.laid=tgt;H0.fl=[]}
 if(PV.m==='start'||PV.m==='done'){H0.laid=tgt;H0.fl=[]}
 if(tgt<H0.laid){H0.laid=tgt;H0.fl=[]}
 const inflight=q?0:H0.fl.length,diff=tgt-H0.laid-inflight,pend=Math.max(0,tgt-H0.laid),cyc=clamp(11/Math.max(1,pend),.14,1.5),fast=cyc<.5;
 /* backdrop */
 {const rg=cx.createRadialGradient(xc,gy-rows*bh*.5,10,xc,gy-rows*bh*.5,Math.max(W,H)*.6);rg.addColorStop(0,'rgba(255,235,210,'+(.05+.16*H0.lit)+')');rg.addColorStop(1,'rgba(255,235,210,0)');cx.fillStyle=rg;cx.fillRect(0,0,W,H)}
 cx.fillStyle='rgba(255,255,255,.05)';cx.fillRect(0,gy,W,H*.1);cx.strokeStyle='rgba(235,240,255,.3)';cx.lineWidth=1.5;cx.beginPath();cx.moveTo(W*.02,gy);cx.lineTo(W,gy);cx.stroke();
 if(H0.lit>.01){const gg=cx.createRadialGradient(xc,gy,4,xc,gy,W*.5);gg.addColorStop(0,'rgba(255,190,100,'+.4*H0.lit+')');gg.addColorStop(1,'rgba(255,190,100,0)');cx.fillStyle=gg;cx.fillRect(0,gy-4,W,H*.14)}
 /* the pieces */
 const palFor=(c,i)=>q?HS_PAL.quit:c.role==='cloth'?[HS_PAL.cloth[(c.i)%4]]:type==='castle'?HS_PAL.stone:c.role==='roof'?HS_PAL.roof:HS_PAL.brick;
 const shown=q?N-H0.laid:H0.laid,hsh=(i,n)=>((i*2654435761)>>>0)%n;
 for(let i=0;i<N;i++){const c=GRD.cells[i],[x,y]=cellXY(i);
  if(i>=shown){if(!q){cx.strokeStyle='rgba(235,240,255,.13)';cx.lineWidth=1;cx.strokeRect(x+.5,y+.5,cw-1.6,bh-1.6)}continue}
  const un=Math.min(P.N-1,Math.floor(i*P.N/N)),wv=!q&&P.wk?P.wk[un]||0:0,fa=H0.fa[i]||0,pal=palFor(c,i);
  cx.fillStyle=wv>=.5?'#8a5a48':pal[hsh(i,pal.length)];cx.fillRect(x,y,cw-1.4,bh-1.4);cx.fillStyle='rgba(255,255,255,.12)';cx.fillRect(x,y,cw-1.4,Math.max(1,bh*.18));
  if(wv>0){cx.strokeStyle='rgba(60,20,20,.9)';cx.lineWidth=1.2;cx.beginPath();cx.moveTo(x+cw*.3,y);cx.lineTo(x+cw*.42,y+bh*.4);cx.lineTo(x+cw*.34,y+bh*.55);cx.lineTo(x+cw*.5,y+bh-1.4);cx.stroke()}
  if(fa>.02){cx.fillStyle='rgba(255,230,170,'+fa*.7+')';cx.fillRect(x-1,y-1,cw+.6,bh+.6);H0.fa[i]=Math.max(0,fa-dt*1.4)}
  BHIT.push({g,x,w:cw,y0:y,y1:y+bh,d0:addD(g.start,un*P.per),d1:addD(g.start,Math.min(P.L-1,un*P.per+P.per-1))})}
 /* doors, windows, gate: they appear row by row as the wall rises, and glow when the round is finished */
 const lit=H0.lit,warm=lit>.01?'rgba(255,200,120,'+lit+')':null,frame=type==='castle'?'#5d6578':type==='tent'?'#7a4a26':'#7a4a26';
 GRD.cuts.forEach(cu=>{if(q)return;let n=0;while(n<cu.h&&H0.laid>=GRD.rs[Math.min(GRD.rows,cu.j+n+1)])n++;if(n<=0)return;
  const x=hl+cu.i*cw,w=cu.w*cw,h=n*bh,y=gy-(cu.j+n)*bh;cx.fillStyle=cu.k==='win'||cu.k==='slit'?'#10161f':'#17110d';cx.fillRect(x,y,w,h);if(warm){cx.fillStyle=warm;cx.fillRect(x,y,w,h)}cx.strokeStyle=frame;cx.lineWidth=cu.k==='slit'?1:1.6;cx.strokeRect(x,y,w,h);
  if(cu.k==='win'){cx.beginPath();cx.moveTo(x+w/2,y);cx.lineTo(x+w/2,y+h);cx.moveTo(x,y+h/2);cx.lineTo(x+w,y+h/2);cx.stroke()}
  if((cu.k==='door')&&n>=cu.h){cx.fillStyle='#f3c37a';cx.beginPath();cx.arc(x+w*.82,y+h*.5,Math.max(1,cw*.08),0,6.283);cx.fill()}
  if(cu.k==='gate'&&n>=cu.h){cx.strokeStyle=frame;cx.lineWidth=1;for(let k=1;k<cu.w;k++){cx.beginPath();cx.moveTo(x+k*cw,y);cx.lineTo(x+k*cw,y+h);cx.stroke()}}
  if(cu.k==='flap'&&n>=cu.h){cx.strokeStyle='rgba(255,255,255,.55)';cx.lineWidth=1.2;cx.beginPath();cx.moveTo(x+w/2,y);cx.lineTo(x+w/2,y+h);cx.stroke()}});
 /* flag on a finished castle or tent, smoke from a finished house */
 const fulld=!q&&H0.laid>=N&&tgt>=N,clearedd=q&&H0.laid>=N;
 if(fulld&&!q){const top=gy-rows*bh;if(type==='castle'||type==='tent'){const fx=hl+GRD.cols*cw/2,w1=Math.sin(t*3)*cw*.3;cx.strokeStyle='#ddd';cx.lineWidth=1.5;cx.beginPath();cx.moveTo(fx,top);cx.lineTo(fx,top-bh*5);cx.stroke();cx.fillStyle='#ef5b6b';cx.beginPath();cx.moveTo(fx,top-bh*5);cx.lineTo(fx+cw*2.2+w1,top-bh*4.3);cx.lineTo(fx,top-bh*3.6);cx.closePath();cx.fill()}
  else if(!rd&&GRD.chim){for(let k=0;k<3;k++){const ph=(t*.35+k/3)%1,sx=hl+(GRD.chim.i+.5)*cw+Math.sin(t*1.3+k*2)*cw*.5+ph*cw,sy=gy-(GRD.chim.j+1)*bh-ph*bh*5;cx.fillStyle='rgba(225,228,238,'+(.3*(1-ph))+')';cx.beginPath();cx.arc(sx,sy,cw*(.25+ph*.45),0,6.283);cx.fill()}}}
 /* the man */
 const M=H0;M.lit+=((fulld||clearedd?1:0)-M.lit)*Math.min(1,dt*1.3);
 const stackX=xs,stackTop=gy-1.7*Math.min(cw,u*2.4)*.5*2;
 let pose='stand',bend=0,hx=0,hy=0,py=null,tp=0,brick=false,moving=false;
 const mvx=(tx,s2)=>{const dx=tx-M.x,ad=Math.abs(dx);if(ad<2){M.v=0;M.wk=false;return false}M.wk=true;M.d=Math.sign(dx);const tv=Math.sign(dx)*Math.min(s2,ad*4+8);M.v+=(tv-M.v)*Math.min(1,dt*6);let st=M.v*dt;if(Math.abs(st)>ad)st=dx;M.x+=st;M.ph+=Math.abs(st)/(1.25*u)*3.1416;return true};
 const throwX=stackX-3.1*u,wallL=hl-3.4*u;
 const spawn=(ci)=>{const[tx,ty]=cellXY(ci),p=[M.x+2.6*u,gy-9.6*u],dist=Math.hypot(tx-p[0],ty-p[1]);M.fl.push({i:ci,x0:p[0],y0:p[1],x1:tx+cw/2,y1:ty+bh/2,t:0,dur:rd?.01:clamp(.5+dist*.0009,.35,.7)*(fast?.7:1),arc:18+dist*.18})};
 const busy=diff>0||(!q&&M.fl.length>0);
 if(busy&&M.sit)M.sit=false;
 if(!q){
  if(diff>0&&M.m==='idle'){M.m='toStack';M.sit=false}
  if(M.m==='toStack'){moving=mvx(throwX,mh*(fast?1.8:1.1));pose=moving?'walk':'stand';if(!moving){M.m='cycle';M.f=0;M.rel=false;M.d=1}}
  else if(M.m==='cycle'){M.d=1;M.f+=dt/cyc;const split=fast?0:.45,f=M.f;
   if(f<split){const b=Math.sin(clamp(f/split,0,1)*Math.PI);pose='plant';bend=b;hx=stackX-.4*u;py=stackTop-.1*u;brick=f>split*.45}
   else{const tpp=(f-split)/(1-split);pose='throw';tp=tpp;brick=tpp<.62;if(!M.rel&&tpp>=.62&&tgt-H0.laid-M.fl.length>0&&H0.laid+M.fl.length<N){M.rel=true;spawn(H0.laid+M.fl.length)}}
   if(M.f>=1){M.f=0;M.rel=false;if(tgt-H0.laid-M.fl.length<=0){M.m='idle'}}}}
 else{/* quit: he pulls the old wall apart, one brick at a time */
  if(diff>0){M.m='wall';moving=mvx(wallL,mh*(fast?1.8:1.2));pose=moving?'walk':'point';M.d=1;if(!moving){M.f+=dt/cyc;const ci=N-H0.laid-1,[bx2,by2]=cellXY(Math.max(0,ci));hx=bx2;hy=Math.max(gy-9.5*u,by2+bh/2);if(M.f>=1&&ci>=0){M.f=0;const[tx,ty]=cellXY(ci);M.fl.push({i:ci,x0:tx+cw/2,y0:ty+bh/2,x1:tx-W*.25-Math.random()*40,y1:ty-H*.3,t:0,dur:rd?.01:.9,arc:20,away:true,rot:Math.random()*3});H0.laid++}}}
  else{M.m='idle';M.f=0}}
 /* flights */
 const fpal=q?HS_PAL.quit:type==='tent'?HS_PAL.cloth:type==='castle'?HS_PAL.stone:HS_PAL.brick;
 M.fl=M.fl.filter(f=>{f.t+=dt;const s2=clamp(f.t/f.dur,0,1),x=f.x0+(f.x1-f.x0)*s2,y=f.y0+(f.y1-f.y0)*s2-f.arc*4*s2*(1-s2)*(f.away?1.4:1);
  cx.save();cx.translate(x,y);cx.rotate(f.away?(f.rot||0)+s2*9:s2*7);cx.globalAlpha=f.away?1-s2:1;cx.fillStyle=fpal[f.i%fpal.length];cx.fillRect(-cw*.45,-bh*.4,cw*.9,bh*.8);cx.restore();
  if(s2>=1){if(!f.away){H0.laid=Math.max(H0.laid,f.i+1);H0.fa[f.i]=1;if(!fast)sfx('tick');if(!rd&&!fast)for(let k=0;k<3;k++)WL.dust.push({x:f.x1,y:f.y1,vx:(Math.random()-.5)*30,vy:-Math.random()*30,l:1})}return false}return true});
 /* idle life when there is nothing to carry */
 const idle=!busy&&M.m==='idle';
 if(idle&&M.sit){M.sitT-=dt;M.pt-=dt;pose=M.ss||'sit-type';M.d=1;if(M.ss==='roll')pose='sit-think';
  if(M.pt<=0){const pk=['sit-type','sit-type','sit-think','sit-drink','sit-drink','roll','roll','sit-write','sit-think'];M.ss=pk[Math.floor(Math.random()*pk.length)];M.pt=2.8+Math.random()*2.6;M.rt=M.ss==='roll'?seatBase+(Math.random()<.5?-1:1)*(1.5+Math.random()*3)*u:seatBase+(Math.random()-.5)*.8*u;M.rt=clamp(M.rt,W*.04,W*.2)}
  if(M.rt!=null){const dx=M.rt-M.cx,sd=u*(M.ss==='roll'?2.0:.7),st=Math.sign(dx)*Math.min(Math.abs(dx),sd*dt);M.cx+=st;M.wh+=st/(.35*u)}M.x=M.cx;if(M.sitT<=0){M.sit=false;M.sub='stretch';M.pt=2.5}}
 else if(idle){M.pt-=dt;
  if(M.sub==='cheer'){pose='cheer';if(M.pt<=0)M.pt=0}
  else if(M.sub==='sitdown'){moving=mvx(M.cx,mh*.7);pose=moving?'walk':'stand';if(!moving){M.sit=true;M.x=M.cx;M.sitT=10+Math.random()*8;M.ss='sit-type';M.pt=2;M.rt=seatBase;M.sub='stand';M.d=1}}
  else if(M.sub==='pace'||M.sub==='admire'){moving=mvx(M.tx,mh*.6);pose=moving?'walk':(M.sub==='admire'?'look':'stand');if(!moving&&M.sub==='admire')M.d=1}
  else pose=M.sub==='stand'?'stand':M.sub;
  if(M.pt<=0&&!rd){const pk=['think','look','scratch','stretch','pace','pace','sip','stand','think','sitdown','sitdown','admire',fulld||clearedd?'cheer':'think'];const sub=pk[Math.floor(Math.random()*pk.length)];M.sub=sub;M.pt=sub==='sitdown'?99:3.5+Math.random()*3.5;M.d=Math.random()<.5?-1:1;
   if(sub==='pace')M.tx=clamp(M.x+(Math.random()<.5?-1:1)*W*(.1+Math.random()*.12),W*.2,throwX);
   if(sub==='admire')M.tx=clamp(throwX-Math.random()*W*.05,W*.2,throwX);
   if(sub==='cheer')M.pt=2}}
 else if(!busy&&M.m!=='idle'){M.m='idle'}
 M.x=clamp(M.sit?M.cx:M.x,W*.03,W*.97);
 /* desk, chair, stack and the man */
 wallDesk(deskX,gy,u,t,rd,M.sit&&M.ss==='sit-drink');wallChair(M.cx,gy,u,M.wh);
 {const sp=q?HS_PAL.quit:type==='tent'?HS_PAL.cloth:type==='castle'?HS_PAL.stone:HS_PAL.brick;const sw=Math.min(cw,u*2.4);for(let k=0;k<3;k++){cx.fillStyle=sp[k%sp.length];cx.fillRect(stackX-sw*.9,gy-(k+1)*sw*.5*1.15,sw*1.8,sw*.5*1.05)}}
 if(!M.sit){cx.fillStyle='rgba(0,0,0,.28)';cx.beginPath();cx.ellipse(M.x,gy+1,3.4*u,.4*u,0,0,6.283);cx.fill()}
 trMan(M.x,gy,mh,{d:M.d,t,ph:M.ph,pose,bend,rd,T:M.T,dt,hx,hy,py,tp,brick,mx:deskX+4.1*u});
 if(pose==='think'&&!rd){cx.fillStyle='rgba(255,255,255,.8)';for(let j=0;j<3;j++){cx.globalAlpha=.4+.6*Math.max(0,Math.sin(t*3-j*.8));cx.beginPath();cx.arc(M.x+mh*.2+j*mh*.1,gy-mh*1.15-j*mh*.05,mh*.03+j*.8,0,6.283);cx.fill()}cx.globalAlpha=1}
 WL.dust=WL.dust.filter(p=>(p.l-=dt*1.4)>0);WL.dust.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;cx.fillStyle='rgba(235,200,160,'+p.l*.7+')';cx.fillRect(p.x,p.y,1.8,1.8)});
 /* counters and caption */
 const L2=P.L,day=clamp(diffD(g.start,todayKey())+1,0,L2),laid=H0.laid,fp=clamp(W*.1,32,60),unit=type==='tent'?'PATCH':'BRICK',pl=type==='tent'?'ES':'S';
 cx.textAlign='left';cx.fillStyle='rgba(235,240,255,.55)';cx.font='700 '+clamp(W*.032,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';hseSp('DAY',W*.07,H*.15,4,'left');
 cx.fillStyle='rgba(245,247,255,.88)';cx.font='700 '+fp+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(String(PV.m==='start'?0:PV.m==='done'?L2:day),W*.07,H*.15+fp*.95);
 cx.fillStyle='rgba(235,240,255,.55)';cx.font='700 '+clamp(W*.03,10,13)+'px Bricolage Grotesque,system-ui,sans-serif';hseSp(laid+(q?(laid===1?' '+unit+' DOWN':' '+unit+pl+' DOWN'):laid===1?' '+unit+' LAID':' '+unit+pl+' LAID'),W*.07,H*.15+fp*1.55,3,'left');
 cx.fillStyle='rgba(245,247,255,.8)';cx.font='700 '+clamp(W*.04,13,19)+'px Bricolage Grotesque,system-ui,sans-serif';hseSp(q?'ONE CLEAN DAY, ONE BRICK DOWN':type==='tent'?'ONE PATCH A DAY':'ONE BRICK A DAY',W/2,gy+Math.max(34,H*.07),clamp(W*.012,4,9),'center');
 cx.fillStyle=rgba(g.color,.9);cx.font='600 '+clamp(W*.032,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText(g.name+' · '+L2+' days',W/2,gy+Math.max(34,H*.07)+22);
 cx.restore();
 const mx=x=>W/2+SH.x+(x-W/2)*SH.s,my=y=>H/2+SH.y+(y-H/2)*SH.s;BHIT.forEach(b=>{b.x=mx(b.x);b.w*=SH.s;b.y0=my(b.y0);b.y1=my(b.y1)})}
