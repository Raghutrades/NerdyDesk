/* boot: every module is loaded, now start the app */
brandInit();
init();
