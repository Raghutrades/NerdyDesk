/* ===== Synapse renderer: glowing neurons that grow, fire and show progress ===== */
function genTree(seed,rich){const R=rng(seed),segs=[],roots=rich?7+Math.floor(R()*3):6+Math.floor(R()*3),MAXD=rich?5:4;
 function br(p,d,len,depth,dist){let cur=p,dd=d,last=null;for(let s=0;s<2;s++){const j=[(R()-.5)*.55,(R()-.5)*.55,(R()-.5)*.55];let nd=[dd[0]+j[0],dd[1]+j[1],dd[2]+j[2]];const l=Math.hypot(...nd)||1;nd=nd.map(v=>v/l);const L=len/2,nx=[cur[0]+nd[0]*L,cur[1]+nd[1]*L,cur[2]+nd[2]*L];dist+=L;last={a:cur,b:nx,d:depth,dist,tip:false};segs.push(last);cur=nx;dd=nd}
  if(depth<MAXD&&!(rich&&depth>=3&&R()<.22)){const k=depth<3?2:(R()<.5?2:1);for(let i=0;i<k;i++){const j=[(R()-.5)*1.4,(R()-.5)*1.4,(R()-.5)*1.4];let nd=[dd[0]+j[0],dd[1]+j[1],dd[2]+j[2]];const l=Math.hypot(...nd)||1;br(cur,nd.map(v=>v/l),len*(.64+R()*.14),depth+1,dist)}}else last.tip=true}
 for(let i=0;i<roots;i++){const a=R()*6.283,b=Math.acos(2*R()-1);br([0,0,0],[Math.sin(b)*Math.cos(a),Math.sin(b)*Math.sin(a),Math.cos(b)],.5+R()*.2,0,0)}
 let mx=0;segs.forEach(s=>{if(s.dist>mx)mx=s.dist});segs.forEach(s=>{s.t=s.dist/mx;s.hit=false});return segs}
function treeOf(g){const r=rt(g);if(!r.segs){r.segs=genTree(hashStr(g.id)+7,true);const R=rng(hashStr(g.id)+99),idx=[];r.segs.forEach((s,i)=>{if(s.tip)idx.push(i)});for(let i=idx.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[idx[i],idx[j]]=[idx[j],idx[i]]}r.tipOrder=idx;r.buf=new Float32Array(r.segs.length*4)}return r.segs}
let DECOR=null;const WD_B=[2.3,1.7,1.25,.95,.75,.6];
function drawSynapse(now,dt){const th=TH(),t=now*.001,tk=todayKey();
 if(!DUST)initStars();
 if(!DECOR){const R=rng(4242);DECOR=[];for(let i=0;i<8;i++)DECOR.push({x:(R()-.5)*3.4,y:(R()-.5)*2.4,z:1.2+R()*1.8,segs:genTree(900+i),sc:.25+R()*.25})}
 const items=[];
 /* far, out-of-focus neurons for depth */
 cx.globalCompositeOperation='lighter';
 DECOR.forEach(dn=>{pj(dn.x,dn.y,dn.z);const blur=clamp(PZ*.3,0,1);cx.lineWidth=.8;cx.strokeStyle=`rgba(${th.neb[0]},${.09+.07*(1-blur)})`;cx.beginPath();
  dn.segs.forEach(s=>{if(s.d>2)return;pj(dn.x+s.a[0]*dn.sc,dn.y+s.a[1]*dn.sc,dn.z+s.a[2]*dn.sc);cx.moveTo(PX,PY);pj(dn.x+s.b[0]*dn.sc,dn.y+s.b[1]*dn.sc,dn.z+s.b[2]*dn.sc);cx.lineTo(PX,PY)});cx.stroke();
  pj(dn.x,dn.y,dn.z);glow(PX,PY,10*UNIT*PS,th.neb[1]||th.neb[0],.14,true)});
 /* dust with depth of field */
 const nd=Math.round(DUST.length*QF);
 for(let i=0;i<nd;i++){const d=DUST[i];const dx=d.x+Math.sin(t*.1*d.s+d.p)*.05,dy=d.y+Math.cos(t*.08*d.s+d.p)*.05;pj(dx,dy,d.z);const bl=Math.abs(PZ);glow(PX,PY,(1.5+bl*5)*UNIT*d.s,'255,255,255',clamp(.12-.03*bl,.02,.14),true)}
 /* axons between neurons */
 LINKS.forEach(([a,b],li)=>{if(synOne())return;const ga=gById(a),gb=gById(b);if(!ga||!gb)return;const ra=rt(ga),rb=rt(gb),act=Math.max(ra.flash,rb.flash),hot=Math.max(ra.heat,rb.heat);const quit=isB(ga)||isB(gb);
  const ca=quit?'#ff5d73':ga.color,cb=quit?'#ff5d73':gb.color;
  arcPt(ra,rb,0,.18);const x0=PX,y0=PY;arcPt(ra,rb,1,.18);const x1=PX,y1=PY;
  const gr=cx.createLinearGradient(x0,y0,x1,y1);const A=.1+.5*act+.12*hot;gr.addColorStop(0,rgba(ca,A));gr.addColorStop(1,rgba(cb,A));
  cx.strokeStyle=gr;cx.lineWidth=(5+9*act)*UNIT;cx.globalAlpha=.35;cx.beginPath();const lp=[];for(let i=0;i<=16;i++){arcPt(ra,rb,i/16,.18);lp.push([PX,PY]);if(!i)cx.moveTo(PX,PY);else cx.lineTo(PX,PY)}cx.stroke();cx.globalAlpha=1;LHIT.push({a,b,pts:lp});
  const gr2=cx.createLinearGradient(x0,y0,x1,y1);const A2=.28+.6*act;gr2.addColorStop(0,rgba(ca,A2));gr2.addColorStop(1,rgba(cb,A2));cx.strokeStyle=gr2;cx.lineWidth=(1+1.8*act)*UNIT;cx.beginPath();for(let i=0;i<=16;i++){arcPt(ra,rb,i/16,.18);if(!i)cx.moveTo(PX,PY);else cx.lineTo(PX,PY)}cx.stroke();
  if(QF>.45){for(let i=1;i<6;i++){arcPt(ra,rb,i/6,.18);glow(PX,PY,(3.2+2*act)*UNIT*PS,'255,255,255',.25+.4*act,false)}}
  if(!reduced()){const ph=((t*.16+li*.37)%1);arcPt(ra,rb,ph,.18);glow(PX,PY,8*UNIT*PS,rgbOf(ca),.55);glow(PX,PY,3*UNIT*PS,'255,255,255',.7)}});
 ORDER.forEach(g=>{if(!synVis(g))return;const r=rt(g);pj(r.x,r.y,r.z);items.push({g,r,x:PX,y:PY,z:PZ,s:PS})});items.sort((a,b)=>b.z-a.z);
 const maxD=QF<.55?3:5;
 items.forEach(it=>{const g=it.g,r=it.r,lv=levelOf(g),quit=isB(g),segs=treeOf(g),B=r.buf,col=quit?'#ff5d73':g.color,rgb=rgbOf(mix(col,'#ffffff',.12)),brite=rgbOf(mix(col,'#ffffff',.55));
  const prog=quit?clamp(lv,0,1):clamp(progAdj(gStats(g).prog||0),0,1),done=Math.round(doneCount(g)*(PV.m==='start'?0:PV.m==='done'?1:rpP()));
  const grow=quit?clamp(r.gr*1.1,.25,1)*(RP.on||PV.m?.5+.5*clamp(lv,0,1):1):clamp(.5+r.gr*.6,.5,1),vf=quit?.22+.78*Math.pow(clamp(lv,0,1),2.6):PV.m==='start'?.2:RP.on?.2+.8*rpP():1,Rw=(.27+.16*grow)*(S.set.layout==='orbit'?1:1.1)*(synOne()?2.15:1)*vf;
  const soma=nodeR(g,r)*it.s*.4,blur=clamp(Math.abs(it.z)*.18,0,.9),sc=clamp(it.s,.6,1.4),heat=r.heat;
  const doneToday=isDoneL(g.logs[tk]);
  /* project once */
  const vis=[[],[],[],[],[],[]];
  for(let i=0;i<segs.length;i++){const s=segs[i];if(s.d>maxD||s.t>grow)continue;pj(r.x+s.a[0]*Rw,r.y+s.a[1]*Rw,r.z+s.a[2]*Rw);B[i*4]=PX;B[i*4+1]=PY;pj(r.x+s.b[0]*Rw,r.y+s.b[1]*Rw,r.z+s.b[2]*Rw);B[i*4+2]=PX;B[i*4+3]=PY;vis[s.d].push(i)}
  cx.globalCompositeOperation='lighter';cx.lineCap='round';
  for(let d=0;d<=maxD;d++){const arr=vis[d];if(!arr.length)continue;
   cx.lineWidth=WD_B[d]*4.2*UNIT*sc;cx.strokeStyle=`rgba(${rgb},${(.045+.07*heat+(doneToday?.03:0))*(1-blur*.5)})`;cx.beginPath();arr.forEach(i=>{cx.moveTo(B[i*4],B[i*4+1]);cx.lineTo(B[i*4+2],B[i*4+3])});cx.stroke();
   cx.lineWidth=WD_B[d]*UNIT*sc;cx.strokeStyle=`rgba(${rgb},${clamp((.78-.08*d+.22*heat)*(1-blur*.45)*(quit?.8:1),0,1)})`;cx.beginPath();arr.forEach(i=>{cx.moveTo(B[i*4],B[i*4+1]);cx.lineTo(B[i*4+2],B[i*4+3])});cx.stroke()}
  /* thin bright core on thick branches, gives the glossy filament look */
  cx.lineWidth=.9*UNIT;cx.strokeStyle=`rgba(${brite},${.45*(1-blur*.5)})`;cx.beginPath();for(let d=0;d<=2;d++)vis[d].forEach(i=>{cx.moveTo(B[i*4],B[i*4+1]);cx.lineTo(B[i*4+2],B[i*4+3])});cx.stroke();
  if(QF>.55){cx.fillStyle=`rgba(${brite},.7)`;for(let d=1;d<=maxD;d++)vis[d].forEach(i=>{if(i%3===0)cx.fillRect(B[i*4+2]-1,B[i*4+3]-1,2,2)})}
  /* progress boutons: one lit tip per slice of the round completed */
  const tips=r.tipOrder,nt=tips.length,lit=quit?Math.round((1-clamp(lv,0,1))*nt*.0):Math.min(nt,Math.max(done>0?1:0,Math.round(prog*nt)));
  if(QF>.4)for(let k=0;k<nt;k++){const i=tips[k],s=segs[i];if(s.d>maxD&&!(s.d===maxD))continue;if(s.t>grow)continue;
   if(!B[i*4+2]&&!B[i*4+3])continue;const on=k<lit&&!quit;
   if(on){glow(B[i*4+2],B[i*4+3],(5+4*heat)*UNIT*sc,rgb,.85,false);glow(B[i*4+2],B[i*4+3],2.2*UNIT*sc,'255,255,255',.9)}
   else if(!quit){cx.fillStyle=`rgba(${rgb},.22)`;cx.fillRect(B[i*4+2]-1,B[i*4+3]-1,2,2)}}
  /* firing wave and quiet ambient signals */
  const fronts=[];if(r.wave>=0)fronts.push([r.wave/.75,1]);if(!reduced()&&!quit){fronts.push([((t*.13+r.ph*.07)%1.35),.35]);if(doneToday)fronts.push([((t*.2+r.ph*.11+.5)%1.35),.55])}
  fronts.forEach(([wp,pw])=>{cx.lineWidth=(1.2+1.6*pw)*UNIT;cx.strokeStyle=`rgba(255,255,255,${.85*pw*(r.wave>=0&&pw===1?1-wp:1)})`;cx.beginPath();const gl=[];
   for(let d=0;d<=maxD;d++)vis[d].forEach(i=>{const s=segs[i];if(Math.abs(s.t-wp*1.1)>.12)return;cx.moveTo(B[i*4],B[i*4+1]);cx.lineTo(B[i*4+2],B[i*4+3]);if(s.d>=2&&QF>.5)gl.push(i)});cx.stroke();
   gl.forEach(i=>glow(B[i*4+2],B[i*4+3],(5+7*pw)*UNIT*sc,rgb,.45+.4*pw))});
  /* soma */
  glow(it.x,it.y,soma*(2.5+r.flash*2),rgb,.26+.22*lv+r.flash*.45+.1*heat,true);
  if(g.priority==='must')glow(it.x,it.y,soma*3.2,'255,210,63',.22+.1*Math.sin(t*2.2+r.ph),true);
  glow(it.x,it.y,soma*1.5,rgb,.7+r.flash*.25);cx.globalCompositeOperation='source-over';
  const sg=cx.createRadialGradient(it.x-soma*.3,it.y-soma*.3,soma*.08,it.x,it.y,soma);sg.addColorStop(0,'#ffffff');sg.addColorStop(.45,mix(col,'#ffffff',.5));sg.addColorStop(1,mix(col,'#000000',.55));
  cx.fillStyle=sg;cx.beginPath();cx.ellipse(it.x,it.y,soma,soma*.93,.4,0,6.283);cx.fill();
  if(r.flash>.02){cx.globalCompositeOperation='lighter';glow(it.x,it.y,soma*1.7,'255,255,255',r.flash*.8);cx.globalCompositeOperation='source-over'}
  if(quit){cx.strokeStyle='rgba(255,93,115,.75)';cx.setLineDash([3,3]);cx.lineWidth=1.2;cx.beginPath();cx.arc(it.x,it.y,soma*1.7,0,6.283);cx.stroke();cx.setLineDash([])}
  if(soma>8)glyph(cx,g.icon,it.x,it.y,soma*1.15,'rgba(8,10,18,.8)',1);
  HITS.push({g,x:it.x,y:it.y,r:Math.max(16,soma*2.4),z:it.z,s:it.s});drawSelRing(HITS[HITS.length-1],now)});
 cx.globalCompositeOperation='source-over';
 /* vignette */
 const vg=cx.createRadialGradient(W/2,H/2,Math.min(W,H)*.35,W/2,H/2,Math.max(W,H)*.75);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.5)');cx.fillStyle=vg;cx.fillRect(0,0,W,H)}
