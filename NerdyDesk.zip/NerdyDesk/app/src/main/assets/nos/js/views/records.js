/* ===== records: every metric opens the rows behind it; chart tooltips ===== */
const REC={k:null,g:null,cols:[],rows:[],title:''};
function recRows(gs,f){const out=[];gs.forEach(g=>Object.keys(g.logs).forEach(k=>{const l=g.logs[k];if(l&&(!f||f(l,k,g)))out.push({g,k,l})}));out.sort((a,b)=>a.k<b.k?1:a.k>b.k?-1:((b.l.t||'')<(a.l.t||'')?-1:1));return out}
function fvals(g,l){const a=(g.fields||[]).filter(f=>l.f&&l.f[f.id]!==undefined&&l.f[f.id]!=='').map(f=>`${f.label}: ${l.f[f.id]}${f.unit?' '+f.unit:''}`);if(l.amt!==undefined&&l.amt!=='')a.push('Amount: '+l.amt);if(l.urges)a.push('Urges: '+l.urges);if(l.trig)a.push('Trigger: '+l.trig);if(l.prep)a.push('Prep: '+l.prep+'m');if(l.mood)a.push('Mood '+l.mood);return a.join(', ')}
const LCOLS=['Date','Time','Goal','Result','Min','Quality','Values','Note'];
const lcells=x=>{const l=x.l,g=x.g;return[fmtD(x.k,{day:'numeric',month:'short',year:'2-digit'}),l.t||'',g.name,l.slip?'Slip':l.skip?'Rest':isB(g)?'Clean':'Done',l.min?l.min+' min':'',l.q?l.q+'/5':'',fvals(g,l),l.note||'']};
function oppDone(gs,a,b){let o=0,d=0,sl=0;const t=todayKey();gs.forEach(g=>{for(let k=a;k<=b&&k<=t;k=addD(k,1)){const st=dueState(g,k);if(['paused','notstarted','ended','skipped'].includes(st.s))continue;if(st.s==='done'){d++;o++}else if(st.s==='slip'){o++;sl++}else if(st.s==='due'&&(k<t||st.urgent)&&(!st.flex||st.urgent))o++}});return{o,d,sl}}
function recBuild(k,gid){const t=todayKey(),gs=gid&&gid!=='all'&&gById(gid)?[gById(gid)]:S.goals,one=gs.length===1,g1=one?gs[0]:null,R={title:'',sub:one?g1.name:'All goals',sum:[],cols:[],rows:[]};
 const logs=(title,f,sumf)=>{const r=recRows(gs,f);R.title=title;R.cols=LCOLS.slice();R.rows=r.map(lcells);R.raw=r;const mins=sum(r.map(x=>+x.l.min||0));R.sum=[[r.length,'records']];if(mins)R.sum.push([dur(mins),'total time']);const qs=r.filter(x=>x.l.q>0).map(x=>x.l.q);if(qs.length)R.sum.push([avg(qs).toFixed(1)+'/5','avg quality']);if(sumf)R.sum=R.sum.concat(sumf(r))};
 const [a,b]=k.split(':');
 if(a==='reps'||a==='done')logs(one&&isB(g1)?'Every clean day':'Every rep',isDoneL);
 else if(a==='time')logs('Logged time',l=>isDoneL(l)&&+l.min>0);
 else if(a==='quality')logs('Focus quality ratings',l=>l.q>0);
 else if(a==='slips')logs('Slips',l=>l.slip);
 else if(a==='urges')logs('Urges ridden out',l=>+l.urges>0,r=>[[sum(r.map(x=>+x.l.urges||0)),'urges']]);
 else if(a==='notes')logs('Notes',l=>l.note);
 else if(a==='wk'){const e=addD(b,6);logs('Week of '+fmtD(b),(l,d)=>isDoneL(l)&&d>=b&&d<=e)}
 else if(a==='wd'){logs(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'][+b]+' reps',(l,d)=>isDoneL(l)&&(dow(d)+6)%7===+b)}
 else if(a==='tod'){logs(['Night (before 6)','Morning','Afternoon','Evening'][+b]+' reps',l=>isDoneL(l)&&l.t&&Math.floor(+l.t.slice(0,2)/6)===+b)}
 else if(a==='day'){R.title=fmtD(b,{weekday:'long',day:'numeric',month:'long',year:'numeric'});R.cols=['Goal','Status','Time','Min','Quality','Values','Note'];
  gs.forEach(g=>{const st=dueState(g,b),l=g.logs[b];if(['notstarted','ended'].includes(st.s)&&!l)return;const lab={done:isB(g)?'Clean':'Done',slip:'Slip',due:b<t?'Missed':'Scheduled',flex:b<t?'Missed':'Any day this period',rest:'Rest day',optional:'Optional',skipped:'Rest',paused:'Paused'}[st.s]||st.s;R.rows.push([g.name,lab,l&&l.t||'',l&&l.min?l.min+' min':'',l&&l.q?l.q+'/5':'',l?fvals(g,l):'',l&&l.note||''])});
  const dd=S.daily[b];if(dd)R.sum=[[dd.mood||'-','mood'],[dd.energy||'-','energy'],[dd.sleep||'-','sleep h']];const ds=dayStat(b);R.sum.unshift([ds.done+'/'+ds.opp,'goals done'])}
 else if(a==='rate'||a==='adh'||a==='weeks'){
  if(a==='rate'){const n=+b||30;R.title='Daily completion, last '+n+' days';R.cols=['Date','Done','Planned','Rate','Slips'];for(let i=0;i<n;i++){const d=addD(t,-i),x=oppDone(gs,d,d);if(!x.o&&i>0)continue;R.rows.push([fmtD(d,{weekday:'short',day:'numeric',month:'short'}),x.d,x.o,x.o?Math.round(x.d/x.o*100)+'%':'-',x.sl||''])}const T=oppDone(gs,addD(t,-n+1),t);R.sum=[[T.o?Math.round(T.d/T.o*100)+'%':'-','overall'],[T.d+'/'+T.o,'done / planned']]}
  else{R.title='Adherence by week';R.cols=['Week of','Done','Planned','Adherence'];let n=0,N=0;const st0=gs.reduce((m,g)=>g.start<m?g.start:m,t);for(let i=0;i<60;i++){const s=addD(weekStart(t),-7*i);if(addD(s,6)<st0)break;const x=oppDone(gs,s,addD(s,6));if(!x.o)continue;n+=x.d;N+=x.o;R.rows.push([fmtD(s),x.d,x.o,Math.round(x.d/x.o*100)+'%'])}R.sum=[[N?Math.round(n/N*100)+'%':'-','overall'],[n+'/'+N,'done / planned']]}}
 else if(a==='strength'){
  if(one){const q=isB(g1),ser=strengthSeries(g1).slice().reverse();R.title=q?'Old-pathway strength by day':'Strength by day';R.cols=['Date','Strength','Change','What happened'];
   ser.forEach((x,i)=>{const prev=ser[i+1],l=g1.logs[x.k],d=prev?Math.round((x.v-prev.v)*100):0;R.rows.push([fmtD(x.k,{weekday:'short',day:'numeric',month:'short'}),Math.round(x.v*100)+'%',(d>0?'+':'')+d,l?(l.slip?'Slip':isDoneL(l)?(q?'Clean':'Done'):'Rest'):(x.k<t&&(sched(g1,x.k)||q)?(q?'Quiet day':'Missed'):'')])});const s=ser.map(x=>x.v);R.sum=[[Math.round((s[0]||0)*100)+'%','now'],[Math.round(Math.max(0,...s)*100)+'%','peak']]}
  else{R.title='Strength by goal';R.cols=['Goal','Kind','Strength now','14 days ago','Change','Streak','Best'];S.goals.forEach(g=>{const s=gStats(g),ser=strengthSeries(g),q=isB(g),f=v=>q?1-v:v,now=ser.length?f(ser[ser.length-1].v):0,old=ser.length>14?f(ser[ser.length-15].v):null;R.rows.push([g.name,q?'Quit':'Build',Math.round(now*100)+'%',old==null?'-':Math.round(old*100)+'%',old==null?'-':((now-old)>=0?'+':'')+Math.round((now-old)*100),s.streak+s.unit,s.best])});R.sum=[[Math.round(overallStrength()*100)+'%','brain strength']];R.note='Quit goals show how far the old habit has faded, so higher is better for every row.'}}
 else if(a==='streak'){
  if(one){R.title='Streak history';R.cols=['From','To','Length','Status'];streakHistory(g1).sort((x,y)=>y.n-x.n).forEach(x=>R.rows.push([fmtD(x.a),fmtD(x.b),x.n+(isFlex(g1)?'':' days'),x.live?'Running now':'Ended']));const s=gStats(g1);R.sum=[[s.streak+s.unit,'current'],[s.best,'best']];if(isFlex(g1)){R.note='Weekly and monthly goals count whole periods, so streaks are shown as a number on the card.'}}
  else{R.title='Streaks by goal';R.cols=['Goal','Current','Best','Last rep'];S.goals.forEach(g=>{const s=gStats(g);R.rows.push([g.name,s.streak+s.unit,s.best,s.last?fmtD(s.last):'-'])})}}
 else if(a==='perfect'){R.title='Perfect days';R.cols=['Date','Goals done'];let c=0;for(let i=0;i<400;i++){const d=addD(t,-i),x=dayStat(d);if(x.opp&&x.done===x.opp){c++;if(R.rows.length<200)R.rows.push([fmtD(d,{weekday:'short',day:'numeric',month:'short',year:'numeric'}),x.done+' of '+x.opp])}}R.sum=[[perfectStreak(),'current streak'],[c,'in last 400 days']]}
 else if(a==='active'){R.title='Active goals';R.cols=['Goal','Kind','Priority','Schedule','Round','Reps','Adherence','Strength'];S.goals.filter(g=>!g.paused&&g.start<=t&&g.end>=t).forEach(g=>{const s=gStats(g);R.rows.push([g.name,isB(g)?'Quit':'Build',PRI[g.priority].n,schedText(g),fmtD(g.start)+' to '+fmtD(g.end),s.done+'/'+s.expT,pct(s.adh),Math.round(s.level*100)+'%'])})}
 else if(a==='field'&&one){const f=g1.fields.find(x=>x.id===b);R.title=f?f.label:'Values';R.cols=['Date','Time',f?f.label+(f.unit?' ('+f.unit+')':''):'Value','Minutes','Note'];const r=recRows(gs,l=>l.f&&l.f[b]!==undefined&&l.f[b]!=='');R.rows=r.map(x=>[fmtD(x.k,{day:'numeric',month:'short',year:'2-digit'}),x.l.t||'',x.l.f[b],x.l.min?x.l.min+' min':'',x.l.note||'']);const v=r.map(x=>+x.l.f[b]).filter(x=>!isNaN(x));if(v.length)R.sum=[[v.length,'entries'],[Math.round(sum(v)*10)/10,'total'],[(sum(v)/v.length).toFixed(1),'average'],[Math.max(...v),'best'],[Math.min(...v),'lowest']]}
 else if(a==='mood'||a==='sleep'||a==='energy'){R.title='Daily check-ins';R.cols=['Date','Mood','Energy','Sleep (h)','Note'];Object.keys(S.daily).sort().reverse().forEach(d=>{const x=S.daily[d];if(x&&(x.mood||x.energy||x.sleep))R.rows.push([fmtD(d,{weekday:'short',day:'numeric',month:'short'}),x.mood||'',x.energy||'',x.sleep||'',x.note||''])})}
 else if(a==='month'){const m0=b+'-01',m1=addD(dayKey(new Date(parseK(m0).getFullYear(),parseK(m0).getMonth()+1,1)),-1);logs(parseK(m0).toLocaleDateString([],{month:'long',year:'numeric'})+' records',(l,d)=>d>=m0&&d<=m1);const x=oppDone(gs,m0,m1);R.sum.unshift([x.o?Math.round(x.d/x.o*100)+'%':'-','completion'])}
 else logs('Records',()=>true);
 R.k=k;R.g=gid;return R}
function openRec(k,gid){const R=recBuild(k,gid);REC.cur=R;
 const keep=R.cols.map((c,i)=>R.rows.some(r=>r[i]!==''&&r[i]!=null)),cols=R.cols.filter((c,i)=>keep[i]),rows=R.rows.map(r=>r.filter((c,i)=>keep[i]));R.cols2=cols;R.rows2=rows;
 FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');$('#mbox').innerHTML=`<div class="row wrapr"><div><h2 class="vt" style="margin:0">${esc(R.title)}</h2><div class="xs mute">${esc(R.sub)}</div></div><span class="sp"></span><button class="btn sm" data-act="reccsv">${ic('dl')} CSV</button><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div>
 ${R.sum.length?`<div class="row wrapr" style="gap:8px;margin:12px 0">${R.sum.map(s=>`<div class="kpi"><b>${esc(String(s[0]))}</b><span>${esc(s[1])}</span></div>`).join('')}</div>`:''}
 ${rows.length?`<div class="rtw"><table class="t rt"><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr>${rows.slice(0,400).map(r=>`<tr>${r.map(c=>`<td>${esc(String(c))}</td>`).join('')}</tr>`).join('')}</table></div>${rows.length>400?`<div class="xs mute">Showing the latest 400 of ${rows.length}. The CSV has everything.</div>`:''}`:'<div class="card mute sm" style="margin-top:12px">Nothing recorded for this yet. Log a few days and the records appear here.</div>'}
 ${R.note?`<div class="xs mute" style="margin-top:8px">${esc(R.note)}</div>`:''}`;$('#mbox').scrollTop=0;sfx('open')}
ACT.rec=el=>openRec(el.dataset.k,el.dataset.g||(UI.view==='ins'?UI.an.scope:'all'));
ACT.recx=()=>closeModal();
ACT.reccsv=()=>{const R=REC.cur;if(!R)return;const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';downloadText('neuroorbitsynapse-'+R.k.replace(/[^a-z0-9]+/gi,'-')+'.csv',[R.cols2.map(q).join(',')].concat(R.rows2.map(r=>r.map(q).join(','))).join('\n'),'text/csv');toast('CSV downloaded')};
const recBtn=(k,g)=>`<button class="btn sm ghost rbtn" data-act="rec" data-k="${k}" ${g?`data-g="${g}"`:''}>Records ${ic('fwd')}</button>`;
const cardHd=(t,k,x,g)=>`<div class="row wrapr" style="margin-bottom:4px"><h3 style="margin:0">${t}</h3><span class="sp"></span>${x||''}${k?recBtn(k,g):''}</div>`;
/* ---- tooltips ---- */
(function(){let tip=null,cur=null;const mk=()=>{if(!tip){tip=document.createElement('div');tip.id='tip';document.body.appendChild(tip)}return tip};
 const hide=()=>{if(tip)tip.classList.remove('on');if(cur){cur.classList.remove('hl');cur=null}};
 const show=(el,x,y)=>{const t=mk();if(cur!==el){if(cur)cur.classList.remove('hl');el.classList.add('hl');cur=el;t.textContent=el.getAttribute('data-tip')}t.classList.add('on');const r=t.getBoundingClientRect();let L=x+14,T=y-r.height-12;if(L+r.width>innerWidth-8)L=x-r.width-14;if(L<8)L=8;if(T<8)T=y+18;t.style.left=L+'px';t.style.top=T+'px'};
 const mv=e=>{const el=e.target.closest&&e.target.closest('[data-tip]');if(el)show(el,e.clientX,e.clientY);else hide()};
 document.addEventListener('pointermove',mv);document.addEventListener('pointerdown',mv);document.addEventListener('scroll',hide,true);document.addEventListener('pointerleave',hide);
 document.addEventListener('pointerup',e=>{if(e.pointerType==='touch')setTimeout(hide,1800)})})();

document.addEventListener('click',e=>{const c=e.target.closest&&e.target.closest('[data-rec]');if(!c||e.target.closest('[data-act],button,a,input,select,textarea,label,summary,.seg'))return;openRec(c.dataset.rec,c.dataset.g||(UI.view==='ins'?UI.an.scope:'all'))});
