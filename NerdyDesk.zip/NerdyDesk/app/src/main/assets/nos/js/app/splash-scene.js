/* app/splash-scene — the cinematic intro: a real 3D flight through a neural forest, drawn on a canvas.
   cinScene(canvas,{w,h,target,lite}) returns {draw(t)}; t is seconds on the story timeline.
   Story: a spark -> one neuron grows -> an action potential races down its myelinated axon (chase camera) ->
   a synapse releases vesicles -> the next neuron fires -> the camera pulls back as the whole forest lights up in a
   cascade and the busiest paths thicken (Hebbian wiring) -> everything spirals into one point -> the logo. */
const CIN={END:12.6,TF:9.7,
 caps:[[.5,'It starts with a single spark.'],[2.5,'A signal races down the axon.'],[4.55,'Across the synapse, a puff of chemistry.'],[5.9,'Fire together, wire together.'],[7.7,'Every repetition thickens the path.'],[9.2,'']],
 at:{p1:10.0,p2:10.4,p3:10.8,p4:11.1,p5:11.3}};
function cinRng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const cinC=(x,a,b)=>Math.max(0,Math.min(1,(x-a)/(b-a)));
const cinE=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
const cinO=x=>1-Math.pow(1-x,3);
const cinL=(a,b,k)=>a+(b-a)*k;
const v3={add:(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],sub:(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],mul:(a,k)=>[a[0]*k,a[1]*k,a[2]*k],
 dot:(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],len:a=>Math.hypot(a[0],a[1],a[2]),
 norm:a=>{const l=Math.hypot(a[0],a[1],a[2])||1;return[a[0]/l,a[1]/l,a[2]/l]},lerp:(a,b,k)=>[a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k,a[2]+(b[2]-a[2])*k]};
function cinScene(cv,o){
 const dpr=Math.min(window.devicePixelRatio||1,2),W=o.w,H=o.h,u=W/390,F=W*1.12;
 cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);cv.style.width=W+'px';cv.style.height=H+'px';
 const g=cv.getContext('2d'),R=cinRng(5),tg=o.target||{x:W/2,y:H*.4},TF=CIN.TF,TH=(()=>{const rd=n=>{try{let v=getComputedStyle(document.body).getPropertyValue(n).trim();if(v[0]==='#'){if(v.length===4)v='#'+[1,2,3].map(i=>v[i]+v[i]).join('');return[1,3,5].map(i=>parseInt(v.substr(i,2),16))}const m=v.match(/\d+/g);if(m&&m.length>=3)return m.slice(0,3).map(Number)}catch(e){}return null},a=rd('--acc')||[77,208,255],b=rd('--acc2')||[138,125,255],mx=(c,k)=>c.map(x=>Math.round(x+(255-x)*k)),sc=(c,k)=>c.map(x=>Math.round(x*k));return{CY:a.join(','),VI:b.join(','),WH:mx(a,.85).join(','),LIT:mx(a,.55).join(','),DK:sc(a,.16).join(','),BG:sc(a,.035).join(','),BG2:sc(a,.16).join(',')}})(),CY=TH.CY,VI=TH.VI,WH=TH.WH;
 const NN=o.lite?64:98,UP=[0,1,0],CEN=[0,0,720];
 /* ---------- the forest: somas, dendrite trees, axons ---------- */
 const S=[[0,0,0],[46,-34,520]];
 const segDist=(p,a,b)=>{const ab=v3.sub(b,a),t=Math.max(0,Math.min(1,v3.dot(v3.sub(p,a),ab)/v3.dot(ab,ab)));return v3.len(v3.sub(p,v3.add(a,v3.mul(ab,t))))};
 for(let tries=0;tries<4000&&S.length<NN;tries++){const a=R()*6.283,rad=70+Math.pow(R(),.75)*430,p=[Math.cos(a)*rad,Math.sin(a)*rad*.8,-80+R()*1750];
  if(S.every(q=>v3.len(v3.sub(q,p))>74)&&segDist(p,S[0],S[1])>85)S.push(p)}
 const N=S.length;
 const rv=k=>v3.norm([R()-.5,R()-.5,R()-.5]);
 function tree(root,dir,len,depth,out,d){const end=v3.add(root,v3.mul(dir,len));out.push([root,end,d]);if(d<depth){for(let j=0;j<2;j++)tree(end,v3.norm(v3.add(dir,v3.mul(rv(),.95))),len*.68,depth,out,d+1)}}
 const D=S.map((p,i)=>{const out=[],hero=i<2,n=hero?6:5;for(let k=0;k<n;k++){let dir=rv();if(i===0&&dir[2]>.35)dir[2]*=-.7;if(i===1&&dir[2]<-.2)dir[2]*=-.5;tree(v3.add(p,v3.mul(v3.norm(dir),11)),v3.norm(dir),hero?30:24,hero?3:2,out,0)}return out});
 /* axons: gentle 3D bezier curves, sampled with arc length */
 const E=[];
 function addEdge(i,j,bow){const a=S[i],b=S[j],d=v3.sub(b,a),L=v3.len(d),n=v3.norm(d),side=v3.norm(v3.cross(n,[.2,1,.35])),c=v3.add(v3.lerp(a,b,.5),v3.mul(side,(bow==null?(R()-.5)*.5:bow)*L)),st=v3.add(a,v3.mul(n,14)),en=v3.sub(b,v3.mul(n,i===0&&j===1?50:24)),pts=[],M=26;
  for(let k=0;k<=M;k++){const s=k/M,q=1-s;pts.push([q*q*st[0]+2*q*s*c[0]+s*s*en[0],q*q*st[1]+2*q*s*c[1]+s*s*en[1],q*q*st[2]+2*q*s*c[2]+s*s*en[2]])}
  const cum=[0];for(let k=1;k<pts.length;k++)cum.push(cum[k-1]+v3.len(v3.sub(pts[k],pts[k-1])));E.push({i,j,pts,cum,len:cum[cum.length-1],t1:[]})}
 addEdge(0,1,.28);
 for(let i=0;i<N;i++){const nb=S.map((q,j)=>[j,v3.len(v3.sub(q,S[i]))]).filter(x=>x[0]!==i&&!(i===0)).sort((a,b)=>a[1]-b[1]).slice(0,3);nb.forEach(([j,d])=>{if(d<420&&!E.some(e=>e.i===i&&e.j===j))addEdge(i,j)})}
 const at=(e,s)=>{const L=Math.max(0,Math.min(1,s))*e.len;let k=1;while(k<e.cum.length-1&&e.cum[k]<L)k++;const f=(L-e.cum[k-1])/Math.max(1e-6,e.cum[k]-e.cum[k-1]);return{p:v3.lerp(e.pts[k-1],e.pts[k],f),t:v3.norm(v3.sub(e.pts[k],e.pts[k-1]))}};
 const E0=E[0],SPA=250,TA=2.35,TB=TA+E0.len/SPA,SYN=at(E0,1).p,STAN=at(E0,1).t;
 /* ---------- the cascade, precomputed ---------- */
 const PL=[],FL=S.map(()=>[]),SPEED=430;
 function wave(src,t0){const ft=new Array(N).fill(Infinity),done=new Array(N).fill(false);ft[src]=t0;FL[src].push(t0);
  for(let it=0;it<N;it++){let u2=-1,b=Infinity;for(let k=0;k<N;k++)if(!done[k]&&ft[k]<b){b=ft[k];u2=k}if(u2<0||b>9.2)break;done[u2]=true;
   E.forEach((e,ei)=>{if(e.i!==u2||(ei===0&&src===1))return;const a=ft[u2]+.03,bb=a+e.len/SPEED;PL.push({e:ei,t0:a,t1:bb});e.t1.push(bb);if(bb+.06<ft[e.j]){ft[e.j]=bb+.06;FL[e.j].push(bb+.06)}})}}
 wave(1,TB+.1);
 {let s2=2,best=1e9;for(let k=2;k<N;k++){const d=Math.abs(S[k][2]-300)+Math.hypot(S[k][0],S[k][1])*.4;if(d<best){best=d;s2=k}}wave(s2,TB+1.9)}
 for(let k=0;k<N;k++)if(!FL[k].length&&k!==0)FL[k].push(TB+.4+v3.len(v3.sub(S[k],SYN))/SPEED*1.15);
 FL[0].push(TA+.02);
 const dust=Array.from({length:o.lite?90:180},()=>({p:[(R()-.5)*1100,(R()-.5)*900,-150+R()*1900],ph:R()*6.28,b:.3+R()*.7}));
 const VES=Array.from({length:56},()=>{const d=v3.norm([STAN[0]+(R()-.5)*.9,STAN[1]+(R()-.5)*.9,STAN[2]+(R()*.6)]);return{d,v:30+R()*110,l:.7+R()*.8,c:R()<.5?CY:WH,wob:R()*6.28}});
 const SPK=Array.from({length:80},()=>({a:R()*6.283,v:60+R()*240,c:R()<.5?CY:VI}));
 /* ---------- camera ---------- */
 let cp=[0,0,0],cr=[1,0,0],cu=[0,1,0],cf=[0,0,1],px=W/2,py=H*.46;
 function setCam(p,l,roll){cp=p;cf=v3.norm(v3.sub(l,p));let r=v3.norm(v3.cross(UP,cf));if(r[0]===0&&r[1]===0&&r[2]===0)r=[1,0,0];cr=r;cu=v3.cross(cf,cr);if(roll){const c=Math.cos(roll),s=Math.sin(roll),r2=v3.add(v3.mul(cr,c),v3.mul(cu,s)),u2=v3.sub(v3.mul(cu,c),v3.mul(cr,s));cr=r2;cu=u2}}
 const PJ=[0,0,0,0];
 /* world warp for the final convergence: everything spirals into the centre */
 let WK=0;const warp=p=>{if(WK<=0)return p;const rx=p[0]-CEN[0],ry=p[1]-CEN[1],a=WK*4.6*(1-Math.min(1,Math.hypot(rx,ry)/900)*.4),c=Math.cos(a),s=Math.sin(a),sc=1-WK*.985;return[CEN[0]+(rx*c-ry*s)*sc,CEN[1]+(rx*s+ry*c)*sc,CEN[2]+(p[2]-CEN[2])*sc]};
 const pj=p=>{const w=warp(p),dx=w[0]-cp[0],dy=w[1]-cp[1],dz=w[2]-cp[2],z=dx*cf[0]+dy*cf[1]+dz*cf[2];PJ[2]=z;if(z<8){PJ[3]=0;return PJ}const k=F/z;PJ[0]=px+(dx*cr[0]+dy*cr[1]+dz*cr[2])*k;PJ[1]=py-(dx*cu[0]+dy*cu[1]+dz*cu[2])*k;PJ[3]=k;return PJ};
 const fog=z=>{const a=Math.max(0,Math.min(1,1-(z-250)/2000));return a*a*Math.min(1,(z-8)/70)};
 const glow=(x,y,r,rgb,a)=>{if(a<=.004||r<=.4)return;const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(${rgb},${a})`);gr.addColorStop(.35,`rgba(${rgb},${a*.35})`);gr.addColorStop(1,`rgba(${rgb},0)`);g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)};
 const streak=(x,y,len,rgb,a)=>{if(a<=.01)return;const gr=g.createLinearGradient(x-len,y,x+len,y);gr.addColorStop(0,`rgba(${rgb},0)`);gr.addColorStop(.5,`rgba(${rgb},${a})`);gr.addColorStop(1,`rgba(${rgb},0)`);g.fillStyle=gr;g.fillRect(x-len,y-1.3*u,len*2,2.6*u)};
 const flashOf=(i,t)=>{let f=0;const L=FL[i];for(let k=0;k<L.length;k++){const d=t-L[k];if(d>0)f=Math.max(f,Math.exp(-d*2.2))}return f};
 const firesOf=(i,t)=>{let n=0;FL[i].forEach(f=>{if(t>f)n++});return n};
 let ema=16,last=0,q=1;
 function draw(t){
  const nw=performance.now();if(last){ema=ema*.92+(nw-last)*.08;q=ema>30?0:1}last=nw;
  g.setTransform(dpr,0,0,dpr,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.fillStyle=`rgb(${TH.BG})`;g.fillRect(0,0,W,H);
  const bgr=g.createRadialGradient(W/2,H*.45,0,W/2,H*.45,Math.max(W,H)*.8);bgr.addColorStop(0,`rgba(${TH.BG2},.9)`);bgr.addColorStop(1,`rgba(${TH.BG},0)`);g.fillStyle=bgr;g.fillRect(0,0,W,H);
  /* camera keys */
  const chase=cinE(cinC(t-.3,TA,TB)),A=at(E0,chase),side=v3.norm(v3.cross(A.t,UP)),la=at(E0,Math.min(1,chase+.2)).p;
  const p1a=[Math.sin(t*.6)*12,-6+Math.cos(t*.5)*5,cinL(-250,-128,cinO(cinC(t,0,TA)))],p1b=v3.add(v3.sub(A.p,v3.mul(A.t,100)),v3.add(v3.mul(UP,20),v3.mul(side,16))),
   wc=cinO(cinC(t,TA-.5,TA+.4));let p1=v3.lerp(p1a,p1b,wc),l1=v3.lerp(S[0],la,wc);
  const ws=cinO(cinC(t,TB-.4,TB+.5));if(ws>0){const tipC=v3.add(SYN,v3.add(v3.mul(STAN,-52-30*cinC(t,TB,TB+1.3)),v3.add(v3.mul(side,30),v3.mul(UP,16+8*Math.sin(t*1.4)))));p1=v3.lerp(p1,tipC,ws);l1=v3.lerp(l1,v3.add(SYN,v3.mul(STAN,14)),ws)}
  const w4=cinE(cinC(t,TB+.5,TB+3.7)),ang=-.55+.2*(t-TB),el=.16+.14*cinC(t,TB,TB+4),rad=cinL(480,720,cinO(cinC(t,TB,TB+3.6))),
   p4=v3.add(CEN,[Math.sin(ang)*Math.cos(el)*rad,Math.sin(el)*rad,-Math.cos(ang)*Math.cos(el)*rad]);
  const w5=cinE(cinC(t,8.35,9.65)),p5=[CEN[0],CEN[1],CEN[2]-cinL(720,680,w5)];
  let p=v3.lerp(v3.lerp(p1,p4,w4),p5,w5),l=v3.lerp(v3.lerp(l1,CEN,w4),CEN,w5);
  setCam(p,l,.05*Math.sin(t*.4)*(1-w5));WK=cinE(cinC(t,8.55,9.65));
  px=cinL(W/2,tg.x,w5);py=cinL(H*.46,tg.y,w5);
  const lite=q===0;
  /* dust */
  g.globalCompositeOperation='lighter';
  dust.forEach(d=>{const w=[d.p[0]+Math.sin(t*.4+d.ph)*14,d.p[1]+Math.cos(t*.3+d.ph)*14,d.p[2]],j=pj(w);if(!j[3])return;glow(j[0],j[1],(1.2+d.b*2.2)*j[3]*F/430*u*1.4,'120,170,255',.3*d.b*fog(j[2])*cinC(t,.2,1.6))});
  g.lineCap='round';g.lineJoin='round';
  const disc=cinC(t,TA+.2,TB);
  /* dendrite trees */
  for(let i=0;i<N;i++){const sj=pj(S[i]);if(!sj[3])continue;const fz=fog(sj[2]);if(fz<.02)continue;const hero=i<2,vis=hero?(i===0?1:cinC(t,TA,TA+1.2)):disc,fl=flashOf(i,t),fires=firesOf(i,t);if(vis<=.01)continue;
   const baseA=(.16+.5*fl+.04*Math.min(5,fires))*fz*vis;if(lite&&!hero&&fl<.3)continue;
   g.strokeStyle=`rgba(${fl>.4?WH:CY},${Math.min(.9,baseA)})`;g.lineWidth=Math.min(1.7*u,Math.max(.4,.8*sj[3]*F/430*u*(hero?1.2:1)));g.beginPath();
   D[i].forEach(sg=>{let pr=1;if(i===0)pr=cinO(cinC(t,.9+sg[2]*.45,.9+sg[2]*.45+.7));else if(i===1)pr=cinO(cinC(t,TA+.4+sg[2]*.4,TA+1.4+sg[2]*.4));if(pr<=0)return;const a=pj(sg[0]),ax=a[0],ay=a[1],az=a[3];if(!az)return;const b=pj(v3.lerp(sg[0],sg[1],pr));if(!b[3])return;g.moveTo(ax,ay);g.lineTo(b[0],b[1])});g.stroke();
   if(i===0&&t<2.3){/* growing tips glow */}}
  /* axons */
  E.forEach((e,ei)=>{const a=pj(e.pts[0]);if(!a[3]&&ei)return;const mid=pj(e.pts[13]),fz=fog(mid[2]);if(fz<.02&&ei)return;
   let grow=1,vis=ei===0?1:disc;if(ei===0)grow=cinC(t,1.5,2.35);if(vis<=.01||grow<=0)return;
   const w=e.t1.filter(x=>x<t).length,last2=e.t1.reduce((m,x)=>x<t?Math.max(m,x):m,-9),heat=w?Math.exp(-(t-last2)*1.1):0,fade=1-cinC(t,8.9,9.6)*0;
   const base=(ei===0?.45:.11)+Math.min(.55,w*.2)+heat*.8,wd=Math.min(ei===0?2.6*u:2.4*u,Math.max(.4,(ei===0?1.5:.5)*mid[3]*F/430*u+Math.min(w,4)*.55*mid[3]*F/430*u));
   const n=Math.max(2,Math.floor(e.pts.length*grow)),path=()=>{g.beginPath();let st=false;for(let k=0;k<n;k++){const j=pj(e.pts[k]);if(!j[3])continue;st?g.lineTo(j[0],j[1]):(g.moveTo(j[0],j[1]),st=true)}};
   g.strokeStyle=`rgba(${CY},${Math.min(.95,base*Math.max(fz,ei?0:.7)*vis)})`;g.lineWidth=wd;
   if(ei===0&&t<TB+.4){g.setLineDash([Math.min(16*u,9*u*mid[3]*F/430+2),Math.min(5*u,2.6*u*mid[3]*F/430+1)]);g.lineCap='butt'}path();g.stroke();g.setLineDash([]);g.lineCap='round';
   if(heat>.05||w>=2){g.strokeStyle=`rgba(${WH},${Math.min(.85,(heat*.75+w*.06)*Math.max(fz,.45))})`;g.lineWidth=Math.max(.4,wd*.45);path();g.stroke()}});
  /* somas */
  for(let i=0;i<N;i++){const j=pj(S[i]);if(!j[3])continue;const fz=Math.max(fog(j[2]),i<2?.5:0);if(fz<.02)continue;const sc=j[3]*F/430,hero=i<2,
    vis=i===0?cinO(cinC(t,.15,1.5)):i===1?cinC(t,TA-.2,TA+1):disc;if(vis<=.005)continue;const fl=flashOf(i,t),fires=firesOf(i,t),r=Math.max(1.8*u,(hero?5.6:4)*sc*u*(1+.06*Math.sin(t*5+i))),a=vis*fz;
   glow(j[0],j[1],r*(3.6+fl*14+(i===0&&t<3?1.2*Math.sin(t*6)+1.5:0)),CY,Math.min(1,(.18+.75*fl+.05*Math.min(6,fires))*a));glow(j[0],j[1],r*1.7,VI,.35*a*(.3+fl));
   g.globalCompositeOperation='source-over';g.beginPath();g.arc(j[0],j[1],r,0,6.283);{const sg=g.createRadialGradient(j[0]-r*.35,j[1]-r*.35,r*.1,j[0],j[1],r);sg.addColorStop(0,`rgba(${fl>.3?WH:TH.LIT},${.95*a})`);sg.addColorStop(1,`rgba(${fl>.3?TH.LIT:TH.DK},${.95*a})`);g.fillStyle=sg}g.fill();g.lineWidth=Math.max(.5,.7*sc*u);g.strokeStyle=`rgba(${CY},${(.25+.6*fl)*a})`;g.stroke();g.globalCompositeOperation='lighter';
   glow(j[0],j[1],r*.5,WH,(.3+.7*fl)*a)}
  /* B's dendritic spine, facing the synapse */
  {const sp=cinO(cinC(t,TA+.2,TA+1.2));if(sp>0){const base=v3.add(S[1],v3.mul(STAN,-12)),tip=v3.add(S[1],v3.mul(STAN,-30)),a=pj(base),b=pj(v3.lerp(base,tip,sp));if(a[3]&&b[3]){g.strokeStyle=`rgba(${CY},.7)`;g.lineWidth=Math.max(.8,2.4*b[3]*F/430*u);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke();glow(b[0],b[1],5*b[3]*F/430*u*(1+flashOf(1,t)*3),WH,.8)}}}
  /* axon terminal bouton + the chase-cam action potential */
  {const bp=pj(SYN);if(bp[3]){glow(bp[0],bp[1],10*bp[3]*F/430*u,CY,.5*cinC(t,TA+1,TB))}}
  const sp=cinE(cinC(t,TA,TB));if(t>TA&&t<TB+.25){for(let k=0;k<14;k++){const s2=Math.max(0,sp-k*.012),pp=at(E0,s2).p,j=pj(pp);if(!j[3])continue;const sc=j[3]*F/430;glow(j[0],j[1],(k?(16-k)*1.5:26)*sc*u,k<2?WH:CY,k?(.55-k*.035):.95)}
   const hj=pj(at(E0,sp).p);if(hj[3]){const sc=hj[3]*F/430;streak(hj[0],hj[1],150*u,WH,.55);glow(hj[0],hj[1],8*sc*u,'255,255,255',1);
    for(let k=0;k<7;k++){const a=Math.random()*6.283,rr=(6+Math.random()*16)*sc*u;glow(hj[0]+Math.cos(a)*rr,hj[1]+Math.sin(a)*rr,3*sc*u,CY,.7)}}}
  /* synapse: vesicle burst + flash + ring */
  const sa=t-TB;if(sa>-.05&&sa<1.9){const sj=pj(SYN);const fl=Math.exp(-Math.max(0,sa)*3.2)*cinC(sa,-.05,.03);if(sj[3]){const sc=sj[3]*F/430;glow(sj[0],sj[1],(90+60*cinC(sa,0,.5))*sc*u,WH,.9*fl);streak(sj[0],sj[1],220*u*Math.min(1,fl*1.6),CY,.8*fl)}
   VES.forEach(v=>{const age=sa/v.l;if(age<=0||age>=1)return;const dist=v.v*sa*(1-age*.35),pp=v3.add(SYN,v3.add(v3.mul(v.d,dist),[Math.sin(sa*5+v.wob)*3,Math.cos(sa*4+v.wob)*3,0])),j=pj(pp);if(!j[3])return;const sc=j[3]*F/430;glow(j[0],j[1],5.5*sc*u,v.c,.85*Math.sin(age*Math.PI));
    g.fillStyle=`rgba(${WH},${.9*Math.sin(age*Math.PI)})`;g.beginPath();g.arc(j[0],j[1],1.4*sc*u+.4,0,6.283);g.fill()});
   const rp=cinC(sa,.05,1.0);if(rp>0&&rp<1&&sj[3]){g.strokeStyle=`rgba(${CY},${.6*(1-rp)})`;g.lineWidth=1.6*u;g.beginPath();g.arc(sj[0],sj[1],(6+rp*90)*sj[3]*F/430*u,0,6.283);g.stroke()}}
  /* cascade pulses */
  PL.forEach(pu=>{if(t<pu.t0||t>pu.t1)return;const e=E[pu.e],s=(t-pu.t0)/(pu.t1-pu.t0);for(let k=0;k<(lite?2:4);k++){const j=pj(at(e,Math.max(0,s-k*.035)).p);if(!j[3])continue;const fz=Math.max(fog(j[2]),.3),sc=j[3]*F/430;glow(j[0],j[1],(k?11-k*2:24)*sc*u+3*u,k?CY:WH,(k?.6-k*.12:1)*Math.max(fz,.3)*(1-cinC(t,9,9.5)))}});
  /* the finale */
  const flashW=cinC(t,TF-.05,TF);const fi=t<TF?Math.pow(cinC(t,TF-.7,TF),3):1-cinC(t,TF,TF+.9);
  if(t>8.4){const cj={x:tg.x,y:tg.y},co=cinC(t,8.4,TF);glow(cj.x,cj.y,(30+150*co)*u,CY,.25+.55*co);glow(cj.x,cj.y,(14+40*co)*u,WH,.4+.6*co)}
  const fr=cinC(t,TF,TF+1.6);if(fr>0&&fr<1){const A2=Math.sin(Math.min(1,fr*1.3)*Math.PI);for(let i=0;i<22;i++){const a=i/22*6.283+t*.3,Ln=(60+330*cinO(fr))*u;const gr=g.createLinearGradient(tg.x,tg.y,tg.x+Math.cos(a)*Ln,tg.y+Math.sin(a)*Ln);gr.addColorStop(0,`rgba(${WH},${.55*A2})`);gr.addColorStop(1,`rgba(${CY},0)`);g.strokeStyle=gr;g.lineWidth=(1.5+(i%3))*u;g.beginPath();g.moveTo(tg.x,tg.y);g.lineTo(tg.x+Math.cos(a)*Ln,tg.y+Math.sin(a)*Ln);g.stroke()}
   SPK.forEach(s=>{const k=cinO(fr);glow(tg.x+Math.cos(s.a)*s.v*k*u*1.3,tg.y+Math.sin(s.a)*s.v*k*u*1.3,5*u,s.c,.85*(1-fr))});
   g.strokeStyle=`rgba(${CY},${.6*(1-fr)})`;g.lineWidth=2*u;g.beginPath();g.arc(tg.x,tg.y,(30+fr*190)*u,0,6.283);g.stroke();streak(tg.x,tg.y,260*u*(1-fr*.4),CY,.5*(1-fr))}
  g.globalCompositeOperation='lighter';if(fi>.004){const gr=g.createRadialGradient(tg.x,tg.y,0,tg.x,tg.y,Math.max(W,H)*.85);gr.addColorStop(0,`rgba(235,248,255,${fi})`);gr.addColorStop(1,`rgba(77,208,255,${fi*.5})`);g.fillStyle=gr;g.fillRect(0,0,W,H)}
  /* lens: vignette + letterbox that opens at the finale */
  g.globalCompositeOperation='source-over';const vg=g.createRadialGradient(W/2,H*.5,Math.min(W,H)*.35,W/2,H*.5,Math.max(W,H)*.78);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.45)');g.fillStyle=vg;g.fillRect(0,0,W,H);
}
 return{draw,S,E,PL,TB}}
