/* ===== Universe renderer ===== */
const TH=()=>THEMES[S.set.theme]||THEMES.blue;
let STARS=null,DUST=null;
function initStars(){const r=rng(777);STARS=[];for(let i=0;i<260;i++){const a=r()*6.283,b=Math.acos(2*r()-1),d=1.6+r()*2.2;STARS.push({x:Math.sin(b)*Math.cos(a)*d,y:Math.sin(b)*Math.sin(a)*d,z:Math.cos(b)*d,m:.4+r()*.9,p:r()*6.28})}
 DUST=[];for(let i=0;i<120;i++)DUST.push({x:(r()-.5)*3,y:(r()-.5)*2.2,z:(r()-.5)*3,p:r()*6.28,s:.4+r()})}
function drawStars(now){if(!STARS)initStars();const th=TH(),n=Math.round(STARS.length*(.5+.5*QF));cx.fillStyle=`rgb(${th.sp})`;
 for(let i=0;i<n;i++){const s=STARS[i];pj(s.x,s.y,s.z);const tw=.55+.45*Math.sin(now*.0015*s.m+s.p);cx.globalAlpha=clamp(.12+.5*tw*s.m*PS*.9,0,.85);const z=Math.max(.6,1.4*s.m*UNIT);cx.fillRect(PX,PY,z,z)}cx.globalAlpha=1}
function pathRing(R,incl,off){let first=true;cx.beginPath();for(let i=0;i<=56;i++){const a=i/56*6.2832,x=Math.cos(a)*R,z0=Math.sin(a)*R;pj(x,z0*Math.sin(incl),z0*Math.cos(incl));if(first){cx.moveTo(PX,PY);first=false}else cx.lineTo(PX,PY)}}
function drawLinks(now,col){const mono=!!TH().mono;
 LINKS.forEach(([a,b])=>{const ga=gById(a),gb=gById(b);if(!ga||!gb)return;const ra=rt(ga),rb=rt(gb);const act=Math.max(ra.flash,rb.flash);
  cx.strokeStyle=col?col(ga,gb,act):`rgba(${TH().sp},${.07+.3*act})`;cx.lineWidth=(.8+1.6*act)*UNIT;cx.beginPath();const lp=[];
  for(let i=0;i<=14;i++){arcPt(ra,rb,i/14);lp.push([PX,PY]);if(!i)cx.moveTo(PX,PY);else cx.lineTo(PX,PY)}cx.stroke();LHIT.push({a,b,pts:lp})})}
/* one tiny bead per slice of the round on each orbit: lit = reps done, so progress is visible at a glance */
function drawBeads(g,r){if(QF<.4)return;const q=isB(g),s=gStats(g),n=clamp(lenDays(g),8,100),prog=q?clamp(progAdj(s.done/Math.max(1,lenDays(g))),0,1):clamp(progAdj(s.prog||0),0,1),lit=Math.round(prog*n),rgb=rgbOf(q?'#ff5d73':g.color),incl=r.inclU||0,R=r.R,tk=todayKey();
 const idx=clamp(Math.floor(diffD(g.start,tk)/Math.max(1,lenDays(g))*n),0,n-1);cx.globalCompositeOperation='lighter';
 for(let i=0;i<n;i++){const a=i/n*6.2832-1.5708,x=Math.cos(a)*R,z0=Math.sin(a)*R;pj(x,z0*Math.sin(incl),z0*Math.cos(incl));
  if(i<lit)glow(PX,PY,(3.2+(i===lit-1?2.5*(1+r.heat):0))*UNIT*PS,rgb,.9-.25*i/n,false);else{cx.globalAlpha=.3;cx.fillStyle=`rgb(${rgb})`;cx.fillRect(PX-.8,PY-.8,1.6,1.6);cx.globalAlpha=1}}
 cx.globalCompositeOperation='source-over'}
function drawUniverse(now,dt){const th=TH(),t=now*.001,L=S.set.layout;drawStars(now);
 if(L==='orbit'){cx.lineWidth=1;ORDER.forEach(g=>{const r=rt(g);cx.strokeStyle=isB(g)?'rgba(255,93,115,.14)':rgba(g.color,.13+.2*r.heat);if(isB(g))cx.setLineDash([3,6]);pathRing(r.R,r.inclU||0);cx.stroke();cx.setLineDash([]);drawBeads(g,r)});
  drawLinks(now,(ga,gb,act)=>act>.04?rgba(act>.2&&rt(ga).flash>=rt(gb).flash?ga.color:gb.color,Math.min(.8,act*.9)):'rgba(0,0,0,0)')}
 else drawLinks(now);
 const items=[{core:1,z:0}];ORDER.forEach(g=>{const r=rt(g);pj(r.x,r.y,r.z);items.push({g,r,x:PX,y:PY,z:PZ,s:PS})});
 items.sort((a,b)=>b.z-a.z);cx.globalCompositeOperation='source-over';
 items.forEach(it=>{if(it.core){pj(0,0,0);const p=1+.06*Math.sin(t*1.6),R=(30+14*Math.min(1,overallStrength()))*UNIT*Math.pow(cam.zoom,.5)*p*PS;
   cx.globalCompositeOperation='lighter';glow(PX,PY,R*4,rgbOf(th.acc2),.2,true);glow(PX,PY,R*2.2,rgbOf(th.acc),.45);glow(PX,PY,R*.9,'255,255,255',.7);cx.globalCompositeOperation='source-over';return}
  const g=it.g,r=it.r,rad=nodeR(g,r)*it.s,x=it.x,y=it.y,lv=levelOf(g);HITS.push({g,x,y,r:Math.max(10,rad),z:it.z,s:it.s});
  if(isB(g))drawDwarf(g,r,x,y,rad,lv,t);else drawPlanet(g,r,x,y,rad,lv,t,it.z);drawSelRing(HITS[HITS.length-1],now)})}
function drawPlanet(g,r,x,y,rad,lv,t,z){const rgb=rgbOf(g.color),pr=g.priority==='must';
 cx.globalCompositeOperation='lighter';glow(x,y,rad*(3+r.flash*2.5),rgb,.32+.25*lv+r.flash*.4,true);
 if(pr){glow(x,y,rad*3.6,'255,210,63',.35+.15*Math.sin(t*2.2+r.ph),true)}cx.globalCompositeOperation='source-over';
 const gr=cx.createRadialGradient(x-rad*.38,y-rad*.4,rad*.1,x,y,rad);gr.addColorStop(0,mix(g.color,'#ffffff',.65));gr.addColorStop(.45,g.color);gr.addColorStop(1,mix(g.color,'#000000',.7));
 /* back half of ring */
 const ring=lv>.55||pr,rc=pr?'#ffd23f':g.color;
 if(ring){cx.strokeStyle=rgba(rc,.55);cx.lineWidth=Math.max(1,rad*.12);cx.beginPath();cx.ellipse(x,y,rad*1.75,rad*.5,-.4,Math.PI,6.283);cx.stroke()}
 cx.fillStyle=gr;cx.beginPath();cx.arc(x,y,rad,0,6.283);cx.fill();
 if(r.flash>.02){cx.globalCompositeOperation='lighter';glow(x,y,rad*1.5,'255,255,255',r.flash*.8);cx.strokeStyle=rgba(g.color,r.flash*.8);cx.lineWidth=Math.max(1.2,rad*.07);cx.lineCap='round';cx.beginPath();for(let i=0;i<10;i++){const a=i*.6283+t*.6,l0=rad*1.15,l1=rad*(1.6+r.flash*2.6);cx.moveTo(x+Math.cos(a)*l0,y+Math.sin(a)*l0);cx.lineTo(x+Math.cos(a)*l1,y+Math.sin(a)*l1)}cx.stroke();cx.globalCompositeOperation='source-over'}
 if(rad>9)glyph(cx,g.icon,x,y,rad*1.05,'rgba(255,255,255,.88)',1);
 if(ring){cx.strokeStyle=rgba(rc,.8);cx.lineWidth=Math.max(1,rad*.12);cx.beginPath();cx.ellipse(x,y,rad*1.75,rad*.5,-.4,0,Math.PI);cx.stroke()}
 if(pr){cx.strokeStyle='rgba(255,210,63,.75)';cx.lineWidth=1.3;cx.setLineDash([2,4]);cx.beginPath();cx.arc(x,y,rad*1.35,0,6.283);cx.stroke();cx.setLineDash([])}
 const st=gStats(g),moons=Math.min(4,Math.floor((st.streak||0)/(st.unit==='d'?7:2)));
 for(let i=0;i<moons;i++){const a=t*(.9+i*.3)+i*1.9,mr=rad*(1.9+i*.5);const mx=x+Math.cos(a)*mr,my=y+Math.sin(a)*mr*.42;cx.fillStyle='rgba(255,255,255,.85)';cx.beginPath();cx.arc(mx,my,Math.max(1.5,rad*.15),0,6.283);cx.fill()}}
function drawDwarf(g,r,x,y,rad,lv,t){const rg=cx.createRadialGradient(x-rad*.3,y-rad*.3,rad*.1,x,y,rad);rg.addColorStop(0,'#4a3038');rg.addColorStop(1,'#120a0e');
 cx.globalCompositeOperation='lighter';glow(x,y,rad*(2.4+r.flash*2),'255,77,94',.16+.22*lv+r.flash*.4,true);cx.globalCompositeOperation='source-over';
 const n=Math.round(16*lv*(.4+.6*QF))+2;cx.fillStyle='rgba(255,120,130,.55)';
 for(let i=0;i<n;i++){const a=t*(.35+(i%5)*.07)+i*2.4,d=rad*(1.5+(i%4)*.28);cx.fillRect(x+Math.cos(a)*d,y+Math.sin(a)*d*.5,1.8,1.8)}
 cx.fillStyle=rg;cx.beginPath();cx.arc(x,y,rad,0,6.283);cx.fill();cx.strokeStyle=`rgba(255,93,115,${.4+.4*lv})`;cx.lineWidth=1.4;cx.setLineDash([3,3]);cx.stroke();cx.setLineDash([]);
 cx.strokeStyle='rgba(255,93,115,.5)';cx.lineWidth=1.2;const q=rad*.45;cx.beginPath();cx.moveTo(x-q,y-q);cx.lineTo(x+q,y+q);cx.moveTo(x+q,y-q);cx.lineTo(x-q,y+q);cx.stroke();
 if(r.flash>.02){cx.globalCompositeOperation='lighter';glow(x,y,rad*1.6,'80,255,170',r.flash*.7);cx.globalCompositeOperation='source-over'}
 if(rad>9)glyph(cx,g.icon,x,y,rad*.95,'rgba(255,170,180,.8)',1)}

