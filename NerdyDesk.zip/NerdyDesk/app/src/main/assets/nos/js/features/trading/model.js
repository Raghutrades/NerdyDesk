/* ===== Trading desk: data model, templates and the metrics engine =====
   S.trd = { prof, days:{date:{pre,live:{obs[]},post}}, trades:[] }. Everything stays on this device. */
const TD_STRAT=['Breakout','Pullback','Reversal','Range fade','Trend follow','Gap play','News play','Scalp','Expiry play'];
const TD_INS=['Nifty','BankNifty','Sensex','FinNifty','Stocks','BTC','ETH','Nasdaq perp','Gold'];
const TD_TYPE=['Equity cash','Equity intraday','Futures','Options','Crypto spot','Crypto perp','Forex','Other'];
const TD_MIST=['FOMO','Revenge trade','Overtrading','No stop-loss','Moved stop-loss','Exited early','Entered late','Oversized','Ignored plan','Chased price','Averaged down','Traded news blindly'];
const TD_EMO=['Calm','Confident','Anxious','FOMO','Bored','Angry','Tired','Greedy'];
const TD_SNAP=[['us','US markets'],['asia','Asia'],['eu','Europe'],['gift','Gift Nifty / SGX'],['crude','Crude oil'],['gold','Gold'],['usd','Dollar / INR'],['vix','Volatility (VIX)']];
const TD_EVENTS=['Results','RBI / Fed','Budget','Expiry day','FII / DII data','Holiday','Global event','Nothing special'];
const TD_PAT=['Trend day','Range day','Gap up','Gap down','Inside day','Breakout setup','Reversal setup','Choppy'];
const TD_CHECK=['Slept well','Plan is written','Levels marked','News checked','Risk set','Calm and ready'];
const TD_OBS=['Observation','Level hit','News','Pattern','Emotion','Mistake','Idea'];
const TD_BIAS=[['bull','Bullish'],['bear','Bearish'],['range','Sideways'],['none','No view']];
const TD_PHASES=[['pre','Pre-market','Plan before the open'],['live','During market','Notes and trades'],['post','Post-market','Review and lessons']];
function tdProf(){const t=trdS();t.prof=t.prof||{};const p=t.prof;p.cur=p.cur||'₹';p.strat=Array.isArray(p.strat)&&p.strat.length?p.strat:TD_STRAT.slice();p.ins=Array.isArray(p.ins)&&p.ins.length?p.ins:TD_INS.slice();p.chk=Array.isArray(p.chk)&&p.chk.length?p.chk:TD_CHECK.slice();p.mist=Array.isArray(p.mist)&&p.mist.length?p.mist:TD_MIST.slice();return p}
function trdS(){S.trd=S.trd&&typeof S.trd==='object'?S.trd:{};S.trd.days=S.trd.days&&typeof S.trd.days==='object'?S.trd.days:{};S.trd.trades=Array.isArray(S.trd.trades)?S.trd.trades:[];S.trd.prof=S.trd.prof&&typeof S.trd.prof==='object'?S.trd.prof:{};return S.trd}
function normTrd(o){const s={days:{},trades:[],prof:{},away:[]};if(!o||typeof o!=='object')return s;const str=(v,n)=>String(v==null?'':v).slice(0,n),arr=(a,n,m)=>Array.isArray(a)?a.map(x=>str(x,m||60)).slice(0,n):[],num=v=>v===''||v==null||!isFinite(+v)?null:+v,imgs=a=>Array.isArray(a)?a.map(String).slice(0,12):[];
 if(o.prof&&typeof o.prof==='object'){const p=o.prof;s.prof={cur:str(p.cur||'₹',3),strat:arr(p.strat,30,30),ins:arr(p.ins,40,30),chk:arr(p.chk,20,40),mist:arr(p.mist,30,30)}}
 Object.keys(o.days||{}).forEach(k=>{if(!/^\d{4}-\d\d-\d\d$/.test(k))return;const d=o.days[k]||{},pr=d.pre,po=d.post,lv=d.live||{};
  s.days[k]={pre:pr&&typeof pr==='object'?{ts:str(pr.ts,8),bias:str(pr.bias,8),snap:pr.snap&&typeof pr.snap==='object'?Object.fromEntries(Object.entries(pr.snap).slice(0,12).map(([a,b])=>[str(a,12),str(b,6)])):{},events:arr(pr.events,10),news:str(pr.news,1200),sup:str(pr.sup,200),res:str(pr.res,200),pats:arr(pr.pats,10),pat:str(pr.pat,1200),focus:arr(pr.focus,10),types:arr(pr.types,6),strat:arr(pr.strat,8),w1:str(pr.w1,5),w2:str(pr.w2,5),maxLoss:num(pr.maxLoss),maxTrades:num(pr.maxTrades),rules:str(pr.rules,1200),plan:str(pr.plan,1500),chk:arr(pr.chk,20,40),feel:+pr.feel||0,img:imgs(pr.img)}:null,
   live:{obs:(Array.isArray(lv.obs)?lv.obs:[]).filter(x=>x&&x.tx!=null).slice(0,200).map(x=>({id:str(x.id||uid('o'),20),t:str(x.t,8),k:str(x.k||'Observation',20),tx:str(x.tx,1000),img:imgs(x.img)}))},
   off:d.off&&typeof d.off==='object'&&['wait','pass','holiday','away','other'].includes(d.off.t)?{t:d.off.t,note:str(d.off.note,300),ts:str(d.off.ts,8)}:null,
   post:po&&typeof po==='object'?{ts:str(po.ts,8),pnl:num(po.pnl),adh:+po.adh||0,worked:str(po.worked,1200),failed:str(po.failed,1200),mist:arr(po.mist,12,30),lessons:str(po.lessons,1500),pats:str(po.pats,1200),tomorrow:str(po.tomorrow,1200),grade:str(po.grade,2),feel:+po.feel||0,img:imgs(po.img)}:null}});
 s.away=(Array.isArray(o.away)?o.away:[]).filter(r=>r&&/^\d{4}-\d\d-\d\d$/.test(r.a)&&/^\d{4}-\d\d-\d\d$/.test(r.b)&&r.a<=r.b).slice(0,60).map(r=>({a:r.a,b:r.b,note:str(r.note,200)}));
 s.trades=(Array.isArray(o.trades)?o.trades:[]).filter(t=>t&&t.d&&/^\d{4}-\d\d-\d\d$/.test(t.d)).slice(-5000).map(t=>({id:str(t.id||uid('t'),20),d:t.d,t:str(t.t,8),ins:str(t.ins,40),type:str(t.type,24),side:str(t.side,8),opt:str(t.opt,30),strat:str(t.strat,30),entry:num(t.entry),exit:num(t.exit),qty:num(t.qty),sl:num(t.sl),tgt:num(t.tgt),fees:num(t.fees),pnl:num(t.pnl),r:num(t.r),why:str(t.why,800),emo:str(t.emo,16),mist:arr(t.mist,10,30),grade:str(t.grade,2),note:str(t.note,1000),img:imgs(t.img)}));
 return s}
const tdDay=k=>{const t=trdS();return t.days[k]||(t.days[k]={pre:null,live:{obs:[]},post:null})};
const tdHas=k=>{const d=trdS().days[k];return d?{pre:!!d.pre,live:!!(d.live&&d.live.obs.length)||trdS().trades.some(t=>t.d===k),post:!!d.post}:{pre:false,live:trdS().trades.some(t=>t.d===k),post:false}};
const tdFmt=v=>{if(v==null||!isFinite(v))return '-';const a=Math.abs(v),s=a>=1e5?(a/1e5).toFixed(a>=1e6?1:2)+'L':a>=1e3?(a/1e3).toFixed(a>=1e4?1:2)+'k':a.toFixed(a<100&&a%1?2:0);return (v<0?'-':v>0?'+':'')+tdProf().cur+s};
const tdPlain=v=>v==null||!isFinite(v)?'-':tdProf().cur+Math.abs(v).toLocaleString('en-IN',{maximumFractionDigits:2});
/* pnl of one trade: typed value wins, otherwise price maths */
function tdCalc(t){if(t.pnl!=null)return t.pnl;if(t.entry==null||t.exit==null||t.qty==null)return null;const dir=/short|sell|pe/i.test(t.side)&&!/long|buy/i.test(t.side)?-1:1;return (t.exit-t.entry)*t.qty*dir-(t.fees||0)}
function tdR(t){const p=tdCalc(t);if(p==null||t.sl==null||t.entry==null||t.qty==null)return null;const risk=Math.abs(t.entry-t.sl)*t.qty;return risk>0?p/risk:null}
const tdTr=(a,b)=>trdS().trades.filter(t=>(!a||t.d>=a)&&(!b||t.d<=b)).map(t=>Object.assign({},t,{p:tdCalc(t),rr:tdR(t)})).filter(t=>t.p!=null);
function tdDayPnl(k){const L=tdTr(k,k);if(L.length)return sum(L.map(t=>t.p));const d=trdS().days[k];return d&&d.post&&d.post.pnl!=null?d.post.pnl:null}
function tdGroup(L,keyf){const m={};L.forEach(t=>{const k=keyf(t);if(k==null||k==='')return;const o=m[k]=m[k]||{k,n:0,w:0,p:0,gw:0,gl:0};o.n++;o.p+=t.p;if(t.p>0){o.w++;o.gw+=t.p}else if(t.p<0)o.gl+=-t.p});return Object.values(m).sort((a,b)=>b.p-a.p)}
function tdEngine(a,b){const L=tdTr(a,b).sort((x,y)=>(x.d+x.t).localeCompare(y.d+y.t)),E={L,n:L.length};if(!L.length)return E;
 const w=L.filter(t=>t.p>0),l=L.filter(t=>t.p<0);E.total=sum(L.map(t=>t.p));E.wins=w.length;E.losses=l.length;E.winRate=w.length/L.length;E.gw=sum(w.map(t=>t.p));E.gl=-sum(l.map(t=>t.p));E.avgW=w.length?E.gw/w.length:0;E.avgL=l.length?E.gl/l.length:0;E.payoff=E.avgL?E.avgW/E.avgL:null;E.pf=E.gl?E.gw/E.gl:null;E.exp=E.total/L.length;
 const days={};L.forEach(t=>{days[t.d]=(days[t.d]||0)+t.p});E.dayKeys=Object.keys(days).sort();E.days=days;E.nd=E.dayKeys.length;E.wd=E.dayKeys.filter(k=>days[k]>0).length;
 let eq=0,pk=0,dd=0;E.curve=E.dayKeys.map(k=>{eq+=days[k];pk=Math.max(pk,eq);dd=Math.min(dd,eq-pk);return eq});E.maxDD=dd;E.best=E.dayKeys.reduce((x,k)=>days[k]>(days[x]??-1e18)?k:x,E.dayKeys[0]);E.worst=E.dayKeys.reduce((x,k)=>days[k]<(days[x]??1e18)?k:x,E.dayKeys[0]);
 let st=0,sg=0;for(let i=E.dayKeys.length-1;i>=0;i--){const s=Math.sign(days[E.dayKeys[i]]);if(!s)break;if(!sg)sg=s;if(s===sg)st++;else break}E.streak=st*sg;
 const R=L.map(t=>t.rr).filter(x=>x!=null);E.R=R;E.avgR=R.length?avgN(R):null;
 E.byStrat=tdGroup(L,t=>t.strat);E.byIns=tdGroup(L,t=>t.ins);E.byType=tdGroup(L,t=>t.type);E.byEmo=tdGroup(L,t=>t.emo);E.byGrade=tdGroup(L,t=>t.grade);
 E.byHour=tdGroup(L,t=>t.t?(+t.t.slice(0,2)):null).sort((x,y)=>x.k-y.k);E.byWd=tdGroup(L,t=>dow(t.d)).sort((x,y)=>x.k-y.k);
 const mc={};L.forEach(t=>(t.mist||[]).forEach(m=>{const o=mc[m]=mc[m]||{k:m,n:0,p:0};o.n++;o.p+=t.p}));E.mist=Object.values(mc).sort((x,y)=>x.p-y.p);
 /* day level links: plan adherence, preparation, number of trades */
 const dm=E.dayKeys.map(k=>{const d=trdS().days[k]||{},n=L.filter(t=>t.d===k).length;return{k,p:days[k],n,adh:d.post&&d.post.adh||0,pre:!!d.pre,feel:d.pre&&d.pre.feel||0}});E.dm=dm;
 const hiA=dm.filter(x=>x.adh>=4),loA=dm.filter(x=>x.adh>0&&x.adh<=3);E.adh=hiA.length>=3&&loA.length>=3?{hi:avgN(hiA.map(x=>x.p)),lo:avgN(loA.map(x=>x.p)),nh:hiA.length,nl:loA.length}:null;
 const pr=dm.filter(x=>x.pre),np=dm.filter(x=>!x.pre);E.prep=pr.length>=3&&np.length>=3?{a:avgN(pr.map(x=>x.p)),b:avgN(np.map(x=>x.p)),na:pr.length,nb:np.length}:null;
 const my=dm.filter(x=>x.n>=1);const med=my.length?my.map(x=>x.n).sort((p,q)=>p-q)[Math.floor(my.length/2)]:0;const many=my.filter(x=>x.n>med&&x.n>=3),few=my.filter(x=>x.n<=med);E.over=many.length>=3&&few.length>=3?{many:avgN(many.map(x=>x.p)),few:avgN(few.map(x=>x.p)),nm:many.length,nf:few.length,med}:null;
 return E}
function tdCoach(E){const F=[],c=tdPlain,N=E.n;if(!N)return F;
 if(N>=10&&E.exp!=null)F.push({w:E.exp>0?'good':'warn',k:'Edge',h:E.exp>0?`Your average trade makes ${c(E.exp)}`:`Your average trade loses ${c(E.exp)}`,x:`Across ${N} trades: win rate ${pctS(E.winRate)}, average win ${c(E.avgW)}, average loss ${c(E.avgL)}.`+(E.winRate<.5&&E.payoff>=1.5?' You win less than half the time but your wins are bigger. That is a valid edge if you keep losses small.':E.winRate>=.5&&E.payoff<1?' You win often but your losses are larger than your wins. Cutting losers sooner would help most.':''),ev:N+' trades',s:90});
 if(E.byStrat.length>=2){const b=E.byStrat.filter(x=>x.n>=4);if(b.length>=2){const t=b[0],w=b[b.length-1];F.push({w:'info',k:'Setups',h:`${t.k} is your best setup, ${w.k} your weakest`,x:`${t.k}: ${tdFmt(t.p)} over ${t.n} trades (${Math.round(t.w/t.n*100)}% wins). ${w.k}: ${tdFmt(w.p)} over ${w.n} trades.`,ev:'strategies with 4+ trades',s:80})}}
 if(E.mist.length&&E.mist[0].p<0&&E.mist[0].n>=2)F.push({w:'warn',k:'Costliest mistake',h:`${E.mist[0].k} cost you ${c(E.mist[0].p)}`,x:`You tagged it on ${E.mist[0].n} trades. Removing just this one habit is worth more than finding a new setup.`,ev:E.mist[0].n+' tagged trades',s:95});
 if(E.adh)F.push({w:E.adh.hi>E.adh.lo?'good':'info',k:'Discipline',h:E.adh.hi>E.adh.lo?'Following your plan pays':'Plan adherence not showing in results yet',x:`On days you rated plan-following 4 or 5, you averaged ${tdFmt(E.adh.hi)}. On days you rated it 3 or less: ${tdFmt(E.adh.lo)}.`,ev:E.adh.nh+' vs '+E.adh.nl+' days',s:85});
 if(E.prep)F.push({w:E.prep.a>E.prep.b?'good':'info',k:'Preparation',h:E.prep.a>E.prep.b?'Prepared days do better':'Preparing has not changed results yet',x:`Days with a pre-market plan averaged ${tdFmt(E.prep.a)}. Days without: ${tdFmt(E.prep.b)}. This is an association in your own records.`,ev:E.prep.na+' vs '+E.prep.nb+' days',s:70});
 if(E.over)F.push({w:E.over.many<E.over.few?'warn':'info',k:'Overtrading',h:E.over.many<E.over.few?'More trades, worse days':'More trades have not hurt so far',x:`Days with more than ${E.over.med} trades averaged ${tdFmt(E.over.many)}. Days with ${E.over.med} or fewer: ${tdFmt(E.over.few)}. Consider a daily trade limit.`,ev:E.over.nm+' vs '+E.over.nf+' days',s:75});
 const hb=E.byHour.filter(x=>x.n>=4);if(hb.length>=2){const t=hb.reduce((x,y)=>y.p>x.p?y:x),w=hb.reduce((x,y)=>y.p<x.p?y:x);if(t.k!==w.k)F.push({w:'info',k:'Timing',h:`Best hour ${String(t.k).padStart(2,'0')}:00, hardest ${String(w.k).padStart(2,'0')}:00`,x:`${tdFmt(t.p)} in the best hour (${t.n} trades) versus ${tdFmt(w.p)} in the worst (${w.n}).`,ev:'hours with 4+ trades',s:60})}
 const eb=E.byEmo.filter(x=>x.n>=3);if(eb.length>=2){const w=eb[eb.length-1];if(w.p<0)F.push({w:'warn',k:'Feeling',h:`Trades taken while "${w.k}" lost ${c(w.p)}`,x:`${w.n} trades. Notice the feeling before entering, and skip or size down when it shows up.`,ev:w.n+' trades',s:72})}
 if(E.maxDD<0&&E.nd>=5)F.push({w:'info',k:'Drawdown',h:`Deepest dip: ${c(E.maxDD)}`,x:'Measured from your highest running total to the lowest point after it, on daily results. Know your number before it happens so a normal dip does not feel like a crisis.',ev:E.nd+' trading days',s:50});
 if(E.streak<=-3)F.push({w:'warn',k:'Streak',h:`${-E.streak} losing days in a row`,x:'After a losing run, many traders push harder. Consider halving size or pausing until the next planned day.',ev:'recent days',s:88});
 return F.sort((a,b)=>b.s-a.s)}
