/* ===== Constellation of Self: goal relationships, weekly shift, what brightness means ===== */
const RELK={supports:'supports',competes:'competes with',depends:'depends on'};
const REL={k:'supports'};
function relCard(g){const rl=(g.rel||[]).filter(r=>gById(r.to)),others=S.goals.filter(x=>x.id!==g.id);
 return `<h3 class="h3" style="margin-top:20px">Connections on the map</h3><div class="card">${rl.length?rl.map(r=>{const o=gById(r.to);return `<div class="row sm" style="padding:6px 0;border-bottom:1px solid var(--line)"><span style="flex:1">This ${RELK[r.k]} <b>${esc(o.name)}</b></span><button class="btn sm ghost" data-act="reldel" data-id="${g.id}" data-to="${o.id}">Remove</button></div>`}).join(''):'<div class="sm mute">No links yet, so the map joins goals in a simple ring. Add a link and the map uses only the links you define.</div>'}
 ${others.length?`<div class="row wrapr" style="gap:8px;margin-top:10px"><select data-chg="relk" style="width:auto">${Object.keys(RELK).map(k=>`<option value="${k}" ${REL.k===k?'selected':''}>${RELK[k]}</option>`).join('')}</select><select data-chg="reladd" data-id="${g.id}" style="width:auto"><option value="">Pick a goal...</option>${others.map(o=>`<option value="${o.id}">${esc(o.name)}</option>`).join('')}</select></div>`:''}
 <div class="xs mute" style="margin-top:8px">Links are yours to define. They show how goals relate, not how good any goal is.</div></div>`}
CHG.relk=el=>{REL.k=el.value};
CHG.reladd=el=>{const g=gById(el.dataset.id),to=el.value;if(!g||!to)return;g.rel=(g.rel||[]).filter(r=>r.to!==to);g.rel.push({to,k:REL.k});REV++;save();relink();renderDrawer(true);sfx('tick')};
ACT.reldel=el=>{const g=gById(el.dataset.id);if(!g)return;g.rel=(g.rel||[]).filter(r=>r.to!==el.dataset.to);REV++;save();relink();renderDrawer(true)};
/* weekly shift: this 7 days against the 7 before */
function shiftRows(){const t=todayKey(),a0=addD(t,-6),b0=addD(t,-13),b1=addD(t,-7);
 return S.goals.filter(g=>!g.paused&&g.start<=t).map(g=>{const se=strengthSeries(g),at=d=>{const e=se.find(x=>x.k===d);return e?e.v:null};
  const now=at(t<g.end?t:g.end),prev=at(b1);const cnt=(x,y)=>{let n=0;for(let k=x;k<=y;k=addD(k,1))if(k>=g.start&&isDoneL(g.logs[k]))n++;return n};
  const n1=cnt(a0,t),n0=cnt(b0,b1),d=prev==null||now==null?null:Math.round((now-prev)*100);
  const lab=d==null?'New':d>=4?'Strengthened':d<=-4?'Softened':'Steady';return {g,n1,n0,d,lab,now}})}
function openShift(){const R=shiftRows();FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');
 $('#mbox').innerHTML=`<div class="row wrapr"><div><h2 class="vt" style="margin:0">Weekly shift</h2><div class="xs mute">The last 7 days against the 7 before. Patterns, not personal worth.</div></div><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div>
 ${R.length?`<div class="rtw"><table class="t rt"><tr><th>Goal</th><th>Change</th><th>This week</th><th>Week before</th><th>Strength</th></tr>${R.map(r=>`<tr data-act="open" data-id="${r.g.id}" style="cursor:pointer"><td>${esc(r.g.name)}</td><td>${r.lab}${r.d==null?'':' ('+(r.d>0?'+':'')+r.d+')'}</td><td>${r.n1}</td><td>${r.n0}</td><td>${Math.round(r.now*100)}%</td></tr>`).join('')}</table></div>`:'<div class="card mute sm" style="margin-top:12px">No active goals yet.</div>'}
 <div class="xs mute" style="margin-top:8px">Brightness on the map is a model of recent consistency (a 14-day half-life for build goals), not a brain measurement. A dim goal means a quieter stretch, nothing more. Tap a row to see the data behind it.</div>`;$('#mbox').scrollTop=0;sfx('open')}
ACT.shift=()=>openShift();
