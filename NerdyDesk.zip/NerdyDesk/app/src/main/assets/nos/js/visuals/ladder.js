/* ===== Ladder view: every finished day is one rung up a rope ladder toward a glowing hatch (quit goals: climb out of the pit, old rungs fall away) ===== */
const LA={};
function ladderMan(x,y,h,ph,mode,t,he,lw,rd){const c=cx,u=h/10,w=Math.max(1.8,h*.07);c.save();c.strokeStyle='#fff';c.fillStyle='#fff';c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.shadowColor='rgba(255,255,255,.65)';c.shadowBlur=7;
 const climb=mode==='climb',bob=rd?0:Math.sin(t*1.7)*u*.1,s=Math.sin(ph),hip=[x,y-u*4.2+bob],sh=[x,y-u*7.2+bob];
 let hd=[x,y-u*8.7+bob];if(mode==='look'){hd=[x+Math.sin(t*2)*u*.7,hd[1]]}
 const line=(a,b,k)=>{c.beginPath();c.moveTo(a[0],a[1]);if(k)c.lineTo(k[0],k[1]);c.lineTo(b[0],b[1]);c.stroke()};
 /* legs: feet on rungs, alternate when climbing */
 const lf=[x-lw*.28,y+(climb?-Math.max(0,s)*u*2.2:0)],rf=[x+lw*.28,y+(climb?-Math.max(0,-s)*u*2.2:0)];
 line(hip,lf,[x-lw*.34,(hip[1]+lf[1])/2]);line(hip,rf,[x+lw*.34,(hip[1]+rf[1])/2]);line(hip,sh);
 /* arms */
 let lh=[x-lw*.5,sh[1]-u*1.1],rh=[x+lw*.5,sh[1]-u*1.1];
 if(climb){lh[1]=sh[1]-u*2.4+s*u*1.7;rh[1]=sh[1]-u*2.4-s*u*1.7}
 else if(mode==='cheer'){lh=[x-u*2.6,sh[1]-u*3.4-Math.abs(Math.sin(t*7))*u*.6];rh=[x+u*2.6,sh[1]-u*3.4-Math.abs(Math.sin(t*7+1))*u*.6]}
 else if(mode==='wave'){rh=[x+u*2.8,sh[1]-u*3+Math.sin(t*9)*u*.7]}
 else if(mode==='think'){rh=[hd[0]+u*.6,hd[1]+u*1.3]}
 else if(mode==='hit'){rh=[x+u*2,sh[1]-u*3.3]}
 line(sh,lh,[x-lw*.62,sh[1]-u*.3]);line(sh,rh,[x+lw*.62,sh[1]-u*.3]);
 c.beginPath();c.arc(hd[0],hd[1],u*1.15,0,6.283);c.fill();c.restore()}
function drawLadder(now,dt){const th=TH(),t=now*.001,g=focusG(),rd=reduced();BHIT=[];
 if(!g){cx.fillStyle='rgba(235,240,255,.7)';cx.font='600 15px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText('Add a goal to climb',W/2,H/2);return}
 cx.save();cx.translate(W/2+SH.x,H/2+SH.y);cx.scale(SH.s,SH.s);cx.translate(-W/2,-H/2);
 const P=pathStat(g),q=P.q,N=P.N,k=P.k,r=rt(g),col=g.color,rgb=rgbOf(col),L=LA[g.id]||(LA[g.id]={pos:k,ph:0,init:false,slide:0});
 const fe=PF&&PF.g===g.id?(performance.now()-PF.t0)/1000:99;
 if(!L.init||Math.abs(k-L.pos)>2.6||rd){L.pos=k;L.init=true}
 if(PF&&PF.g===g.id&&!PF.lad&&PF.kind!=='slip'){PF.lad=true;L.pos=Math.max(0,k-1)}
 if(PF&&PF.g===g.id&&!PF.lad&&PF.kind==='slip'){PF.lad=true;L.slide=1}
 const dp=k-L.pos,spd=(L.rate||1.05)*(Math.abs(dp)>1.4?1.8:1);let moving=false;const tv=Math.abs(dp)>.004?Math.sign(dp)*Math.min(spd,Math.abs(dp)*3.4+.12):0;L.v=(L.v||0)+(tv-(L.v||0))*Math.min(1,dt*5);
 if(Math.abs(dp)>.004||Math.abs(L.v)>.03){let st=L.v*dt;if(Math.abs(st)>Math.abs(dp))st=dp;L.pos+=st;L.ph+=Math.abs(st)*3.1416*2;moving=Math.abs(L.v)>.05}else{L.v=0;L.rate=0}
 if(L.slide>0){L.slide=Math.max(0,L.slide-dt*1.1)}
 const rs=clamp(Math.min(W,H)*.085,34,54),lw=clamp(W*.26,92,150),cxm=W/2,figY=H*.62,pos=L.pos-(L.slide>0?Math.sin(L.slide*3.14)*.7:0),yR=i=>figY+(pos-i)*rs,top=N+1.6;
 /* sky glow from the hatch */
 const prox=clamp(pos/N,0,1),hy=yR(top);
 cx.save();const lg=cx.createLinearGradient(0,hy,0,hy+H*.9);lg.addColorStop(0,`rgba(255,255,255,${.1+.2*prox})`);lg.addColorStop(1,'rgba(255,255,255,0)');cx.fillStyle=lg;cx.beginPath();cx.moveTo(cxm-lw*.55,hy);cx.lineTo(cxm+lw*.55,hy);cx.lineTo(cxm+lw*2.2,H+20);cx.lineTo(cxm-lw*2.2,H+20);cx.closePath();cx.fill();cx.restore();
 /* pit (quit) or ground (build) */
 const gy=yR(-.6);
 if(q){const pg=cx.createLinearGradient(0,gy-rs*3,0,gy+rs*4);pg.addColorStop(0,'rgba(255,60,80,0)');pg.addColorStop(1,'rgba(255,60,80,.5)');cx.fillStyle=pg;cx.fillRect(0,gy-rs*3,W,H);cx.fillStyle=rgba('#fff',.5);cx.font='700 '+clamp(W*.03,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';if(gy<H-10)cx.fillText('Temptation',cxm,Math.min(H-8,gy+rs*1.2))}
 else if(gy<H+20){cx.fillStyle='rgba(255,255,255,.08)';cx.fillRect(0,gy,W,H-gy);cx.strokeStyle='rgba(255,255,255,.2)';cx.lineWidth=1.5;cx.beginPath();cx.moveTo(cxm-lw*2.2,gy);cx.lineTo(cxm+lw*2.2,gy);cx.stroke();cx.fillStyle='rgba(235,240,255,.55)';cx.font='600 '+clamp(W*.03,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText('Start',cxm,gy+18)}
 /* pillars like the walls you climb out of */
 cx.fillStyle='rgba(220,225,240,.16)';[-1,1].forEach(sd=>{const px=cxm+sd*lw*1.75;cx.fillRect(px-3,Math.min(yR(top)-20,0),6,H*2)});
 /* rails */
 const yTop=yR(top),yBot=Math.max(yR(-1),H+10),sw=a=>rd?0:Math.sin(a*.012+t*.9)*2.2;
 cx.lineCap='round';[-1,1].forEach(sd=>{cx.strokeStyle='rgba(206,176,138,.95)';cx.lineWidth=3.6;cx.beginPath();for(let y=Math.max(yTop,-10);y<=Math.min(yBot,H+10);y+=14){const x=cxm+sd*lw*.5+sw(y);y===Math.max(yTop,-10)?cx.moveTo(x,y):cx.lineTo(x,y)}cx.stroke();
  cx.strokeStyle='rgba(120,92,60,.9)';cx.lineWidth=1;for(let y=Math.max(yTop,-10);y<=Math.min(yBot,H+10);y+=9){const x=cxm+sd*lw*.5+sw(y);cx.beginPath();cx.moveTo(x-2.5,y);cx.lineTo(x+2.5,y+3);cx.stroke()}});
 /* rungs */
 const first=q?Math.max(1,k-2):1,per=P.per;
 for(let i=first;i<=N;i++){const y=yR(i);if(y<-30||y>H+30)continue;const done=i<=k,cur=Math.abs(i-L.pos)<.5,tilt=Math.sin(i*1.9)*.07+(rd?0:Math.sin(t*1.1+i)*.012);
  /* quit: the rung you left breaks away and falls */
  let fall=0;if(q&&i<k-0&&i>=k-2){fall=clamp((k-i-.2)/1.8,0,1)}
  const dy=fall*fall*rs*1.6,al=1-fall*.85;
  cx.save();cx.translate(cxm,y+dy);cx.rotate(tilt+fall*.5);cx.globalAlpha=al*(done||cur?1:.62);
  const wv=!q&&done&&P.wk?P.wk[i-1]||0:0;
  if(wv>=.99){/* a missed day: the rung is snapped in two and hangs loose */
   cx.fillStyle='rgba(150,112,96,1)';cx.save();cx.translate(-lw*.56,-4);cx.rotate(.32);cx.fillRect(0,0,lw*.5,9);cx.restore();cx.save();cx.translate(lw*.56,-4);cx.rotate(-.1);cx.fillRect(-lw*.42,3,lw*.42,9);cx.restore();
   cx.strokeStyle='rgba(255,110,130,.9)';cx.lineWidth=1.4;cx.beginPath();cx.moveTo(-lw*.1,-5);cx.lineTo(-lw*.02,2);cx.lineTo(-lw*.12,6);cx.moveTo(lw*.12,-2);cx.lineTo(lw*.04,4);cx.lineTo(lw*.14,9);cx.stroke()}
  else{cx.fillStyle=done?(wv>0?'rgba(190,150,120,1)':'rgba(214,184,142,1)'):'rgba(150,130,104,.9)';cx.fillRect(-lw*.56,-4,lw*1.12,9);
   cx.strokeStyle=done?(wv>0?'rgba(255,140,120,.95)':rgba(col,.95)):'rgba(0,0,0,.35)';cx.lineWidth=done?1.6:1;cx.strokeRect(-lw*.56,-4,lw*1.12,9);
   if(wv>0){cx.strokeStyle='rgba(120,40,40,.95)';cx.lineWidth=1.3;cx.beginPath();cx.moveTo(-lw*.06,-4);cx.lineTo(lw*.02,0);cx.lineTo(-lw*.04,2);cx.lineTo(lw*.05,5);cx.stroke()}}
  if(PMILE.includes(i*per)||PMILE.includes(i*per-per+1)){cx.fillStyle='#ffd23f';cx.fillRect(-lw*.56,-4,5,9);cx.fillRect(lw*.56-5,-4,5,9)}
  cx.restore();cx.globalAlpha=1;
  BHIT.push({g,x:cxm-lw*.56,w:lw*1.12,y0:y-8,y1:y+8,d0:addD(g.start,(i-1)*per),d1:addD(g.start,Math.min(P.L-1,(i-1)*per+per-1))})}
 /* hatch and goal */
 if(hy>-120&&hy<H+60){const gl=.5+.5*prox+(rd?0:.12*Math.sin(t*2));glow(cxm,hy-6,lw*(1+prox),'255,255,255',.35*gl+.1);cx.fillStyle=`rgba(255,255,255,${.55+.4*prox})`;cx.beginPath();cx.moveTo(cxm-lw*.62,hy);cx.lineTo(cxm+lw*.62,hy);cx.lineTo(cxm+lw*.8,hy-rs*.5);cx.lineTo(cxm-lw*.8,hy-rs*.5);cx.closePath();cx.fill();
  cx.fillStyle=rgba(col,.95);cx.font='700 '+clamp(W*.032,12,16)+'px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText(q?'Freedom':'Goal',cxm,hy-rs*.8);HITS.push({g,x:cxm,y:hy-rs*.2,r:lw*.7,z:1,s:1})}
 /* the climber */
 let mode='idle';const doneToday=dueState(g).s==='done',cel=PF&&PF.g===g.id&&PF.kind!=='slip'&&fe>1.1&&fe<3.4&&!moving;
 if(moving)mode='climb';else if(cel&&!rd)mode='cheer';else if(!rd){const cy=(t+(g.id.charCodeAt(g.id.length-1)%7))%16;if(cy>=3&&cy<5.5)mode='look';else if(cy>=7&&cy<10)mode='think';else if(cy>=11&&cy<12.4)mode='wave';else if(r.flash>.25||doneToday&&(t%7<1.4))mode='cheer'}
 const mh=rs*2.5,fy=yR(L.pos),jy=mode==='cheer'&&!rd?-Math.abs(Math.sin(t*5))*mh*.12:0;
 glow(cxm,fy-mh*.5,mh*1.2,rgb,.28+r.flash*.4);ladderMan(cxm,fy+jy,mh,L.ph,mode,t,fe,lw,rd);
 HITS.push({g,x:cxm,y:fy-mh*.5,r:mh*.7,z:2,s:1});
 if(mode==='think'){cx.fillStyle='rgba(255,255,255,.8)';for(let j=0;j<3;j++){cx.globalAlpha=.4+.6*Math.max(0,Math.sin(t*3-j*.8));cx.beginPath();cx.arc(cxm+mh*.35+j*mh*.12,fy-mh*1.1-j*mh*.05,mh*.04+j*.5,0,6.283);cx.fill()}cx.globalAlpha=1}
 /* fire: sparks, a lock-in ring, falling rung dust and a caption */
 let capFn=null;
 if(PF&&PF.g===g.id){const life=PF.kind==='mile'?5.4:3.6;if(fe>life)PF=null;else{
  if(!PF.sp&&!moving&&fe>.5){PF.sp=true;PF.p=PF.p||[];const gold=PF.kind==='mile',n=rd?0:gold?40:22,bx=cxm,by=yR(Math.round(L.pos));for(let i=0;i<n;i++){const a=Math.random()*6.283,sp2=40+Math.random()*130;PF.p.push({x:bx,y:by,vx:Math.cos(a)*sp2,vy:Math.sin(a)*sp2-50,l:1,r:Math.random()*6,vr:(Math.random()-.5)*14,z:2+Math.random()*3})}PF.ring=by;sfx('fire')}
  const gold=PF.kind==='mile',pc=PF.kind==='slip'?'#ff9aa8':gold?'#ffd23f':col;
  if(PF.p)PF.p.forEach(p2=>{p2.x+=p2.vx*dt;p2.y+=p2.vy*dt;p2.vy+=240*dt;p2.r+=p2.vr*dt;p2.l-=dt*.7;if(p2.l>0){cx.save();cx.globalAlpha=Math.min(1,p2.l*1.4);cx.translate(p2.x,p2.y);cx.rotate(p2.r);cx.fillStyle=Math.random()<.5?pc:'rgba(214,184,142,1)';cx.fillRect(-p2.z,-p2.z*.5,p2.z*2,p2.z);cx.restore()}});
  if(PF.ring!=null&&fe<2){const f=clamp((fe-.5)/1.2,0,1);cx.strokeStyle=rgba(pc,(1-f)*.8);cx.lineWidth=2;cx.beginPath();cx.ellipse(cxm,PF.ring,lw*(.4+f*1.6),rs*(.3+f*.7),0,0,6.283);cx.stroke()}
  if(!rd&&fe<1.4&&PF.kind!=='slip'){glow(cxm,hy>0?hy:0,lw*(1+fe),'255,255,255',(1-fe/1.4)*.5)}
  const ca=fe<.4?fe/.4:fe>life-.8?(life-fe)/.8:1,txt=PF.kind==='slip'?'Slip logged. The ladder is still here.':PF.kind==='back'?'Back on the ladder.':q?(PF.kind==='mile'?'Clean day '+gStats(g).done+'. Milestone. The old path fell away.':'Clean day '+gStats(g).done+'. One rung up.'):(PF.kind==='mile'?'Day '+gStats(g).done+'. Milestone rung.':'Day '+gStats(g).done+'. One rung up.');
  capFn=(()=>{cx.globalAlpha=clamp(ca,0,1);cx.fillStyle=pc;cx.textAlign='center';cx.font='700 '+clamp(W*.036,13,19)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(txt,cxm,Math.max(90,H*.27));cx.globalAlpha=1})}}
 if(capFn)capFn();
 cx.restore();
 const mx=x=>W/2+SH.x+(x-W/2)*SH.s,my=y=>H/2+SH.y+(y-H/2)*SH.s;BHIT.forEach(b=>{b.x=mx(b.x);b.w*=SH.s;b.y0=my(b.y0);b.y1=my(b.y1)});HITS.forEach(h=>{if(h.g===g&&h.z>=1&&!h._m){h._m=1;h.x=mx(h.x);h.y=my(h.y);h.r*=SH.s}})}
