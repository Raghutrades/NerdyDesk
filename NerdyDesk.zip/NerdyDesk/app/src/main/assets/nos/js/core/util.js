/* ===== NeuroOrbitSynapse: utilities ===== */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),lerp=(a,b,t)=>a+(b-a)*t,pad=n=>String(n).padStart(2,'0');
let _now=null;const NOW=()=>_now?new Date(_now):new Date();
const dayKey=(d=NOW())=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const todayKey=()=>dayKey(NOW());
const parseK=k=>{const p=String(k).split('-').map(Number);return new Date(p[0],p[1]-1,p[2])};
const addD=(k,n)=>{const d=parseK(k);d.setDate(d.getDate()+n);return dayKey(d)};
const diffD=(a,b)=>{const x=a.split('-').map(Number),y=b.split('-').map(Number);return Math.round((Date.UTC(y[0],y[1]-1,y[2])-Date.UTC(x[0],x[1]-1,x[2]))/864e5)};
const dow=k=>parseK(k).getDay();
const weekStart=k=>addD(k,-((dow(k)+6)%7));
const monthStart=k=>k.slice(0,8)+'01';
const monthEnd=k=>{const d=parseK(k);return dayKey(new Date(d.getFullYear(),d.getMonth()+1,0))};
const fmtD=(k,o)=>parseK(k).toLocaleDateString([],o||{day:'numeric',month:'short'});
const fmtLong=k=>parseK(k).toLocaleDateString([],{weekday:'long',day:'numeric',month:'long',year:'numeric'});
const WD=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const hm=(d=NOW())=>pad(d.getHours())+':'+pad(d.getMinutes());
const mins=t=>{const p=String(t).split(':');return (+p[0])*60+(+p[1]||0)};
const uid=p=>(p||'x')+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){let s=seed>>>0;return()=>{s=(s+0x6D2B79F5)>>>0;let t=Math.imul(s^s>>>15,1|s);t=(t+Math.imul(t^t>>>7,61|t))^t;return((t^t>>>14)>>>0)/4294967296}}
const hex2=h=>{h=String(h||'#888888').replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return[n>>16&255,n>>8&255,n&255]};
const rgba=(h,a)=>{const c=hex2(h);return `rgba(${c[0]},${c[1]},${c[2]},${a})`};
const mix=(a,b,t)=>{const x=hex2(a),y=hex2(b);return '#'+[0,1,2].map(i=>pad(Math.round(lerp(x[i],y[i],t)).toString(16))).join('')};
const lum=h=>{const c=hex2(h);return (.299*c[0]+.587*c[1]+.114*c[2])/255};
const sum=a=>a.reduce((x,y)=>x+y,0),avg=a=>a.length?sum(a)/a.length:0;
const plural=(n,w,p)=>n+' '+(n===1?w:(p||w+'s'));


/* safe canvas arcs: a negative or non-finite radius must never throw (animated radii can dip below 0) */
(function(){const P=CanvasRenderingContext2D.prototype,a=P.arc,e=P.ellipse,f=v=>isFinite(v)&&v>0?v:0;
 P.arc=function(x,y,r,s,t,c){return a.call(this,x,y,f(r),s,t,c)};
 P.ellipse=function(x,y,rx,ry,rot,s,t,c){return e.call(this,x,y,f(rx),f(ry),rot,s,t,c)}})();
