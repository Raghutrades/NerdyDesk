/* ===== Journal: write entries, tag them, link to goals, see mood over time ===== */
UI.jn={type:'all',tag:'',goal:'',q:'',draft:{mood:0,energy:0,tags:[],goal:'',title:'',tx:'',d:'',id:''},open:false};
const JTAGS=['Win','Lesson','Gratitude','Stress','Idea','Craving','Health','Work','Mistake','Plan'];
const JPROMPTS=['What is one thing I did today that my future self will thank me for?','What got in my way today, and what is the smallest fix?','Which habit felt easiest today, and why?','When did I feel the urge to quit, and what did I do instead?','What am I proud of this week?','What did I learn about myself today?','If today were a rep for the person I am becoming, how did it go?','What one small thing would make tomorrow easier?','Which goal needs more care right now?','What am I grateful for right now?'];
let JPI=0;
const wc=s=>(String(s).trim().match(/\S+/g)||[]).length;
function jItems(){const L=[];(S.journal||[]).forEach(j=>L.push({src:'entry',id:j.id,d:j.d,t:j.t,title:j.title,tx:j.tx,mood:j.mood,energy:j.energy,tags:j.tags||[],goal:j.goal,pin:j.pin}));
 Object.keys(S.daily).forEach(k=>{const d=S.daily[k];if(d&&(d.note||d.mood||d.sleep!=null&&d.sleep!==''))L.push({src:'daily',d:k,title:'Daily check-in',tx:[d.note,d.energy?'Energy '+d.energy+'/5':'',d.sleep!=null&&d.sleep!==''?'Sleep '+d.sleep+'h':''].filter(Boolean).join('  |  '),mood:d.mood||0,tags:[]})});
 S.goals.forEach(g=>{(g.reviews||[]).forEach(r=>L.push({src:'review',d:r.d.slice(0,10),title:'Review: '+g.name,tx:[r.w&&'Worked: '+r.w,r.b&&'Got in the way: '+r.b,r.a&&'Change: '+r.a].filter(Boolean).join('\n'),goal:g.id,tags:[]}));Object.keys(g.logs).forEach(k=>{const l=g.logs[k];if(l&&l.note)L.push({src:'note',d:k,title:g.name,tx:l.note,goal:g.id,tags:[]})})});
 return L}
function jStats(){const all=jItems(),days=new Set(all.map(x=>x.d)),t=todayKey();let st=0;for(let i=0;i<400;i++){const k=addD(t,-i);if(days.has(k))st++;else if(i>0)break}
 const moods=moodSeries('mood',30).concat((S.journal||[]).filter(j=>j.mood&&j.d>=addD(t,-29)).map(j=>j.mood)),tg={};(S.journal||[]).forEach(j=>(j.tags||[]).forEach(x=>tg[x]=(tg[x]||0)+1));
 return{entries:(S.journal||[]).length,streak:st,mood:moods.length?avg(moods):null,words:sum((S.journal||[]).map(j=>wc(j.tx))),tags:Object.entries(tg).sort((a,b)=>b[1]-a[1]).slice(0,5)}}
/* the editor, timeline, month, moments and growth views live in 84dz_jour2.js */
