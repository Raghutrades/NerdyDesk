/* ===== reminders, notifications, calendar export ===== */
let SWREG=null,DEFERRED=null;
function swInit(){if(!('serviceWorker' in navigator)||!/^https?:$/.test(location.protocol))return;
 navigator.serviceWorker.register('sw.js').then(r=>{SWREG=r}).catch(()=>{});navigator.serviceWorker.ready.then(r=>{SWREG=r}).catch(()=>{})}
const notifPerm=()=>('Notification' in window)?Notification.permission:'unsupported';
function sysNotify(title,body,o){o=o||{};if(notifPerm()!=='granted')return;
 const opts={body,tag:o.tag,icon:'icons/nos7-icon-192.png',badge:'icons/nos7-badge-96.png',vibrate:[120,60,120],renotify:!!o.tag,data:{goal:o.goal||'',url:'./'}};
 if(o.actions&&SWREG)opts.actions=o.actions;
 try{if(SWREG&&SWREG.showNotification)SWREG.showNotification(title,opts);else new Notification(title,opts)}catch(e){try{new Notification(title,{body,icon:'icon-192.png'})}catch(x){}}}
function notify(title,body,o){o=o||{};toast(title+(body?': '+body:''));sfx('notify');sysNotify(title,body,o)}
function reminderList(){const out=[];
 S.goals.forEach(g=>{if(g.remind&&g.remind.on&&!g.paused)(g.remind.times||[]).forEach((t,i)=>out.push({id:'g:'+g.id+':'+i,time:t,days:g.remind.days&&g.remind.days.length?g.remind.days:null,goal:g.id,msg:'',kind:'goal'}))});
 S.reminders.forEach(r=>{if(r.on)out.push({id:'c:'+r.id,time:r.time,days:r.days,goal:r.goal,msg:r.msg,kind:'custom'})});return out}
function reminderBody(g,r){if(r.msg)return r.msg;if(!g)return 'Time to fire your neuron.';if(isB(g))return g.cue||'Stay strong. Every clean day weakens the old pathway.';
 const w=g.win?'Planned for '+g.win[0]+' to '+g.win[1]+'. ':'';return w+(g.cue||'Time to fire this neuron.')}
function goalActions(g){return g?[{action:'done',title:isB(g)?'Clean day':'Mark done'},{action:'open',title:'Open'}]:[{action:'open',title:'Open'}]}
function relevant(r,g,k){const n=NOW();if(r.days&&!r.days.includes(n.getDay()))return false;
 if(g){const st=dueState(g,k);if(['done','paused','ended','notstarted','slip','skipped'].includes(st.s))return false;if(r.kind==='goal'&&!r.days&&!['due','optional'].includes(st.s))return false}return true}
function checkAlerts(){const n=NOW(),k=dayKey(n),t=hm(n),Fd=S.set.fired;if(Fd.day!==k){Fd.day=k;Fd.m={}}let ch=false;const nm=mins(t);
 reminderList().forEach(r=>{const g=r.goal?gById(r.goal):null;
  if(r.time===t&&!Fd.m[r.id]){if(!relevant(r,g,k))return;Fd.m[r.id]=nm;ch=true;
   notify(g?g.name:'NeuroOrbitSynapse',reminderBody(g,r),{tag:r.id,goal:g?g.id:'',actions:goalActions(g)})}
  else if(Fd.m[r.id]&&S.set.notif.escalate&&g&&g.priority==='must'){const el=nm-Fd.m[r.id];
   if((el===30||el===60)&&!Fd.m[r.id+':e'+el]&&relevant(r,g,k)){Fd.m[r.id+':e'+el]=1;ch=true;notify('Still pending: '+g.name,'This one is marked Must. Do it now, even a small version.',{tag:r.id,goal:g.id,actions:goalActions(g)})}}});
 const N=S.set.notif;
 if(N.risk&&t===N.riskTime&&!Fd.m.risk){Fd.m.risk=1;ch=true;const p=S.goals.filter(g=>{const st=dueState(g,k);return st.s==='due'&&streakInfo(g).n>=2});if(p.length)notify('Streak at risk',p.map(g=>g.name+' ('+streakInfo(g).n+')').join(', '),{tag:'risk'})}
 if(N.wrap&&t===N.wrapTime&&!Fd.m.wrap){Fd.m.wrap=1;ch=true;const it=todayItems(k).filter(x=>x.st.s==='done'||x.st.s==='due');notify('Daily wrap-up',it.filter(x=>x.st.s==='done').length+' of '+it.length+' goals fired today.'+(n.getDay()===0?' Sunday: write your weekly review.':''),{tag:'wrap'})}
 if(t>='08:00'&&!Fd.m.starts){Fd.m.starts=1;ch=true;const st=S.goals.filter(g=>g.start===k&&!g.paused);if(st.length)notify('Starting today',st.map(g=>g.name).join(', '),{tag:'starts'})}
 if(N.round&&t>='09:00'&&!Fd.m.round){Fd.m.round=1;ch=true;const e=S.goals.filter(g=>{const d=diffD(k,g.end);return !g.paused&&d>=0&&d<=3&&g.start<=k});if(e.length)notify('Round ending soon',e.map(g=>g.name+' ('+diffD(k,g.end)+' days left)').join(', '),{tag:'round'})}
 if(ch)save()}
function catchUp(){if(!S.set.notif.catchup)return;const n=NOW(),k=dayKey(n),nm=mins(hm(n)),Fd=S.set.fired;if(Fd.day!==k){Fd.day=k;Fd.m={}}const miss=[];
 reminderList().forEach(r=>{const g=r.goal?gById(r.goal):null,rm=mins(r.time);if(Fd.m[r.id])return;if(rm<nm&&nm-rm<=240&&relevant(r,g,k)){Fd.m[r.id]=-1;miss.push((g?g.name:'Reminder')+' at '+r.time)}});
 if(miss.length){toast('Missed while away: '+miss.join(', '));save()}}
/* calendar export */
const icsD=k=>k.replace(/-/g,'');
function firstOn(g,from,days){let k=from>g.start?from:g.start;for(let i=0;i<14;i++){if(!days||days.includes(dow(k)))return k;k=addD(k,1)}return from}
function ruleFor(g,days){const e=g?g.end:null;let r='FREQ=DAILY';
 if(g&&!isB(g)){const s=g.sched;if(s.t==='days'&&s.days.length&&s.days.length<7)r='FREQ=WEEKLY;BYDAY='+s.days.map(d=>['SU','MO','TU','WE','TH','FR','SA'][d]).join(',');else if(s.t==='every'&&s.every>1)r='FREQ=DAILY;INTERVAL='+s.every}
 if(days&&days.length&&days.length<7)r='FREQ=WEEKLY;BYDAY='+days.map(d=>['SU','MO','TU','WE','TH','FR','SA'][d]).join(',');
 return{r,e}}
function remEvents(){const L=[];reminderList().forEach(r=>{const g=r.goal?gById(r.goal):null,days=r.days||(g&&!isB(g)&&g.sched.t==='days'?g.sched.days:null),ru=ruleFor(g,r.kind==='custom'?r.days:null);
 const start=firstOn(g||{start:todayKey()},todayKey(),days||(r.kind==='custom'?r.days:null));
 L.push({id:r.id,title:(g?g.name:'NeuroOrbitSynapse'),body:reminderBody(g,r),time:r.time,start,rule:ru.r,until:ru.e})});return L}
const icsFold=l=>{if(l.length<=74)return l;let o='',s=l;while(s.length>74){o+=s.slice(0,74)+'\r\n ';s=s.slice(74)}return o+s};
const icsEsc=s=>String(s).replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\n/g,'\\n');
function buildICS(only){const L=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//NeuroOrbitSynapse//EN','CALSCALE:GREGORIAN','X-WR-CALNAME:NeuroOrbitSynapse'],stamp=icsD(todayKey())+'T000000';
 remEvents().filter(e=>!only||e.id.startsWith('g:'+only)).forEach(e=>{const hh=e.time.replace(':','')+'00',t2=pad(Math.min(23,+e.time.slice(0,2)))+e.time.slice(3,5)+'00';
  L.push('BEGIN:VEVENT','UID:'+e.id.replace(/[^\w]/g,'')+'@neuroorbitsynapse','DTSTAMP:'+stamp,'DTSTART:'+icsD(e.start)+'T'+hh,'DURATION:PT15M','RRULE:'+e.rule+(e.until?';UNTIL='+icsD(e.until)+'T235959':''),'SUMMARY:'+icsEsc(e.title),'DESCRIPTION:'+icsEsc(e.body),'BEGIN:VALARM','TRIGGER:PT0M','ACTION:DISPLAY','DESCRIPTION:'+icsEsc(e.title),'END:VALARM','END:VEVENT')});
 S.goals.filter(g=>!only||g.id===only).forEach(g=>{if(g.start>todayKey())L.push('BEGIN:VEVENT','UID:start'+g.id+'@neuroorbitsynapse','DTSTAMP:'+stamp,'DTSTART;VALUE=DATE:'+icsD(g.start),'SUMMARY:'+icsEsc('Starts: '+g.name),'END:VEVENT');
  L.push('BEGIN:VEVENT','UID:end'+g.id+'@neuroorbitsynapse','DTSTAMP:'+stamp,'DTSTART;VALUE=DATE:'+icsD(g.end),'SUMMARY:'+icsEsc('Round ends: '+g.name),'END:VEVENT')});
 L.push('END:VCALENDAR');return L.map(icsFold).join('\r\n')}
function gcalLink(e){const d=icsD(e.start),h=e.time.replace(':','')+'00',h2=pad(Math.min(23,+e.time.slice(0,2)))+e.time.slice(3,5)+'00';
 return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text='+encodeURIComponent(e.title)+'&details='+encodeURIComponent(e.body)+'&dates='+d+'T'+h+'/'+d+'T'+h2+'&recur='+encodeURIComponent('RRULE:'+e.rule+(e.until?';UNTIL='+icsD(e.until):''))}

