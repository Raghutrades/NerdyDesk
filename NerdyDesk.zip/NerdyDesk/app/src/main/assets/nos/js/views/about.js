/* ===== v5 About: same content, folded into tidy sections ===== */
function renderAbout(){renderAboutOld();const r=$('#aboutc'),kids=[...r.children],out=[];let cur=null;
 const det=(t,open)=>{const d=document.createElement('details');d.className='gsec';if(open)d.open=true;d.innerHTML=`<summary><span><b>${esc(t)}</b></span></summary><div class="abin"></div>`;return d};
 kids.forEach(c=>{if(c.classList.contains('row')&&c.querySelector('h2')){c.remove();return}
  if(c.matches('h3.gh')){cur=det(c.textContent,false);out.push(cur);c.remove();return}
  const h=c.matches('.card')&&c.querySelector(':scope>h3');
  if(c.classList.contains('abhero')||!c.parentNode){cur=null;out.push(c);return}
  if(h&&!cur){const d=det(h.textContent,out.length<2);h.remove();c.style.cssText='border:0;background:none;padding:0;margin:0';d.querySelector('.abin').appendChild(c);out.push(d);return}
  if(cur){const w=c.querySelector&&c.matches('.card')&&c.querySelector(':scope>h3');cur.querySelector('.abin').appendChild(c);return}
  out.push(c)});
 r.innerHTML='<h1 class="pgt">About</h1>';out.forEach(x=>r.appendChild(x));r.querySelectorAll('.gsec').forEach(d=>d.style.marginTop='10px')}
