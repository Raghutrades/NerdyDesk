/* ===== Board view (the main visual): a stick man in front of a giant chalkboard. Build goals on the left, quit goals on the right. New goals are written by hand; tap a goal to brainstorm it. ===== */
const WL={w:{},bar:{},cnt:{},ck:{},hold:{},lay:{},lw:{},foc:null,q:[],task:null,dust:[],init:false,nt:'build',man:{x:0,d:1,ph:0,v:0,pt:2,sub:'stand',tx:null,T:{},lift:0,cheer:0}};
const WL_FONT='"Patrick Hand","Bricolage Grotesque",system-ui,sans-serif';try{document.fonts&&document.fonts.load('20px "Patrick Hand"')}catch(e){}
function wallReplay(g){const ids=g?[g.id]:ORDER.map(x=>x.id);ids.forEach(id=>{WL.w[id]=0;WL.bar[id]=0;WL.ck[id]=0;WL.hold[id]=true;if(!WL.q.some(x=>x.id===id))WL.q.push({type:'write',id})});WL.task=null}
function wallBarTarget(g){const real=clamp(gStats(g).prog||0,0,1);return PV.m==='start'?0:PV.m==='done'?1:RP.on?real*rpP():real}
function drawWall(now,dt){const t=now*.001,rd=reduced(),M=WL.man;BHIT=[];mapwrap.classList.toggle('wfoc',!!WL.foc);
 const gs=ORDER.slice(0,24),n=gs.length,B=gs.filter(g=>!isB(g)&&!g.tk),Q=gs.filter(isB),T=gs.filter(g=>!isB(g)&&g.tk);
 /* wall and floor */
 const bx=W*.02,bw=W*.96,by=H*.075,bh=H*.68,wy=by+bh+H*.012;
 let gr=cx.createLinearGradient(0,0,0,wy);gr.addColorStop(0,'rgba(58,64,80,.55)');gr.addColorStop(1,'rgba(34,38,50,.55)');cx.fillStyle=gr;cx.fillRect(0,0,W,wy);
 gr=cx.createLinearGradient(0,wy,0,H);gr.addColorStop(0,'#4a3624');gr.addColorStop(1,'#2a1d13');cx.fillStyle=gr;cx.fillRect(0,wy,W,H-wy);
 cx.strokeStyle='rgba(0,0,0,.35)';cx.lineWidth=1;for(let i=-6;i<=14;i++){cx.beginPath();cx.moveTo(W/2+(i-4)*W*.07,wy);cx.lineTo(W/2+(i-4)*W*.22,H);cx.stroke()}
 for(let j=1;j<5;j++){const y=wy+(H-wy)*(j/5)**1.6;cx.beginPath();cx.moveTo(0,y);cx.lineTo(W,y);cx.stroke()}
 /* the board */
 cx.save();cx.shadowColor='rgba(0,0,0,.6)';cx.shadowBlur=22;cx.fillStyle='#5b3d22';cx.fillRect(bx-6,by-6,bw+12,bh+12);cx.restore();
 gr=cx.createLinearGradient(0,by,0,by+bh);gr.addColorStop(0,'#1d2a27');gr.addColorStop(1,'#141d1b');cx.fillStyle=gr;cx.fillRect(bx,by,bw,bh);
 cx.fillStyle='#7a5530';cx.fillRect(bx-6,by+bh,bw+12,6);cx.fillStyle='rgba(255,255,255,.7)';cx.fillRect(bx+bw*.62,by+bh-2,bw*.08,3);cx.fillRect(bx+bw*.74,by+bh-3,bw*.04,4);
 const CH='rgba(246,248,238,.93)',fa=WL.foc?WL.foc.t:0;cx.globalAlpha=1-fa;
 /* two halves */
 const hw=bw*.5,ix=bx,iy=by+bh*.12,ih=bh*.86;
 const i0=by+bh*.12,i1=by+bh*.985,sp2=(i1-i0);const secs=[{t:'build',list:B,x:ix,w:hw,y0:i0,h:sp2,hy:by+bh*.075,lab:'Build',col:CH},{t:'quit',list:Q,x:ix+hw,w:hw,y0:i0,h:sp2*.44,hy:by+bh*.075,lab:'Quit',col:'rgba(255,140,160,.95)'},{t:'task',list:T,x:ix+hw,w:hw,y0:i0+sp2*.55,h:sp2*.45,hy:i0+sp2*.5,lab:'Daily tasks',col:'rgba(140,200,255,.95)'}];
secs.forEach(sc=>{sc.list=sc.list.slice().sort((p,q)=>(dueState(p).s==='done')-(dueState(q).s==='done'))});
 const cell={},adds=[];let fsMin=22;
 secs.forEach(sc=>{const cnt=sc.list.length+1,cols=cnt>10?2:1,rows=Math.ceil(cnt/cols),cw=(sc.w-bw*.03)/cols,ch=Math.min(sc.h/rows,bh*.2);sc.fs=clamp(Math.min(ch*.3,cw*.1,19),8,19);fsMin=Math.min(fsMin,sc.fs)});
 secs.forEach(sc=>{const cnt=sc.list.length+1,cols=cnt>10?2:1,rows=Math.ceil(cnt/cols),cw=(sc.w-bw*.03)/cols,ch=Math.min(sc.h/rows,bh*.2),fs=fsMin;
  cx.font='400 '+fs+'px '+WL_FONT;
  for(let i=0;i<cnt;i++){const col=Math.floor(i/rows),row=i%rows,x=sc.x+bw*.012+col*cw,y=sc.y0+row*ch;
   if(i===sc.list.length){adds.push({t:sc.t,x,y,w:cw,h:ch,fs});continue}
   const g=sc.list[i],nx=x+fs*1.9,maxW=cw-fs*1.9-fs*3.2;let nm=g.name,tw=cx.measureText(nm).width;while(nm.length>3&&tw>maxW){nm=nm.slice(0,-2);tw=cx.measureText(nm+'…').width;if(tw<=maxW){nm+='…';break}}tw=cx.measureText(nm).width;
   {WL.sy=WL.sy||{};let yy=WL.sy[g.id];if(yy==null||rd)yy=y;else yy+=(y-yy)*Math.min(1,dt*5);if(Math.abs(yy-y)<.3)yy=y;WL.sy[g.id]=yy;const dy=yy-y;
   cell[g.id]={g,i,x,y:y+dy,w:cw,h:ch,fs,nx,nm,tw,by:y+dy+ch*.4,barY:y+dy+ch*.58,barW:cw-fs*1.1}}}});
 /* headings, divider, counter */
 const hf=clamp(bh*.065,12,22);cx.font='400 '+hf+'px '+WL_FONT;cx.textAlign='left';
 secs.forEach(sc=>{const hh=sc.t==='build'?hf:hf*.82;cx.font='400 '+hh+'px '+WL_FONT;cx.fillStyle=sc.col;cx.fillText(sc.lab+(sc.list.length?' · '+sc.list.length:''),sc.x+bw*.03,sc.hy);cx.strokeStyle=sc.col.replace(/[\d.]+\)$/,'.5)');cx.lineWidth=1.6;cx.beginPath();cx.moveTo(sc.x+bw*.03,sc.hy+bh*.02);cx.quadraticCurveTo(sc.x+sc.w*.5,sc.hy+bh*.033,sc.x+sc.w-bw*.03,sc.hy+bh*.018);cx.stroke()});
 cx.setLineDash([3,5]);cx.strokeStyle='rgba(246,248,238,.22)';cx.beginPath();cx.moveTo(ix+hw,by+bh*.05);cx.lineTo(ix+hw,by+bh*.97);cx.stroke();cx.setLineDash([]);
 const done0=gs.filter(g=>dueState(g).s==='done').length;cx.textAlign='right';cx.fillStyle='rgba(246,248,238,.55)';cx.font='400 '+Math.max(9,hf*.62)+'px '+WL_FONT;cx.fillText(n?'today '+done0+'/'+n:'',ix+bw-bw*.02,by+bh*.03+hf*.3);
 /* first run: everything already on the board; later new goals get written live */
 if(!WL.init){gs.forEach(g=>{WL.w[g.id]=1;WL.bar[g.id]=wallBarTarget(g);WL.ck[g.id]=dueState(g).s==='done'?1:0;WL.cnt[g.id]=doneCount(g)});WL.init=true;M.x=W*.5}
 gs.forEach(g=>{if(WL.w[g.id]==null){WL.w[g.id]=0;WL.bar[g.id]=0;WL.ck[g.id]=0;WL.hold[g.id]=true;WL.cnt[g.id]=doneCount(g);WL.q.push({type:'write',id:g.id})}
  else{const c=doneCount(g);if(c>WL.cnt[g.id]&&WL.w[g.id]>=1&&!WL.q.some(x=>x.id===g.id&&x.type!=='leaf')&&!(WL.task&&WL.task.id===g.id&&WL.task.type!=='leaf')){WL.q.push({type:'tick',id:g.id});WL.hold[g.id]=true;if(dueState(g).s==='done')WL.ck[g.id]=0};WL.cnt[g.id]=c}});
 WL.q=WL.q.filter(x=>gs.some(g=>g.id===x.id));
/* the man's work */
 const mh=clamp(H*.28,80,200),u=mh/10,gy=H*.93,reachTop=gy-10.5*u,deskX=W*.16,seatBase=deskX+.2*u,foc=WL.foc;
 if(M.cx==null)M.cx=seatBase;M.cx=clamp(M.cx,W*.08,W*.5);
 const taskCell=p=>p.type==='leaf'?WL.lay[p.key]:cell[p.id];
 if(!WL.task&&WL.q.length){const pool=foc?WL.q.filter(x=>x.type==='leaf'):WL.q;
  if(pool.length){let bi=0,bd=1e9;pool.forEach((p,i)=>{const cc=taskCell(p),dd=cc?Math.abs((cc.nx!=null?cc.nx:cc.x)-M.x):0;if(dd<bd){bd=dd;bi=i}});const p=pool[bi];WL.q.splice(WL.q.indexOf(p),1);WL.task=Object.assign({stage:'walk',t:0},p);M.sit=false;M.sitT=0;M.cheer=0}}
 const TS=1+Math.min(2.4,WL.q.length*.6);
 let task=WL.task,pose='stand',hx=0,hy=0,wantX=null,moving=false;const sp=mh*1.0*(task?TS:1);
 /* walking has hysteresis so the pose never flickers between walk and write */
 const mv=(tx,s2,th,keepD)=>{const dx=tx-M.x,ad=Math.abs(dx);if(ad<2||(!M.wk&&ad<(th||0))){M.v=0;M.wk=false;return false}M.wk=true;if(!keepD)M.d=Math.sign(dx);const tv=Math.sign(dx)*Math.min(s2,ad*4+8);M.v=(M.v||0)+(tv-(M.v||0))*Math.min(1,dt*6);let st=M.v*dt;if(Math.abs(st)>ad)st=dx;M.x+=st;M.ph+=Math.abs(st)/(1.25*u)*3.1416;return true};
 let liftT=0;const cl=x=>clamp(x,W*.08,W*.92);
 const dust=(x,y,r)=>{if(!rd&&Math.random()<dt*r)WL.dust.push({x,y,vx:(Math.random()-.5)*14,vy:10+Math.random()*20,l:1})};
 const hand=(x,y,fs2,k)=>{/* lettering: the hand never rests, it loops and flicks like real writing */hx=x+Math.sin(t*19)*fs2*.2*k+Math.sin(t*31)*fs2*.08*k;hy=y+(Math.abs(Math.sin(t*11))-.45)*fs2*.45*k+Math.sin(t*23)*fs2*.12*k};
 const stepTo=(x2,y2)=>{wantX=cl(x2-2*u);M.d=1;moving=mv(wantX,sp*.7,1.4*u,true);pose=moving?'walk':'write';liftT=Math.max(0,reachTop-y2+.8*u)};
 if(task){const lc=task.type==='leaf'?WL.lay[task.key]:null,c=task.type==='leaf'?null:cell[task.id];
  if(!c&&!lc){task.wait=(task.wait||0)+dt;if(task.wait>.7||!foc&&task.type==='leaf'){if(task.type==='leaf')WL.lw[task.key]=1;WL.task=null;task=null}}else{
  const tx0=c?c.nx:lc.x;
  if(task.stage==='walk'){wantX=cl(tx0-1.8*u);moving=mv(wantX,sp,0);pose=moving?'walk':'stand';if(rd)M.x=wantX;if(!moving||rd){task.stage=task.type==='write'?'text':task.type==='leaf'?'ltext':(dueState(c.g).s==='done'?'check':'bar');task.t=0;M.d=1;if(task.stage==='check')WL.ck[task.id]=0}}
  else if(task.stage==='text'){const dur=rd?.01:(1+c.nm.length*.15)/Math.sqrt(TS);WL.w[task.id]=Math.min(1,(WL.w[task.id]||0)+dt/dur);hand(tx0+c.tw*WL.w[task.id],c.by-c.fs*.3,c.fs,1);stepTo(hx,hy);dust(hx,hy,14);if(WL.w[task.id]>=1){task.stage='bar';task.t=0;sfx('tick')}}
  else if(task.stage==='ltext'){const tot=lc.n||1,dur=rd?.01:(.8+tot*.05)/Math.sqrt(TS);WL.lw[task.key]=Math.min(1,(WL.lw[task.key]||0)+dt/dur);let acc=0,tg=WL.lw[task.key]*tot,ln=lc.lines[0];for(const l of lc.lines){ln=l;if(acc+l.s.length>=tg)break;acc+=l.s.length}const fr=clamp((tg-acc)/Math.max(1,ln.s.length),0,1);hand(ln.x+ln.w*fr,ln.y-lc.fs*.3,lc.fs,1);stepTo(hx,hy);dust(hx,hy,14);
   if(WL.lw[task.key]>=1){WL.task=null;WL.hold[task.id]=false;if(!rd){M.sub='look';M.pt=2.5;M.tx=null}}}
  else if(task.stage==='check'){task.t+=dt;const dur=rd?.01:.85/TS,p=clamp(task.t/dur,0,1);WL.ck[task.id]=p;const s2=c.fs*.95,P=[[c.x+c.fs*.7,c.by-s2*.4],[c.x+c.fs*1.05,c.by-s2*.05],[c.x+c.fs*1.6,c.by-s2*1.15]],sg=p<.35?[P[0],P[1],p/.35]:[P[1],P[2],(p-.35)/.65];
   hand(sg[0][0]+(sg[1][0]-sg[0][0])*sg[2],sg[0][1]+(sg[1][1]-sg[0][1])*sg[2],c.fs,.5);stepTo(hx,hy);dust(hx,hy,12);if(p>=1){task.stage='bar';task.t=0;sfx('tick')}}
  else if(task.stage==='bar'){task.t+=dt;const tg=wallBarTarget(c.g),cur=WL.bar[task.id]||0,dur=rd?.01:1.7/TS;if(task.type==='write'||task.t<dur)WL.bar[task.id]=cur+(tg-cur)*Math.min(1,dt*2.4*TS);
   const bh2=c.fs*.62,tri=.5+.5*Math.sin(t*10*(1+TS*.15)),ex=c.x+c.fs*.6+c.barW*(WL.bar[task.id]||0);hx=ex+bh2*(tri-.5)*1.4;hy=c.barY+bh2*(1-tri)+c.fs*.05;stepTo(hx,hy);dust(hx,hy,12);
   if(task.t>dur){WL.task=null;WL.hold[task.id]=false;if(!rd){M.sub=task.type==='write'?'look':'cheer';M.pt=task.type==='write'?3:1.6;M.tx=cl(c.x+c.w*.5+(c.x+c.w*.5<W*.5?1:-1)*W*.22);if(M.sub==='cheer')M.cheer=1.6}}}}}
 if(!WL.task&&n&&done0===n&&WL.danced!==todayKey()&&!foc){WL.danced=todayKey();M.sit=false;M.sub='dance';M.pt=8;M.cheer=0;M.tx=null}
 if(!WL.task&&M.sit){/* sits at the desk in front of the board: types, thinks, sips, rolls the chair around */
  M.sitT-=dt;M.pt-=dt;pose=M.ss||'sit-type';M.d=1;
  if(M.ss==='roll')pose='sit-think';
  if(M.pt<=0){const pk=['sit-type','sit-type','sit-think','sit-drink','sit-drink','roll','roll','sit-write','sit-think'];M.ss=pk[Math.floor(Math.random()*pk.length)];M.pt=2.8+Math.random()*2.6;M.rt=M.ss==='roll'?seatBase+(Math.random()<.5?-1:1)*(1.5+Math.random()*3.5)*u:seatBase+(Math.random()-.5)*.8*u;M.rt=clamp(M.rt,W*.08,W*.5)}
  if(M.rt!=null){const dx=M.rt-M.cx,spd=u*(M.ss==='roll'?2.0:.7),st=Math.sign(dx)*Math.min(Math.abs(dx),spd*dt);M.cx+=st;M.wh=(M.wh||0)+st/(.35*u)}
  M.x=M.cx;
  if(M.sitT<=0){M.sit=false;M.sub='stretch';M.pt=2.5}}
 else if(!WL.task){/* brainstorming idle life in front of the board */
  M.pt-=dt;if(M.sub==='cheer'){M.cheer-=dt;pose='cheer';if(M.cheer<=0)M.pt=0}
  else if(M.sub==='sitdown'){moving=mv(M.cx,sp*.6,0);pose=moving?'walk':'stand';if(!moving){M.sit=true;M.x=M.cx;M.sitT=11+Math.random()*8;M.ss='sit-type';M.pt=2;M.rt=seatBase;M.sub='stand';M.d=1}}
  else if(M.sub==='pace'||M.sub==='review'){moving=mv(M.tx,sp*.55,0);pose=moving?'walk':'stand';if(!moving&&M.sub==='review'){const c=cell[M.rid];if(c&&!foc){hx=c.nx+c.tw*.5;hy=Math.max(c.by,reachTop+u);pose='point';M.d=hx>M.x?1:-1}}}
  else if(M.tx!=null&&Math.abs(M.tx-M.x)>3&&M.sub==='look'&&M.pt>1.5){moving=mv(M.tx,sp*.6,0);pose=moving?'walk':'look'}
  else pose=M.sub==='stand'?'stand':M.sub;
  if(M.pt<=0&&!rd){const pk=foc?['think','look','scratch','stretch','pace','sip','stand','think','sitdown','sitdown']:['think','look','scratch','stretch','pace','pace','review','sip','stand','think','sitdown','sitdown','dance','wave','dance'];let sub=pk[Math.floor(Math.random()*pk.length)];M.cheer=0;M.d=Math.random()<.5?-1:1;
   if(sub==='review'&&!n)sub='think';M.sub=sub;M.pt=sub==='sitdown'?99:3.5+Math.random()*3.5;
   if(sub==='pace')M.tx=cl(M.x+(Math.random()<.5?-1:1)*W*(.15+Math.random()*.2));
   if(sub==='review'){const c=gs[Math.floor(Math.random()*n)];M.rid=c.id;const cc=cell[c.id];M.tx=cl(cc.nx+cc.tw*.5-3*u*(Math.random()<.5?1:-1))}}}
 M.lift+=((WL.task?liftT:0)-M.lift)*Math.min(1,dt*4);M.x=M.sit?M.cx:cl(M.x);
 /* bars and ticks follow the real value, except goals still waiting for the man to write them */
 Object.keys(WL.hold).forEach(id=>{if(!(WL.task&&WL.task.id===id)&&!WL.q.some(x=>x.id===id))delete WL.hold[id]});
 gs.forEach(g=>{if(WL.hold[g.id])return;const dn=dueState(g).s==='done';WL.ck[g.id]=dn?1:0;if((WL.w[g.id]||0)<1)return;const tg=wallBarTarget(g),cur=WL.bar[g.id]||0;WL.bar[g.id]=rd||PV.m?tg:cur+(tg-cur)*Math.min(1,dt*1.8)});

 /* draw the chalk */
 gs.forEach(g=>{const c=cell[g.id],fs=c.fs,w=WL.w[g.id]||0,pr=clamp(WL.bar[g.id]||0,0,1),done=dueState(g).s==='done',rgb=rgbOf(g.color);
  const x=c.x,y=c.y;cx.save();cx.lineCap='round';cx.lineJoin='round';
  if(false){cx.fillStyle='rgba(255,255,255,.06)';cx.fillRect(x,y+2,c.w-2,c.h-4)}
  if(w>0){cx.strokeStyle=rgba(g.color,.95);cx.lineWidth=1.8;const s2=fs*.95;cx.beginPath();cx.moveTo(x+fs*.5,c.by-s2*.85);cx.lineTo(x+fs*.5+s2,c.by-s2*.9);cx.lineTo(x+fs*.5+s2*1.02,c.by+s2*.1);cx.lineTo(x+fs*.5-.5,c.by+s2*.05);cx.closePath();cx.stroke();
   const ckp=WL.ck[g.id]==null?(done?1:0):WL.ck[g.id];if(ckp>0){cx.strokeStyle='rgba(120,255,170,.95)';cx.lineWidth=2.2;const P=[[x+fs*.7,c.by-s2*.4],[x+fs*1.05,c.by-s2*.05],[x+fs*1.6,c.by-s2*1.15]];cx.beginPath();cx.moveTo(P[0][0],P[0][1]);const a1=Math.min(1,ckp/.35);cx.lineTo(P[0][0]+(P[1][0]-P[0][0])*a1,P[0][1]+(P[1][1]-P[0][1])*a1);if(ckp>.35){const b1=(ckp-.35)/.65;cx.lineTo(P[1][0]+(P[2][0]-P[1][0])*b1,P[1][1]+(P[2][1]-P[1][1])*b1)}cx.stroke()}
   cx.font='400 '+fs+'px '+WL_FONT;cx.textAlign='left';cx.save();cx.beginPath();cx.rect(c.nx-2,c.by-fs*1.2,c.tw*w+4,fs*1.8);cx.clip();cx.fillStyle=CH;cx.fillText(c.nm,c.nx,c.by);cx.fillText(c.nm,c.nx+.5,c.by+.4);cx.restore()}
  if(w>=1||(WL.task&&WL.task.id===g.id&&WL.task.stage==='bar')){const bx2=x+fs*.6,bw2=c.barW,bh2=fs*.62;cx.strokeStyle='rgba(246,248,238,.6)';cx.lineWidth=1.3;cx.strokeRect(bx2,c.barY,bw2,bh2);
   cx.strokeStyle=rgba(g.color,.95);cx.lineWidth=1.6;const fw=bw2*pr;cx.save();cx.beginPath();cx.rect(bx2,c.barY,fw,bh2);cx.clip();for(let hxx=bx2-bh2;hxx<bx2+fw+bh2;hxx+=5){cx.beginPath();cx.moveTo(hxx,c.barY+bh2);cx.lineTo(hxx+bh2,c.barY);cx.stroke()}cx.restore();
   cx.fillStyle='rgba(246,248,238,.78)';cx.font='400 '+Math.max(8,fs*.62)+'px '+WL_FONT;cx.textAlign='right';cx.fillText((g.win&&dueState(g).s!=='done'?g.win[0]+'  ':'')+(PV.m==='start'?0:PV.m==='done'?lenDays(g):Math.round(pr*lenDays(g)))+'/'+lenDays(g),x+c.w-fs*.4,c.by);
   if(fa<.5)BHIT.push({g,x:c.x,w:c.w,y0:c.y,y1:c.y+c.h,wall:true,d0:g.start,d1:g.end})}
  cx.restore()});
 /* "+ add" spots */
 adds.forEach(a=>{const fs=a.fs,q=a.t==='quit';cx.save();cx.lineCap='round';cx.setLineDash([4,5]);cx.strokeStyle=q?'rgba(255,140,160,.55)':'rgba(246,248,238,.5)';cx.lineWidth=1.4;const rx=a.x+fs*.5,ry=a.y+a.h*.22,rw=Math.min(a.w-fs,fs*9),rh=Math.min(a.h*.56,fs*2.1);cx.strokeRect(rx,ry,rw,rh);cx.setLineDash([]);
  cx.fillStyle=q?'rgba(255,170,185,.9)':'rgba(246,248,238,.82)';cx.font='400 '+fs*1.05+'px '+WL_FONT;cx.textAlign='left';cx.fillText('+ new '+(q?'quit':a.t==='task'?'task':'goal'),rx+fs*.6,ry+rh*.5+fs*.35);cx.restore();
  if(fa<.5)BHIT.push({add:a.t,g:null,x:a.x,w:a.w,y0:a.y,y1:a.y+a.h,wall:true})});cx.globalAlpha=1;
 if(WL.foc)wallFocusDraw(now,dt,t,rd,bx,by,bw,bh,CH,u);
 if(!n){cx.fillStyle='rgba(246,248,238,.5)';cx.font='400 '+clamp(bh*.05,11,16)+'px '+WL_FONT;cx.textAlign='center';cx.fillText('Tap "+ new goal" and he will write it up',ix+bw/2,by+bh*.62)}
 /* chalk dust */
 WL.dust=WL.dust.filter(p=>(p.l-=dt*1.1)>0);WL.dust.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;cx.fillStyle='rgba(246,248,238,'+p.l*.7+')';cx.fillRect(p.x,p.y,1.6,1.6)});
 /* stool or rolling ladder under his feet, then the man */
 const lf=M.lift,fy=gy-lf;
 if(lf>2){const hw2=lf>mh*.5?3.6*u:2.6*u;if(lf>mh*.5){cx.strokeStyle='#c79a5c';cx.lineWidth=Math.max(2,u*.3);cx.lineCap='round';[-1,1].forEach(sd=>{cx.beginPath();cx.moveTo(M.x+sd*hw2*.55,fy);cx.lineTo(M.x+sd*hw2,gy);cx.stroke()});cx.lineWidth=Math.max(1.5,u*.2);for(let k=1;k<=Math.floor(lf/(1.6*u));k++){const yy=gy-k*1.6*u,f2=(gy-yy)/lf,hx2=hw2*(1-f2*.45);cx.beginPath();cx.moveTo(M.x-hx2,yy);cx.lineTo(M.x+hx2,yy);cx.stroke()}cx.fillStyle='#c79a5c';cx.fillRect(M.x-hw2*.62,fy-.4*u,hw2*1.24,.5*u)}
  else{cx.fillStyle='#a07844';cx.fillRect(M.x-2.6*u,fy,5.2*u,lf);cx.fillStyle='#c79a5c';cx.fillRect(M.x-2.9*u,fy-.5*u,5.8*u,.5*u);cx.fillStyle='rgba(0,0,0,.25)';cx.fillRect(M.x-2.6*u,fy+lf*.45,5.2*u,2)}}
 wallDesk(deskX,gy,u,t,rd,M.sit&&M.ss==='sit-drink');wallChair(M.cx,gy,u,M.wh||0);
 if(!M.sit){cx.fillStyle='rgba(0,0,0,.28)';cx.beginPath();cx.ellipse(M.x,gy+1,3.6*u,.45*u,0,0,6.283);cx.fill()}
 trMan(M.x,fy-(lf>2?.5*u:0),mh,{d:M.d,t,ph:M.ph,pose,bend:0,rd,T:M.T,dt,hx,hy,mx:deskX+4.1*u});
 if(pose==='think'&&!rd){cx.fillStyle='rgba(255,255,255,.8)';for(let j=0;j<3;j++){cx.globalAlpha=.4+.6*Math.max(0,Math.sin(t*3-j*.8));cx.beginPath();cx.arc(M.x+mh*.2+j*mh*.1,fy-mh*1.15-j*mh*.05,mh*.03+j*.8,0,6.283);cx.fill()}cx.globalAlpha=1}}
/* ---------- brainstorm map for one goal ---------- */
const WB_SUG={
 h:{learn:['No one to practise speaking with','Words not sticking','Skipping when I feel stuck','Sessions too long, I put them off'],trade:['Overtrading after a loss','Not following my plan','Revenge trades','No time to journal after the market'],fit:['Too tired or sore','Bad weather','No time in the morning','Skipping once and quitting'],quit:['The urge hits at the usual time','Stress or boredom','Friends who still do it','Evenings alone','"Just one" thinking'],gen:['No time in the day','Low energy','Forgetting to do it','The task feels too big','It feels slow, I get bored']},
 d:{quit:['Seeing it around me','Ads and shops on the way','Peer pressure','Old routines and places','Hungry, angry, lonely or tired'],gen:['Phone and notifications','Reels and social media','Messages and calls','Noise at home','Other work pulling me away']},
 n:['Tie it to one fixed cue','Do the 2-minute version on bad days','Put the phone in another room','Tell one person what I am doing','Prepare tomorrow tonight']};
function wbKind(g){const s=(g.name+' '+(g.cat||'')).toLowerCase();return isB(g)?'quit':/hindi|language|learn|study|read|course|class|english|spanish|french|code|coding|skill/.test(s)?'learn':/trad|market|stock|option|intraday|chart/.test(s)?'trade':/gym|run|walk|workout|exercise|yoga|swim|cycle|fit/.test(s)?'fit':'gen'}
function wallInsights(g){const t=todayKey(),s=gStats(g),N=goalNums(g),work=[],not=[],next=[],q=isB(g),pc=v=>Math.round(v*100)+'%';
 const wd=wdPerf([g],56).filter(x=>x.n>=3),best=wd.slice().sort((a,b)=>b.v-a.v)[0],worst=wd.slice().sort((a,b)=>a.v-b.v)[0];
 let miss=0,run=0,maxRun=0,logged=0;for(let i=27;i>=0;i--){const k=addD(t,-i);if(k<g.start||k>=t)continue;const r=isOpp(g,k,t);if(r.o){logged++;if(r.d){run=0}else{miss++;run++;maxRun=Math.max(maxRun,run)}}}
 if(!s.done){work.push('Nothing logged yet. The first '+(q?'clean day':'fire')+' starts the circuit.')}
 else{if(s.streak>0)work.push('Current streak: '+s.streak+(s.unit==='d'?' days':' '+s.unit)+(s.best>s.streak?' (best '+s.best+')':''));
  if(N.r7!=null)work.push('Last 7 days: '+pc(N.r7)+' followed through');
  if(best&&best.v>=60)work.push('Strongest day: '+best.l+' ('+best.v+'%)');
  if(N.trend!=null&&N.trend>=.1)work.push('Rising: up '+Math.round(N.trend*100)+' points on the week before');
  const ms=PMILE.filter(m=>s.done>=m).pop();if(ms)work.push('Passed the day-'+ms+' milestone');
  try{const c=correl([g]);if(c.length)work.push(c[0])}catch(e){}
  if(!work.length)work.push('Early days. Keep logging so patterns show.')}
 if(miss>0)not.push('Missed '+miss+' of the last '+logged+' days that counted');
 if(maxRun>=2)not.push('A run of '+maxRun+' misses in a row. Two in a row is the habit to watch');
 if(worst&&worst.v<=60&&wd.length>1)not.push('Weakest day: '+worst.l+' ('+worst.v+'%)');
 if(N.trend!=null&&N.trend<=-.1)not.push('Slipping: down '+Math.round(-N.trend*100)+' points on the week before');
 if(s.gap!=null&&s.gap>=2)not.push('No log for '+s.gap+' days');
 if(q&&s.slips)not.push(s.slips+' slip'+(s.slips>1?'s':'')+' so far. Each one is data, not failure');
 if(!not.length)not.push(s.done?'Nothing is clearly failing right now.':'Nothing to judge yet.');
 if(worst&&worst.v<=60&&wd.length>1)next.push('Make a smaller version for '+worst.l);
 if(N.r28!=null&&N.r28<.6)next.push('Shrink it: do the 2-minute version on bad days');
 if(s.gap!=null&&s.gap>=2)next.push('Do the smallest version today. Never miss twice');
 if(!next.length)next.push('Keep going. Review again in a week');
 return{work,not,next}}
function wallOpen(id){const g=gById(id);if(!g)return;if(g.tpl==='trade'){tdOpen();return}sfx('open');WL.open=id;const t=todayKey(),s=gStats(g),L=lenDays(g),day=clamp(diffD(g.start,t)+1,0,L),left=Math.max(0,L-day),q=isB(g),done=dueState(g).s==='done',I=wallInsights(g),bs=g.bs||(g.bs={h:[],d:[],n:[]}),kind=wbKind(g);
 const leaf=(txt,b,del)=>`<div class="bsleaf" style="--b:${b}"><span>${esc(txt)}</span>${del?`<button class="bsx" data-act="wbdel" data-id="${g.id}" data-k="${del[0]}" data-i="${del[1]}" aria-label="Remove">×</button>`:''}</div>`;
 const plan=[];plan.push(['End goal',g.why||(q?'Free of this habit for the whole round':'Complete the full round of '+L+' days')+(g.metric?' · target: '+g.metric:'')]);plan.push(['Duration',L+' days · '+fmtD(g.start)+' to '+fmtD(g.end)+' · day '+day+' · '+left+' left']);plan.push(['Schedule',schedText(g)+(g.cue?' · cue: '+g.cue:'')]);(g.tasks||[]).forEach(x=>{const tx=typeof x==='string'?x:(x.t||x.name||x.text||'');if(tx)plan.push(['Step',tx])});
 const sugOf=(k,list)=>list.filter(x=>!(bs[k]||[]).includes(x)).slice(0,5).map(x=>`<button class="bssug" data-act="wbadd" data-id="${g.id}" data-k="${k}" data-v="${esc(x)}">+ ${esc(x)}</button>`).join('');
 const edit=(k,b,ph,sug)=>`<div class="bsadd"><input id="wbi_${k}" class="bsin" placeholder="${ph}" maxlength="120" autocomplete="off" data-enter="wbaddin" data-id="${g.id}" data-k="${k}"><button class="btn sm" data-act="wbaddin" data-id="${g.id}" data-k="${k}">Add</button></div><div class="bssugs" style="--b:${b}">${sug}</div>`;
 const hs=WB_SUG.h[kind]||WB_SUG.h.gen,ds=q?WB_SUG.d.quit:WB_SUG.d.gen;
 const br=(name,b,body)=>`<div class="bsbr" style="--b:${b}"><div class="bsbn">${name}</div><div class="bsleaves">${body}</div></div>`;
 const mood=done?(q?'Clean day logged':'Fired today'):'Not logged yet today';
 FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');$('#mbox').innerHTML=`<div class="row wrapr"><div><div class="xs mute">Brainstorm</div><h2 class="vt" style="margin:0">${esc(g.name)}</h2></div><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div>
 <div class="bsmap" style="--c:${g.color}"><div class="bsroot"><span class="gico" style="--c:${g.color}">${gI(g,22)}</span><b>${esc(g.name)}</b><em>${q?'Quit':'Build'} · ${L} days</em><em>${esc(mood)}</em></div>
 <div class="bsbrs">
 ${br('Plan','#5b7cff',plan.map(p=>leaf(p[0]+': '+p[1],'#5b7cff')).join(''))}
 ${br('Hurdles','#ff5d73',(bs.h||[]).map((x,i)=>leaf(x,'#ff5d73',['h',i])).join('')+edit('h','#ff5d73','What could get in the way?',sugOf('h',hs)))}
 ${br('Distractions','#ff9f43',(bs.d||[]).map((x,i)=>leaf(x,'#ff9f43',['d',i])).join('')+edit('d','#ff9f43','What could pull me away?',sugOf('d',ds)))}
 ${br('What is working','#3ddc97',I.work.map(x=>leaf(x,'#3ddc97')).join(''))}
 ${br('What is not working','#f472b6',I.not.map(x=>leaf(x,'#f472b6')).join(''))}
 ${br('Next move','#b388ff',I.next.map(x=>leaf(x,'#b388ff')).join('')+(bs.n||[]).map((x,i)=>leaf(x,'#b388ff',['n',i])).join('')+edit('n','#b388ff','My own next step',sugOf('n',WB_SUG.n)))}
 </div></div>
 <div class="xs mute" style="margin-top:6px">Working and not working come from your own logs. Hurdles, distractions and next steps are yours: tap a suggestion or type your own.</div>
 <div class="row wrapr" style="gap:8px;margin-top:10px"><button class="btn pri" data-act="wallfire" data-id="${g.id}">${ic('flame',14)} ${done?'Undo today':q?'Clean day':'Fire'}</button><button class="btn" data-act="wallfull" data-id="${g.id}">Full details</button><button class="btn" data-act="wallrep" data-id="${g.id}">${ic('play',13)} Rewrite on board</button></div>`}
/* ---------- quick add: type it, pick build or quit, set the days ---------- */
function wallNew(type){WL.nt=type==='quit'?'quit':type==='task'?'task':'build';WL.ns={t:'daily',days:[1,2,3,4,5],every:2,n:3};sfx('open');FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');
 const DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 $('#mbox').innerHTML=`<div class="row wrapr"><div><h2 class="vt" style="margin:0">Add to the board</h2><div class="xs mute">He writes it up and tracks it every day.</div></div><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div>
 <label class="f" style="margin-top:12px">Kind</label><div class="seg" id="wnt">${[['build','Build a habit'],['quit','Quit a habit'],['task','Daily task'],['trade','Trading day']].map(k=>`<button data-act="wallty" data-v="${k[0]}" class="${WL.nt===k[0]?'on':''}">${k[1]}</button>`).join('')}</div>
 <div class="xs mute" id="wnh" style="margin:6px 0 0"></div>
 <label class="f">What is it?</label><input id="wnn" class="bsin" style="width:100%" placeholder="For example: Learn Hindi" maxlength="60" autocomplete="off" data-enter="wallmake">
 <div id="wnx"><label class="f">Why do you want this?</label><input id="wnw" class="bsin" style="width:100%" placeholder="Your reason in a few words" maxlength="120" autocomplete="off">
 <label class="f">End goal: what does done look like?</label><input id="wne" class="bsin" style="width:100%" placeholder="For example: hold a 10 minute chat" maxlength="160" autocomplete="off"></div>
 <label class="f" id="wndl">For how many days?</label><div class="row wrapr" style="gap:6px"><input id="wnd" class="bsin" type="number" inputmode="numeric" min="1" max="730" value="21" style="width:90px">${[7,21,30,66,100].map(d=>`<button class="chip" data-act="wallday" data-v="${d}">${d}</button>`).join('')}</div>
 <label class="f">How often?</label><div class="seg" id="wns">${[['daily','Every day'],['days','Chosen days'],['every','Alternate'],['weekly','Weekly']].map(k=>`<button data-act="wallsch" data-v="${k[0]}" class="${k[0]==='daily'?'on':''}">${k[1]}</button>`).join('')}</div>
 <div id="wnsx" style="margin-top:8px"></div>
 <label class="f">Time window <span class="mute xs">(optional)</span></label><div class="row wrapr" style="gap:8px"><input id="wnt1" type="time" class="bsin" style="width:110px"><span class="mute">to</span><input id="wnt2" type="time" class="bsin" style="width:110px"></div>
 <div class="row wrapr" style="gap:8px;margin-top:14px"><button class="btn pri" data-act="wallmake">${ic('pen',14)} Write it on the board</button><button class="btn" data-act="recx">Cancel</button></div>
 <div class="xs mute" style="margin-top:8px">Reminders and checklists: open the item later and tap Full details.</div>`;wallFormSync();setTimeout(()=>{const i=$('#wnn');if(i)i.focus()},120)}
function wallFormSync(){const k=WL.nt,H={build:'Something you want to do more. Each day you log minutes and what you learned.',quit:'Something you want to do less. Each day you log a clean day and what you did instead.',task:'A normal task with a time. It shows on the timeline every time it is due.'};
 const h=$('#wnh');if(h)h.textContent=H[k];const x=$('#wnx');if(x)x.style.display=k==='task'?'none':'';const l=$('#wndl');if(l)l.textContent=k==='task'?'Repeat for how many days?':'For how many days?';
 const sc=WL.ns,b=$('#wnsx');if(!b)return;const DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 b.innerHTML=sc.t==='days'?`<div class="row wrapr" style="gap:6px">${DN.map((d,i)=>`<button class="chip ${sc.days.includes(i)?'on':''}" data-act="wallday2" data-v="${i}">${d}</button>`).join('')}</div>`:sc.t==='every'?`<div class="row" style="gap:8px">Every <input id="wnev" type="number" min="2" max="30" value="${sc.every}" class="bsin" style="width:64px"> days</div>`:sc.t==='weekly'?`<div class="row" style="gap:8px"><input id="wnwk" type="number" min="1" max="7" value="${sc.n}" class="bsin" style="width:64px"> times a week, any day</div>`:'<div class="xs mute">Shows up every day.</div>'}


function wallDesk(x,gy,u,t,rd,hideMug){const c=cx;c.save();c.lineCap='round';c.lineJoin='round';c.strokeStyle='rgba(206,176,138,.95)';c.lineWidth=Math.max(2,u*.35);
 c.beginPath();c.moveTo(x+3.2*u,gy-4.2*u);c.lineTo(x+9*u,gy-4.2*u);c.moveTo(x+3.6*u,gy-4.2*u);c.lineTo(x+3.6*u,gy);c.moveTo(x+8.6*u,gy-4.2*u);c.lineTo(x+8.6*u,gy);c.stroke();
 const lx=x+5.6*u,ly=gy-4.2*u;c.strokeStyle='rgba(235,240,255,.85)';c.lineWidth=Math.max(1.4,u*.2);c.beginPath();c.moveTo(lx,ly);c.lineTo(lx+2*u,ly);c.stroke();
 c.fillStyle='rgba(150,205,255,.2)';c.beginPath();c.moveTo(lx+2*u,ly);c.lineTo(lx+2.7*u,ly-3*u);c.lineTo(lx+3.2*u,ly-3*u);c.lineTo(lx+2.5*u,ly);c.closePath();c.fill();c.stroke();
 if(!hideMug){c.fillStyle='#e8c9a0';c.fillRect(x+3.7*u,ly-.9*u,.8*u,.9*u)}c.restore()}
function wallChair(x,gy,u,wheel){const c=cx;c.save();c.lineCap='round';c.lineJoin='round';c.strokeStyle='rgba(206,176,138,.95)';c.fillStyle='rgba(206,176,138,.95)';c.lineWidth=Math.max(2,u*.35);
 c.beginPath();c.moveTo(x-1.4*u,gy-5.8*u);c.lineTo(x-1.4*u,gy-2.4*u);c.lineTo(x+1.2*u,gy-2.4*u);c.moveTo(x-.1*u,gy-2.4*u);c.lineTo(x-.1*u,gy-.7*u);c.moveTo(x-1.5*u,gy-.7*u);c.lineTo(x+1.3*u,gy-.7*u);c.stroke();
 c.lineWidth=Math.max(1.4,u*.2);[-1.3,.2,1.2].forEach((dx,i)=>{const wx=x+dx*u,wy=gy-.35*u;c.beginPath();c.arc(wx,wy,.35*u,0,6.283);c.stroke();c.beginPath();c.moveTo(wx,wy);c.lineTo(wx+Math.cos(wheel+i)*.3*u,wy+Math.sin(wheel+i)*.3*u);c.stroke()});c.restore()}
