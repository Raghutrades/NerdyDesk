/* ===== Trading: days you do not trade. Not trading is a valid, often smart, decision, so the desk never forces a plan.
   A no-trade day (waiting, chose to pass, holiday, away) or a vacation range marks the trading ritual as a planned rest:
   it does not break the streak, is never counted as a miss, and shows its reason on the Trace. ===== */
const TD_OFF=[['wait','No clean setup','Waiting is a position'],['pass','Chose not to trade','A decision, not a miss'],['holiday','Market holiday','Exchange closed'],['away','Away or on vacation','Time off, can span days'],['other','Something else','Your own reason']];
const tdOffLab=t=>(TD_OFF.find(x=>x[0]===t)||[0,'Not trading'])[1];
function tdOffOf(k){const t=trdS(),d=t.days[k];if(d&&d.off)return d.off;const r=(t.away||[]).find(x=>k>=x.a&&k<=x.b);return r?{t:'away',note:r.note||'',range:r}:null}
function tdOffWhy(k){const o=tdOffOf(k);return o?tdOffLab(o.t)+(o.note?': '+o.note:''):''}
/* keep the ritual goal's log in step: a planned rest while the day is off, removed again when it is not */
function tdOffSync(){const g=gTpl();if(!g)return;const t=trdS(),today=todayKey(),days=new Set(Object.keys(t.days).filter(k=>t.days[k].off));
 (t.away||[]).forEach(r=>{let k=r.a,n=0;while(k<=r.b&&k<=today&&n++<400){days.add(k);k=addD(k,1)}});
 days.forEach(k=>{if(k<g.start||k>g.end||k>today)return;const l=g.logs[k];if(!l&&tdOffOf(k)){g.logs[k]={skip:true,at:Date.now(),desk:1,why:tdOffWhy(k)}}else if(l&&l.desk&&tdOffOf(k))l.why=tdOffWhy(k)});
 Object.keys(g.logs).forEach(k=>{const l=g.logs[k];if(l&&l.desk&&!tdOffOf(k))delete g.logs[k]});save()}
setInterval(()=>{try{if(document.visibilityState!=='hidden')tdOffSync()}catch(e){}},300000);
function tdOffHtml(off){const k=TDV.k,fut=k>todayKey();
 const chips=`<div class="tdoffopts">${TD_OFF.map(([v,l,s])=>`<button class="tdoo ${off&&off.t===v?'on':''}" data-act="tdoffset" data-v="${v}"><b>${l}</b><small>${s}</small></button>`).join('')}</div>`;
 const away=(TDV.offT||(off&&off.t))==='away'?`<label class="f">Away until (optional)</label><input type="date" id="tdawayto" min="${k}" value="${off&&off.range?off.range.b:TDV.awayTo||k}" class="bsin" data-chg="tdawayto">`:'';
 if(off){return `<div class="card tdc tdoff"><div class="tdoffh"><span class="tdoffi">${ic('pause',18)}</span><div><b>Not trading ${k===todayKey()?'today':'this day'}</b><small>${esc(tdOffLab(off.t))}${off.range?' · '+fmtD(off.range.a)+' to '+fmtD(off.range.b):''}</small></div></div>
  <p class="xs mute" style="margin:8px 0">This counts as a planned rest. Your streak is safe and nothing is marked as missed.</p>
  <textarea class="tdta" rows="2" data-inp="tdoffnote" placeholder="Why? (optional) e.g. no clean setup, expiry day too wild, family trip">${esc(off.note||'')}</textarea>
  ${TDV.offOpen?chips+away+`<div class="row" style="margin-top:10px"><button class="btn pri sm" data-act="tdoffsave">Save</button></div>`:''}
  <div class="row wrapr" style="gap:8px;margin-top:10px"><button class="btn sm" data-act="tdoffopen">${TDV.offOpen?'Close':'Change reason'}</button><button class="btn sm" data-act="tdoffshow">${TDV.offShow?'Hide planning':'Plan or log anyway'}</button><button class="btn sm ghost" data-act="tdoffclear">I will trade after all</button></div></div>`}
 if(fut)return '';
 return `<div class="tdoffbar"><span>${TDV.offOpen?'Pick why you are not trading':'Not trading today?'}</span><button class="btn sm" data-act="tdoffopen">${TDV.offOpen?'Close':'Mark a no-trade day'}</button></div>${TDV.offOpen?`<div class="card tdc">${chips}${away}<div class="row" style="margin-top:10px"><button class="btn pri sm" data-act="tdoffsave" ${TDV.offT?'':'disabled'}>Save</button></div></div>`:''}`}
ACT.tdoffopen=()=>{TDV.offOpen=!TDV.offOpen;TDV.offT='';sfx('tick');tdKeep()};
ACT.tdoffshow=()=>{TDV.offShow=!TDV.offShow;sfx('tick');tdKeep()};
ACT.tdoffset=el=>{const k=TDV.k,off=tdOffOf(k);TDV.offT=el.dataset.v;if(off&&!off.range){const d=tdDay(k);d.off.t=el.dataset.v;save();tdOffSync()}sfx('tick');tdKeep()};
CHG.tdawayto=el=>{TDV.awayTo=el.value};
INP.tdoffnote=el=>{const k=TDV.k,off=tdOffOf(k);if(!off)return;if(off.range)off.range.note=el.value.slice(0,200);else tdDay(k).off.note=el.value.slice(0,300);save();clearTimeout(TDV.sn);TDV.sn=setTimeout(tdOffSync,500)};
ACT.tdoffsave=()=>{const k=TDV.k,old=tdOffOf(k),t=TDV.offT||(old&&old.t);if(!t)return;const to=($('#tdawayto')||{}).value||TDV.awayTo||k,note=old?old.note:'';
 if(old&&old.range){trdS().away=trdS().away.filter(r=>r!==old.range)}
 if(t==='away'&&to>k){trdS().away.push({a:k,b:to,note});const d=tdDay(k);d.off=null}else{const d=tdDay(k);d.off={t,note,ts:hm()}}
 TDV.offOpen=false;TDV.offT='';save();tdOffSync();afterLog(gTpl());sfx('create');toast('Marked as a no-trade day. Streak is safe.');tdRender()};
ACT.tdoffclear=()=>{const k=TDV.k,off=tdOffOf(k);if(!off)return;if(off.range){if(!confirm('Remove the whole away period '+fmtD(off.range.a)+' to '+fmtD(off.range.b)+'?'))return;trdS().away=trdS().away.filter(r=>r!==off.range)}else tdDay(k).off=null;TDV.offShow=false;save();tdOffSync();afterLog(gTpl());sfx('untick');toast('Back to a trading day');tdRender()};
