/* ===== scene core: camera, layout, effects, interaction ===== */
const UI={view:'home',sel:null,hover:null,drawer:{id:null,tab:'log',date:null},cal:{y:0,m:0,sel:'',tab:'month'},an:{scope:'all'},jf:'',jq:'',fs:false,opt:false};
const cv=$('#cv'),mapwrap=$('#mapwrap');let cx=cv.getContext('2d');const CX0=cx;
let W=0,H=0,DPR=1,UNIT=1,KS=300,QF=1;
const cam={yaw:.6,pit:.3,zoom:1,vy:0,vp:0,auto:true,shake:0,kick:0,drag:null,pinch:null};
const CM=[1,0,1,0];let PX=0,PY=0,PZ=0,PS=1;
const reduceMQ=window.matchMedia?matchMedia('(prefers-reduced-motion: reduce)'):{matches:false};
const reduced=()=>reduceMQ.matches||S.set.reduceMotion;
function camSet(){CM[0]=Math.cos(cam.yaw);CM[1]=Math.sin(cam.yaw);CM[2]=Math.cos(cam.pit);CM[3]=Math.sin(cam.pit)}
const SH={x:0,y:0,s:1,tx:0,ty:0,ts:1};
function shTarget(){if(!INS.on){SH.tx=0;SH.ty=0;SH.ts=1;return}if(innerWidth>700){const pw=Math.min(380,W*.46);SH.tx=-pw/2;SH.ty=0;SH.ts=.82}else{SH.tx=0;SH.ty=-H*.2;SH.ts=.72}}
function pj(X,Y,Z){const x=X*CM[0]+Z*CM[1],z0=Z*CM[0]-X*CM[1],y=Y*CM[2]-z0*CM[3],z=Y*CM[3]+z0*CM[2],s=1/(1+z*.22),k=KS*s;PX=W/2+SH.x+x*k;PY=H/2+SH.y+y*k;PZ=z;PS=s}
function size(){const r=cv.getBoundingClientRect();if(!r.width||!r.height)return;DPR=Math.min(2,window.devicePixelRatio||1);W=r.width;H=r.height;cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);UNIT=clamp(Math.min(W,H)/620,.6,1.5)}
function qualityInit(){const q=S.set.quality;QF=q==='high'?1:q==='balanced'?.65:q==='low'?.35:(((navigator.hardwareConcurrency||8)<=4||(navigator.deviceMemory||8)<=4)?.7:1)}
/* glow sprites */
const SPR={};const rgbOf=h=>hex2(h).join(',');
function spr(rgb){let c=SPR[rgb];if(c)return c;c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);
 g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.16,`rgba(${rgb},.85)`);g.addColorStop(.45,`rgba(${rgb},.22)`);g.addColorStop(1,`rgba(${rgb},0)`);x.fillStyle=g;x.fillRect(0,0,128,128);return SPR[rgb]=c}
function sprSoft(rgb){const k='s'+rgb;let c=SPR[k];if(c)return c;c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);
 g.addColorStop(0,`rgba(${rgb},.55)`);g.addColorStop(.5,`rgba(${rgb},.16)`);g.addColorStop(1,`rgba(${rgb},0)`);x.fillStyle=g;x.fillRect(0,0,128,128);return SPR[k]=c}
function glow(x,y,r,rgb,a,soft){if(r<.5||a<=.003)return;cx.globalAlpha=Math.min(1,a);cx.drawImage(soft?sprSoft(rgb):spr(rgb),x-r,y-r,r*2,r*2);cx.globalAlpha=1}
/* runtime per goal */
const RT={};let ORDER=[],LINKS=[],NB={},ORD_REV=-1;
const rt=g=>RT[g.id]||(RT[g.id]=newRT(g));
function newRT(g){const h=hashStr(g.id);return{x:0,y:0,z:0,ang:(h%628)/100,incl:((h>>8)%100/100-.5)*.6,flash:0,heat:0,amb:2+(h%50)/10,gr:-1,wave:-1,wpw:1,segs:null,byD:null,lastLv:null,ph:(h%100)/16,placed:false,R:.6}}
function orderGoals(){return S.goals.slice().sort((a,b)=>(a.type===b.type?0:a.type==='break'?1:-1)||(PRI[b.priority].w-PRI[a.priority].w)||a.name.localeCompare(b.name))}
function relink(){ORDER=orderGoals();LINKS=[];NB={};const n=ORDER.length,seen=new Set();
 const add=(a,b)=>{if(a===b)return;const x=ORDER[a].id,y=ORDER[b].id,key=x<y?x+'|'+y:y+'|'+x;if(seen.has(key))return;seen.add(key);LINKS.push([x,y]);(NB[x]=NB[x]||[]).push(y);(NB[y]=NB[y]||[]).push(x)};
 const ex=[];S.goals.forEach(g=>(g.rel||[]).forEach(r=>{const a=ORDER.findIndex(o=>o.id===g.id),b=ORDER.findIndex(o=>o.id===r.to);if(a>=0&&b>=0)ex.push([a,b])}));
 if(ex.length)ex.forEach(([a,b])=>add(a,b));else for(let i=0;i<n;i++){add(i,(i+1)%n);if(n>=5)add(i,(i+2)%n)}ORD_REV=REV}
/* Synapse mode shows one neuron (the selected goal) unless Show all is on or the layout is Web */
const is2D=()=>['path','ladder','tree','wall','house','trace'].includes(S.set.mode);
const synOne=()=>(is2D()&&S.set.mode!=='wall'&&ORDER.length>0)||(S.set.mode==='synapse'&&!S.set.synAll&&S.set.layout!=='web'&&ORDER.length>0);
function focusG(){let g=UI.sel&&gById(UI.sel);if(g){if(S.set.synGoal!==g.id)S.set.synGoal=g.id;return g}g=S.set.synGoal&&gById(S.set.synGoal);return g||ORDER[0]||null}
const synVis=g=>!synOne()||focusG()===g;
const RINGR={must:.34,high:.52,normal:.7,low:.88};
function updateLayout(dt,now){const n=ORDER.length,L=S.set.layout,t=now*.001;
 ORDER.forEach((g,i)=>{const r=rt(g);let x=0,y=0,z=0;
  if(L==='orbit'){const R=isB(g)?.46+.1*(i%3):RINGR[g.priority];r.R=R;const dir=isB(g)?-1:1,w=dir*(.16+.22*(1-R))*(.55+levelOf(g)*.6);r.ang+=w*dt;
   const incl=isB(g)?.75+r.incl*.4:r.incl,a=r.ang;r.inclU=incl;x=Math.cos(a)*R;const z0=Math.sin(a)*R;y=z0*Math.sin(incl);z=z0*Math.cos(incl)}
  else if(n>1){if(L==='web'){const f=.55+.45*((i*5)%7)/6,yy=(1-(i+.5)*2/n)*.8,rr=Math.sqrt(Math.max(0,.64-yy*yy)),ph=i*2.39996;x=Math.cos(ph)*rr*f*1.15;y=yy*f*.95;z=Math.sin(ph)*rr*f*1.15}
   else if(L==='helix'){const a=i/Math.max(1,n)*9.4+t*.1;x=Math.cos(a)*.64;z=Math.sin(a)*.64;y=(i/Math.max(1,n-1)-.5)*1.5}
   else{const a=i*.95+t*.05,rad=.2+.72*Math.sqrt((i+.5)/n);x=Math.cos(a)*rad;z=Math.sin(a)*rad;y=Math.sin(i*1.7)*.08}
   x+=Math.sin(t*.4+r.ph)*.018;y+=Math.cos(t*.33+r.ph)*.018}
  if(synOne()&&focusG()===g){x=0;y=0;z=0}
  if(!r.placed&&L==='orbit')r.ang=i/Math.max(1,n)*6.283+(hashStr(g.id)%100)/260;
  const k=r.placed?Math.min(1,dt*(L==='orbit'?12:3)):1;r.x+=(x-r.x)*k;r.y+=(y-r.y)*k;r.z+=(z-r.z)*k;r.placed=true;
  const lv=levelOf(g);if(r.gr<0)r.gr=isB(g)?lv:0;r.gr+=(lv-r.gr)*Math.min(1,dt*(r.gr<lv?1.6:.9)*(PV.m?3:1));if(RP.on)r.gr=lv;
  if(isB(g)&&r.lastLv!==null&&lv<r.lastLv-.02){fragBurst(g,r);r.lastLv=lv}else if(r.lastLv===null||lv>r.lastLv)r.lastLv=lv})}
/* effects (world space) */
const RINGS=[],SPARKS=[],PULSES=[],BOLTS=[];let boom=0,boomG=null;
const nodeBase=g=>{let l=levelOf(g);if(isB(g))l=l*l;return S.set.mode==='universe'?11+17*l:11+12*l};
const nodeR=(g,r)=>nodeBase(g)*UNIT*(1+.28*(r?r.flash:0))*Math.pow(cam.zoom,.55);
function fireGoal(g,pw,from,quiet){pw=pw==null?1:pw;const r=rt(g);r.flash=Math.max(r.flash,Math.min(1,pw));r.heat=Math.max(r.heat,Math.min(1,pw*(quiet?.6:1)));r.wave=0;r.wpw=pw;if(r.segs)r.segs.forEach(s=>{s.hit=false});
 if(synOne()&&!quiet&&pw>.5&&focusG()!==g){UI.sel=g.id;renderMapInfo();buildMapCtl()}
 const nr=nodeR(g,r);RINGS.push({x:r.x,y:r.y,z:r.z,r0:nr*.8,max:nr*2.8+pw*80*UNIT,life:1,c:g.color,w:Math.min(1,pw+.2),dl:0});
 if(reduced())return;
 if(pw>.5&&!quiet){RINGS.push({x:r.x,y:r.y,z:r.z,r0:nr*.6,max:nr*4.2+130*UNIT,life:1,c:g.color,w:.7,dl:.12});RINGS.push({x:r.x,y:r.y,z:r.z,r0:nr*.5,max:nr*5.6+200*UNIT,life:1,c:'#ffffff',w:.45,dl:.26})}
 const n=Math.round((quiet?4:14+pw*30)*QF);for(let i=0;i<n&&SPARKS.length<520;i++){const a=Math.random()*6.283,b=Math.acos(2*Math.random()-1),sp=.06+Math.random()*.24*pw,fl=!quiet&&Math.random()<.4;
  SPARKS.push({x:r.x,y:r.y,z:r.z,vx:Math.sin(b)*Math.cos(a)*sp,vy:Math.sin(b)*Math.sin(a)*sp-(fl?.08:0),vz:Math.cos(b)*sp,life:1,d:.8+Math.random()*1.1,c:fl?mix(g.color,'#ffd23f',.55):g.color,g:fl?-.05:0})}
 if(pw>.3)(NB[g.id]||[]).forEach(id=>{if(id===from)return;if(!gById(id))return;PULSES.push({a:g.id,b:id,t:-Math.random()*.08,v:.0085+Math.random()*.004,pw:pw*.62,c:g.color,tr:[]});if(!quiet)BOLTS.push({a:g.id,b:id,life:.6,c:g.color})})}
function ambFire(g){const r=rt(g);r.flash=Math.max(r.flash,.38);r.wave=0;r.wpw=.5;r.heat=Math.max(r.heat,.3);const nb=NB[g.id]||[];if(nb.length&&Math.random()<.85&&!synOne()){const id=nb[Math.floor(Math.random()*nb.length)];if(gById(id))PULSES.push({a:g.id,b:id,t:0,v:.006,pw:.3,c:g.color,tr:[]})}
 RINGS.push({x:r.x,y:r.y,z:r.z,r0:nodeR(g,r)*.8,max:nodeR(g,r)*2.2+30*UNIT,life:.8,c:g.color,w:.35,dl:0})}
function fragBurst(g,r){if(reduced())return;pj(r.x,r.y,r.z);for(let i=0;i<Math.round(8*QF)&&SPARKS.length<420;i++){const a=Math.random()*6.283;SPARKS.push({x:r.x+Math.cos(a)*.03,y:r.y+Math.sin(a)*.03,z:r.z,vx:Math.cos(a)*.03,vy:.02+Math.random()*.05,vz:(Math.random()-.5)*.04,life:1,d:1.2+Math.random(),c:'#ff4d5e',g:.06})}}
function stepFX(dt){
 RINGS.forEach(o=>{if(o.dl>0){o.dl-=dt;return}o.r0+=(o.max-o.r0)*Math.min(1,dt*4.5)+dt*20;o.life-=dt*1.5});for(let i=RINGS.length-1;i>=0;i--)if(RINGS[i].life<=0)RINGS.splice(i,1);
 SPARKS.forEach(s=>{s.x+=s.vx*dt;s.y+=s.vy*dt;s.z+=s.vz*dt;s.vy+=s.g*dt;s.vx*=.985;s.vz*=.985;s.life-=dt/s.d});for(let i=SPARKS.length-1;i>=0;i--)if(SPARKS[i].life<=0)SPARKS.splice(i,1);
 for(let i=PULSES.length-1;i>=0;i--){const p=PULSES[i],a=gById(p.a),b=gById(p.b);if(!a||!b){PULSES.splice(i,1);continue}p.t+=p.v*dt*60;
  if(p.t>=1){PULSES.splice(i,1);if(p.pw>.28)fireGoal(b,p.pw,a.id,true);else rt(b).flash=Math.max(rt(b).flash,.45);continue}}
 BOLTS.forEach(b=>{b.life-=dt*1.7});for(let i=BOLTS.length-1;i>=0;i--)if(BOLTS[i].life<=0)BOLTS.splice(i,1);
 ORDER.forEach(g=>{const r=rt(g);if(r.heat>0)r.heat=Math.max(0,r.heat-dt*.16);if(!reduced()&&!isB(g)&&!g.paused&&g.start<=todayKey()&&g.end>=todayKey()&&levelOf(g)>.03){r.amb-=dt;if(r.amb<=0){r.amb=(5+Math.random()*7)/(.35+levelOf(g)+(isDoneL(g.logs[todayKey()])?.5:0));ambFire(g)}}
  if(r.flash>0)r.flash=Math.max(0,r.flash-dt*.9);if(r.wave>=0){r.wave+=dt*(.62+.2*r.wpw);if(r.wave>.75)r.wave=-1}});
 boom*=Math.pow(.05,dt);cam.shake*=Math.pow(.02,dt);cam.kick*=Math.pow(.015,dt)}
function arcPt(ra,rb,t,bulge){const x=ra.x+(rb.x-ra.x)*t,y=ra.y+(rb.y-ra.y)*t,z=ra.z+(rb.z-ra.z)*t;let mx=ra.x+rb.x,my=ra.y+rb.y,mz=ra.z+rb.z,ml=Math.hypot(mx,my,mz);if(ml<.06){mx=0;my=-1;mz=0;ml=1}
 const k=(bulge||.26)*Math.sin(Math.PI*t)/ml;pj(x+mx*k,y+my*k,z+mz*k)}
function drawPulses(){cx.globalCompositeOperation='lighter';
 PULSES.forEach(p=>{if(p.t<0)return;const a=gById(p.a),b=gById(p.b);if(!a||!b)return;arcPt(rt(a),rt(b),p.t);p.tr.push(PX,PY);if(p.tr.length>22)p.tr.splice(0,2);
  const rgb=rgbOf(p.c);for(let m=2;m<p.tr.length;m+=2){const f=m/p.tr.length;cx.strokeStyle=`rgba(${rgb},${f*.7})`;cx.lineWidth=(1+f*3.5*p.pw)*UNIT;cx.beginPath();cx.moveTo(p.tr[m-2],p.tr[m-1]);cx.lineTo(p.tr[m],p.tr[m+1]);cx.stroke()}
  glow(PX,PY,(11+8*p.pw)*UNIT*PS,rgb,.95);glow(PX,PY,4*UNIT*PS,'255,255,255',.9)});
 BOLTS.forEach(b=>{const ga=gById(b.a),gb=gById(b.b);if(!ga||!gb)return;const ra=rt(ga),rb=rt(gb),N=12,P=[];for(let i=0;i<=N;i++){arcPt(ra,rb,i/N,.22);P.push([PX,PY])}
  const dx=P[N][0]-P[0][0],dy=P[N][1]-P[0][1],L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;for(let i=1;i<N;i++){const o=(Math.random()-.5)*30*UNIT*Math.sin(Math.PI*i/N)*b.life;P[i][0]+=nx*o;P[i][1]+=ny*o}
  const rgb=rgbOf(b.c);[[7,.22],[2.6,.7]].forEach(([w,a],q)=>{cx.strokeStyle=q?`rgba(255,255,255,${a*b.life})`:`rgba(${rgb},${a*b.life})`;cx.lineWidth=w*UNIT*b.life+.6;cx.lineJoin='round';cx.beginPath();P.forEach((p,i)=>i?cx.lineTo(p[0],p[1]):cx.moveTo(p[0],p[1]));cx.stroke()})});
 RINGS.forEach(o=>{if(o.dl>0)return;pj(o.x,o.y,o.z);cx.strokeStyle=rgba(o.c,o.life*o.w*.9);cx.lineWidth=(1+2.4*o.life)*UNIT;cx.beginPath();cx.arc(PX,PY,o.r0*PS,0,6.283);cx.stroke()});
 SPARKS.forEach(s=>{pj(s.x,s.y,s.z);if(PS>3)return;const rgb=rgbOf(s.c);glow(PX,PY,(3+3*s.life)*UNIT*PS,rgb,s.life*.9)});
 cx.globalCompositeOperation='source-over'}
/* labels and selection */
const LBL_W={};
function drawLabels(){const placed=[],items=HITS.slice().sort((a,b)=>b.z-a.z);cx.textAlign='center';const all=!!S.set.labels;
 items.forEach(h=>{const g=h.g,isSel=UI.sel===g.id,isHov=UI.hover===g.id;if(!all&&!isSel&&!isHov)return;const f=(isSel||isHov?'700 ':'600 ')+Math.round((isSel?13:11.5)*Math.max(.85,UNIT))+'px Bricolage Grotesque,system-ui,sans-serif';
  cx.font=f;const txt=(g.name.length>18?g.name.slice(0,17)+'…':g.name),w=cx.measureText(txt).width+8,hh=16*Math.max(.85,UNIT);
  const x=h.x-w/2,y=h.y+h.r+6;let ok=true;if(!isSel&&!isHov){for(const p of placed)if(x<p[0]+p[2]&&x+w>p[0]&&y<p[1]+p[3]&&y+hh>p[1]){ok=false;break}if(h.z>1.1)ok=false}
  if(!ok)return;placed.push([x,y,w,hh]);const a=isSel||isHov?1:clamp(.35+.75*h.s*h.s,.3,.95);cx.globalAlpha=a;cx.lineWidth=3;cx.strokeStyle='rgba(2,6,16,.85)';cx.lineJoin='round';cx.strokeText(txt,h.x,y+hh*.78);cx.fillStyle=isSel?'#ffffff':'rgba(235,240,255,.92)';cx.fillText(txt,h.x,y+hh*.78);cx.globalAlpha=1})}
function drawSelRing(h,now){const g=h.g;if(UI.sel!==g.id)return;cx.strokeStyle='rgba(255,255,255,.9)';cx.lineWidth=1.4;cx.setLineDash([5,5]);cx.lineDashOffset=-now*.01;cx.beginPath();cx.arc(h.x,h.y,h.r*1.55+4,0,6.283);cx.stroke();cx.setLineDash([])}
/* main frame */
let HITS=[],lastT=0,fpsEma=16,lowT=0,frameN=0;
const mapActive=()=>UI.view==='home'||UI.fs;
function frame(now){requestAnimationFrame(frame);if(document.hidden||!W)return;if(!mapActive()){lastT=0;return}
 let dt=lastT?(now-lastT)/1000:.016;lastT=now;dt=Math.min(.05,dt);fpsEma=fpsEma*.95+dt*1000*.05;
 if(S.set.quality==='auto'){if(fpsEma>36){lowT+=dt}else lowT=Math.max(0,lowT-dt);if(lowT>4&&QF>.4){QF=Math.max(.4,QF*.8);lowT=0}}
 if(ORD_REV!==REV)relink();
 if(is2D()){VW.yaw=VW.pit=VW.vy=VW.vp=0}
 if(!cam.drag&&!cam.pinch){cam.yaw+=cam.vy;cam.pit=clamp(cam.pit+cam.vp,-1.2,1.2);cam.vy*=.94;cam.vp*=.9;if(cam.auto&&!reduced()&&Math.abs(cam.vy)<.002)cam.yaw+=.06*dt}
 {const k=Math.min(1,dt*5);SH.x+=(SH.tx-SH.x)*k;SH.y+=(SH.ty-SH.y)*k;SH.s+=(SH.ts-SH.s)*k;if(Math.abs(SH.tx-SH.x)<.1)SH.x=SH.tx;if(Math.abs(SH.ty-SH.y)<.1)SH.y=SH.ty}camSet();KS=Math.min(W*.44,H*.47)*cam.zoom*SH.s*(1+.06*cam.kick);updateLayout(dt,now);stepFX(dt);
 cx.setTransform(DPR,0,0,DPR,(Math.random()-.5)*cam.shake*DPR,(Math.random()-.5)*cam.shake*DPR);cx.clearRect(-20,-20,W+40,H+40);HITS=[];LHIT=[];
 {const two=is2D(),m=S.set.mode,rotd=false;
  if(rotd){if(!OC||OC.canvas.width!==Math.round(W*DPR)||OC.canvas.height!==Math.round(H*DPR)){const c=document.createElement('canvas');c.width=Math.round(W*DPR);c.height=Math.round(H*DPR);OC={canvas:c,ctx:c.getContext('2d')}}cx=OC.ctx;cx.setTransform(DPR,0,0,DPR,0,0);cx.clearRect(0,0,W,H)}
  if(two){cx.save();cx.translate(W/2+VW.x,H/2+VW.y);cx.scale(VW.z,VW.z);cx.translate(-W/2,-H/2)}
  try{if(m==='universe')drawUniverse(now,dt);else if(m==='path')drawPath(now,dt);else if(m==='ladder')drawLadder(now,dt);else if(m==='tree')drawTree(now,dt);else if(m==='wall')drawWall(now,dt);else if(m==='house')drawHouse(now,dt);else if(m==='trace')drawTrace(now,dt);else drawSynapse(now,dt)}
  catch(e){if(!window.__de||performance.now()-window.__de>4000){window.__de=performance.now();console.error(e)}try{cx.setTransform(DPR,0,0,DPR,0,0);cx.globalAlpha=1;cx.shadowBlur=0;cx.globalCompositeOperation='source-over'}catch(x){}}
  if(two){cx.restore();if(VW.z!==1||VW.x||VW.y){const mx=x=>W/2+VW.x+(x-W/2)*VW.z,my=y=>H/2+VW.y+(y-H/2)*VW.z;HITS.forEach(h=>{h.x=mx(h.x);h.y=my(h.y);h.r*=VW.z});BHIT.forEach(b=>{b.x=mx(b.x);b.w*=VW.z;b.y0=my(b.y0);b.y1=my(b.y1)})}}
  if(rotd){cx=CX0;compose2D(cx,OC.ctx);HITS.forEach(h=>{const q=rot2(h.x,h.y);h.x=q[0];h.y=q[1];h.r*=q[2]});BHIT.forEach(b=>{const q=rot2(b.x+b.w/2,(b.y0+b.y1)/2);b.x=q[0]-b.w*q[2]/2;b.y0=q[1]-(b.y1-b.y0)*q[2]/2;b.y1=q[1]+(b.y1-b.y0)*q[2]/2;b.w*=q[2]})}}
 if(!is2D())drawPulses();drawLabels();
 if(boom>.01&&boomG&&rt(boomG)){const r=rt(boomG);pj(r.x,r.y,r.z);const rg=cx.createRadialGradient(PX,PY,0,PX,PY,Math.max(W,H)*.7);rg.addColorStop(0,rgba(boomG.color,boom*.28));rg.addColorStop(1,rgba(boomG.color,0));cx.fillStyle=rg;cx.fillRect(0,0,W,H)}
 if(frameN++%30===0)syncMapInfoPos()}
/* interaction */
const ptrs=new Map();const VW={x:0,y:0,z:1,yaw:0,pit:0,vy:0,vp:0};
let OC=null;
function rot2(x,y){const u=x-W/2,v=y-H/2,ca=Math.cos(VW.yaw),sa=Math.sin(VW.yaw),cb=Math.cos(VW.pit),sb=Math.sin(VW.pit),X=u*ca,Z0=u*sa,Y=v*cb-Z0*sb,Z=v*sb+Z0*cb,f=Math.max(W,H)*1.8,s=f/Math.max(f*.2,f+Z);return [W/2+X*s,H/2+Y*s,s]}
function compose2D(main,oc){const st=3,back=Math.cos(VW.yaw)<0;main.save();main.globalAlpha=back?.6:1;for(let x=0;x<W;x+=st){const a=rot2(x,H/2),b=rot2(x+st,H/2),t=rot2(x+st/2,0),bt=rot2(x+st/2,H),dx=Math.min(a[0],b[0]),dw=Math.abs(b[0]-a[0])+.6;if(dw<.7)continue;main.drawImage(oc.canvas,x*DPR,0,Math.min(st,W-x)*DPR,H*DPR,dx,t[1],dw,bt[1]-t[1])}main.restore()}
function pickAt(cxp,cyp){let best=null,bd=1e9;HITS.forEach(h=>{const d=Math.hypot(h.x-cxp,h.y-cyp),lim=Math.max(30,h.r*1.7);if(d<lim&&d<bd){bd=d;best=h}});return best}
function pinchMid(){const a=[...ptrs.values()];return[(a[0].x+a[1].x)/2,(a[0].y+a[1].y)/2]}
function pinchDist(){const a=[...ptrs.values()];return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)||1}
cv.addEventListener('pointerdown',e=>{if(UI.opt){UI.opt=false;mapwrap.classList.remove('opt')}ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});try{cv.setPointerCapture(e.pointerId)}catch(x){}cam.vy=cam.vp=0;VW.vy=VW.vp=0;
 if(ptrs.size===2){cam.pinch={d:pinchDist(),z:is2D()?VW.z:cam.zoom,m:pinchMid()};cam.drag=null}else if(ptrs.size===1)cam.drag={x:e.clientX,y:e.clientY,moved:false}});
cv.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect();
 if(!ptrs.has(e.pointerId)){const h=pickAt(e.clientX-r.left,e.clientY-r.top);const id=h?h.g.id:null;if(id!==UI.hover){UI.hover=id;cv.style.cursor=id?'pointer':'grab'}return}
 ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(cam.pinch&&ptrs.size>=2){const zz=clamp(cam.pinch.z*pinchDist()/cam.pinch.d,.55,3);if(is2D())VW.z=zz;else{cam.zoom=zz;const m=pinchMid(),mx=m[0]-cam.pinch.m[0],my=m[1]-cam.pinch.m[1];cam.yaw+=mx*.006;cam.pit=clamp(cam.pit+my*.0045,-1.2,1.2);cam.pinch.m=m}return}
 if(!cam.drag)return;const dx=e.clientX-cam.drag.x,dy=e.clientY-cam.drag.y;if(Math.abs(dx)+Math.abs(dy)>5)cam.drag.moved=true;
 if(cam.drag.moved&&is2D()){if(WL.foc&&S.set.mode==='wall'){WL.foc.scT=clamp(WL.foc.scT-(e.clientY-cam.drag.y)/VW.z,0,WL.foc.max||0);cam.drag.y=e.clientY;cam.drag.x=e.clientX}return}else if(cam.drag.moved){cam.yaw+=dx*.0075;cam.pit=clamp(cam.pit+dy*.0055,-1.2,1.2);cam.vy=dx*.0075*.9;cam.vp=dy*.0055*.9;cam.drag.x=e.clientX;cam.drag.y=e.clientY;showFsx()}});
const endPtr=e=>{ptrs.delete(e.pointerId);if(ptrs.size<2)cam.pinch=null};
cv.addEventListener('pointerup',e=>{const wasTap=cam.drag&&!cam.drag.moved&&ptrs.size===1;const r=cv.getBoundingClientRect();endPtr(e);if(!ptrs.size)cam.drag=null;if(wasTap)onTap(e.clientX-r.left,e.clientY-r.top)});
cv.addEventListener('pointercancel',e=>{endPtr(e);if(!ptrs.size)cam.drag=null});
cv.addEventListener('pointerleave',()=>{UI.hover=null});
cv.addEventListener('wheel',e=>{e.preventDefault();if(WL.foc&&S.set.mode==='wall'){WL.foc.scT=clamp(WL.foc.scT+e.deltaY,0,WL.foc.max||0);return}const f=e.deltaY<0?1.1:.91;if(is2D())VW.z=clamp(VW.z*f,.55,3);else cam.zoom=clamp(cam.zoom*f,.55,3)},{passive:false});
cv.addEventListener('dblclick',()=>resetView());
/* stop the browser zooming the whole page while pinching the visual */
['touchstart','touchmove'].forEach(n=>cv.addEventListener(n,e=>{if(e.touches&&e.touches.length>1)e.preventDefault()},{passive:false}));
['gesturestart','gesturechange','gestureend'].forEach(n=>{cv.addEventListener(n,e=>e.preventDefault());document.addEventListener(n,e=>e.preventDefault())});
document.addEventListener('touchmove',e=>{if(e.touches&&e.touches.length>1&&e.target.closest&&e.target.closest('#mapwrap'))e.preventDefault()},{passive:false});
function onTap(x,y){if(UI.opt){UI.opt=false;mapwrap.classList.remove('opt')}const h=pickAt(x,y);if(!h){const lk=!is2D()&&pickLink(x,y);if(lk){insLink(lk.a,lk.b);return}const bk=is2D()&&pathBrickAt(x,y);if(bk){if(bk.add)wallNew(bk.add);else if(bk.wb)wallHit(bk);else if(bk.wall)wallFocus(bk.g.id);else insGoal(bk.g.id,INS.on?INS.tab:'ov');return}if(INS.on){insClose();return}if(UI.sel){UI.sel=null;renderMapInfo()}return}
 const again=UI.sel===h.g.id;UI.sel=h.g.id;rt(h.g).flash=Math.max(rt(h.g).flash,.5);RINGS.push({x:rt(h.g).x,y:rt(h.g).y,z:rt(h.g).z,r0:h.r,max:h.r*2.4,life:.8,c:h.g.color,w:.6});sfx('tap');
 insGoal(h.g.id,INS.on&&INS.m==='goal'?INS.tab:'ov')}
function resetView(){cam.yaw=.6;cam.pit=.3;cam.zoom=1;cam.vy=cam.vp=0;VW.x=VW.y=0;VW.z=1;VW.yaw=VW.pit=VW.vy=VW.vp=0}
/* full screen */
let fsxT=null;
function showFsx(){if(!UI.fs)return;const b=$('#fsx');b.classList.add('show');clearTimeout(fsxT);fsxT=setTimeout(()=>b.classList.remove('show'),2600)}
function setFS(on){UI.fs=!!on;mapwrap.classList.toggle('fs',UI.fs);document.body.classList.toggle('isfs',UI.fs);
 if(on){try{const p=mapwrap.requestFullscreen&&mapwrap.requestFullscreen();if(p&&p.catch)p.catch(()=>{})}catch(e){}showFsx()}
 else{try{if(document.fullscreenElement)document.exitFullscreen()}catch(e){}$('#fsx').classList.remove('show')}
 setTimeout(size,60);setTimeout(size,350);renderMapInfo()}
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&UI.fs)setFS(false)});
mapwrap.addEventListener('pointermove',()=>{if(UI.fs)showFsx()});mapwrap.addEventListener('pointerdown',()=>{if(UI.fs)showFsx()});

