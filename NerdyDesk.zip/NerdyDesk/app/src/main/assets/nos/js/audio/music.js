/* ===== generative background music: slow evolving pads, soft plucks, deep bass, reverb. No audio files. ===== */
const MUS={nodes:null,timer:null,next:0,step:0,run:false,chord:null};
const MSC={minor:[0,2,3,5,7,8,10],major:[0,2,4,5,7,9,11],dorian:[0,2,3,5,7,9,10],lyd:[0,2,4,6,7,9,11]};
const MTHEME={ember:['dorian',50],blue:['minor',45],universe:['lyd',48],brain:['minor',47],aurora:['major',52],nebula:['dorian',46],sunset:['major',50],matrix:['minor',43],ocean:['lyd',45],gold:['major',48],crimson:['minor',44],arctic:['lyd',50],tokyo:['dorian',49],forest:['major',47],black:['minor',42],micro:['dorian',45]};
const PROG=[[0,5,3,4],[0,3,5,4],[0,4,5,3],[5,3,0,4]];
const mf=m=>440*Math.pow(2,(m-69)/12);
function impulse(a,dur,dec){const len=Math.floor(a.sampleRate*dur),b=a.createBuffer(2,len,a.sampleRate),fi=Math.floor(a.sampleRate*.04);for(let c=0;c<2;c++){const d=b.getChannelData(c);let l1=0,l2=0;for(let i=0;i<len;i++){const n=Math.random()*2-1;l1+=(n-l1)*.16;l2+=(l1-l2)*.2;d[i]=l2*Math.pow(1-i/len,dec)*(i<fi?i/fi:1)*2.2}}return b}
function musInit(){const a=ac();if(!a||MUS.nodes)return !!MUS.nodes;
 /* own gentle path straight to the speakers: no fast limiter, no convolution reverb, so nothing can crackle or pump */
 const master=a.createGain();master.gain.value=0;const comp=a.createDynamicsCompressor();comp.threshold.value=-24;comp.knee.value=30;comp.ratio.value=2;comp.attack.value=.03;comp.release.value=.5;master.connect(comp);comp.connect(a.destination);
 const bus=a.createGain(),dry=a.createGain(),wet=a.createGain();dry.gain.value=.8;wet.gain.value=.5;
 bus.connect(dry);dry.connect(master);
 const d1=a.createDelay(2),d2=a.createDelay(2),fb=a.createGain(),lp=a.createBiquadFilter();d1.delayTime.value=.37;d2.delayTime.value=.61;fb.gain.value=.32;lp.type='lowpass';lp.frequency.value=1800;lp.Q.value=.3;
 bus.connect(d1);bus.connect(d2);d1.connect(lp);d2.connect(lp);lp.connect(fb);fb.connect(d1);fb.connect(d2);lp.connect(wet);wet.connect(master);
 MUS.nodes={master,bus,a};return true}
function musVoice(type,f,t,dur,g,o){const a=MUS.nodes.a,os=a.createOscillator(),gn=a.createGain(),fl=a.createBiquadFilter();os.type=type;os.frequency.value=f;if(o&&o.det)os.detune.value=o.det;fl.type='lowpass';fl.frequency.value=(o&&o.lp)||1400;
 const at=(o&&o.atk)||.02;gn.gain.setValueAtTime(.0001,t);gn.gain.linearRampToValueAtTime(g,t+at);gn.gain.setTargetAtTime(.0001,t+at+(dur*(o&&o.hold||.3)),dur*.35);os.connect(fl);fl.connect(gn);gn.connect(MUS.nodes.bus);os.start(t);const end=t+dur*2+.6;gn.gain.setTargetAtTime(0,t+dur*1.6,.15);os.stop(end)}
const MST={auto:{n:'Match my theme',d:'Key follows your colour theme',step:1.05,den:.5},calm:{n:'Calm',d:'Slow, warm, major',sc:'major',root:48,step:1.35,den:.32},focus:{n:'Focus',d:'Steady and even',sc:'dorian',root:46,step:1.05,den:.45},deep:{n:'Deep',d:'Low and spacious',sc:'minor',root:41,step:1.55,den:.22},bright:{n:'Bright',d:'Lifted and playful',sc:'lyd',root:52,step:.85,den:.7},lofi:{n:'Lo-fi',d:'Soft beat and keys',sc:'dorian',root:50,step:.95,den:.55,beat:1}};
const musSt=()=>MST[S.set.music.st]||MST.auto;
function musScale(){const st=musSt(),th=MTHEME[S.set.theme]||['minor',45],sc=MSC[st.sc||th[0]];return{sc,root:st.root||th[1]}}
function degNote(d,oct){const {sc,root}=musScale(),n=sc.length,o=Math.floor(d/n),i=((d%n)+n)%n;return root+12*(o+(oct||0))+sc[i]}
function musSchedule(){const a=MUS.nodes.a;if(!MUS.run)return;
 while(MUS.next<a.currentTime+3){const t=MUS.next,st=MUS.step,bar=Math.floor(st/8),pg=PROG[Math.floor(bar/4)%PROG.length],deg=pg[bar%4];
  if(st%8===0){MUS.chord=[deg,deg+2,deg+4,deg+(bar%2?6:7)];const dur=8.6;
   MUS.chord.forEach((d,i)=>{const f=mf(degNote(d,i>1?1:0));musVoice('triangle',f,t,dur,.045,{atk:2.4,hold:.55,lp:900+i*180,det:-5});musVoice('sine',f*1.003,t+.05,dur,.04,{atk:2.8,hold:.55,lp:1200,det:5})});
   musVoice('sine',mf(degNote(deg,-2)),t,dur,.11,{atk:.6,hold:.7,lp:300})}
  const ch=MUS.chord||[0,2,4];
  if(Math.random()<musSt().den){const d=ch[Math.floor(Math.random()*ch.length)]+(Math.random()<.5?7:14);musVoice('sine',mf(degNote(d,0)),t+Math.random()*.3,2.2,.05,{atk:.012,hold:.04,lp:3200});musVoice('triangle',mf(degNote(d,0))*2,t+Math.random()*.3,1.2,.012,{atk:.01,hold:.03,lp:4200})}
  if(Math.random()<.1){const d=ch[Math.floor(Math.random()*ch.length)]+14;musVoice('sine',mf(degNote(d,1)),t+.2,3,.03,{atk:.02,hold:.05,lp:5000})}
  if(musSt().beat){const b=st%4;if(b===0)musVoice('sine',58,t,.5,.16,{atk:.004,hold:.05,lp:200});if(b===2)musVoice('triangle',190,t,.18,.05,{atk:.003,hold:.02,lp:900});if(st%2===1)musVoice('triangle',5200,t,.05,.004,{atk:.004,hold:.01,lp:5200})}
  MUS.step++;MUS.next+=musSt().step||1.05}}
function musStart(){if(MUS.run&&MUS.nodes)return;if(!musInit())return;const a=MUS.nodes.a;if(a.state==='suspended'){try{a.resume()}catch(e){}}
 MUS.run=true;MUS.next=a.currentTime+.5;MUS.step=0;MUS.nodes.master.gain.cancelScheduledValues(a.currentTime);MUS.nodes.master.gain.setValueAtTime(0,a.currentTime);MUS.nodes.master.gain.setTargetAtTime(.55*S.set.music.vol,a.currentTime+.3,1.2);
 clearInterval(MUS.timer);MUS.timer=setInterval(()=>{try{musSchedule()}catch(e){}},400);musSchedule()}
function musRestart(){if(!MUS.run||!MUS.nodes)return;const a=MUS.nodes.a,g=MUS.nodes.master.gain;g.cancelScheduledValues(a.currentTime);g.setTargetAtTime(0,a.currentTime,.08);MUS.run=false;clearInterval(MUS.timer);setTimeout(()=>{MUS.chord=null;MUS.run=true;MUS.step=0;MUS.next=a.currentTime+.1;g.cancelScheduledValues(a.currentTime);g.setTargetAtTime(.55*S.set.music.vol,a.currentTime,.4);MUS.timer=setInterval(()=>{try{musSchedule()}catch(e){}},400);try{musSchedule()}catch(e){}},300)}
function musStop(){if(!MUS.nodes){MUS.run=false;return}MUS.run=false;clearInterval(MUS.timer);const a=MUS.nodes.a;MUS.nodes.master.gain.cancelScheduledValues(a.currentTime);MUS.nodes.master.gain.setTargetAtTime(0,a.currentTime,.5)}
function musSync(){if(S.set.music.on){try{ac()}catch(e){}musStart()}else musStop()}
function musVol(){if(MUS.nodes&&MUS.run){const a=MUS.nodes.a;MUS.nodes.master.gain.setTargetAtTime(.55*S.set.music.vol,a.currentTime,.2)}}
/* a bright pentatonic bell on every fire, in key with the music */
function musFire(){if(!MUS.run||!MUS.nodes)return;const a=MUS.nodes.a,t=a.currentTime+.02,base=[0,2,4,6,9];base.slice(0,4).forEach((d,i)=>{musVoice('sine',mf(degNote(d+7,1)),t+i*.09,2.4,.06,{atk:.01,hold:.05,lp:5200});musVoice('triangle',mf(degNote(d+7,2)),t+i*.09,1.4,.014,{atk:.01,hold:.04,lp:6000})})}
document.addEventListener('visibilitychange',()=>{if(!MUS.nodes)return;try{if(document.hidden)MUS.nodes.a.suspend();else if(S.set.music.on||S.set.snd.on)MUS.nodes.a.resume()}catch(e){}});
