/* ===== focus session: prepare, run a timer, reflect, then it logs the rep ===== */
const FOC=(()=>{let F=null,wl=null,iv=null;
 const el=()=>$('#focus'),elapsed=()=>F?F.acc+(F.paused||!F.t0?0:Date.now()-F.t0):0,fmt=s=>pad(Math.floor(s/60))+':'+pad(s%60);
 async function lock(on){try{if(on&&navigator.wakeLock){wl=await navigator.wakeLock.request('screen')}else if(wl){wl.release();wl=null}}catch(e){}}
 function open(id){const g=gById(id);if(!g)return;if(isB(g)){openDrawer(id,'log');return}
  if(UI.fs)setFS(false);closeDrawer(true);F={id,phase:'prep',intent:'',mins:g.defMin>0?g.defMin:30,acc:0,t0:0,paused:false,dist:0,q:3,e:3,note:'',vals:{},ck:(g.chk[todayKey()]||[]).slice(),rang:false};
  el().hidden=false;document.body.style.overflow='hidden';sfx('open');render()}
 function close(){if(iv)clearInterval(iv);iv=null;lock(false);F=null;el().hidden=true;el().innerHTML='';document.body.style.overflow=''}
 const steps=()=>{const p={prep:0,run:1,reflect:2}[F.phase];return `<div class="fsteps">${[0,1,2].map(i=>`<i class="${i<=p?'on':''}"></i>`).join('')}</div>`};
 const keep=()=>{const n=$('#f-note');if(n)F.note=n.value;const i=$('#f-int');if(i)F.intent=i.value;$$('#focus [data-ff]').forEach(x=>F.vals[x.dataset.ff]=x.value)};
 function render(){if(!F)return;const g=gById(F.id);if(!g)return close();const e=el();e.style.setProperty('--c',g.color);let h=`<div class="fwrap"><div class="fhead"><button class="btn sm" data-act="fexit">${ic('back',14)} ${F.phase==='run'?'Leave session':'Back'}</button><span class="sp"></span><button class="ibtn" data-act="fexit" aria-label="Close">${ic('x')}</button></div>${steps()}`;
  if(F.phase==='prep'){const n=g.tasks.length;
   h+=`<div class="xs mute">Step 1 of 3, prepare</div><h2 style="margin:4px 0 2px">${esc(g.name)}</h2><p class="sm mute" style="margin:0 0 12px">${g.cue?'Cue: '+esc(g.cue)+'. ':''}Preparation is part of the work. Tick what is ready, set one clear target, then go.</p>
   ${n?`<div class="card"><b>What have I prepared? <span class="mute">(${F.ck.length}/${n})</span></b><div class="bar" style="margin:8px 0"><i style="width:${F.ck.length/n*100}%;background:${g.color}"></i></div>${g.tasks.map((t,i)=>`<label class="togg" style="margin:6px 0" data-act="fck" data-i="${i}"><span class="sw ${F.ck.includes(i)?'on':''}"></span><span>${esc(t)}</span></label>`).join('')}</div>`:'<div class="card sm" style="border-left:3px solid var(--c)">No prep checklist yet. Add some in the goal\'s Plan tab, because prepared sessions usually score higher.</div>'}
   <label class="f">My target for this session</label><input type="text" id="f-int" value="${esc(F.intent)}" placeholder="e.g. Finish 20 pages, or 3 clean setups only">
   <div class="xs mute" style="margin-top:12px;text-align:center">How long?</div><div class="durs">${[10,15,25,30,45,60,90].map(m=>`<button class="btn sm ${F.mins===m?'pri':''}" data-act="fmins" data-v="${m}">${m} min</button>`).join('')}<input type="number" id="f-cm" min="1" max="600" style="width:90px" placeholder="custom"></div>
   <div class="row" style="margin-top:14px"><button class="btn" data-act="fcancel">Cancel</button><button class="btn pri" style="flex:2" data-act="fgo">Start ${F.mins} min focus</button></div>`}
  else if(F.phase==='run'){const tot=F.mins*60,left=Math.max(0,tot-Math.floor(elapsed()/1000)),C=2*Math.PI*46,pr=Math.min(1,elapsed()/1000/tot);
   h+=`<div class="xs mute" style="text-align:center">Step 2 of 3, focus</div><h2 style="text-align:center;margin:4px 0">${esc(g.name)}</h2>${F.intent?`<p class="sm mute" style="text-align:center;margin:0">Target: ${esc(F.intent)}</p>`:''}
   <div class="tring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" stroke="rgba(255,255,255,.1)"/><circle id="f-arc" cx="50" cy="50" r="46" stroke="${g.color}" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-pr)}"/></svg><div class="tx"><div><b id="f-t">${fmt(left)}</b><div class="sm mute" id="f-s">${F.paused?'Paused':left===0?'Time is up, keep going or finish':'Stay with it'}</div></div></div></div>
   <div class="row wrapr" style="justify-content:center"><button class="btn" data-act="fpause">${F.paused?'Resume':'Pause'}</button><button class="btn" data-act="fplus">+5 min</button><button class="btn" data-act="fdist">Distracted <b id="f-d">${F.dist}</b></button></div>
   <div class="row" style="margin-top:12px"><button class="btn danger" data-act="fabort">Abandon</button><button class="btn pri" style="flex:2" data-act="ffinish">Finish and reflect</button></div>
   <p class="xs mute" style="text-align:center;margin-top:10px">Tap Distracted every time your attention slips. It is data for your Insights, not a penalty.</p>`}
  else{const mins=Math.max(1,Math.round(elapsed()/60000));
   h+=`<div class="xs mute">Step 3 of 3, reflect</div><h2 style="margin:4px 0">${mins} minute${mins>1?'s':''} of focus</h2>${F.intent?`<p class="sm mute" style="margin:0 0 8px">Target was: ${esc(F.intent)}</p>`:''}
   <div class="sm mute">Did I hit my target? Focus quality</div><div class="q5">${[1,2,3,4,5].map(n=>`<button data-act="fq" data-v="${n}" class="${F.q===n?'on':''}">${n}</button>`).join('')}</div>
   <div class="sm mute">Energy</div><div class="q5">${[1,2,3,4,5].map(n=>`<button data-act="fe" data-v="${n}" class="${F.e===n?'on':''}">${n}</button>`).join('')}</div>
   ${g.fields.filter(f=>f.type==='number'||f.type==='text').map(f=>`<label class="f">${esc(f.label)}${f.unit?' ('+esc(f.unit)+')':''}</label><input data-ff="${f.id}" type="${f.type==='number'?'number':'text'}" ${f.type==='number'?'step="any"':''} value="${esc(F.vals[f.id]||'')}" placeholder="${f.ex!==''&&f.ex!=null?'e.g. '+esc(f.ex):''}">`).join('')}
   ${g.tasks.length?`<div class="sm mute" style="margin-top:8px">Checklist</div>${g.tasks.map((t,i)=>`<label class="togg" style="margin:6px 0" data-act="fck" data-i="${i}"><span class="sw ${F.ck.includes(i)?'on':''}"></span><span>${esc(t)}</span></label>`).join('')}`:''}
   <label class="f">Note</label><textarea id="f-note" rows="2" placeholder="What worked, what pulled me away">${esc(F.note)}</textarea>
   <div class="row" style="margin-top:12px"><button class="btn" data-act="fdiscard">Discard</button><button class="btn pri" style="flex:2" data-act="fsave">Save session</button></div>`}
  e.innerHTML=h+'</div>'}
 function tick(){if(!F||F.phase!=='run')return;const g=gById(F.id),tot=F.mins*60,s=Math.floor(elapsed()/1000),left=Math.max(0,tot-s),t=$('#f-t');if(!t)return;t.textContent=fmt(left);
  const C=2*Math.PI*46,a=$('#f-arc');if(a)a.setAttribute('stroke-dashoffset',C*(1-Math.min(1,s/tot)));
  if(left===0&&!F.rang)alarm(g);if(F.rang&&!F.paused&&F.rep<6&&Date.now()-F.lastRing>9000){F.rep++;F.lastRing=Date.now();sfx('badge');navigator.vibrate&&navigator.vibrate([200,100,200])}}
 function alarm(g){F.rang=true;F.rep=0;F.lastRing=Date.now();sfx('badge');setTimeout(()=>sfx('bell'),500);navigator.vibrate&&navigator.vibrate([300,120,300,120,300]);const st=$('#f-s');if(st)st.textContent="Time's up. Keep going or finish.";el().classList.add('up');if(document.hidden||!document.hasFocus())sysNotify('Focus complete',g.name+': '+F.mins+' minutes done. Open the app to finish and reflect.',{tag:'focus'+g.id,goal:g.id});else toast("Focus complete: "+g.name)}
 const armed2=(b,t)=>{if(b.dataset.arm){return true}b.dataset.arm=1;const o=b.innerHTML;b.textContent=t;setTimeout(()=>{if(b.isConnected){delete b.dataset.arm;b.innerHTML=o}},2500);return false};
 ACT.fmins=el=>{keep();F.mins=+el.dataset.v;render()};
 ACT.fcancel=()=>close();
 ACT.fexit=el=>{if(F.phase==='prep'||F.phase==='reflect'&&false){close();return}if(armed2(el,'Tap again to leave (session is not saved)'))close()};
 function schedSW(){try{if(navigator.serviceWorker&&navigator.serviceWorker.controller){const g=gById(F.id);navigator.serviceWorker.controller.postMessage({type:'focusTimer',at:Date.now()+(F.mins*60000-elapsed()),title:'Focus complete',body:g.name+': '+F.mins+' minutes done. Open the app to finish and reflect.',tag:'focus'+g.id})}}catch(e){}}
 ACT.fdiscard=el=>{if(armed2(el,'Tap again to discard'))close()};ACT.fabort=el=>{if(armed2(el,'Tap again to abandon'))close()};
 ACT.fgo=()=>{keep();const cm=+($('#f-cm')||{}).value;if(cm>0)F.mins=Math.min(600,cm);if('Notification' in window&&Notification.permission==='default')try{Notification.requestPermission()}catch(e){}
  F.phase='run';F.t0=Date.now();F.acc=0;F.paused=false;lock(true);schedSW();if(iv)clearInterval(iv);iv=setInterval(tick,400);render();sfx('tap')};
 ACT.fpause=()=>{if(F.paused){F.t0=Date.now();F.paused=false;schedSW()}else{F.acc+=Date.now()-F.t0;F.paused=true}render()};
 ACT.fplus=()=>{F.mins+=5;F.rang=false;el().classList.remove('up');schedSW();render()};
 ACT.fdist=()=>{F.dist++;const x=$('#f-d');if(x)x.textContent=F.dist;sfx('untick')};
 ACT.ffinish=()=>{if(!F.paused){F.acc+=Date.now()-F.t0;F.paused=true}F.phase='reflect';if(iv)clearInterval(iv);lock(false);sfx('bell');render()};
 ACT.fq=el=>{keep();F.q=+el.dataset.v;render()};ACT.fe=el=>{keep();F.e=+el.dataset.v;render()};
 ACT.fck=el=>{keep();const i=+el.dataset.i,j=F.ck.indexOf(i);j<0?F.ck.push(i):F.ck.splice(j,1);sfx('tick');render()};
 ACT.fsave=()=>{keep();const g=gById(F.id),k=todayKey(),secs=Math.floor(elapsed()/1000),f={};Object.keys(F.vals).forEach(id=>{if(F.vals[id]!=='')f[id]=F.vals[id]});
  const o={min:Math.max(1,Math.round(secs/60)),q:F.q,en:F.e,note:F.note,intent:F.intent,focusSecs:secs,dist:F.dist};if(Object.keys(f).length)o.f=Object.assign({},(g.logs[k]||{}).f,f);
  const old=logDone(g,k,o);g.chk[k]=F.ck.slice();const m=o.min;close();afterLog(g);toast('Session saved: '+m+' min. '+doneCount(g)+' reps wired in.',undoer(g,k,old))};
 setInterval(()=>{if(F&&F.phase==='run')tick()},1000);
 document.addEventListener('visibilitychange',()=>{if(F&&F.phase==='run'&&!document.hidden){if(!wl)lock(true);tick()}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&F&&F.phase==='prep')close()});
 return{open,close,active:()=>!!F}})();
ACT.focus=el=>FOC.open(el.dataset.id);
ACT.newbuild=()=>{if(UI.fs)setFS(false);openForm(null)};
ACT.newquit=()=>{if(UI.fs)setFS(false);openForm(null);FM=blankGoal('break');FM.isNew=true;renderForm()};
