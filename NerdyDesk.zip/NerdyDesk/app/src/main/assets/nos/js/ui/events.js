/* ===== UI core: icons, toast, theme, actions, log ops, badges ===== */
const IC={play:'<path d="M7 5l12 7-12 7z"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.500 9.500a2.500 2.500 0 114 2c-1 .7-1.500 1.200-1.500 2.500M12 17h.01"/>',opt:'<path d="M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',goals:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',cal:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',ins:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',jour:'<path d="M5 3h12a2 2 0 012 2v16H7a2 2 0 01-2-2V3zM9 8h6M9 12h6"/>',set:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',plus:'<path d="M12 5v14M5 12h14"/>',check:'<path d="M5 12l5 5 9-10"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',snd:'<path d="M4 9v6h4l5 4V5L8 9H4zM16 9a4 4 0 010 6M18.5 6.5a8 8 0 010 11"/>',mute:'<path d="M4 9v6h4l5 4V5L8 9H4zM17 9l5 6M22 9l-5 6"/>',fs:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',fsx:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',reset:'<path d="M4 4v6h6M20 20v-6h-6M5 14a8 8 0 0014 3M19 10A8 8 0 005 7"/>',bell:'<path d="M6 17V11a6 6 0 0112 0v6l2 2H4l2-2zM10 21h4"/>',dl:'<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',edit:'<path d="M4 20h4L19 9l-4-4L4 16v4z"/>',trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',pause:'<path d="M8 5v14M16 5v14"/>',skip:'<path d="M5 5l10 7-10 7V5zM19 5v14"/>',flame:'<path d="M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',star:'<path d="M12 3l2.7 6 6.3.6-4.8 4.3 1.5 6.3L12 17l-5.7 3.2 1.5-6.3L3 9.6 9.3 9z"/>',back:'<path d="M15 5l-7 7 7 7"/>',fwd:'<path d="M9 5l7 7-7 7"/>'};
const ic=(n,s)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${s?`style="width:${s}px;height:${s}px"`:''} aria-hidden="true">${IC[n]||(GI[n]?`<path d="${GI[n]}"/>`:'')}</svg>`;
function toast(msg,undo){const box=$('#toasts');if(!box)return;const t=document.createElement('div');t.className='toast';t.innerHTML=`<span>${esc(msg)}</span>`;
 if(undo){const b=document.createElement('button');b.textContent='Undo';b.onclick=()=>{undo();t.remove()};t.appendChild(b)}
 [...box.children].forEach(c=>{if(c.firstChild&&c.firstChild.textContent===msg)c.remove()});box.appendChild(t);while(box.children.length>2)box.firstChild.remove();setTimeout(()=>t.remove(),undo?5500:3200)}
function applyTheme(){const th=THEMES[S.set.theme]||THEMES.blue,r=document.documentElement.style;
 ['bg','panel','line','ink','mute','acc','acc2'].forEach(k=>r.setProperty('--'+k,th[k]));r.setProperty('--onacc',lum(th.acc)>.5?'#0a0c12':'#ffffff');
 th.neb.forEach((c,i)=>r.setProperty('--b'+(i+1),'rgb('+c+')'));const m=$('#tcolor');if(m)m.content=th.bg;document.body.classList.toggle('reduce',reduced())}
/* delegated events */
const ACT={},CHG={},INP={};
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;const f=ACT[el.dataset.act];if(f){if(el.tagName!=='A')e.preventDefault();f(el,e)}});
document.addEventListener('change',e=>{const el=e.target.closest('[data-chg]');if(el&&CHG[el.dataset.chg])CHG[el.dataset.chg](el,e)});
document.addEventListener('input',e=>{const el=e.target.closest('[data-inp]');if(el&&INP[el.dataset.inp])INP[el.dataset.inp](el,e)});
/* navigation */
const VIEWS=[['home','Home','home'],['goals','Goals','goals'],['cal','Calendar','cal'],['ins','Insights','ins'],['jour','Journal','jour'],['guide','Guide','book'],['about','About','heart'],['set','Settings','set']];
function buildNav(){const mk=a=>a.map(v=>`<button data-act="nav" data-v="${v[0]}" class="${UI.view===v[0]?'on':''}">${ic(v[2])}<span>${v[1]}</span></button>`).join('');$('#nav').innerHTML=mk(VIEWS);$('#bnav').innerHTML=mk(VIEWS.filter(v=>v[0]!=='guide'));
 $('#addbtn').innerHTML=ic('plus')+'<span>New goal</span>';$('#sndbtn').innerHTML=ic(S.set.snd.on?'snd':'mute');$('#sndbtn').classList.toggle('on',S.set.snd.on);
 $('#musbtn').innerHTML=ic('music');$('#musbtn').classList.toggle('on',!!S.set.music.on);$('#musbtn').title=S.set.music.on?'Music on (tap to turn off)':'Music off (tap to turn on)';$('#guidebtn').innerHTML=ic('help');const bb=$('#brbtn');if(bb)bb.innerHTML=ic('breath');const gb=$('#gmbtn');if(gb)gb.innerHTML=ic('brain');const tb=$('#trbtn');if(tb)tb.innerHTML=ic('dumbbell')}
function go(v){if(!VIEWS.some(x=>x[0]===v))v='home';if(UI.fs)setFS(false);UI.view=v;S.set.view=v;
 $$('.view').forEach(s=>s.classList.toggle('on',s.id==='v-'+v));buildNav();closeDrawer(true);renderView();window.scrollTo(0,0);if(v==='home')setTimeout(size,30)}
ACT.nav=el=>{sfx('nav');go(el.dataset.v)};
ACT.snd=()=>{S.set.snd.on=!S.set.snd.on;save();buildNav();if(S.set.snd.on)sfx('tap')};
ACT.closeall=()=>{closeDrawer();closeModal()};
function renderView(){const v=UI.view;try{({home:renderHome,goals:renderGoals,cal:renderCal,ins:renderIns,jour:renderJour,guide:renderGuide,about:renderAbout,set:renderSet})[v]()}catch(e){console.error(e);showFail(e)}}
function showFail(e){let b=$('#failbar');if(!b){b=document.createElement('div');b.id='failbar';document.body.appendChild(b)}b.innerHTML=`<div><b>Something did not load.</b> <span class="xs">${esc(String(e&&e.message||e).slice(0,140))}</span></div><div class="row" style="gap:8px"><button class="btn sm" data-act="repair">Repair and reload</button><button class="btn sm ghost" data-act="failx">Dismiss</button></div>`}
ACT.failx=()=>{const b=$('#failbar');if(b)b.remove()};
ACT.hardref=async()=>{toast('Refreshing...');try{saveNow()}catch(e){}try{const rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(r=>r.unregister()));const ks=await caches.keys();await Promise.all(ks.map(k=>caches.delete(k)))}catch(e){}location.reload()};
ACT.repair=async()=>{try{S.set.view='home';S.set.splashDay='';S.set.synAll=false;S.set.synGoal='';saveNow()}catch(e){}try{const rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(r=>r.unregister()));const ks=await caches.keys();await Promise.all(ks.map(k=>caches.delete(k)))}catch(e){}location.reload()};
addEventListener('error',e=>{if(e&&e.message&&!/ResizeObserver/.test(e.message))showFail(e.error||e.message)});addEventListener('unhandledrejection',e=>{});
function renderAll(){renderView();if(UI.drawer.id)renderDrawer(true)}
/* ---- log operations ---- */
function afterLog(g,kind){save();checkBadges();renderAll();renderMapInfo()}
function milestone(g){const s=streakInfo(g).n,u=streakInfo(g).unit;if(u!=='d')return;if([3,7,14,21,30,50,66,100].includes(s)){sfx('badge');toast(`${g.name}: ${s}-day streak`);rt(g).flash=1;RINGS.push({x:rt(g).x,y:rt(g).y,z:rt(g).z,r0:10,max:200*UNIT,life:1.2,c:'#ffd23f',w:1})}}
function logDone(g,k,extra){k=k||todayKey();const old=g.logs[k],keep=old&&!old.slip&&!old.skip?old:null;
 const l=Object.assign({},keep||{});if(extra)Object.assign(l,extra);if(!isB(g)&&g.core.min&&l.min==null)l.min=g.defMin||0;l.t=l.t||(k<todayKey()?(g.win&&g.win[0]||'12:00'):hm());if(g.mis)delete g.mis[k];if(!l.at){l.at=Date.now();if(k<todayKey())l.late=1}g.logs[k]=l;
 if(k===todayKey()){const i=Math.max(0,S.goals.indexOf(g));sfx(isB(g)?'clean':'fire',i);fireGoal(g,isB(g)?.7:1);(NB[g.id]||[]).forEach(id=>{const o=gById(id);if(o){const q=rt(o);q.flash=Math.max(q.flash||0,.4)}});if(!reduced()){boom=isB(g)?.5:.75;boomG=g;cam.kick=1}JF[g.id]=Date.now()+1700;try{musFire()}catch(e){}
  const sn=streakInfo(g);try{if(is2D()&&focusG()===g)pathFire(g,{comeback:comebackQ(g,k)})}catch(e){}screenBurst(g,{txt:isB(g)?(sn.n>1?sn.n+(sn.unit==='d'?' clean days':' clean'):'Clean day'):(sn.n>1?sn.n+(sn.unit==='d'?'-day streak':sn.unit+' streak'):'+1 rep')});milestone(g)}
 else screenBurst(g,{small:true,txt:'Logged '+fmtD(k)});
 return old}
function logSlip(g,k,extra){k=k||todayKey();const old=g.logs[k];if(g.mis)delete g.mis[k];g.logs[k]=Object.assign({slip:true,t:hm(),at:Date.now()},k<todayKey()?{late:1}:{},extra||{});sfx('slip');cam.shake=7;const r=rt(g);fragBurst(g,r);screenBreak(g);try{if(is2D()&&focusG()===g)pathFire(g,{slip:true})}catch(e){}return old}
function logSkip(g,k){k=k||todayKey();const old=g.logs[k];if(g.mis)delete g.mis[k];g.logs[k]=Object.assign({skip:true,at:Date.now()},k<todayKey()?{late:1}:{});sfx('skip');return old}
function clearLog(g,k){const old=g.logs[k];delete g.logs[k];sfx('untick');return old}
function undoer(g,k,old){return()=>{if(old)g.logs[k]=old;else delete g.logs[k];afterLog(g)}}
ACT.done=el=>{const g=gById(el.dataset.id);if(!g)return;const k=todayKey();const st=dueState(g,k);
 if(st.s==='done'){const old=clearLog(g,k);afterLog(g);toast('Unmarked '+g.name,undoer(g,k,old));return}
 const old=logDone(g,k);afterLog(g);toast((isB(g)?'Clean day logged: ':'Fired: ')+g.name,undoer(g,k,old))};
ACT.slip=el=>{const g=gById(el.dataset.id);if(!g)return;const k=todayKey(),old=logSlip(g,k);afterLog(g);toast('Slip logged. The old path got stronger, but tomorrow is clean.',undoer(g,k,old))};
ACT.skip=el=>{const g=gById(el.dataset.id);if(!g)return;const k=el.dataset.k||todayKey(),old=logSkip(g,k);afterLog(g);toast('Marked as a planned rest for '+g.name,undoer(g,k,old))};
/* ---- badges ---- */
const BADGES=[
{id:'first',n:'First fire',e:'bolt',d:'Log your first rep',t:()=>S.goals.some(g=>doneCount(g)>0)},
{id:'s3',n:'Spark',e:'spark',d:'3 reps in a row on any goal',t:()=>S.goals.some(g=>gStats(g).best>=3)},
{id:'s7',n:'One week',e:'flame',d:'7 in a row',t:()=>S.goals.some(g=>gStats(g).best>=7)},
{id:'s21',n:'Three weeks',e:'sprout',d:'21 in a row',t:()=>S.goals.some(g=>gStats(g).best>=21)},
{id:'s66',n:'Automatic',e:'brain',d:'66 days in a row. In one study that was the average time to feel automatic. Yours may take less or more',t:()=>S.goals.some(g=>gStats(g).best>=66)},
{id:'s100',n:'Centurion',e:'trophy',d:'100 reps on one goal',t:()=>S.goals.some(g=>doneCount(g)>=100)},
{id:'r10',n:'Ten reps',e:'check',d:'10 reps on one goal',t:()=>S.goals.some(g=>doneCount(g)>=10)},
{id:'r50',n:'Fifty reps',e:'star',d:'50 reps on one goal',t:()=>S.goals.some(g=>doneCount(g)>=50)},
{id:'multi',n:'Many circuits',e:'web',d:'3 active goals',t:()=>S.goals.filter(g=>!g.paused).length>=3},
{id:'five',n:'Constellation',e:'globe',d:'5 active goals',t:()=>S.goals.filter(g=>!g.paused).length>=5},
{id:'perfect',n:'Perfect day',e:'sun',d:'Finish everything due in a day (at least 2 goals)',t:()=>{const s=dayStat(todayKey());return s.opp>=2&&s.done===s.opp}},
{id:'quit7',n:'Fading path',e:'shield',d:'7 clean days on a quit goal',t:()=>S.goals.some(g=>isB(g)&&gStats(g).best>=7)},
{id:'quit30',n:'Pathway pruned',e:'cut',d:'30 clean days on a quit goal',t:()=>S.goals.some(g=>isB(g)&&gStats(g).best>=30)},
{id:'bounce',n:'Bounce back',e:'pulse',d:'Return to a goal the day after a slip or miss',t:()=>S.goals.some(g=>{const ks=Object.keys(g.logs).sort();for(let i=1;i<ks.length;i++){if(g.logs[ks[i-1]].slip&&isDoneL(g.logs[ks[i]])&&diffD(ks[i-1],ks[i])===1)return true}return false})},
{id:'hour10',n:'Ten hours',e:'clock',d:'10 hours logged in total',t:()=>sum(S.goals.map(g=>gStats(g).hours))>=10},
{id:'hour50',n:'Fifty hours',e:'clock',d:'50 hours logged in total',t:()=>sum(S.goals.map(g=>gStats(g).hours))>=50},
{id:'must',n:'Kept the Must',e:'crown',d:'Finish a Must goal 7 days running',t:()=>S.goals.some(g=>g.priority==='must'&&gStats(g).best>=7)},
{id:'review',n:'Reflector',e:'notebook',d:'Write a goal review',t:()=>S.goals.some(g=>(g.reviews||[]).length)},
{id:'journal',n:'Daily check-in',e:'pen',d:'Log mood and sleep on 7 days',t:()=>Object.keys(S.daily).filter(k=>S.daily[k]&&(S.daily[k].mood||S.daily[k].sleep)).length+(S.journal||[]).length>=7},
{id:'weekend',n:'Weekend warrior',e:'sun',d:'Log a rep on a Saturday and Sunday of the same weekend',t:()=>S.goals.some(g=>Object.keys(g.logs).some(k=>dow(k)===6&&isDoneL(g.logs[k])&&isDoneL(g.logs[addD(k,1)])))},
{id:'early',n:'Early bird',e:'sun',d:'Log something before 7 AM',t:()=>S.goals.some(g=>Object.values(g.logs).some(l=>l.t&&l.t<'07:00'&&isDoneL(l)))},
{id:'night',n:'Night owl',e:'moon',d:'Log something after 10 PM',t:()=>S.goals.some(g=>Object.values(g.logs).some(l=>l.t&&l.t>='22:00'&&isDoneL(l)))},
{id:'round',n:'Round complete',e:'target',d:'Finish a goal round with 80% or better adherence',t:()=>S.goals.some(g=>g.end<todayKey()&&(adherence(g)||0)>=.8)},
{id:'export',n:'Backed up',e:'save',d:'Export your data',t:()=>!!S.set.lastExport}];
let BADGE_QUIET=true;
function checkBadges(){const have=new Set(S.badges.map(b=>typeof b==='string'?b:b.id));let n=0;BADGES.forEach(b=>{if(have.has(b.id))return;let ok=false;try{ok=b.t()}catch(e){}if(ok){S.badges.push({id:b.id,d:todayKey()});n++;if(!BADGE_QUIET){sfx('badge');toast(`Badge earned: ${b.n}`)}}});if(n)save()}
/* ---- small chart helpers ---- */
function spark(vals,o){o=o||{};const w=o.w||300,h=o.h||70,c=o.c||'var(--acc)';if(vals.length<2)return `<div class="mute sm">Not enough data yet.</div>`;
 const mn=o.min!=null?o.min:Math.min(...vals),mx=o.max!=null?o.max:Math.max(...vals),sp=(mx-mn)||1,pts=vals.map((v,i)=>[i/(vals.length-1)*(w-8)+4,h-6-(v-mn)/sp*(h-12)]);
 const d=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join('');
 return `<svg class="svgc" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path d="${d}L${w-4} ${h-2}L4 ${h-2}Z" fill="${c}" opacity=".13"/><path d="${d}" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`}
function bars(items,o){o=o||{};const w=o.w||320,h=o.h||110,mx=Math.max(1,...items.map(i=>i.v)),bw=w/items.length;
 return `<svg class="svgc" viewBox="0 0 ${w} ${h+18}">${items.map((it,i)=>{const bh=it.v/mx*h,tp=`data-tip="${esc(it.l)}: ${Math.round(it.v*10)/10}${it.t?'\n'+esc(it.t):''}"`,rc=it.k?`data-act="rec" data-k="${it.k}" style="cursor:pointer"`:'';return `<rect x="${i*bw+bw*.15}" y="${h-bh}" width="${bw*.7}" height="${Math.max(1,bh)}" rx="3" fill="${it.c||'var(--acc)'}" opacity="${it.v?1:.25}" pointer-events="none"/><rect class="hit" x="${i*bw}" y="0" width="${bw}" height="${h+16}" ${tp} ${rc}/><text x="${i*bw+bw/2}" y="${h+13}" text-anchor="middle" font-size="10" fill="var(--mute)">${esc(it.l)}</text>${it.v&&items.length<=14?`<text x="${i*bw+bw/2}" y="${h-bh-3}" text-anchor="middle" font-size="9.5" fill="var(--ink)">${Math.round(it.v*10)/10}</text>`:''}`}).join('')}</svg>`}
function ringSvg(p,c,sz){const r=24,C=2*Math.PI*r;return `<svg viewBox="0 0 56 56"><circle cx="28" cy="28" r="${r}" fill="none" stroke="color-mix(in srgb,var(--ink) 10%,transparent)" stroke-width="5"/><circle cx="28" cy="28" r="${r}" fill="none" stroke="${c}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${(C*clamp(p,0,1)).toFixed(1)} ${C.toFixed(1)}"/></svg>`}
const pct=v=>v==null?'–':Math.round(v*100)+'%';
const dur=m=>m>=60?(Math.floor(m/60)+'h '+Math.round(m%60)+'m'):Math.round(m)+'m';

