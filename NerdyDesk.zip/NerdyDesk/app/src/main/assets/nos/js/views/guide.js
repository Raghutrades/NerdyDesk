/* ===== v5 Guide: one clean pass, grouped by what you are doing, with search ===== */
const GQ={q:''};
function guideSecs(){const N=G_NEW.slice(),take=re=>{const o=[];for(let i=N.length-1;i>=0;i--)if(re.test(N[i][1]+' '+N[i][0])){o.unshift(N[i]);N.splice(i,1)}return o};
 const trade=take(/trading/i),music=take(/music|sound|station/i),ins=take(/insight|progress|metric|dashboard|trace/i),mind=take(/breath|journal|pulse|mood|meditat/i),games=take(/game|train|workout/i),board=take(/board|layout|adding|man |house|late entr|closeout|tab/i);
 const R=(a,raw)=>a.map(s=>[s[0],raw?s[1]:esc(s[1]),raw?s[2]:esc(s[2])]);
 return [
  ['Start here','Add something, tick it, watch it grow','target',R(G_STEPS).concat(R(board,1))],
  ['Habits, quitting and daily tasks','Build, quit and task goals, why and end goal, alternatives','shield',R(G_QUIT).concat(R(N,1))],
  ['Insights and metrics','What every number means in plain words','chart',R(ins,1)],
  ['Mind: breathe, meditate, pulse, journal','Calm, focus, sleep, urge SOS, mood faces','breathe',R(G_BREATH,1).concat(R(mind,1))],
  ['Train and games','Workouts with sets and timing, brain games','train',R(G_TRAIN,1).concat(R(games,1))],
  ['Trading desk','Pre-market, live, post-market, ritual and insights','chart',R(trade,1)],
  ['Music and sound','Six stations, volume, soft sound effects','music',R(music,1)],
  ['Reading the map','Orbit, Synapse, Path, Ladder, Tree, House, Board','globe',R(G_MAP)]]}
function renderGuide(){const q=GQ.q.trim().toLowerCase(),S0=guideSecs(),mk=s=>`<div class="card gstep"><div class="row"><span class="gico" style="--c:var(--acc)">${ic(s[0],16)}</span><b>${s[1]}</b></div><p class="sm mute" style="margin:8px 0 0">${s[2]}</p></div>`,
 hit=s=>!q||(s[1]+' '+s[2]).toLowerCase().includes(q);
 const secs=S0.map((x,i)=>{const items=x[3].filter(hit);if(!items.length)return '';return `<details class="gsec" ${q||i===0?'open':''}><summary><span class="gico" style="--c:var(--acc)">${ic(x[2],16)}</span><span><b>${x[0]}</b><small>${x[1]}</small></span><em>${items.length}</em></summary><div class="grid g2">${items.map(mk).join('')}</div></details>`}).join('');
 const sci=[...G_WHY,...G_FAQ].filter(a=>!q||(a[0]+' '+a[1]).toLowerCase().includes(q)),det=a=>`<details class="gdet"><summary>${esc(a[0])}</summary><p>${esc(a[1])}</p></details>`;
 $('#guidec').innerHTML=`<h1 class="pgt">Guide</h1><input id="gdq" class="bsin gpq" placeholder="Search the guide" value="${esc(GQ.q)}" data-inp="gdq" autocomplete="off">
 ${q?'':`<div class="ghero card"><div class="serif" style="font-size:22px;line-height:1.25">Repeat something and its circuit gets stronger. This app lets you watch that happen.</div><div class="row wrapr" style="gap:8px;margin-top:10px"><button class="btn pri" data-act="tour">${ic('fwd',14)} Replay the quick tour</button><button class="btn" data-act="nav" data-v="set">Settings</button></div></div>
 <div class="card" style="margin-top:12px"><h3>Your rhythm</h3><div class="col" style="gap:8px;margin-top:6px">${G_RHYTHM.map(r=>`<div class="sm"><b>${esc(r[0])}.</b> <span class="mute">${esc(r[1])}</span></div>`).join('')}</div></div>`}
 <div style="margin-top:12px">${secs||'<div class="card mute sm">Nothing matches that search.</div>'}</div>
 ${sci.length?`<details class="gsec" ${q?'open':''}><summary><span class="gico" style="--c:var(--acc)">${ic('brain',16)}</span><span><b>Why it works, limits and questions</b><small>The science, and where it stops</small></span><em>${sci.length}</em></summary><div class="card gwhy">${sci.map(det).join('')}</div>${q?'':`<div class="card" style="margin-top:8px"><h3>How the strength score works</h3><p class="sm mute" style="margin:6px 0 0">Each scheduled day is a chance. A rep adds to the score, a scheduled day with no record lets it fade slowly, and small samples are discounted so a short perfect run does not fool you. It is an estimated model, not a measurement. ${esc(G_LIMITS)}</p></div>`}</details>`:''}`}
INP.gdq=el=>{GQ.q=el.value;clearTimeout(GQ.t);GQ.t=setTimeout(()=>{renderGuide();const i=$('#gdq');if(i){i.focus();i.setSelectionRange(99,99)}},250)};
