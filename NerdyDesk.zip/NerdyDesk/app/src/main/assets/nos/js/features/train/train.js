/* ===== Core Axon: guided core-strength training with an animated figure, timing you control, calories and tracking ===== */
IC.dumbbell=IC.dumbbell||'<path d="M6 8v8M18 8v8M3 10v4M21 10v4M6 12h12"/>';
/* side-view poses: head, shoulder, hip, knee, ankle, elbow, hand */
const TP={
 plank:{h:[62,33],s:[54,37],p:[34,41],k:[22,45],a:[10,50],e:[54,48],w:[62,49]},
 high:{h:[62,30],s:[54,34],p:[34,40],k:[22,45],a:[10,50],e:[55,43],w:[56,50]},
 tap:{h:[62,30],s:[54,34],p:[34,40],k:[22,45],a:[10,50],e:[58,38],w:[60,28]},
 side:{h:[60,26],s:[50,31],p:[34,38],k:[22,44],a:[10,50],e:[50,46],w:[60,48]},
 sideup:{h:[60,22],s:[50,27],p:[34,31],k:[22,40],a:[10,50],e:[50,46],w:[60,48]},
 dbA:{h:[14,46],s:[24,46],p:[44,46],k:[44,28],a:[56,28],e:[24,32],w:[24,20]},
 dbB:{h:[14,46],s:[24,46],p:[44,46],k:[56,40],a:[70,44],e:[14,38],w:[6,44]},
 bdA:{h:[62,28],s:[52,32],p:[32,32],k:[32,48],a:[22,50],e:[52,42],w:[52,50]},
 bdB:{h:[62,28],s:[52,32],p:[32,32],k:[20,32],a:[6,32],e:[64,32],w:[76,30]},
 holl:{h:[12,36],s:[20,40],p:[40,46],k:[54,40],a:[68,32],e:[8,30],w:[0,26]},
 hollB:{h:[16,32],s:[24,38],p:[40,46],k:[56,38],a:[70,28],e:[12,26],w:[4,22]},
 crL:{h:[10,46],s:[22,46],p:[40,46],k:[48,32],a:[58,46],e:[16,44],w:[12,40]},
 crU:{h:[22,34],s:[28,38],p:[40,46],k:[48,32],a:[58,46],e:[30,36],w:[24,32]},
 brD:{h:[10,46],s:[22,46],p:[40,46],k:[52,34],a:[58,46],e:[28,46],w:[36,46]},
 brU:{h:[10,46],s:[22,44],p:[40,30],k:[52,32],a:[58,46],e:[28,46],w:[36,46]},
 supD:{h:[14,46],s:[26,46],p:[42,46],k:[54,46],a:[66,46],e:[16,46],w:[6,46]},
 supU:{h:[14,40],s:[26,43],p:[42,46],k:[54,42],a:[66,38],e:[16,38],w:[6,34]},
 st:{h:[40,10],s:[40,20],p:[40,34],k:[40,44],a:[40,52],e:[40,28],w:[40,36]},
 stK:{h:[40,10],s:[40,20],p:[40,34],k:[50,32],a:[48,44],e:[34,26],w:[44,22]},
 stO:{h:[44,10],s:[42,20],p:[40,34],k:[52,32],a:[50,44],e:[48,26],w:[44,18]},
 cow:{h:[62,40],s:[52,36],p:[30,36],k:[30,48],a:[22,50],e:[52,46],w:[52,50]},
 cat:{h:[56,38],s:[52,32],p:[30,28],k:[30,48],a:[22,50],e:[52,46],w:[52,50]},
 child:{h:[56,46],s:[44,44],p:[20,46],k:[28,48],a:[14,50],e:[54,48],w:[66,50]},
 vsit:{h:[22,20],s:[26,30],p:[38,46],k:[50,36],a:[62,28],e:[40,34],w:[56,32]},
 vlow:{h:[14,32],s:[20,38],p:[38,46],k:[52,40],a:[66,38],e:[34,38],w:[54,40]},
 flA:{h:[10,46],s:[22,46],p:[40,46],k:[52,43],a:[66,40],e:[16,46],w:[24,46]},
 flB:{h:[10,46],s:[22,46],p:[40,46],k:[52,45],a:[66,45],e:[16,46],w:[24,46]}};
/* id:[name, region (f front, s sides, b back, m mobility), MET, work seconds, poseA, poseB, cue, easier, harder, sideSplit] */
const TX={
 plank:['Forearm plank','f',3.8,40,'plank','plank','Ribs down, squeeze glutes, long line from head to heels','Knee plank','Long-lever plank',0],
 deadbug:['Dead bug','f',3.5,40,'dbA','dbB','Lower back stays heavy on the floor','Heel taps','Slow lower',0],
 birddog:['Bird dog','b',3.5,40,'bdA','bdB','Reach long, keep hips level','Arm only','Pause and elbow to knee',0],
 hollow:['Hollow hold','f',4,30,'holl','hollB','Low back pressed down, chin tucked','Bent knees','Arms overhead, legs low',0],
 taps:['Plank shoulder taps','f',4,40,'high','tap','Hips still while the hand taps','Wide feet','Feet together',0],
 bridge:['Glute bridge','b',3.2,40,'brD','brU','Push through heels, squeeze at the top','Shorter range','Single leg',0],
 sideplank:['Side plank','s',3.5,30,'side','side','Stack hips, push the floor away','Knee side plank','Top leg lift',1],
 twist:['Russian twist','s',3.8,40,'vlow','vlow','Rotate from the ribs, not the arms','Feet down','Feet up',0],
 bicycle:['Bicycle crunch','s',4,40,'crL','crU','Slow elbow to opposite knee','Smaller range','Hold each side',0],
 standcrunch:['Standing oblique crunch','s',3.3,40,'st','stO','Bring knee up to the elbow, stay tall','Smaller range','Add a pause',0],
 xclimb:['Cross-body mountain climbers','s',6,30,'high','tap','Drive the knee toward the opposite elbow','Slow down','Faster',0],
 hipdip:['Side-plank hip dips','s',3.8,30,'sideup','side','Lower and lift the hip with control','Knee version','Hold at the bottom',1],
 climber:['Mountain climbers','f',8,30,'high','tap','Quick feet, hips low','Slow tempo','Faster',0],
 jacks:['Plank jacks','f',6,30,'high','tap','Jump feet wide and together, hips steady','Step out','Faster',0],
 flutter:['Flutter kicks','f',3.8,40,'flA','flB','Small fast kicks, low back down','Bend the knees','Lower legs',0],
 vups:['V-ups','f',5,30,'holl','vsit','Reach hands to toes','Tuck-ups','Slower lower',0],
 highknees:['High knees','f',7,30,'st','stK','Light feet, drive the knees up','March in place','Faster',0],
 skater:['Skater steps','s',5.5,30,'st','stO','Step wide, soft landing','Smaller steps','Add a hop',0],
 superman:['Superman','b',3.2,40,'supD','supU','Lift chest and legs, look at the floor','Arms only','Hold at the top',0],
 bridgemarch:['Bridge march','b',3.5,40,'brU','brU','Keep hips high and level','Shorter marches','Slow it down',0],
 snowangel:['Reverse snow angels','b',3.2,40,'supD','supU','Sweep arms wide, squeeze shoulder blades','Smaller sweep','Hold a pause',0],
 birdreach:['Bird dog with reach','b',3.8,40,'bdA','bdB','Reach past the toes and fingertips','Arm only','Slow tempo',0],
 sgbridge:['Single-leg glute bridge','b',3.8,30,'brD','brU','Hips level, push through one heel','Two-leg bridge','Add a pause',1],
 ytw:['Prone Y-T-W raises','b',3,40,'supD','supU','Thumbs up, lift from the upper back','Smaller range','Hold each letter',0],
 hollowrock:['Hollow rock','f',4.5,30,'holl','hollB','Rock as one solid shape','Hollow hold','Faster rock',0],
 legraise:['Leg raises','f',4,40,'flB','flA','Lower slowly, back stays down','Bent knees','Hover at the bottom',0],
 vsittap:['V-sit toe taps','f',4.2,30,'vsit','vlow','Chest tall, tap alternate toes','Bent knees','Straight legs',0],
 plankreach:['Plank with reach','f',4,40,'high','tap','Reach long, hips stay square','Knee plank','Hold the reach',0],
 sidelift:['Side plank with leg lift','s',4,30,'side','sideup','Lift the top leg without dropping the hip','Knee version','Pulse at the top',1],
 tuckup:['Tuck-ups','f',4.5,30,'holl','vsit','Knees to chest, control the lower','Heel taps','Straight-leg V-ups',0],
 slowclimb:['Slow mountain climbers','f',5,40,'high','tap','Pause each knee at the elbow','Shorter range','Add a pause',0],
 maxplank:['Max plank hold (test)','f',3.8,60,'plank','plank','Hold clean form for as long as you can','Knee plank','Long-lever plank',0],
 sidetest:['Side plank test','s',3.5,30,'side','side','Hold clean form on each side','Knee side plank','Top leg lift',1],
 supman:['Superman hold','b',3.2,30,'supU','supU','Hold at the top, breathe','Arms only','Add small pulses',0],
 catcow:['Cat-cow','m',2.3,40,'cow','cat','Move with your breath, slowly','Smaller range','Add a hip sway',0],
 child:["Child's pose",'m',2,40,'child','child','Sink the hips back, breathe low','Knees wide','Walk hands to each side',0],
 hips9090:['90/90 hip switches','m',2.5,40,'vlow','vlow','Rotate both knees side to side','Smaller range','Lift off the floor',0],
 thread:['Thread the needle','m',2.3,30,'cow','cat','Slide the arm under, rotate the chest','Smaller range','Hold longer',1],
 suptwist:['Supine twist','m',2,40,'crL','crL','Drop the knees to one side, shoulders down','Support knees','Hold longer',1],
 belly:['Belly breathing','m',1.5,60,'crL','crL','Hand on belly, breathe in slow through the nose','Shorter time','Longer exhale',0],
 warm:['Warm-up','m',3,120,'st','stK','March, arm circles, easy hip circles','','',0],
 cool:['Cool-down','m',2.3,120,'child','child','Slow breaths, let the body settle','','',0]};
const TPLAN={1:['plank','deadbug','birddog','hollow','taps','bridge'],2:['sideplank','twist','bicycle','standcrunch','xclimb','hipdip'],3:['climber','jacks','flutter','vups','highknees','skater'],4:['superman','bridgemarch','snowangel','birdreach','sgbridge','ytw'],5:['hollowrock','legraise','vsittap','plankreach','sidelift','tuckup','slowclimb'],6:['maxplank','deadbug','sidetest','bicycle','supman','climber','hollow'],0:['catcow','child','hips9090','thread','suptwist','belly']};
const TFOC={1:'Anti-extension and stability',2:'Rotation and obliques',3:'Dynamic core and conditioning',4:'Back and glutes',5:'Strength core',6:'Mixed circuit and benchmark',0:'Recovery and mobility'};
const TPRE={quick:{n:'Quick',w:30,r:15,rounds:1},std:{n:'Standard',w:40,r:20,rounds:2},deep:{n:'Deep',w:45,r:15,rounds:3},custom:{n:'Custom'}};
const TR={on:false,view:'setup',day:null,steps:[],si:0,se:0,acc:0,last:0,raf:0,paused:false,wl:null,work:0,kcal:0,items:[],start:'',t0:0};
const trData=()=>{S.train=S.train||{};S.train.sessions=S.train.sessions||[];S.train.prof=S.train.prof||{};S.train.plan=Object.assign({off:[],ov:{},lvl:'int',pre:'std',w:40,r:20,rounds:2,warm:true,cool:true,voice:false,light:false},S.train.plan||{});return S.train};
const trDay=()=>TR.day==null?new Date(NOW()).getDay():TR.day;
const trIds=d=>{const D=trData();return (D.plan.ov[d]||TPLAN[d]).slice()};
const LV={beg:.75,int:1,adv:1.25};
function trSteps(day){const D=trData(),P=D.plan,ids=trIds(day),steps=[],pre=TPRE[P.pre]||TPRE.std,wk=P.pre==='custom'?P.w:pre.w,rs=P.pre==='custom'?P.r:pre.r,R=P.pre==='custom'?P.rounds:pre.rounds,lf=(LV[P.lvl]||1)*(P.light?.8:1),rec=day===0;
 if(P.warm&&!rec)steps.push({t:'warm',ex:'warm',dur:120,n:'Warm-up'});
 for(let r=1;r<=R;r++)ids.forEach((id,i)=>{const x=TX[id],base=rec?x[3]:Math.round(wk*(x[3]/40)),dur=Math.max(10,Math.round(base*(rec?1:lf)));
  if(x[9]){['Left','Right'].forEach((sd,k)=>{steps.push({t:'work',ex:id,dur:Math.max(10,Math.round(dur*(wk>=40?.75:1))),r,i,n:x[0]+' ('+sd+')',of:ids.length,R});if(!k)steps.push({t:'rest',ex:id,dur:5,n:'Switch sides'})})}
  else steps.push({t:'work',ex:id,dur,r,i,n:x[0],of:ids.length,R});
  const last=i===ids.length-1&&r===R;if(!last)steps.push({t:'rest',ex:i===ids.length-1?ids[0]:ids[i+1],dur:i===ids.length-1?Math.round(rs*1.5):rs,n:i===ids.length-1?'Round break':'Rest',nxt:i===ids.length-1?ids[0]:ids[i+1]})});
 if(P.cool)steps.push({t:'cool',ex:'cool',dur:120,n:'Cool-down'});return steps}
function trKcal(steps){const kg=+trData().prof.wt;if(!kg)return null;let k=0;steps.forEach(s=>{const met=s.t==='rest'?1.8:s.t==='warm'?3:s.t==='cool'?2.3:TX[s.ex][2];k+=met*kg*s.dur/3600});return Math.round(k/5)*5}
const trMin=s=>Math.round(s/60);
/* the animated figure */
function trFig(cv,ex,tm,still,fixed,rest){const x=TX[ex],A=TP[x[4]],B=TP[x[5]],c=cv.getContext('2d'),W=cv.width,H=cv.height;c.clearRect(0,0,W,H);
 if(A.fv){trFront(cv,ex,tm,still,fixed,rest);return}
 const same=x[4]===x[5]||rest,f=fixed!=null?fixed:rest?0:still?(Math.floor(tm/1.6)%2):.5-.5*Math.cos(tm*2.6),bob=(same&&!still||rest)?Math.sin(tm*(rest?1.6:2.2))*(rest?.7:.45):0;
 const J=['h','s','p','k','a','e','w'],P={};J.forEach(j=>P[j]=[A[j][0]+(B[j][0]-A[j][0])*f,A[j][1]+(B[j][1]-A[j][1])*f]);P.h[1]+=bob;P.s[1]+=bob*.8;
 if(rest){P.e=[P.s[0]+(Math.sin(tm*1.3)*1.5),P.s[1]+8];P.w=[P.e[0]+Math.sin(tm*1.3)*2,P.e[1]+7]}
 const sc=Math.min(W/80,H/60),ox=(W-80*sc)/2,oy=(H-60*sc)/2,X=p=>[ox+p[0]*sc,oy+p[1]*sc],col=getComputedStyle(document.body).getPropertyValue('--acc').trim()||'#4cc9f0';
 const dir=P.h[0]>=P.p[0]?1:-1,floorPose=Math.max(P.p[1],P.s[1])>30&&Math.abs(P.s[0]-P.p[0])>12;
 /* mat and floor */
 if(floorPose||rest===false&&Math.abs(P.s[0]-P.p[0])>12){c.fillStyle='rgba(255,255,255,.07)';c.beginPath();c.roundRect?c.roundRect(ox+2*sc,oy+51.5*sc,76*sc,3.2*sc,1.6*sc):c.rect(ox+2*sc,oy+51.5*sc,76*sc,3.2*sc);c.fill()}
 if(A.wall!=null){const wx=ox+A.wall*sc;c.fillStyle='rgba(255,255,255,.10)';c.fillRect(wx-5*sc,oy+2*sc,5*sc,51*sc);c.strokeStyle='rgba(255,255,255,.22)';c.lineWidth=1;for(let yy=6;yy<52;yy+=6){c.beginPath();c.moveTo(wx-5*sc,oy+yy*sc);c.lineTo(wx,oy+(yy-4)*sc);c.stroke()}}
 c.strokeStyle='rgba(255,255,255,.16)';c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(ox,oy+53*sc);c.lineTo(ox+80*sc,oy+53*sc);c.stroke();
 c.fillStyle='rgba(0,0,0,.28)';c.beginPath();c.ellipse(X([ (P.s[0]+P.p[0]+P.a[0])/3,53])[0],oy+53.4*sc,Math.max(14,Math.abs(P.a[0]-P.s[0])/2+8)*sc*.8,1.5*sc,0,0,6.283);c.fill();
 const seg=(pts,w,color,al)=>{c.globalAlpha=al==null?1:al;c.strokeStyle=color;c.lineWidth=w*sc;c.lineCap='round';c.lineJoin='round';c.beginPath();pts.forEach((p,i)=>{const q=X(p);i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1])});c.stroke();c.globalAlpha=1};
 const skin='#f2b88f',skinD='#c98f68',pants='#2d3558',pantsD='#1f2545',shirt=col,shoe='#f4f6ff';
 const o=p=>[p[0]+3.2*dir*-1,p[1]-1.6];
 const foot=(a,k,al)=>{const q=X(a),L=4.6*sc*dir;c.globalAlpha=al;c.fillStyle=shoe;c.strokeStyle='rgba(0,0,0,.25)';c.lineWidth=1;c.beginPath();c.ellipse(q[0]+L*.45,q[1]+.4*sc,3.1*sc,1.7*sc,0,0,6.283);c.fill();c.stroke();c.globalAlpha=1};
 const hand=(w,al,cl)=>{const q=X(w);c.globalAlpha=al;c.fillStyle=cl;c.beginPath();c.arc(q[0],q[1],2*sc,0,6.283);c.fill();c.globalAlpha=1};
 /* far limbs */
 seg([o(P.p),o(P.k)],6.4,pantsD);seg([o(P.k),o(P.a)],5.2,pantsD);foot(o(P.a),0,.9);
 seg([o(P.s),o(P.e)],3.6,skinD);seg([o(P.e),o(P.w)],3.2,skinD);hand(o(P.w),1,skinD);
 /* torso and near legs */
 seg([P.s,P.p],9.2,shirt);c.globalAlpha=.25;seg([[P.s[0],P.s[1]],[P.p[0],P.p[1]]],3,'#ffffff',.25);
 seg([P.p,P.k],6.8,pants);seg([P.k,P.a],5.4,pants);foot(P.a,0,1);
 /* head and neck */
 seg([P.s,[P.s[0]+(P.h[0]-P.s[0])*.55,P.s[1]+(P.h[1]-P.s[1])*.55]],3,skin);
 const hp=X(P.h);c.fillStyle='#2a2230';c.beginPath();c.arc(hp[0],hp[1],5.5*sc,0,6.283);c.fill();c.fillStyle=skin;c.beginPath();c.arc(hp[0]+dir*1.3*sc,hp[1]+.9*sc,4.5*sc,0,6.283);c.fill();
 c.fillStyle='#2a2230';c.beginPath();c.arc(hp[0]+dir*3*sc,hp[1]+.4*sc,.6*sc,0,6.283);c.fill();
 /* near arm */
 seg([P.s,P.e],4,skin);seg([P.e,P.w],3.5,skin);hand(P.w,1,skin);
 /* sleeve */
 seg([P.s,[P.s[0]+(P.e[0]-P.s[0])*.38,P.s[1]+(P.e[1]-P.s[1])*.38]],4.6,shirt);
 const MU=TMUS[ex];if(MU&&!rest){const al=still?.3:.2+.16*Math.sin(tm*3.4);MU.g.forEach(gp=>{if(gp==='legs'){seg([P.p,P.k],6.8,col,al);seg([P.k,P.a],5.4,col,al)}else if(gp==='arms'){seg([P.s,P.e],4,col,al);seg([P.e,P.w],3.5,col,al)}else if(gp==='core'||gp==='chest'||gp==='back'){seg([P.s,P.p],9.2,col,al)}})}
 c.globalAlpha=1}
/* small still of the start or end position, used for the Start and Move-to pair and the Up next preview */
function trStill(cv,ex,which){if(cv)trFig(cv,ex,0,true,which,false)}
/* setup */
function trProf(){const p=trData().prof;return `<div class="card" style="margin-top:12px"><div class="b">Body profile <span class="xs mute">optional, stays on this device</span></div><div class="row wrapr" style="gap:8px;margin-top:8px">${[['age','Age','years'],['wt','Weight','kg'],['ht','Height','cm']].map(f=>`<label class="brn"><span>${f[1]} (${f[2]})</span><input type="number" min="0" value="${p[f[0]]||''}" data-chg="trprof" data-k="${f[0]}" style="width:100px"></label>`).join('')}</div><div class="xs mute" style="margin-top:6px">Weight is only used to estimate calories. ${p.wt?'':'Without it, calories are hidden.'}</div><div class="brtg"><button class="chip ${p.hide?'on':''}" data-act="trtog" data-k="hide">Hide weight and calories</button></div></div>`}
CHG.trprof=el=>{trData().prof[el.dataset.k]=+el.value||null;save();trKeep()};
function trSetup(){const D=trData(),P=D.plan,day=trDay(),ids=trIds(day),steps=trSteps(day),tot=sum(steps.map(s=>s.dur)),kc=trKcal(steps),st=trStats(),hide=D.prof.hide;
 const dn=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],off=P.off.includes(day);
 if(!D.prof.ok)return `<div class="brwrap"><div class="row"><h2 class="vt" style="margin:0">Before you start</h2><span class="sp"></span><button class="ibtn" data-act="trx" aria-label="Close">${ic('x')}</button></div><div class="card" style="margin-top:14px"><div class="sm">Core Axon is a training guide, not medical advice. Please read:</div><ul class="sm" style="margin:10px 0 0 18px;line-height:1.7"><li>Stop if you feel sharp pain, dizziness or chest discomfort.</li><li>If you have a back injury, recent surgery, are pregnant, or have diastasis recti, check with a doctor or physiotherapist first.</li><li>Warm-up and cool-down are on by default. Keep them on.</li><li>Calories are rough estimates and can be hidden. There are no calorie targets.</li></ul></div><button class="btn pri" style="margin-top:14px" data-act="trok">I understand, continue</button></div>`;
 return `<div class="brwrap"><div class="row"><div><h2 class="vt" style="margin:0">Core Axon</h2><div class="xs mute">${TFOC[day]}${off?' · marked as a day off':''}</div></div><span class="sp"></span><button class="ibtn" data-act="trx" aria-label="Close">${ic('x')}</button></div>
 <div class="row wrapr" style="gap:8px;margin:12px 0"><div class="kpi"><b>${st.wk}</b><span>sessions this week</span></div><div class="kpi"><b>${dur(st.wkMin)}</b><span>minutes this week</span></div><div class="kpi"><b>${st.streak}</b><span>day streak</span></div><div class="kpi"><b>${st.n}</b><span>sessions</span></div></div>
 <div class="chips">${[1,2,3,4,5,6,0].map(d=>`<button class="chip ${day===d?'on':''}" data-act="trday" data-v="${d}">${dn[d]}${P.off.includes(d)?' (off)':''}</button>`).join('')}</div>
 <div class="card" style="margin-top:10px">${ids.map((id,i)=>`<div class="row sm" style="padding:6px 0;border-bottom:1px solid var(--line)"><span class="mute" style="width:20px">${i+1}</span><span style="flex:1">${TX[id][0]}</span><button class="btn sm ghost" data-act="trprev2" data-id="${id}">How</button><button class="btn sm ghost" data-act="trswap" data-i="${i}" aria-label="Swap exercise">Swap</button></div>`).join('')}<div class="row wrapr" style="gap:8px;margin-top:8px"><button class="chip ${off?'on':''}" data-act="troff">Mark ${dn[day]} as day off</button><button class="chip" data-act="trreset">Reset day</button></div></div>
 <label class="f">Level</label><div class="chips">${[['beg','Beginner'],['int','Intermediate'],['adv','Advanced']].map(l=>`<button class="chip ${P.lvl===l[0]?'on':''}" data-act="trlvl" data-v="${l[0]}">${l[1]}</button>`).join('')}</div>
 <label class="f">How long for each set?</label><div class="chips">${Object.keys(TPRE).map(k=>`<button class="chip ${P.pre===k?'on':''}" data-act="trpre" data-v="${k}">${TPRE[k].n}${k!=='custom'?` ${TPRE[k].w}s / ${TPRE[k].r}s x${TPRE[k].rounds}`:''}</button>`).join('')}</div>
 ${P.pre==='custom'?`<div class="row wrapr" style="gap:10px;margin-top:10px">${[['w','Work (s)'],['r','Rest (s)'],['rounds','Rounds']].map(f=>`<label class="brn"><span>${f[1]}</span><input type="number" min="5" max="180" value="${P[f[0]]}" data-chg="trnum" data-k="${f[0]}"></label>`).join('')}</div>`:''}
 <div class="brtg">${[['warm','Warm-up'],['cool','Cool-down'],['voice','Voice cues'],['light','Today feels light']].map(f=>`<button class="chip ${P[f[0]]?'on':''}" data-act="trtog" data-k="${f[0]}">${f[1]}</button>`).join('')}</div>
 <div class="card" style="margin-top:14px"><b>${dur(tot/60)}</b> total${kc!=null&&!hide?` · about <b>${kc}</b> kcal <span class="xs mute">(estimate, can be 20 to 30 percent off)</span>`:''}<div class="xs mute">${steps.filter(s=>s.t==='work').length} work sets${P.warm&&day!==0?', warm-up':''}${P.cool?', cool-down':''}. Even the recovery day has a full, gentle set.</div></div>
 ${hide?'':trProf()}
 <div class="row wrapr" style="margin-top:16px;gap:8px"><button class="btn pri" data-act="trgo">${ic('play',14)} Begin</button><button class="btn" data-act="trcardio">Indoor cardio circuit</button><button class="btn" data-act="trmanual">Log a workout I did</button><button class="btn" data-act="trhist">History</button><button class="btn ghost" data-act="trcalc">How calories are estimated</button></div></div>`}
function trStats(){const L=trData().sessions,t=todayKey(),w0=addD(t,-6),days=new Set(L.map(x=>x.d));let st=0,k=days.has(t)?t:addD(t,-1);while(days.has(k)){st++;k=addD(k,-1)}const wkL=L.filter(x=>x.d>=w0);return{n:L.length,wk:wkL.length,wkMin:sum(wkL.map(x=>x.sec))/60,streak:st,kcal:sum(wkL.map(x=>x.kcal||0)),days:days.size}}
const trKeep=()=>{const b=$('#train'),y=b.scrollTop;trRender();b.scrollTop=y};
function trRender(){const b=$('#train');b.hidden=false;if(TR.view==='setup')b.innerHTML=trSetup();else if(TR.view==='done')b.innerHTML=TR.doneHtml;else if(TR.view==='hist')b.innerHTML=TR.histHtml;else if(TR.view==='x')b.innerHTML=TR.xHtml;
 else b.innerHTML=`<button class="ibtn brexit" data-act="trend" aria-label="End session">${ic('x')}</button><div class="trtop"><div class="xs mute" id="trpos"></div><div id="trnm" class="trnm"></div></div><div class="trfig"><canvas id="trcv" width="320" height="190"></canvas><div class="trring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" fill="none" stroke="var(--line)" stroke-width="5"/><circle id="trarc" cx="50" cy="50" r="44" fill="none" stroke="var(--acc)" stroke-width="5" stroke-linecap="round" stroke-dasharray="0 276" transform="rotate(-90 50 50)"/></svg><b id="trcnt">3</b></div></div><div class="trpair" id="trpair"><div class="trpl" id="trpl"></div><div class="trpr"><div><canvas id="trpa" width="200" height="120"></canvas><em>Start</em></div><span>&rsaquo;</span><div><canvas id="trpb" width="200" height="120"></canvas><em>Move to</em></div></div><div class="trpn" id="trpn"></div></div><div id="trhow" class="trhowwrap"></div><div class="brtxt"><div class="sm" id="trcue"></div><div class="xs mute" id="trnext" style="margin-top:6px"></div><div class="row wrapr" style="justify-content:center;gap:6px;margin-top:12px"><button class="btn sm" data-act="trprev">Previous</button><button class="btn sm" data-act="trpause" id="trpause">Pause</button><button class="btn sm" data-act="trskip">Skip</button><button class="btn sm" data-act="tradd">+10s</button><button class="btn sm" data-act="trvar" id="trvar">Easier</button><button class="btn sm ghost" data-act="trend">End</button></div></div>`}
function openTrain(){TR.view=TR.on?'run':'setup';TR.day=TR.day==null?new Date(NOW()).getDay():TR.day;trRender();document.body.classList.add('brOpen')}
function trClose(){if(TR.on)trFinish(true);$('#train').hidden=true;document.body.classList.remove('brOpen');TR.view='setup'}
ACT.train=()=>{sfx('open');openTrain()};ACT.trx=()=>trClose();
ACT.trok=()=>{trData().prof.ok=true;save();trKeep()};
ACT.trday=el=>{TR.day=+el.dataset.v;trKeep()};
ACT.troff=()=>{const P=trData().plan,d=trDay();P.off=P.off.includes(d)?P.off.filter(x=>x!==d):[...P.off,d];save();trKeep()};
ACT.trreset=()=>{const P=trData().plan;delete P.ov[trDay()];save();trKeep()};
ACT.trswap=el=>{const P=trData().plan,d=trDay(),ids=trIds(d),i=+el.dataset.i,reg=TX[ids[i]][1],pool=Object.keys(TX).filter(k=>TX[k][1]===reg&&!ids.includes(k)&&k!=='warm'&&k!=='cool'&&k!=='belly');if(!pool.length)return;ids[i]=pool[Math.floor(Math.random()*pool.length)];P.ov[d]=ids;save();trKeep()};
ACT.trlvl=el=>{trData().plan.lvl=el.dataset.v;save();trKeep()};
ACT.trpre=el=>{const P=trData().plan;P.pre=el.dataset.v;if(TPRE[P.pre].w){P.w=TPRE[P.pre].w;P.r=TPRE[P.pre].r;P.rounds=TPRE[P.pre].rounds}save();trKeep()};
CHG.trnum=el=>{trData().plan[el.dataset.k]=clamp(Math.round(+el.value)||5,el.dataset.k==='rounds'?1:5,el.dataset.k==='rounds'?10:180);save();trKeep()};
ACT.trtog=el=>{const D=trData(),k=el.dataset.k;if(k==='hide')D.prof.hide=!D.prof.hide;else D.plan[k]=!D.plan[k];save();trKeep()};
ACT.trcalc=()=>{toast('Calories = MET x weight (kg) x hours. Core work is about 3.5 to 8 MET, rest about 1.8. Rounded to 5 kcal. Real values vary by roughly 20 to 30 percent.')};
/* player */
ACT.trgo=async()=>{const D=trData(),day=trDay();TR.steps=trSteps(day);if(!TR.steps.length)return;TR.on=true;TR.paused=false;TR.si=0;TR.se=0;TR.acc=0;TR.work=0;TR.items=[];TR.vr=false;TR.start=hm();TR.view='run';TR.dayN=day;TR.tm=0;TR.kcal=0;
 try{if(navigator.wakeLock)TR.wl=await navigator.wakeLock.request('screen')}catch(e){}trRender();TR.last=performance.now();trStepStart();TR.raf=requestAnimationFrame(trLoop)};
function trSay(t){if(trData().plan.voice&&window.speechSynthesis){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.rate=.95;speechSynthesis.speak(u)}catch(e){}}}
function trStepStart(){const s=TR.steps[TR.si];TR.vr=false;const x=TX[s.ex];const set=(id,v)=>{const e=$(id);if(e)e.textContent=v};
 const works=TR.steps.filter(q=>q.t==='work');set('#trpos',s.t==='work'?`Move ${s.i+1} of ${s.of} · round ${s.r} of ${s.R}`:s.t==='rest'?'Rest':s.t==='warm'?'Warm-up':'Cool-down');set('#trnm',s.n);set('#trcue',s.t==='rest'?'Breathe, shake it out.':x[6]+(TMUS[s.ex]?'  ·  Works: '+TMUS[s.ex].l:''));
 const nx=TR.steps.slice(TR.si+1).find(q=>q.t==='work'||q.t==='cool');set('#trnext',s.t==='rest'&&s.nxt?'Next: '+TX[s.nxt][0]:nx?'Next: '+nx.n:'Last one');const vb=$('#trvar');if(vb){vb.textContent='Easier';vb.style.display=s.t==='work'&&x[7]?'':'none'}
 const tr=$('#train');if(tr)tr.classList.toggle('rest',s.t==='rest');const pe=s.t==='rest'&&s.nxt?s.nxt:s.ex,px=TX[pe];set('#trpl',s.t==='rest'?(s.nxt?'UP NEXT':'SWITCH SIDES'):s.t==='work'?'HOW IT GOES':s.t==='warm'?'WARM-UP MOVES':'COOL-DOWN');set('#trpn',s.t==='rest'?(s.nxt?px[0]+': '+px[6]:'Change sides and carry on. Same move, other side.'):'');if(s.t==='rest')set('#trnm','Rest');
 trStill($('#trpa'),pe,0);trStill($('#trpb'),pe,1);if(s.t==='rest')set('#trcue','Breathe. Shake out your arms and legs.');
 try{sfx(s.t==='work'?'tap':'tick')}catch(e){}if(window.navigator.vibrate&&s.t!=='rest'){try{navigator.vibrate(40)}catch(e){}}trSay(s.t==='rest'?'Rest':s.n)}
function trLoop(now){if(!TR.on)return;TR.raf=requestAnimationFrame(trLoop);const dt=Math.min(.1,(now-TR.last)/1000);TR.last=now;if(TR.paused)return;
 TR.acc+=dt;TR.se+=dt;TR.tm+=dt;let s=TR.steps[TR.si];if(s.t==='work')TR.work+=dt;
 while(TR.se>=s.dur){TR.se-=s.dur;if(s.t==='work')TR.items.push({ex:s.ex,sec:s.dur,v:TR.vr?'easy':''});TR.si++;if(TR.si>=TR.steps.length){trFinish(false);return}s=TR.steps[TR.si];trStepStart()}
 const left=Math.max(0,s.dur-TR.se),cv=$('#trcv'),cnt=$('#trcnt'),arc=$('#trarc');if(cv)trFig(cv,s.t==='rest'?'warm':s.ex,TR.tm,reduced(),null,s.t==='rest');if(cnt){const v=Math.ceil(left);if(cnt.textContent!==String(v)){cnt.textContent=v;if(v<=3&&v>=1&&s.dur>6){try{tone(v===1?880:660,.12,{v:.2})}catch(e){}}if(s.t==='work'&&Math.abs(left-s.dur/2)<.6&&s.dur>=20&&!s.half){s.half=true}}}
 if(arc)arc.setAttribute('stroke-dasharray',(TR.se/s.dur*276).toFixed(1)+' 276')}
ACT.trpause=()=>{TR.paused=!TR.paused;const b=$('#trpause');if(b)b.textContent=TR.paused?'Resume':'Pause';TR.last=performance.now()};
ACT.trskip=()=>{const s=TR.steps[TR.si];if(s.t==='work')TR.items.push({ex:s.ex,sec:Math.round(TR.se),skip:true});TR.acc+=s.dur-TR.se;TR.si++;TR.se=0;if(TR.si>=TR.steps.length)trFinish(false);else trStepStart()};
ACT.trprev=()=>{TR.si=Math.max(0,TR.si-1);TR.se=0;trStepStart()};
ACT.tradd=()=>{TR.steps[TR.si].dur+=10};
ACT.trvar=()=>{TR.vr=!TR.vr;const b=$('#trvar'),s=TR.steps[TR.si],x=TX[s.ex];if(b)b.textContent=TR.vr?'Harder':'Easier';const c=$('#trcue');if(c)c.textContent=(TR.vr?'Easier: ':'')+(TR.vr?x[7]:x[6])};
ACT.trend=()=>{if(TR.on)trFinish(true);else trClose()};
function trFinish(early){TR.on=false;cancelAnimationFrame(TR.raf);try{if(TR.wl)TR.wl.release()}catch(e){}TR.wl=null;try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}
 const done=TR.steps.slice(0,TR.si),sec=Math.round(TR.acc),worked=Math.round(TR.work),kg=+trData().prof.wt;let kc=null;if(kg){let k=0;done.forEach(s=>{const met=s.t==='rest'?1.8:s.t==='warm'?3:s.t==='cool'?2.3:TX[s.ex][2];k+=met*kg*s.dur/3600});const cur=TR.steps[TR.si];if(cur&&TR.se>0){const met=cur.t==='rest'?1.8:cur.t==='warm'?3:cur.t==='cool'?2.3:TX[cur.ex][2];k+=met*kg*TR.se/3600}kc=Math.round(k/5)*5}
 let saved=false;if(worked>=30){const D=trData();D.sessions.push({d:todayKey(),t:TR.start,day:TR.dayN,lvl:D.plan.lvl,sec,work:worked,kcal:kc,eff:null,pain:false,items:TR.items.slice(),focus:TFOC[TR.dayN]});D.sessions.slice(-400);
  TR.items.forEach(it=>{if(it.skip||TX[it.ex][3]<20)return;if(!D.pb)D.pb={};const b=D.pb[it.ex];if(!b||it.sec>b)D.pb[it.ex]=it.sec});trLogGoal(sec,kc);save();saved=true;sfx('badge')}
 TR.view='done';const hide=trData().prof.hide;TR.doneHtml=`<div class="brwrap" style="text-align:center;padding-top:8vh"><div class="brorb done"><i></i><i></i></div><h2 class="vt" style="margin-top:22px">${saved?(early?'Good work, session saved':'Session complete'):'Session ended'}</h2><div class="mute">${saved?`${brMin(sec)} total, ${brMin(worked)} of work${kc!=null&&!hide?`, about ${kc} kcal (estimate)`:''}.`:'Under 30 seconds of work, so it was not saved.'}</div>
 ${saved?`<div class="b" style="margin-top:18px">How hard was it?</div><div class="chips" style="justify-content:center;margin-top:8px">${[1,2,3,4,5,6,7,8,9,10].map(n=>`<button class="chip" data-act="treff" data-v="${n}">${n}</button>`).join('')}</div><div class="brtg" style="justify-content:center"><button class="chip" data-act="trpain">Felt pain or discomfort</button></div><div class="xs mute" style="margin-top:8px">If something felt sharp or wrong, rest and check with a clinician.</div>`:''}
 <div class="row" style="justify-content:center;gap:8px;margin-top:18px"><button class="btn pri" data-act="trback">Back to plan</button><button class="btn" data-act="trx">Close</button></div></div>`;if(!$('#train').hidden)trRender();if(UI.view==='ins')try{renderIns()}catch(e){}}
ACT.treff=el=>{const L=trData().sessions,x=L[L.length-1];if(x){x.eff=+el.dataset.v;save()}$$('#train [data-act=treff]').forEach(b=>b.classList.toggle('on',b===el))};
ACT.trpain=el=>{const L=trData().sessions,x=L[L.length-1];if(x){x.pain=!x.pain;save();el.classList.toggle('on',x.pain)}};
ACT.trback=()=>{TR.view='setup';trRender()};
function trLogGoal(sec,kc){const t=todayKey();let g=S.goals.find(x=>x.cat==='core-axon');if(!g){g=normGoal({name:'Core training',type:'build',cat:'core-axon',icon:'dumbbell',color:'#ff8a2b',priority:'normal',start:t,end:addD(t,99),sched:{t:'days',days:[1,2,3,4,5,6,0]},why:'A stronger core carries everything else',metric:'Finish the day\'s core routine'});S.goals.push(g);REV++}
 const min=Math.max(1,Math.round(sec/60));logDone(g,t,{min,q:null,note:`Core Axon: ${TFOC[TR.dayN]}${kc!=null&&!trData().prof.hide?', about '+kc+' kcal':''}${min<5?' (minimum version)':''}`});afterLog(g)}
ACT.trhist=()=>{const L=trData().sessions.slice().reverse().slice(0,80),D=trData(),pb=Object.keys(D.pb||{}).sort((a,b)=>D.pb[b]-D.pb[a]).slice(0,8);TR.view='hist';TR.histHtml=`<div class="brwrap"><div class="row"><h2 class="vt" style="margin:0">Training history</h2><span class="sp"></span><button class="btn sm" data-act="trback">Back</button></div>${pb.length?`<div class="card" style="margin-top:12px"><div class="b">Personal bests (longest single set)</div>${pb.map(k=>`<div class="row sm" style="padding:4px 0"><span style="flex:1">${TX[k][0]}</span><b>${D.pb[k]}s</b></div>`).join('')}</div>`:''}${L.length?`<div class="rtw" style="margin-top:12px"><table class="t rt"><tr><th>Date</th><th>Focus</th><th>Time</th><th>Work</th><th>kcal</th><th>Effort</th></tr>${L.map(x=>`<tr><td>${fmtD(x.d)}</td><td>${esc(x.focus||'')}</td><td>${brMin(x.sec)}</td><td>${brMin(x.work)}</td><td>${x.kcal!=null&&!D.prof.hide?x.kcal:''}</td><td>${x.eff||''}${x.pain?' !':''}</td></tr>`).join('')}</table></div>`:'<div class="card mute sm" style="margin-top:12px">No sessions yet.</div>'}</div>`;trRender()};
/* insights card with day, week, month and all-time views */
function trainCard(){const D=trData(),L=D.sessions,t=todayKey();if(!L.length)return `<div class="card" style="margin-top:14px"><div class="row"><h3 style="margin:0">Core training</h3><span class="sp"></span><button class="btn sm" data-act="train">Open Core Axon</button></div><div class="sm mute" style="margin-top:6px">No sessions yet. The top bar dumbbell opens a daily plan of 6 to 7 guided core moves.</div></div>`;
 const rng=n=>L.filter(x=>x.d>=addD(t,-(n-1))),agg=a=>({n:a.length,min:sum(a.map(x=>x.sec))/60,kc:sum(a.map(x=>x.kcal||0)),eff:avg(a.filter(x=>x.eff).map(x=>x.eff))}),W=agg(rng(7)),M=agg(rng(30)),A=agg(L),T1=agg(L.filter(x=>x.d===t));
 const days=[];for(let i=13;i>=0;i--){const k=addD(t,-i);days.push({k,v:sum(L.filter(x=>x.d===k).map(x=>x.sec))/60})}const mx=Math.max(5,...days.map(d=>d.v));
 const reg={f:0,s:0,b:0,m:0};rng(30).forEach(x=>x.items.forEach(it=>{if(TX[it.ex]&&!it.skip)reg[TX[it.ex][1]]+=it.sec}));const rt=sum(Object.values(reg))||1,hide=D.prof.hide;
 const cell=(l,a)=>`<div class="kpi"><b>${a.n}</b><span>${l} sessions</span><em>${dur(a.min)}${a.kc&&!hide?' · '+a.kc+' kcal':''}</em></div>`;
 return `<div class="card" style="margin-top:14px"><div class="row wrapr"><h3 style="margin:0">Core training</h3><span class="sp"></span><button class="btn sm" data-act="trhist">Records</button><button class="btn sm pri" data-act="train">Open Core Axon</button></div><div class="ingrid" style="margin:12px 0">${cell('Today',T1)}${cell('7 days',W)}${cell('30 days',M)}${cell('All time',A)}</div>
 <svg viewBox="0 0 308 62" style="width:100%;max-width:520px;height:auto">${days.map((d,i)=>{const h=Math.round(d.v/mx*54);return `<rect x="${i*22+2}" y="${60-h}" width="16" height="${Math.max(h,d.v?3:1)}" rx="3" fill="${d.v?'var(--acc)':'var(--line)'}"><title>${fmtD(d.k)}: ${Math.round(d.v)} min</title></rect>`}).join('')}</svg><div class="xs mute">Last 14 days, minutes trained.</div>
 <div class="xs mute" style="margin-top:10px">Focus balance, last 30 days</div><div class="inbars" style="height:46px">${[['f','Front'],['s','Sides'],['b','Back'],['m','Mobility']].map(r=>insBar(r[1],1,reg[r[0]]/rt,false)).join('')}</div>${M.eff?`<div class="xs mute">Average effort ${M.eff.toFixed(1)} of 10 over 30 days.</div>`:''}</div>`}
