/* ===== splash + init ===== */
function afterSplash(){BADGE_QUIET=false;try{tdOffSync()}catch(e){}setTimeout(()=>{try{pulseMaybe()}catch(e){}},2600);if(!S.set.flags.tourV5&&new URLSearchParams(location.search).get('tour')!=='0')setTimeout(()=>tourShow(0),700);if(S.set.music.on)musSync();setTimeout(()=>{catchUp();checkAlerts()},400);handleParams();if(S.set.snd.amb)ambience(true)}
function handleParams(){const p=new URLSearchParams(location.search);let ch=false;
 if(p.get('done')){const g=gById(p.get('done'));if(g&&dueState(g).s!=='done'){logDone(g);save();toast('Logged from notification: '+g.name);ch=true}}
 if(p.get('goal')){const g=gById(p.get('goal'));if(g)setTimeout(()=>openDrawer(g.id),500)}
 if(p.get('view'))go(p.get('view'));
 if(p.toString()){try{history.replaceState(null,'',location.pathname)}catch(e){}}if(ch)renderAll()}
function init(){try{init0()}catch(e){console.error(e);try{const sp=$('#splash');if(sp)sp.remove();SPDONE=true;requestAnimationFrame(frame)}catch(_){}showFail(e)}}
function init0(){const st=loadState();BADGE_QUIET=true;
 /* map mode/layout also refresh settings */
 const _m=ACT.mode,_l=ACT.layout;ACT.mode=(el,e)=>{_m(el,e);if(UI.view==='set')renderSet()};ACT.layout=(el,e)=>{_l(el,e);if(UI.view==='set')renderSet()};
 applyTheme();qualityInit();$('#tagline').textContent=TAGLINE;size();initStars();relink();buildNav();
 $('#fsx').innerHTML=ic('fsx');checkBadges();
 UI.view=S.set.view&&VIEWS.some(v=>v[0]===S.set.view)?S.set.view:'home';go(UI.view);startQuotes();swInit();
 if(st==='migrated')setTimeout(()=>toast(`Welcome to NeuroOrbitSynapse. Your ${S.goals.length} earlier goal${S.goals.length===1?'':'s'} and all logs carried over.`),4200);
 runSplash();requestAnimationFrame(frame);
 let lastDay=todayKey();
 setInterval(()=>{tickClock();const k=todayKey();if(k!==lastDay){lastDay=k;REV++;renderAll()}},1000);
 setInterval(()=>{checkAlerts()},15000);setInterval(()=>{if(!document.hidden&&UI.view==='home'){renderHero();renderToday()}},60000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){const k=todayKey();if(k!==lastDay){lastDay=k;REV++}checkAlerts();renderAll();size()}});
 addEventListener('resize',()=>{size()});if(window.ResizeObserver)new ResizeObserver(()=>size()).observe(mapwrap);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(UI.fs)setFS(false);else if($('#modal').classList.contains('on'))closeModal();else closeDrawer()}});
 if(navigator.serviceWorker)navigator.serviceWorker.addEventListener('message',e=>{const d=e.data||{};if(d.type==='done'&&d.goal){const g=gById(d.goal);if(g&&dueState(g).s!=='done'){logDone(g);save();renderAll();toast('Logged: '+g.name)}}else if(d.type==='open'&&d.goal)openDrawer(d.goal)});
 document.addEventListener('pointerdown',()=>{try{ac()}catch(e){}},{once:true});
 window.__nos={S:()=>S,go,UI,fireGoal,ORDER:()=>ORDER}}


