/* ===== state, persistence, migration ===== */
const KEY='nos-v4';
const defSet=()=>({theme:'blue',mode:'trace',wallv:1,layout:'orbit',rot:true,quality:'auto',snd:{on:true,vol:.6,amb:false},music:{on:false,vol:.5},labels:false,pulseOn:true,widgets:['ring','next','week','streak'],synAll:false,synGoal:'',splashDay:'',notif:{risk:true,riskTime:'20:00',wrap:true,wrapTime:'21:30',round:true,catchup:true,escalate:true},name:'',lastExport:'',view:'home',flags:{},fired:{day:'',m:{}},reduceMotion:false,splash:true});
let S={v:4,goals:[],daily:{},rev:{wk:{},mo:{},exp:[]},journal:[],reminders:[],badges:[],set:defSet()};
let REV=0;
const normField=f=>({id:f.id||uid('f'),label:f.label||'Field',type:['number','text','longtext','rating','select','check','time'].includes(f.type)?f.type:'text',unit:f.unit||'',ex:f.ex==null?'':String(f.ex),opts:Array.isArray(f.opts)?f.opts.slice():[],primary:!!f.primary});
function normGoal(g){
 const t=g.type==='break'?'break':'build',tp=tplById(g.cat)||null;
 const d={id:g.id||uid('g'),name:String(g.name||'Goal').slice(0,60),type:t,cat:g.cat||'custom',icon:resolveIcon(g,tp),color:g.color||GCOLORS[0],
  priority:PRI[g.priority]?g.priority:'normal',start:g.start||todayKey(),end:g.end,
  sched:Object.assign({t:'daily',days:[1,2,3,4,5],n:3,every:2},g.sched||{}),win:(g.win&&g.win.length===2)?g.win.slice():null,
  remind:Object.assign({on:false,times:[],days:null},g.remind||{}),why:g.why||'',metric:g.metric||'',cue:g.cue||'',
  tasks:Array.isArray(g.tasks)?g.tasks.slice():[],chk:g.chk||{},fields:(g.fields||[]).map(normField),
  core:Object.assign({min:true,prep:false,q:true},g.core||{}),defMin:g.defMin==null?20:+g.defMin,limit:g.limit==null||g.limit===''?null:+g.limit,
  weeklyTarget:g.weeklyTarget?+g.weeklyTarget:null,logs:g.logs||{},reviews:g.reviews||[],jr:g.jr||[],rounds:g.rounds||[],rev:g.rev||[],
  rel:Array.isArray(g.rel)?g.rel.filter(r=>r&&r.to&&RELK[r.k]):[],paused:!!g.paused,hideEx:!!g.hideEx,created:g.created||todayKey(),out:normOut(g.out),tk:!!g.tk,tpl:String(g.tpl||'').slice(0,12),eg:String(g.eg||'').slice(0,160),mis:normMis(g.mis),bs:(b=>({h:Array.isArray(b.h)?b.h.map(x=>String(x).slice(0,120)).slice(0,30):[],d:Array.isArray(b.d)?b.d.map(x=>String(x).slice(0,120)).slice(0,30):[],n:Array.isArray(b.n)?b.n.map(x=>String(x).slice(0,120)).slice(0,30):[]}))(g.bs&&typeof g.bs==='object'?g.bs:{})};
 if(!d.end||d.end<d.start)d.end=addD(d.start,(g.target>=7?g.target:100)-1);
 if(diffD(d.start,d.end)>729)d.end=addD(d.start,729);
 if(t==='break')d.sched={t:'daily',days:[],n:1,every:1};
 if(!['daily','days','weekly','every','monthly'].includes(d.sched.t))d.sched.t='daily';
 return d}
function normState(o){
 const s={v:4,goals:[],daily:{},journal:[],reminders:[],badges:[],set:defSet()};
 if(!o||typeof o!=='object')return s;
 s.goals=(o.goals||[]).filter(g=>g&&typeof g==='object').map(normGoal);
 s.daily=o.daily&&typeof o.daily==='object'?o.daily:{};
 s.rev=(r=>({wk:r.wk&&typeof r.wk==='object'?r.wk:{},mo:r.mo&&typeof r.mo==='object'?r.mo:{},exp:(Array.isArray(r.exp)?r.exp:[]).filter(e=>e&&e.id&&e.chg).map(e=>({id:String(e.id),src:String(e.src||''),prob:String(e.prob||''),chg:String(e.chg).slice(0,200),exp:String(e.exp||''),start:String(e.start||todayKey()),review:String(e.review||todayKey()),res:String(e.res||''),out:String(e.out||'')}))}))(o.rev&&typeof o.rev==='object'?o.rev:{});
 s.reminders=(o.reminders||[]).map(r=>({id:r.id||uid('r'),time:r.time||'08:00',days:Array.isArray(r.days)?r.days:[0,1,2,3,4,5,6],msg:r.msg||'',goal:r.goal||'',on:r.on!==false}));
 s.badges=Array.isArray(o.badges)?o.badges:[];s.train=o.train&&typeof o.train==='object'?o.train:{};s.breath=(Array.isArray(o.breath)?o.breath:[]).filter(x=>x&&x.d).map(x=>({d:String(x.d),t:String(x.t||''),sec:+x.sec||0,cyc:+x.cyc||0,pat:String(x.pat||''),pur:String(x.pur||''),bpm:+x.bpm||0,pct:+x.pct||0,gid:String(x.gid||''),c0:x.c0==null?null:+x.c0,c1:x.c1==null?null:+x.c1,u0:x.u0==null?null:+x.u0,u1:x.u1==null?null:+x.u1}));
 s.pulse=(Array.isArray(o.pulse)?o.pulse:[]).filter(x=>x&&x.d&&+x.mood>=1&&+x.mood<=5).map(x=>({d:String(x.d),t:String(x.t||''),mood:+x.mood,doing:Array.isArray(x.doing)?x.doing.map(String).slice(0,10):[],note:String(x.note||'').slice(0,200),fid:String(x.fid||''),energy:+x.energy||null,focus:+x.focus||null,stress:+x.stress||null,next:String(x.next||'').slice(0,120)}));
 s.games=o.games&&typeof o.games==='object'?{rec:(Array.isArray(o.games.rec)?o.games.rec:[]).filter(x=>x&&x.g&&x.lv&&isFinite(+x.sc)).map(x=>({g:String(x.g),lv:String(x.lv),sc:+x.sc,d:String(x.d||''),t:String(x.t||''),acc:x.acc==null?null:+x.acc,raw:x.raw==null?null:+x.raw,dur:x.dur==null?null:+x.dur,ab:x.ab?1:0})),days:(o.games.days&&typeof o.games.days==='object'?Object.fromEntries(Object.entries(o.games.days).filter(([k,v])=>isFinite(+v)).map(([k,v])=>[String(k),+v])):{})}:{rec:[],days:{}};
 s.journal=(Array.isArray(o.journal)?o.journal:[]).filter(j=>j&&typeof j==='object').map(j=>({id:j.id||uid('j'),d:j.d||todayKey(),t:j.t||'',title:String(j.title||'').slice(0,120),tx:String(j.tx||''),mood:+j.mood||0,energy:+j.energy||0,tags:Array.isArray(j.tags)?j.tags.slice(0,12):[],goal:j.goal||'',pin:!!j.pin,kind:j.kind||'entry',img:Array.isArray(j.img)?j.img.map(String).slice(0,24):[]}));
 s.trd=normTrd(o.trd);
 const d=defSet(),u=o.set||{};
 s.set=Object.assign(d,u,{snd:Object.assign(d.snd,u.snd||{}),music:Object.assign(d.music,u.music||{}),notif:Object.assign(d.notif,u.notif||{}),flags:Object.assign({},u.flags||{}),fired:u.fired||d.fired});
 if(!THEMES[s.set.theme])s.set.theme='blue';
 if(!['universe','synapse','path','ladder','tree','wall','house','trace'].includes(s.set.mode))s.set.mode='wall';if(!s.set.wallv){s.set.mode='wall';s.set.wallv=1}
 if(!s.set.flags.traceDef){s.set.mode='trace';s.set.flags.traceDef=true}
 if(!['orbit','web','helix','spiral'].includes(s.set.layout))s.set.layout='orbit';
 return s}
function legacy(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}}
const fromLegacyGoals=gs=>gs.map(g=>{const c=Object.assign({},g,{core:{min:true,prep:true,q:true},defMin:30,fields:[],priority:'normal',sched:{t:'daily'}});['x','y','z','den','bd','flash','n'].forEach(k=>delete c[k]);c.logs={};Object.keys(g.logs||{}).forEach(k=>{const l=Object.assign({},g.logs[k]);if(typeof l.h==='number'&&!l.t)l.t=pad(l.h)+':00';delete l.h;delete l.n;c.logs[k]=l});if(c.rev&&c.rev.length&&c.rev[0]&&c.rev[0].what!==undefined)c.rev=c.rev.slice();return c});
function migrateLegacy(){
 const gs=legacy('neuron-goals-v1',null);if(!Array.isArray(gs)||!gs.length)return null;
 const ui=legacy('neuron-ui',{}),snd=legacy('neuron-snd',{}),rem=legacy('neuron-rem',[]),ns=legacy('neuron-notif',{}),bd=legacy('neuron-bd',[]);
 const o={goals:fromLegacyGoals(gs),daily:{},reminders:rem,badges:bd,set:{}};
 if(ui.t&&THEMES[ui.t])o.set.theme=ui.t;
 if(ui.m)o.set.layout=ui.m==='orbit'?'orbit':ui.m==='helix'?'helix':'web';
 o.set.snd={on:snd.on!==false,vol:snd.v==null?.6:snd.v,amb:!!snd.amb};
 o.set.notif={risk:ns.risk!==false,riskTime:ns.riskTime||'20:00',wrap:ns.wrap!==false,wrapTime:ns.wrapTime||'21:30',round:ns.round!==false};
 o.set.flags={migrated:true};
 return normState(o)}
let _saveT=null,_saveFail=false;
function saveNow(){try{localStorage.setItem(KEY,JSON.stringify(S));_saveFail=false}catch(e){if(!_saveFail){_saveFail=true;try{toast('Could not save. Your browser storage may be full. Export a backup now.')}catch(x){}}}}
function save(){REV++;clearTimeout(_saveT);_saveT=setTimeout(saveNow,150)}
addEventListener('pagehide',()=>{clearTimeout(_saveT);saveNow()});
function loadState(){
 let raw=null;try{raw=JSON.parse(localStorage.getItem(KEY))}catch(e){}
 if(raw&&raw.v===4){S=normState(raw);return 'ok'}
 const m=migrateLegacy();if(m){S=m;saveNow();return 'migrated'}
 S=normState(null);return 'fresh'}
const gById=id=>S.goals.find(g=>g.id===id);
const isB=g=>g.type==='break';


function normMis(m){const o={};if(m&&typeof m==='object')Object.keys(m).forEach(k=>{if(/^\d{4}-\d{2}-\d{2}$/.test(k))o[k]=+m[k]||1});return o}
