/* ===== Journal, redesigned: Timeline, Month, Moments (photos), Growth. Photos are stored on this device in IndexedDB, shrunk first. ===== */
IC.img='<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 3-3 4 4"/>';IC.bulb='<path d="M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.8c.7.6 1 1.2 1 2.2h5c0-1 .3-1.6 1-2.2A6 6 0 0012 3z"/>';
UI.jn.view=UI.jn.view||'time';UI.jn.day='';
const MF=['','😞','😕','😐','🙂','😄'],MC=['','#e5646a','#f09a55','#c9c4b0','#7ccf8d','#4cc9f0'],MW=['Rough','Low','Okay','Good','Great'];
const jBlank=()=>({mood:0,energy:0,tags:[],goal:'',title:'',tx:'',d:'',id:'',img:[],t:''});
UI.jn.draft=Object.assign(jBlank(),UI.jn.draft||{});UI.jn.draft.img=UI.jn.draft.img||[];
/* ---- photo store ---- */
let _idb=null;const IMGC={};
function idb(){return _idb||(_idb=new Promise((ok,no)=>{try{const r=indexedDB.open('nos-img',1);r.onupgradeneeded=()=>r.result.createObjectStore('img');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}catch(e){no(e)}}))}
function idbPut(id,blob){return idb().then(db=>new Promise((ok,no)=>{const t=db.transaction('img','readwrite');t.objectStore('img').put(blob,id);t.oncomplete=ok;t.onerror=()=>no(t.error)}))}
function idbGet(id){return idb().then(db=>new Promise((ok,no)=>{const q=db.transaction('img').objectStore('img').get(id);q.onsuccess=()=>ok(q.result);q.onerror=()=>no(q.error)}))}
function idbAll(){return idb().then(db=>new Promise((ok,no)=>{const o={},c=db.transaction('img').objectStore('img').openCursor();c.onsuccess=()=>{const x=c.result;if(x){o[x.key]=x.value;x.continue()}else ok(o)};c.onerror=()=>no(c.error)}))}
function imgUrl(id){if(IMGC[id])return Promise.resolve(IMGC[id]);return idbGet(id).then(b=>b?(IMGC[id]=URL.createObjectURL(b)):'').catch(()=>'')}
function hydrate(root){(root||document).querySelectorAll('img[data-iid]').forEach(im=>{if(im.src&&im.dataset.ok)return;imgUrl(im.dataset.iid).then(u=>{if(u){im.src=u;im.dataset.ok=1}else im.closest('.jph')&&im.closest('.jph').classList.add('gone')})})}
function shrink(file,max){return new Promise((ok,no)=>{const u=URL.createObjectURL(file),im=new Image();im.onload=()=>{const r=Math.min(1,max/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=Math.round(im.width*r);cv.height=Math.round(im.height*r);cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);URL.revokeObjectURL(u);cv.toBlob(b=>b?ok(b):no(new Error('blob')),'image/jpeg',.82)};im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('img'))};im.src=u})}
const jDraftSave=()=>{try{localStorage.setItem('nos-jdraft',JSON.stringify(UI.jn.draft))}catch(e){}};
try{const d=JSON.parse(localStorage.getItem('nos-jdraft')||'null');if(d&&(d.tx||d.title)&&!d.id)UI.jn.draft=Object.assign(jBlank(),d)}catch(e){}
/* ---- text formatting (bold, highlight, bullets, headings) ---- */
function jFmt(t){return esc(t).split('\n').map(l=>{let h=l.replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/==(.+?)==/g,'<mark>$1</mark>');if(/^#\s/.test(l))return '<div class="jh">'+h.replace(/^#\s/,'')+'</div>';if(/^-\s/.test(l))return '<div class="jli">'+h.replace(/^-\s/,'')+'</div>';return h||'&nbsp;'}).join('<br>').replace(/<br>(<div)/g,'$1').replace(/(<\/div>)<br>/g,'$1')}
/* ---- helpers ---- */
const jDay=k=>{const ds=dayStat(k);return ds.opp?ds.done+' of '+ds.opp+' habits':''};
const jMoodOf=k=>{const a=(S.journal||[]).filter(j=>j.d===k&&j.mood).map(j=>j.mood),d=S.daily[k];if(d&&d.mood)a.push(+d.mood);return a.length?Math.round(avg(a)):0};
const jPhotos=()=>{const L=[];(S.journal||[]).forEach(j=>(j.img||[]).forEach(id=>L.push({id,d:j.d,j:j.id})));return L.sort((a,b)=>a.d<b.d?1:-1)};
/* ---- editor ---- */
function jThumbs(){const d=UI.jn.draft;return (d.img||[]).map((id,i)=>`<div class="jph"><img data-iid="${id}" alt="Photo ${i+1}"><button data-act="jimgx" data-i="${i}" aria-label="Remove photo">${ic('x',12)}</button></div>`).join('')}
INP.jtitle=el=>{UI.jn.draft.title=el.value;jDraftSave()};INP.jtx=el=>{UI.jn.draft.tx=el.value;const w=$('#jwc');if(w)w.textContent=wc(el.value)+' words';jDraftSave()};
CHG.jdate=el=>{if(el.value)UI.jn.draft.d=el.value>todayKey()?todayKey():el.value;jRe()};CHG.jgoal=el=>{UI.jn.draft.goal=el.value;jDraftSave()};
ACT.jnew=el=>{const day=el&&el.dataset&&el.dataset.k;if(!UI.jn.draft.id&&day)UI.jn.draft.d=day;sfx('open');jOpenEditor()};
ACT.jclose=()=>{jDraftSave();jsClose()};
ACT.jmood=el=>{const d=UI.jn.draft,v=+el.dataset.v;d.mood=d.mood===v?0:v;sfx('tick');jDraftSave();jRe()};
ACT.jener=el=>{const d=UI.jn.draft,v=+el.dataset.v;d.energy=d.energy===v?0:v;sfx('tick');jDraftSave();jRe()};
ACT.jtag=el=>{const a=UI.jn.draft.tags,i=a.indexOf(el.dataset.v);if(i>=0)a.splice(i,1);else a.push(el.dataset.v);sfx('tick');jDraftSave();jRe()};
ACT.jtagadd=el=>{const v=(el.value||'').trim().slice(0,20);if(!v)return;const a=UI.jn.draft.tags;if(!a.includes(v))a.push(v);jDraftSave();jRe()};
ACT.jprompt=()=>{JPI++;UI.jn.draft.showP=true;sfx('tick');jRe()};
ACT.jphoto=()=>{const i=$('#jimgin');if(i)i.click()};
CHG.jimg=async el=>{const fs=[...el.files].slice(0,12);if(!fs.length)return;toast('Adding '+fs.length+' photo'+(fs.length>1?'s':'')+'...');let n=0;for(const f of fs){try{const b=await shrink(f,1400),id=uid('p');await idbPut(id,b);UI.jn.draft.img.push(id);n++}catch(e){}}el.value='';jDraftSave();jRe();toast(n?n+' photo'+(n>1?'s':'')+' added (kept on this device)':'Those photos could not be read.')};
ACT.jimgx=el=>{UI.jn.draft.img.splice(+el.dataset.i,1);jDraftSave();jRe()};
ACT.jfmt=el=>{const t=$('#jtx');if(!t)return;const a=t.selectionStart,b=t.selectionEnd,v=t.value,sel=v.slice(a,b),k=el.dataset.v;let ins,ca;
 if(k==='b'||k==='h'){const m=k==='b'?'**':'==';ins=m+(sel||'text')+m;ca=a+m.length;t.setRangeText(ins,a,b,'end');if(!sel)t.setSelectionRange(ca,ca+4)}
 else{const ls=v.lastIndexOf('\n',a-1)+1,pre=k==='l'?'- ':'# ';t.setRangeText(pre,ls,ls,'end')}
 UI.jn.draft.tx=t.value;const w=$('#jwc');if(w)w.textContent=wc(t.value)+' words';jDraftSave();t.focus()};
ACT.jcancel=()=>{UI.jn.draft=jBlank();try{localStorage.removeItem('nos-jdraft')}catch(e){}jsClose();renderJour()};
ACT.jsave=()=>{const d=UI.jn.draft;if(!d.tx.trim()&&!d.title.trim()&&!(d.img||[]).length){toast('Write something or add a photo first.');return}
 const old=d.id?S.journal.find(x=>x.id===d.id):null,e={id:d.id||uid('j'),d:d.d||todayKey(),t:d.t||(old?old.t:hm()),title:d.title.trim(),tx:d.tx,mood:d.mood,energy:d.energy,tags:d.tags.slice(),goal:d.goal,img:(d.img||[]).slice(),pin:old?!!old.pin:false,kind:'entry'};
 if(old){S.journal[S.journal.indexOf(old)]=e}else S.journal.push(e);
 if(e.mood&&e.d===todayKey()&&!(S.daily[e.d]||{}).mood)S.daily[e.d]=Object.assign({},S.daily[e.d],{mood:e.mood});
 UI.jn.draft=jBlank();try{localStorage.removeItem('nos-jdraft')}catch(x){}sfx('create');save();checkBadges();jsClose();renderJour();toast('Moment saved')};
ACT.jedit=el=>{const j=S.journal.find(x=>x.id===el.dataset.id);if(!j)return;UI.jn.draft={mood:j.mood,energy:j.energy,tags:(j.tags||[]).slice(),goal:j.goal||'',title:j.title,tx:j.tx,d:j.d,id:j.id,img:(j.img||[]).slice(),t:j.t};sfx('tap');jOpenEditor()};
ACT.jdel=el=>{const i=S.journal.findIndex(x=>x.id===el.dataset.id);if(i<0)return;const old=S.journal.splice(i,1)[0];save();closeModal();renderJour();toast('Moment deleted',()=>{S.journal.push(old);save();renderJour()})};
ACT.jpin=el=>{const j=S.journal.find(x=>x.id===el.dataset.id);if(j){j.pin=!j.pin;save();closeModal();renderJour()}};
ACT.jweekly=()=>{const t=todayKey(),a=addD(t,-6),r=rateBetween(a,t),gs=S.goals.filter(g=>g.start<=t&&!g.paused).map(g=>({g,r:rateBetween(a,t,[g])})).filter(x=>x.r!=null).sort((x,y)=>y.r-x.r);
 const tx=`# Week of ${fmtD(a)} to ${fmtD(t)}\nCompletion: ${pct(r)}\n${gs.length?'Strongest: '+gs[0].g.name+' ('+pct(gs[0].r)+')\nNeeds care: '+gs[gs.length-1].g.name+' ('+pct(gs[gs.length-1].r)+')\n':''}\n# What worked\n\n# What got in the way\n\n# What I will change next week\n`;
 const d=UI.jn.draft;Object.assign(d,{title:d.title||'Weekly reflection',tx,tags:['Plan','Lesson'],d:t});jDraftSave();jRe();jOpenEditor()};
/* ---- viewing one moment ---- */
function jView(x){const g=x.goal?gById(x.goal):null,j=x.src==='entry'?(S.journal||[]).find(q=>q.id===x.id):null;
 return `<div class="row wrapr"><div><div class="xs mute">${fmtLong(x.d)}${x.t?'  '+x.t:''}</div><h2 class="vt" style="margin:0">${esc(x.title||'Moment')}</h2></div><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div>
 <div class="row wrapr" style="gap:6px;margin:8px 0">${x.mood?`<span class="pill" style="border-color:${MC[x.mood]}">${MF[x.mood]} ${MW[x.mood-1]}</span>`:''}${x.energy?`<span class="pill">Energy ${x.energy}/5</span>`:''}${g?`<span class="pill" style="color:${g.color}">${esc(g.name)}</span>`:''}${jDay(x.d)?`<span class="pill">${jDay(x.d)} that day</span>`:''}${(x.tags||[]).map(t=>`<span class="pill">${esc(t)}</span>`).join('')}</div>
 <div class="jbody">${jFmt(x.tx||'')}</div>
 ${j&&(j.img||[]).length?`<div class="jgal">${j.img.map((id,i)=>`<div class="jph big" data-act="jlight" data-j="${j.id}" data-i="${i}"><img data-iid="${id}" alt="Photo ${i+1}"></div>`).join('')}</div>`:''}
 ${j?`<div class="row wrapr" style="margin-top:14px;gap:8px"><button class="btn" data-act="jedit" data-id="${j.id}">Edit</button><button class="btn ghost" data-act="jpin" data-id="${j.id}">${j.pin?'Unpin':'Pin'}</button><button class="btn ghost danger" data-act="jdel" data-id="${j.id}">Delete</button></div>`:''}`}
let JVX=[];
ACT.jopen=el=>{const x=JVX[+el.dataset.i];if(!x)return;FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');$('#mbox').innerHTML=jView(x);hydrate($('#mbox'))};
ACT.jlight=el=>{const j=S.journal.find(q=>q.id===el.dataset.j);if(!j)return;JL.ids=j.img.slice();JL.i=+el.dataset.i;JL.d=j.d;jLightShow()};
const JL={ids:[],i:0,d:''};
function jLightShow(){FM=null;$('#modal').classList.add('on');$('#shade').classList.add('on');$('#mbox').innerHTML=`<div class="row"><span class="xs mute">${fmtLong(JL.d)} · ${JL.i+1} of ${JL.ids.length}</span><span class="sp"></span><button class="ibtn" data-act="recx" aria-label="Close">${ic('x')}</button></div><div class="jlight"><img data-iid="${JL.ids[JL.i]}" alt="Photo"></div><div class="row" style="margin-top:8px;gap:8px">${JL.ids.length>1?`<button class="btn" data-act="jlnav" data-d="-1">Previous</button><button class="btn" data-act="jlnav" data-d="1">Next</button>`:''}</div>`;hydrate($('#mbox'))}
ACT.jlnav=el=>{JL.i=(JL.i+ +el.dataset.d+JL.ids.length)%JL.ids.length;jLightShow()};
ACT.jday=el=>{UI.jn.day=UI.jn.day===el.dataset.k?'':el.dataset.k;sfx('tick');renderJour()};
ACT.jv=el=>{UI.jn.view=el.dataset.v;sfx('nav');renderJour()};
ACT.jtype=el=>{UI.jn.type=el.dataset.v;sfx('tick');renderJour()};ACT.jftag=el=>{UI.jn.tag=UI.jn.tag===el.dataset.v?'':el.dataset.v;sfx('tick');renderJour()};
CHG.jfgoal=el=>{UI.jn.goal=el.value;renderJour()};
ACT.jmnav=el=>{const c=UI.jn.cm||(UI.jn.cm={y:NOW().getFullYear(),m:NOW().getMonth()});c.m+=+el.dataset.d;if(c.m<0){c.m=11;c.y--}if(c.m>11){c.m=0;c.y++}sfx('tick');renderJour()};
/* ---- timeline ---- */
function jCard(x,i){const g=x.goal?gById(x.goal):null,j=x.src==='entry'?(S.journal||[]).find(q=>q.id===x.id):null,im=j?(j.img||[]):[],p=parseK(x.d);
 return `<div class="jrow"><div class="jdate"><b>${p.getDate()}</b><span>${MON[(p.getDay()+6)%7]}</span>${x.mood?`<i style="background:${MC[x.mood]}" title="${MW[x.mood-1]}">${MF[x.mood]}</i>`:''}</div>
 <div class="card jcard click ${x.pin?'pinned':''}" data-act="jopen" data-i="${i}" style="${g?`border-left:3px solid ${g.color}`:''}">
  <div class="row xs mute" style="gap:6px;flex-wrap:wrap">${x.t?`<span>${x.t}</span>`:''}<span class="pill">${({entry:'Moment',daily:'Check-in',review:'Review',note:'Goal note'})[x.src]}</span>${g?`<span class="pill" style="color:${g.color}">${esc(g.name)}</span>`:''}${x.pin?'<span class="pill">Pinned</span>':''}${jDay(x.d)&&x.src==='entry'?`<span class="pill">${jDay(x.d)}</span>`:''}</div>
  ${x.title&&x.src!=='note'?`<div class="b" style="margin-top:6px">${esc(x.title)}</div>`:''}<div class="sm jex">${jFmt((x.tx||'').slice(0,420))}</div>
  ${im.length?`<div class="jmos n${Math.min(im.length,4)}">${im.slice(0,4).map((id,k)=>`<div class="jph"><img data-iid="${id}" alt="">${k===3&&im.length>4?`<span class="more">+${im.length-4}</span>`:''}</div>`).join('')}</div>`:''}
  ${(x.tags||[]).length?`<div class="row" style="gap:5px;margin-top:8px;flex-wrap:wrap">${x.tags.map(t=>`<span class="pill">${esc(t)}</span>`).join('')}</div>`:''}</div></div>`}
function jFiltered(){const q=(UI.jn.q||'').toLowerCase(),J=UI.jn;let f=jItems().filter(x=>(J.type==='all'||x.src===J.type)&&(!J.tag||(x.tags||[]).includes(J.tag))&&(!J.goal||x.goal===J.goal)&&(!J.day||x.d===J.day)&&(!q||((x.title||'')+' '+x.tx+' '+(x.tags||[]).join(' ')).toLowerCase().includes(q)));
 f.sort((a,b)=>(b.pin?1:0)-(a.pin?1:0)||(a.d<b.d?1:a.d>b.d?-1:((b.t||'')>(a.t||'')?1:-1)));return f}
function jList(){const f=jFiltered();JVX=f.slice(0,250);if(!f.length)return `<div class="card mute sm">Nothing here yet. Tap <b>Write</b> to add your first moment. Check-ins, reviews and goal notes also appear here.</div>`;
 let h='',cur='';JVX.forEach((x,i)=>{const m=x.pin?'Pinned':parseK(x.d).toLocaleDateString(undefined,{month:'long',year:'numeric'});if(m!==cur){cur=m;h+=`<h3 class="h3 jm">${m}</h3>`}h+=jCard(x,i)});return h}
/* ---- month ---- */
function jMonth(){const c=UI.jn.cm||(UI.jn.cm={y:NOW().getFullYear(),m:NOW().getMonth()}),first=dayKey(new Date(c.y,c.m,1)),gs=weekStart(first),title=new Date(c.y,c.m,1).toLocaleDateString(undefined,{month:'long',year:'numeric'}),ph={};
 (S.journal||[]).forEach(j=>{if((j.img||[]).length&&!ph[j.d])ph[j.d]=j.img[0]});
 let g=`<div class="calnav"><button class="ibtn" data-act="jmnav" data-d="-1" aria-label="Previous month">${ic('back')}</button><b>${title}</b><button class="ibtn" data-act="jmnav" data-d="1" aria-label="Next month">${ic('fwd')}</button></div><div class="mgrid">${MON.map(d=>`<div class="wd">${d}</div>`).join('')}`;
 for(let i=0;i<42;i++){const k=addD(gs,i);if(i>=35&&parseK(k).getMonth()!==c.m)break;const out=parseK(k).getMonth()!==c.m,m=jMoodOf(k),n=jItems().filter(x=>x.d===k&&x.src==='entry').length;
  g+=`<button class="jcell ${out?'out':''} ${UI.jn.day===k?'sel':''} ${k===todayKey()?'today':''}" data-act="jday" data-k="${k}" style="${m?`--m:${MC[m]}`:''}">${ph[k]?`<img data-iid="${ph[k]}" alt="">`:''}<span class="n">${parseK(k).getDate()}</span>${m&&!ph[k]?`<span class="f">${MF[m]}</span>`:''}${n?`<span class="dot">${n}</span>`:''}</button>`}
 g+='</div><div class="xs mute" style="margin-top:8px">Each day shows your mood, or your first photo. Tap a day to read it, tap again to clear.</div>';return g}
/* ---- moments (photos) ---- */
function jMoments(){const P=jPhotos();if(!P.length)return `<div class="card mute sm">No photos yet. Add photos when you write a moment and they gather here, by month, on this device.</div>`;
 let h='',cur='';P.forEach(p=>{const m=parseK(p.d).toLocaleDateString(undefined,{month:'long',year:'numeric'});if(m!==cur){cur=m;h+=`${h?'</div>':''}<h3 class="h3 jm">${m}</h3><div class="jwall">`}h+=`<div class="jph wall" data-act="jlight" data-j="${p.j}" data-i="${(S.journal.find(q=>q.id===p.j).img||[]).indexOf(p.id)}"><img data-iid="${p.id}" alt=""><span>${parseK(p.d).getDate()}</span></div>`});return h+'</div>'}
/* ---- growth ---- */
function jGrowth(){const t=todayKey(),J=S.journal||[],wk=[];for(let i=7;i>=0;i--){const a=weekStart(addD(t,-7*i)),b=addD(a,6),es=J.filter(j=>j.d>=a&&j.d<=b);wk.push({a,n:es.length,w:sum(es.map(j=>wc(j.tx)))})}
 const wdm=[0,1,2,3,4,5,6].map(()=>[]);for(let i=0;i<120;i++){const k=addD(t,-i),m=jMoodOf(k);if(m)wdm[(dow(k)+6)%7].push(m)}
 const hi=[],lo=[];for(let i=0;i<120;i++){const k=addD(t,-i),m=jMoodOf(k),ds=dayStat(k);if(!m||!ds.opp)continue;(ds.done/ds.opp>=.8?hi:lo).push(m)}
 const tg={};J.forEach(j=>(j.tags||[]).forEach(x=>tg[x]=(tg[x]||0)+1));const tags=Object.entries(tg).sort((a,b)=>b[1]-a[1]).slice(0,10),st=jStats();
 return `<div class="grid g4 kp8">${kpi(J.length,'Moments')}${kpi(jPhotos().length,'Photos')}${kpi(st.words,'Words')}${kpi(st.streak+'d','Writing streak')}</div>
 <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Moments per week</h3>${bars(wk.map(w=>({l:fmtD(w.a).replace(/ \d{4}$/,''),v:w.n,c:'var(--acc)'})))}<div class="xs mute">${wk[7].w} words this week, ${wk[6].w} the week before.</div></div>
 <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Average mood by weekday</h3>${wdm.some(a=>a.length)?bars(MON.map((l,i)=>({l,v:wdm[i].length?+avg(wdm[i]).toFixed(1):0,c:'var(--acc2)'}))):'<div class="mute sm">Set a mood on a few days to see this.</div>'}</div>
 <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Mood and habits</h3>${hi.length>=3&&lo.length>=3?`<div class="sm">On days you completed 80% or more of your habits (${hi.length} days) your mood averaged <b>${avg(hi).toFixed(1)}</b>. On other days (${lo.length} days) it averaged <b>${avg(lo).toFixed(1)}</b>.</div><div class="xs mute" style="margin-top:6px">This is an association, not proof. A good mood can lead to doing more, and the reverse.</div>`:'<div class="mute sm">Needs at least 3 days of each kind with a mood set.</div>'}</div>
 ${tags.length?`<div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Your themes</h3><div class="row wrapr" style="gap:6px">${tags.map(x=>`<span class="pill" style="font-size:${11+Math.min(8,x[1])}px">${esc(x[0])} ${x[1]}</span>`).join('')}</div></div>`:''}
 <div class="card" style="margin-top:12px"><h3 style="margin:0 0 6px">Photos backup</h3><div class="sm mute">Photos live only in this browser. Download them as a file to keep a copy, or load a copy back.</div><div class="row wrapr" style="gap:8px;margin-top:8px"><button class="btn" data-act="jphbk">Download photos</button><button class="btn" data-act="jphrs">Load photos file</button><input type="file" id="jphfile" accept="application/json" hidden data-chg="jphload"></div></div>`}
ACT.jphbk=async()=>{try{const all=await idbAll(),ids=jPhotos().map(p=>p.id),out={};for(const id of ids){const b=all[id];if(b)out[id]=await new Promise(r=>{const f=new FileReader();f.onload=()=>r(f.result);f.readAsDataURL(b)})}downloadText('neuroorbitsynapse-photos-'+stamp()+'.json',JSON.stringify({photos:out}),'application/json');toast(Object.keys(out).length+' photos saved to a file')}catch(e){toast('Could not read the photo store.')}};
ACT.jphrs=()=>{const i=$('#jphfile');if(i)i.click()};
CHG.jphload=el=>{const f=el.files[0];if(!f)return;const r=new FileReader();r.onload=async()=>{try{const o=JSON.parse(r.result).photos||{};let n=0;for(const id of Object.keys(o)){const b=await (await fetch(o[id])).blob();await idbPut(id,b);delete IMGC[id];n++}toast(n+' photos restored');renderJour()}catch(e){toast('That file could not be read.')}el.value=''};r.readAsText(f)};
/* ---- page ---- */
function otd(){const t=todayKey(),p=parseK(t),out=[];jItems().forEach(x=>{const q=parseK(x.d);if(q.getFullYear()<p.getFullYear()&&q.getMonth()===p.getMonth()&&q.getDate()===p.getDate()&&x.tx)out.push(x)});return out.slice(0,2)}
/* ---- hero: stats, 14-day mood ribbon, quick compose, writing layout toggle ---- */
function jHero(){const st=jStats(),t=todayKey(),days=Array.from({length:14},(_,i)=>addD(t,i-13)),J=S.journal||[],mf=st.mood?MF[Math.max(1,Math.min(5,Math.round(st.mood)))]:'·';
 const rb=days.map(k=>{const m=jMoodOf(k),n=J.filter(j=>j.d===k).length;return `<button class="jrb ${UI.jn.day===k?'sel':''}" data-act="jday" data-k="${k}" style="${m?'--m:'+MC[m]:''}" title="${fmtD(k)}"><i class="${m?'on':''}">${m?MF[m]:''}</i>${n?'<u></u>':''}<small>${['S','M','T','W','T','F','S'][dow(k)]}</small></button>`}).join('');
 return `<div class="jhero"><div class="jstats"><div><b>${J.length}</b><span>moments</span></div><div><b>${st.streak}<small>d</small></b><span>writing streak</span></div><div><b>${st.words>999?(st.words/1000).toFixed(1)+'k':st.words}</b><span>words</span></div><div><b>${mf}</b><span>mood, 30 days</span></div></div>
  ${jRiver(days)}<button class="jquick" data-act="jnew"><span>${ic('pen',16)}</span><em>What is on your mind?</em></button><button class="jprm" data-act="jqp">${esc(JPROMPTS[JPI%JPROMPTS.length])}</button></div>`}
ACT.jqp=()=>{UI.jn.draft.showP=true;JPI++;ACT.jnew()};
ACT.jlay=el=>{S.set.jlay=el.dataset.v;save();sfx('tick');renderJour()};
function renderJour(){const J=UI.jn,o=otd(),t=todayKey(),m=jMoodOf(t),V=[['time','Timeline'],['month','Month'],['photos','Moments'],['grow','Growth']];
 let body='';if(J.view==='time'){const mood=moodSeries('mood',30);body=`${o.length?`<div class="card" style="margin-bottom:12px"><h3>On this day</h3>${o.map(x=>`<div class="sm" style="margin:6px 0"><span class="mute xs">${fmtLong(x.d)}</span><div>${esc(x.tx.slice(0,220))}</div></div>`).join('')}</div>`:''}
  <div class="row wrapr" style="margin:6px 0 8px;gap:8px"><input type="search" class="bsin" style="flex:1;min-width:140px" placeholder="Search your moments" value="${esc(J.q||'')}" data-inp="jq"><select data-chg="jfgoal" style="max-width:150px"><option value="">All goals</option>${S.goals.map(g=>`<option value="${g.id}" ${J.goal===g.id?'selected':''}>${esc(g.name)}</option>`).join('')}</select></div>
  <div class="seg" style="margin-bottom:8px">${[['all','All'],['entry','Moments'],['daily','Check-ins'],['review','Reviews'],['note','Goal notes']].map(x=>`<button data-act="jtype" data-v="${x[0]}" class="${J.type===x[0]?'on':''}">${x[1]}</button>`).join('')}</div>
  <div class="chips" style="margin-bottom:8px">${JTAGS.map(x=>`<button class="chip ${J.tag===x?'on':''}" data-act="jftag" data-v="${x}">${x}</button>`).join('')}</div>${J.day?`<div class="xs mute" style="margin-bottom:6px">Showing ${fmtLong(J.day)}. <a href="#" data-act="jday" data-k="${J.day}">Clear</a></div>`:''}<div class="jlays">${[['cards','Cards'],['list','List'],['grid','Grid']].map(x=>`<button class="${(S.set.jlay||'cards')===x[0]?'on':''}" data-act="jlay" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><div class="col jl-${S.set.jlay||'cards'}" id="jlist">${jList()}</div>`}
 else if(J.view==='month'){body=`<div class="card">${jMonth()}</div>${J.day?`<div style="margin-top:12px" class="col" id="jlist">${jList()}</div><div class="row" style="margin-top:8px"><button class="btn" data-act="jnew" data-k="${J.day}">Write for this day</button></div>`:''}`}
 else if(J.view==='photos')body=jMoments();else body=jGrowth();
 $('#jourc').innerHTML=`<div class="row wrapr"><div><h2 class="vt">Journal</h2><div class="mute sm">Moments, moods and photos in one place.${m?` Today feels ${MF[m]} ${MW[m-1].toLowerCase()}.`:''}</div></div><span class="sp"></span><button class="btn pri" data-act="jnew">${ic('plus',14)} Write</button></div>
 ${jHero()}<div class="seg jseg" style="margin:12px 0">${V.map(v=>`<button data-act="jv" data-v="${v[0]}" class="${J.view===v[0]?'on':''}">${v[1]}</button>`).join('')}</div>${body}`;hydrate($('#jourc'))}
INP.jq=el=>{UI.jn.q=el.value;const l=$('#jlist');if(l){l.innerHTML=jList();hydrate(l)}};
