/* ===== Indoor cardio set: wall sit, push-ups, planks in several styles, jumping jacks, squats, high knees. No equipment. ===== */
const TMUS={};
Object.assign(TP,{
 wsit:{wall:22,h:[27,10],s:[25,19],p:[25,36],k:[44,36],a:[44,52],e:[33,29],w:[41,27]},
 wsitB:{wall:22,h:[27,10],s:[25,19],p:[25,37],k:[45,37],a:[45,52],e:[32,28],w:[40,24]},
 hp:{h:[62,24],s:[54,28],p:[34,38],k:[22,44],a:[10,50],e:[54,39],w:[54,50]},
 pu:{h:[62,39],s:[54,43],p:[34,46],k:[22,48],a:[10,50],e:[45,46],w:[54,50]},
 rp:{h:[12,31],s:[22,34],p:[42,39],k:[56,45],a:[70,50],e:[21,42],w:[20,50]},
 rpB:{h:[12,36],s:[22,39],p:[42,45],k:[56,48],a:[70,50],e:[21,44],w:[20,50]},
 sqA:{h:[40,10],s:[40,20],p:[40,34],k:[41,44],a:[40,52],e:[44,28],w:[50,26]},
 sqB:{h:[39,17],s:[37,26],p:[30,40],k:[47,41],a:[43,52],e:[46,31],w:[54,28]},
 bkA:{h:[40,10],s:[40,20],p:[40,34],k:[40,44],a:[40,52],e:[34,27],w:[44,27]},
 bkB:{h:[40,10],s:[40,20],p:[40,34],k:[41,44],a:[27,43],e:[44,27],w:[34,26]},
 jjA:{fv:1,h:[40,11],s:[40,20],p:[40,34],kl:[37,43],al:[36,52],kr:[43,43],ar:[44,52],el:[34,27],wl:[33,34],er:[46,27],wr:[47,34],air:0},
 jjB:{fv:1,h:[40,8],s:[40,17],p:[40,31],kl:[33,40],al:[27,48],kr:[47,40],ar:[53,48],el:[31,12],wl:[27,4],er:[49,12],wr:[53,4],air:3}});
Object.assign(TX,{
 wallsit:['Wall sit','c',3.5,30,'wsit','wsitB','Back flat on the wall, thighs level, knees over ankles','Slide up a little higher','Hold longer or add small pulses',0],
 pushup:['Push-up','c',8,30,'hp','pu','Body in one line, chest to a fist from the floor, elbows about 45 degrees','Knee push-ups or hands on a sofa','Slow lower for 3 seconds',0],
 hplank:['High plank hold','c',3.8,40,'hp','hp','Hands under shoulders, push the floor away, squeeze glutes','Knee plank','Lift one hand at a time',0],
 plankpush:['Plank to push-up','c',7,30,'plank','hp','Forearms down, then up one hand at a time, hips steady','Fewer reps, wide feet','Alternate the leading arm',0],
 revplank:['Reverse plank','c',3.5,30,'rp','rp','Lift the hips, chest open, look forward','Bend the knees','Lift one leg',0],
 revdip:['Reverse plank dips','c',4,30,'rp','rpB','Lower the hips and lift them back to the line','Smaller range','Hold at the top',0],
 squat:['Bodyweight squat','c',5,40,'sqA','sqB','Hips back, chest tall, heels down','Squat to a chair','Add a pause at the bottom',0],
 buttkick:['Butt kicks','c',7,30,'bkA','bkB','Quick heels to the glutes, stay tall','March in place','Faster',0],
 jjacks:['Jumping jacks','c',8,30,'jjA','jjB','Land softly, arms overhead, feet wide then together','Step jacks (no jump)','Faster pace',0]});
Object.assign(TMUS,{
 wallsit:{g:['legs'],l:'quads, glutes'},pushup:{g:['arms','chest'],l:'chest, triceps, shoulders, core'},hplank:{g:['core','arms'],l:'core, shoulders'},
 plankpush:{g:['arms','core'],l:'triceps, shoulders, core'},revplank:{g:['legs','back'],l:'glutes, hamstrings, back'},revdip:{g:['legs','back'],l:'glutes, hamstrings, triceps'},
 squat:{g:['legs'],l:'quads, glutes, hamstrings'},buttkick:{g:['legs'],l:'hamstrings, calves'},jjacks:{g:['legs','arms'],l:'calves, shoulders, whole body'},
 highknees:{g:['legs','core'],l:'hip flexors, quads, core'},plank:{g:['core'],l:'core, shoulders'},climber:{g:['core','legs'],l:'core, hip flexors'},jacks:{g:['core','arms'],l:'core, shoulders'}});
const CARDIO=['jjacks','highknees','wallsit','pushup','hplank','squat','buttkick','plankpush'];
ACT.trcardio=()=>{const P=trData().plan,d=trDay();P.ov[d]=CARDIO.slice();save();trKeep();toast('Indoor cardio circuit set for this day.')};
/* front view figure (used by jumping jacks) */
function trFront(cv,ex,tm,still,fixed,rest){const x=TX[ex],A=TP[x[4]],B=TP[x[5]],c=cv.getContext('2d'),W=cv.width,H=cv.height;c.clearRect(0,0,W,H);
 const f=fixed!=null?fixed:rest?0:still?(Math.floor(tm/1.6)%2):.5-.5*Math.cos(tm*5.2),L=(a,b)=>a+(b-a)*f,P={};['h','s','p','kl','al','kr','ar','el','wl','er','wr'].forEach(j=>P[j]=[L(A[j][0],B[j][0]),L(A[j][1],B[j][1])]);
 const air=L(A.air,B.air),sc=Math.min(W/80,H/60),ox=(W-80*sc)/2,oy=(H-60*sc)/2,X=p=>[ox+p[0]*sc,oy+p[1]*sc],col=getComputedStyle(document.body).getPropertyValue('--acc').trim()||'#4cc9f0';
 c.strokeStyle='rgba(255,255,255,.16)';c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(ox,oy+53*sc);c.lineTo(ox+80*sc,oy+53*sc);c.stroke();
 c.fillStyle='rgba(0,0,0,.28)';c.beginPath();c.ellipse(ox+40*sc,oy+53.4*sc,(15-air*1.5)*sc,1.5*sc,0,0,6.283);c.fill();
 const seg=(pts,w,color,al)=>{c.globalAlpha=al==null?1:al;c.strokeStyle=color;c.lineWidth=w*sc;c.lineCap='round';c.lineJoin='round';c.beginPath();pts.forEach((p,i)=>{const q=X(p);i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1])});c.stroke();c.globalAlpha=1};
 const skin='#f2b88f',pants='#2d3558',al=still?.3:.2+.16*Math.sin(tm*3.4);
 const dot=(p,r,cl)=>{const q=X(p);c.fillStyle=cl;c.beginPath();c.arc(q[0],q[1],r*sc,0,6.283);c.fill()};
 /* legs */
 [['kl','al'],['kr','ar']].forEach(k=>{seg([P.p,P[k[0]],P[k[1]]],5.6,pants);dot([P[k[1]][0]+(k[0]==='kl'?-1.6:1.6),P[k[1]][1]+.3],2.4,'#f4f6ff')});
 /* torso, arms, head */
 seg([P.s,P.p],9.6,col);[['el','wl'],['er','wr']].forEach(k=>{seg([P.s,P[k[0]],P[k[1]]],3.8,skin);seg([P.s,[P.s[0]+(P[k[0]][0]-P.s[0])*.4,P.s[1]+(P[k[0]][1]-P.s[1])*.4]],4.8,col);dot(P[k[1]],2,skin)});
 seg([P.s,[P.s[0],P.s[1]-3]],3,skin);dot(P.h,5,skin);c.fillStyle='#2a2230';c.beginPath();c.arc(X(P.h)[0],X(P.h)[1]-.9*sc,5.1*sc,3.14,6.283);c.fill();
 if(!rest){[['kl','al'],['kr','ar']].forEach(k=>{seg([P.p,P[k[0]],P[k[1]]],5.6,col,al)});[['el','wl'],['er','wr']].forEach(k=>seg([P.s,P[k[0]],P[k[1]]],3.8,col,al))}
 c.globalAlpha=1}
