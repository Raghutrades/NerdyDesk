/* ===== Path view: bricks of days between you and your goal (build lays the path, quit takes it away) ===== */
const PA={};let PF=null,BHIT=[],HP=null,BP=null;
const PMILE=[3,7,14,21,30,50,66,100];
function pathBrickAt(x,y){for(let i=BHIT.length-1;i>=0;i--){const b=BHIT[i];if(x>=b.x-2&&x<=b.x+b.w+2&&y>=b.y0-2&&y<=b.y1+2)return b}return null}
function pathFire(g,o){o=o||{};const s=gStats(g),sn=streakInfo(g).n,q=isB(g);let kind=o.slip?'slip':PMILE.includes(sn)&&!o.replay?'mile':o.comeback?'back':'brick';
 PF={g:g.id,t0:performance.now(),kind,p:[],txt:o.slip?'Slip logged. The path is still here.':kind==='mile'?(q?'Clean day '+s.done+'. Milestone.':'Day '+s.done+' laid. Milestone.'):kind==='back'?'Rebuilt. Welcome back.':(q?'Clean day '+s.done+'. Brick destroyed.':'Day '+s.done+' laid.'),spawn:true,hit:q&&kind!=='slip'&&kind!=='back'}}
function pathStat(g){const s=gStats(g),L=lenDays(g),N=clamp(L,4,innerWidth<500?26:42),q=isB(g),exp=Math.max(1,s.expT);
 const frac=q?clamp((s.done-2*s.slips)/exp,0,1):clamp(s.done/exp,0,1);let k=Math.round(frac*N);if(!q&&s.done>0)k=Math.max(1,k);if(q&&s.done>0&&s.slips===0)k=Math.max(1,k);
 const per=Math.max(1,Math.round(L/N));let wk=null;
 if(!q){/* every elapsed day is a brick/rung; days you missed show as weak ones */
  const t=todayKey(),pe=diffD(g.start,t)+(dueState(g,t).s==='done'?1:0),E=clamp(Math.ceil(clamp(pe,0,L)/per),0,N);k=Math.max(E,s.done>0?1:0);
  wk=memo(g,'pwk'+N+'_'+per,()=>{const a=new Array(N).fill(0);for(let i=0;i<N;i++){let o=0,d=0;for(let j=0;j<per;j++){const day=addD(g.start,i*per+j);if(day>=t)break;const r=isOpp(g,day,t);if(r.o){o++;if(r.d)d++}}a[i]=o?1-d/o:0}return a})}
 if(PV.m==='start'){k=0}else if(PV.m==='done'){k=N}else if(RP.on&&S.set.mode==='path'){k=Math.floor(k*rpP()+1e-6)}
 return {s,L,N,q,frac,k:clamp(k,0,N),per,wk:PV.m?null:wk}}
function isoQuad(x,y,l,dep,sk){return [[x,y],[x+l,y],[x+l+sk,y-dep],[x+sk,y-dep]]}
function drawPath(now,dt){const th=TH(),t=now*.001,g=focusG(),rd=reduced();BHIT=[];let capFn=null;
 if(!g){cx.fillStyle='rgba(235,240,255,.7)';cx.font='600 15px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText('Add a goal to see your path',W/2,H/2);return}
 cx.save();cx.translate(W/2+SH.x,H/2+SH.y);cx.scale(SH.s,SH.s);cx.translate(-W/2,-H/2);BP=null;const fe=PF&&PF.g===g.id?(performance.now()-PF.t0)/1000:99,hitE=PF&&PF.g===g.id&&PF.hit?fe:9;
 const FL=isB(g);if(FL){cx.save();cx.translate(W,0);cx.scale(-1,1)}
 const P=pathStat(g),r=rt(g),N=P.N,q=P.q,col=q?mix(th.acc2,'#ff5d73',.5):g.color,rgb=rgbOf(col),acc=rgbOf(g.color);
 const a=PA[g.id]=PA[g.id]&&PA[g.id].length===N?PA[g.id]:(()=>{const x=new Float32Array(N);for(let i=0;i<N;i++)x[i]=(q?i<N-P.k:i<P.k)?1:0;return x})();
 const SW=Math.min(W*.94,1000),X0=(W-SW)/2,cw=SW*.2,gw=SW*.6,gx0=X0+cw,gx1=gx0+gw,Y0=H*.5,sl=.05,dep=clamp(SW*.075,14,40),th2=dep*.42,sk=dep*.9,bl=gw/N;
 const yAt=x=>Y0-(x-X0)*sl,drift=q?P.frac:0;
 /* ambient motes */
 for(let i=0;i<16;i++){const px=(i*977%100)/100*W,py=H-((t*(8+i%5*3)+i*83)%(H*1.1)),al=.12+.1*Math.sin(t+i);cx.fillStyle=`rgba(${th.sp},${al})`;cx.fillRect(px,py,1.6,1.6)}
 /* glow behind the goal */
 const gX=gx1+cw*.55+drift*SW*.1,gY=yAt(gx1+cw*.5)-dep*3.6-drift*SW*.03,gs=(1-.28*drift),lit=q?.25:P.frac;
 glow(gX,gY,SW*.2*gs,rgb,(.1+.35*lit+r.flash*.3)*(1-.4*drift),true);
 /* cliffs */
 const cliff=(x,w,al,off,sc)=>{const y=yAt(x)-off,hh=H-y+20,gr=cx.createLinearGradient(0,y,0,y+hh*.9);gr.addColorStop(0,rgba(mix(th.panel,'#ffffff',.14),.95*al));gr.addColorStop(.35,rgba(mix(th.panel,th.bg,.4),.8*al));gr.addColorStop(1,rgba(th.bg,0));
  cx.fillStyle=gr;cx.beginPath();cx.moveTo(x,y);cx.lineTo(x+w,y-w*sl);cx.lineTo(x+w,y+hh);cx.lineTo(x,y+hh);cx.fill();
  const top=isoQuad(x,y,w,dep*1.1,sk);cx.fillStyle=rgba(mix(th.panel,'#ffffff',.22),.95*al);cx.beginPath();top.forEach((p,i)=>i?cx.lineTo(p[0],p[1]-(p[0]-x)*sl):cx.moveTo(p[0],p[1]));cx.fill();
  cx.strokeStyle=rgba(th.acc,.55*al);cx.lineWidth=1.2;cx.beginPath();cx.moveTo(x,y);cx.lineTo(x+w,y-w*sl);cx.stroke()};
 cliff(X0,cw,1,0,1);
 /* slabs */
 let head=-1;
 for(let i=0;i<N;i++){const want=(q?(i<N-P.k||(i===N-P.k&&hitE<.95&&!rd)):i<P.k)?1:0;if(rd)a[i]=want;else a[i]+=(want-a[i])*Math.min(1,dt*(want?4:3));if(Math.abs(a[i]-want)<.01)a[i]=want;
  const x=gx0+i*bl,y=yAt(x),l=bl*.84,vis=a[i];if(want&&a[i]>=.99)head=i;
  if(vis<.02){if(!q&&i<N){cx.strokeStyle=`rgba(${th.sp},.1)`;cx.lineWidth=1;cx.setLineDash([2,3]);cx.beginPath();isoQuad(x,y,l,dep,sk).forEach((p,k)=>k?cx.lineTo(p[0],p[1]-(p[0]-x)*sl):cx.moveTo(p[0],p[1]));cx.closePath();cx.stroke();cx.setLineDash([])}continue}
  BHIT.push({g,x:q?W-x-(l+sk):x,w:l+sk,y0:y-dep-sk*sl,y1:y+th2,d0:addD(g.start,i*P.per),d1:addD(g.start,Math.min(P.L-1,i*P.per+P.per-1))});const off=q?(1-vis)*70:-(1-vis)*60,al=q?vis:Math.min(1,vis*1.4),hot=(i===head?r.flash:0)+(i===head?.25+.15*Math.sin(t*3):0);
  cx.globalAlpha=al;const fy=y+off;
  cx.fillStyle=rgba(mix(th.panel,'#000000',.3),.95);cx.fillRect(x,fy,l,th2);
  cx.fillStyle=rgba(mix(th.panel,'#ffffff',.2+.3*hot),.97);cx.beginPath();isoQuad(x,fy,l,dep,sk).forEach((p,k)=>k?cx.lineTo(p[0],p[1]-(p[0]-x)*sl):cx.moveTo(p[0],p[1]));cx.fill();
  const wv=!q&&P.wk?P.wk[i]||0:0;if(wv>0){const sx=(px,py)=>[px,py-(px-x)*sl];cx.save();if(wv>=.99){cx.fillStyle='rgba(8,10,16,.55)';cx.beginPath();[[x+l*.42,fy-dep*.1],[x+l*.55,fy+th2*1.2],[x+l*.7,fy-dep*.1]].forEach((p0,k0)=>k0?cx.lineTo(p0[0],p0[1]):cx.moveTo(p0[0],p0[1]));cx.fill()}cx.strokeStyle=wv>=.99?'rgba(255,110,130,.95)':'rgba(255,150,120,.85)';cx.lineWidth=1.6;cx.beginPath();if(l>=9){cx.moveTo(x+l*.38,fy-dep*.8);cx.lineTo(x+l*.5,fy-dep*.5);cx.lineTo(x+l*.4,fy-dep*.3);cx.lineTo(x+l*.58,fy-dep*.05);if(wv>=.5){cx.moveTo(x+l*.72,fy-dep*.7);cx.lineTo(x+l*.62,fy-dep*.45);cx.lineTo(x+l*.78,fy-dep*.25)}}else{cx.moveTo(x+l*.3,fy-dep*.7);cx.lineTo(x+l*.7,fy-dep*.45);cx.lineTo(x+l*.35,fy-dep*.25)}cx.stroke();cx.fillStyle=`rgba(255,90,110,${.1+.22*wv})`;cx.fillRect(x,fy-dep*.9,l,dep*.9+th2);cx.restore()}
  const ms=PMILE.includes((i+1)*P.per)||PMILE.includes(i*P.per+P.per);cx.strokeStyle=ms?'#ffd23f':rgba(col,.55+.4*hot);cx.lineWidth=ms?1.8:1.1;cx.beginPath();cx.moveTo(x,fy);cx.lineTo(x+l,fy);cx.stroke();
  if(q&&i===N-P.k)BP={x:x+l/2+sk/2,y:y-dep/2};if(i===head)HP={x:x+l/2+sk/2,y:fy-dep/2};if(hot>.3)glow(x+l/2+sk/2,fy-dep/2,dep*1.8,rgb,hot*.6);cx.globalAlpha=1}
 /* cliff with goal (drifts away on quit) */
 cx.globalAlpha=1-.45*drift;cliff(gx1+drift*SW*.1,cw,1,drift*SW*.03,gs);cx.globalAlpha=1;
/* the person: a tiny stick figure. Build: walks out along the new bricks. Quit: stands on firm ground and turns away */
 const tgt=q?0:(head>=0?head+.5:-.4),pi=r.pi==null?tgt:r.pi;r.pi=rd?tgt:pi+(tgt-pi)*Math.min(1,dt*3);const moving=!q&&Math.abs(tgt-r.pi)>.05;
 const ox=q?X0+cw*.55:gx0+(r.pi+.5)*bl+(r.pi<0?-cw*.35:0),oy=yAt(ox)-dep*.5,mh=clamp(SW*.055,20,38),today=dueState(g).s==='done';
  /* idle life: stands, paces, thinks, hops, looks around */
 let mode='stand',dx=0,jy=0,dr=q?-1:1,think=false;
 const cel=PF&&PF.g===g.id&&PF.kind!=='slip'&&fe>(PF.hit?1.2:.7)&&fe<(PF.kind==='mile'?4.6:3);
 if(hitE<1.1&&!rd)mode='hit';
 else if(cel&&!rd){mode='cheer';jy=-Math.abs(Math.sin((fe-.7)*5.5))*mh*.55}
 else if(moving)mode='walk';
 else if(!rd){const cy=(t+(g.id.charCodeAt(g.id.length-1)%7))%15;
  if(cy>=3&&cy<6){const p=(cy-3)/3;mode='walk';dx=Math.sin(p*6.283)*mh*.9;dr=Math.cos(p*6.283)>=0?1:-1;if(q)dr=-dr}
  else if(cy>=7&&cy<10.5){mode='think';think=true}
  else if(cy>=11&&cy<12){mode='cheer';jy=-Math.abs(Math.sin((cy-11)*3.14159))*mh*.8}
  else if(cy>=12.5&&cy<14){dr=Math.sin((cy-12.5)*4)>0?1:-1;if(q)dr=-dr}
  else if(r.flash>.25||today&&q&&(t%6<1.6))mode='cheer'}
 glow(ox+dx,oy-mh*.5+jy,mh*1.3,acc,.3+r.flash*.4);stickMan(ox+dx,oy+jy,mh,t,mode,dr,rd,hitE);
 if(think){cx.fillStyle='rgba(255,255,255,.8)';for(let k=0;k<3;k++){const a=.4+.6*Math.max(0,Math.sin(t*3-k*.8));cx.globalAlpha=a;cx.beginPath();cx.arc(ox+dx+(k-1)*mh*.3,oy-mh*1.25-k*mh*.05,mh*.07+k*.4,0,6.283);cx.fill()}cx.globalAlpha=1}
 /* fire sequence: dust, light run and a caption */
 if(PF&&PF.g===g.id){const e=(performance.now()-PF.t0)/1000,life=PF.kind==='mile'?5.4:3.6;if(e>life){PF=null}else{
  if(PF.hit&&BP&&!rd){if(e>.42&&e<.95){const f=(e-.42)/.53,sx=ox+mh*.9*(q?1:-1)*0,sy=oy-mh*.9;cx.save();cx.globalAlpha=.9;cx.strokeStyle='#fff';cx.shadowColor=col;cx.shadowBlur=12;cx.lineWidth=2;cx.beginPath();cx.moveTo(sx,sy);const ex=sx+(BP.x-sx)*f,ey=sy+(BP.y-sy)*f;for(let k=1;k<6;k++){const u=k/6;cx.lineTo(sx+(ex-sx)*u+(Math.random()-.5)*8,sy+(ey-sy)*u+(Math.random()-.5)*8)}cx.lineTo(ex,ey);cx.stroke();cx.restore();glow(ex,ey,14,rgb,.9)}
   if(e>=.95&&!PF.boom){PF.boom=true;for(let i=0;i<30;i++){const a=Math.random()*6.283,sp=40+Math.random()*130;PF.p.push({x:BP.x,y:BP.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-40,l:1})}PF.ring=BP;sfx('fire')}
   if(PF.ring&&e<1.7){const f=(e-.95)/.75;cx.strokeStyle=rgba('#ffffff',Math.max(0,1-f));cx.lineWidth=2;cx.beginPath();cx.arc(PF.ring.x,PF.ring.y,dep*(.5+f*3),0,6.283);cx.stroke();glow(PF.ring.x,PF.ring.y,dep*3,rgb,Math.max(0,.8-f))}}
  if(!PF.hit&&PF.kind!=='slip'&&HP&&e>.45&&!PF.boom&&!rd){PF.boom=true;PF.ring=HP;for(let i=0;i<14;i++){const a=-Math.PI/2+(Math.random()-.5)*2.6,sp=60+Math.random()*110;PF.sh=(PF.sh||[]);PF.sh.push({x:HP.x,y:HP.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,r:Math.random()*6,vr:(Math.random()-.5)*14,z:2+Math.random()*3.5,l:1})}}
  if(PF.hit&&PF.boom&&BP&&!PF.sh&&!rd){PF.sh=[];for(let i=0;i<18;i++){const a=Math.random()*6.283,sp=50+Math.random()*150;PF.sh.push({x:BP.x,y:BP.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-60,r:Math.random()*6,vr:(Math.random()-.5)*16,z:2.5+Math.random()*4,l:1})}}
  if(PF.sh){cx.fillStyle=rgba(mix(th.panel,'#ffffff',.45),1);cx.strokeStyle=rgba(col,.9);cx.lineWidth=1;PF.sh.forEach(q2=>{q2.x+=q2.vx*dt;q2.y+=q2.vy*dt;q2.vy+=260*dt;q2.r+=q2.vr*dt;q2.l-=dt*.55;if(q2.l>0){cx.save();cx.globalAlpha=Math.min(1,q2.l*1.5);cx.translate(q2.x,q2.y);cx.rotate(q2.r);cx.beginPath();cx.moveTo(-q2.z,-q2.z*.7);cx.lineTo(q2.z,-q2.z*.3);cx.lineTo(q2.z*.3,q2.z*.8);cx.closePath();cx.fill();cx.stroke();cx.restore()}});cx.globalAlpha=1}
  if(PF.spawn&&HP){PF.spawn=false;const n=rd?0:PF.kind==='mile'?36:PF.kind==='slip'?6:18;for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*2.4,sp=30+Math.random()*90;PF.p.push({x:HP.x,y:HP.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,l:1})}}
  const gold=PF.kind==='mile',pc=PF.kind==='slip'?'#ff9aa8':gold?'#ffd23f':g.color;PF.p.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=120*dt;p.l-=dt*.9;if(p.l>0){cx.globalAlpha=p.l*.8;cx.fillStyle=pc;cx.fillRect(p.x,p.y,2.2,2.2)}});cx.globalAlpha=1;
  if(HP&&!rd&&e<1.6&&PF.kind!=='slip'){const f=e/1.6;cx.strokeStyle=rgba(pc,(1-f)*.7);cx.lineWidth=1.6;cx.beginPath();cx.arc(HP.x,HP.y,dep*(.6+f*2.4),0,6.283);cx.stroke()}
  if(HP&&e<2.4&&!rd&&PF.kind!=='slip'){const f=clamp(e/2.4,0,1);const lx=HP.x+(gX-HP.x)*f,ly=HP.y+(gY-HP.y)*f;glow(lx,ly,16,gold?'255,210,63':rgb,(1-f)*.9)}
  const ca=e<.4?e/.4:e>life-.8?(life-e)/.8:1;capFn=((tx,al,c2,fz)=>()=>{cx.globalAlpha=clamp(al,0,1);cx.fillStyle=c2;cx.textAlign='center';cx.font='700 '+fz+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(tx,W/2,Y0-SW*.09);cx.globalAlpha=1})(PF.txt,ca,pc,clamp(SW*.034,13,19))}}
 /* the goal diamond */
 const dh=SW*.045*gs+8,fl=.55+.45*Math.sin(t*2);cx.save();cx.translate(gX,gY+(rd?0:Math.sin(t*1.6)*3));
 cx.globalAlpha=1-.35*drift;cx.strokeStyle=rgba(col,.9);cx.lineWidth=1.6;cx.fillStyle=rgba(col,.12+.6*lit*(q?0:1)+.1*fl);
 cx.beginPath();cx.moveTo(0,-dh*1.2);cx.lineTo(dh*.75,0);cx.lineTo(0,dh*1.2);cx.lineTo(-dh*.75,0);cx.closePath();cx.fill();cx.stroke();
 cx.beginPath();cx.moveTo(0,-dh*1.2);cx.lineTo(0,dh*1.2);cx.moveTo(-dh*.75,0);cx.lineTo(dh*.75,0);cx.strokeStyle=rgba(col,.35);cx.lineWidth=1;cx.stroke();cx.restore();cx.globalAlpha=1;
 if(!q&&P.frac>=1){for(let k=0;k<2;k++){const f=((t*.7+k*.5)%1);cx.strokeStyle=rgba(g.color,(1-f)*.6);cx.lineWidth=1.4;cx.beginPath();cx.arc(gX,gY,dh*(1.4+f*2.6),0,6.283);cx.stroke()}}
 HITS.push({g,x:q?W-gX:gX,y:gY,r:dh*1.3,z:1,s:1});
 if(FL)cx.restore();if(capFn)capFn();
 /* captions */
 cx.textAlign='center';cx.font='700 '+clamp(SW*.026,11,15)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillStyle=rgba(col,.95);cx.fillText(q?'Temptation':'Goal',q?W-gX:gX,gY-dh*1.5-8);
 cx.fillStyle='rgba(235,240,255,.92)';cx.font='600 '+clamp(SW*.03,12,17)+'px Bricolage Grotesque,system-ui,sans-serif';
 const day=clamp(diffD(g.start,todayKey())+1,0,P.L);cx.fillText(P.k+' of '+P.N+' '+(q?'bricks removed':'bricks laid')+(P.per>1?' ('+P.per+' days each)':''),W/2,Y0+Math.min(SW*.17,H*.22));
 cx.fillStyle='rgba(235,240,255,.6)';cx.font='500 '+clamp(SW*.024,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(g.name+' · day '+day+' of '+P.L+(W>600?(q?' · each clean day removes a brick':' · each day you show up lays a brick'):''),W/2,Y0+Math.min(SW*.17,H*.22)+20);cx.restore();
 const mx=x=>W/2+SH.x+(x-W/2)*SH.s,my=y=>H/2+SH.y+(y-H/2)*SH.s;BHIT.forEach(b=>{b.x=mx(b.x);b.w*=SH.s;b.y0=my(b.y0);b.y1=my(b.y1)});const lh=HITS[HITS.length-1];if(lh&&lh.g===g){lh.x=mx(lh.x);lh.y=my(lh.y);lh.r*=SH.s}}

function stickMan(x,y,h,t,mode,dir,rd,he){const c=cx,u=h/10,w=Math.max(1.6,h*.075);c.save();c.translate(x,y);c.scale(dir,1);c.strokeStyle='#ffffff';c.fillStyle='#ffffff';c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.shadowColor='rgba(255,255,255,.6)';c.shadowBlur=6;
 const ph=rd?0:t*(mode==='walk'?9:2),sw=mode==='walk'?Math.sin(ph):0,bob=mode==='walk'?Math.abs(Math.cos(ph))*u*.5:rd?0:Math.sin(t*1.6)*u*.12+(mode==='cheer'?-Math.abs(Math.sin(t*6))*u*.7:0),lean=mode==='walk'?u*.5:0;
 const hip=[0,-u*4.3-bob],sh=[lean,-u*7.2-bob],hd=[lean*1.2,-u*8.6-bob];
 const leg=(a,k)=>{const fx=Math.sin(a)*u*3.1,kx=Math.sin(a*.5)*u*1.5;c.beginPath();c.moveTo(hip[0],hip[1]);c.lineTo(hip[0]+kx,hip[1]+u*2.3);c.lineTo(hip[0]+fx,k?-u*.1:0);c.stroke()};
 const sp=mode==='walk'?sw*.75:.3;leg(sp,sw<0&&mode==='walk');leg(-sp,sw>0&&mode==='walk');
 c.beginPath();c.moveTo(hip[0],hip[1]);c.lineTo(sh[0],sh[1]);c.stroke();
 const arm=(a,up)=>{c.beginPath();c.moveTo(sh[0],sh[1]+u*.3);if(up){c.lineTo(sh[0]+a*u*1.6,sh[1]-u*1.4);c.lineTo(sh[0]+a*u*2.4,sh[1]-u*2.8)}else{c.lineTo(sh[0]+Math.sin(a)*u*1.3,sh[1]+u*1.7);c.lineTo(sh[0]+Math.sin(a)*u*1.8,sh[1]+u*3.2)}c.stroke()};
 if(mode==='think'){arm(-.5,false);c.beginPath();c.moveTo(sh[0],sh[1]+u*.3);c.lineTo(sh[0]+u*1.5,sh[1]+u*1.1);c.lineTo(hd[0]+u*.7,hd[1]+u*1.4);c.stroke()}else if(mode==='hit'){const sw2=he<.25?-1.1:he<.42?-1.1+(he-.25)/.17*2.6:1.5-(he-.42)*.6;arm(-.5,false);c.beginPath();c.moveTo(sh[0],sh[1]+u*.3);const hx=sh[0]+Math.sin(sw2)*u*2.6,hy=sh[1]-Math.cos(sw2)*u*2.6;c.lineTo(hx,hy);c.stroke();c.lineWidth=w*1.1;const ax=Math.sin(sw2),ay=-Math.cos(sw2);c.beginPath();c.moveTo(hx,hy);c.lineTo(hx+ax*u*1.2,hy+ay*u*1.2);c.stroke();c.lineWidth=w*2.4;c.beginPath();c.moveTo(hx+ax*u*1.2-ay*u*.9,hy+ay*u*1.2+ax*u*.9);c.lineTo(hx+ax*u*1.2+ay*u*.9,hy+ay*u*1.2-ax*u*.9);c.stroke();c.lineWidth=w}else if(mode==='cheer'){arm(-1,true);arm(1,true)}else if(mode==='walk'){arm(-sw*.9+.1,false);arm(sw*.9+.1,false)}else{arm(-.5,false);arm(.5,false)}
 c.beginPath();c.arc(hd[0],hd[1],u*1.15,0,6.283);c.fill();c.restore()}
