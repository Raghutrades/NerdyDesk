/* ===== Tree view: day 1 is a seed. Every finished day the stick man walks over, waters it and it grows, until a full tree with fruit. Between jobs he sits at his desk, stands, stretches, thinks. ===== */
const TRE={};
const trR=s=>{s=Math.sin(s*127.1+311.7)*43758.5453;return s-Math.floor(s)};
const trPick=a=>a[Math.floor(Math.random()*a.length)];
function trIK(a,b,l1,l2,pref){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||.001;const mx=l1+l2-.01;if(d>mx){b=[a[0]+dx/d*mx,a[1]+dy/d*mx];dx=b[0]-a[0];dy=b[1]-a[1];d=mx}
 const a1=Math.atan2(dy,dx),ca=clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1),an=Math.acos(ca);let best=null,bs=-1e9;[-1,1].forEach(sg=>{const m=[a[0]+Math.cos(a1+sg*an)*l1,a[1]+Math.sin(a1+sg*an)*l1],sc=(m[0]-a[0])*pref[0]+(m[1]-a[1])*pref[1];if(sc>bs){bs=sc;best=m}});return [best,b]}
function trCan(c,hx,hy,d,u,tilt){c.save();c.translate(hx,hy);c.scale(d,1);c.rotate(tilt);c.fillStyle='#8fb8d8';c.strokeStyle='#fff';c.lineWidth=Math.max(1.2,u*.22);
 c.beginPath();c.moveTo(.1*u,-.9*u);c.lineTo(2.3*u,-.9*u);c.lineTo(2.1*u,.8*u);c.lineTo(.3*u,.8*u);c.closePath();c.fill();c.stroke();
 c.beginPath();c.moveTo(2.2*u,.3*u);c.lineTo(3.5*u,-.9*u);c.stroke();c.beginPath();c.arc(.1*u,-.05*u,.8*u,Math.PI*.5,Math.PI*1.5);c.stroke();c.restore();
 const lx=3.5*u,ly=-.9*u,co=Math.cos(tilt),si=Math.sin(tilt);return [hx+d*(lx*co-ly*si),hy+(lx*si+ly*co)]}
function trMan(x,gy,h,o){const c=cx,u=h/10,d=o.d,w=Math.max(1.8,h*.07),t=o.t,ph=o.ph,P=o.pose;c.save();c.strokeStyle='#fff';c.fillStyle='#fff';c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.shadowColor='rgba(255,255,255,.55)';c.shadowBlur=6;
 const sit=P.startsWith('sit'),bob=o.rd?0:Math.sin(t*1.8)*u*.08;let hip,sh,hd,hands=[],feet=[],cup=false,can=null;
 const pa=[d,.2],pk=[d,0],pe=[-d*.4,1];
 if(sit){hip=[x,gy-2.6*u+bob];sh=[x+d*.3*u,hip[1]-3*u];hd=[sh[0]+d*.4*u,sh[1]-1.5*u];
  feet=[[x+d*2.5*u,gy],[x+d*2.9*u,gy]];const dk=gy-4.5*u;
  if(P==='sit-type'){const j=o.rd?0:1;hands=[[x+d*(4.5*u+Math.sin(t*15)*.18*u*j),dk+Math.sin(t*19)*.2*u*j],[x+d*(4.9*u+Math.sin(t*13+1)*.18*u*j),dk+Math.sin(t*17+2)*.2*u*j]];hd[1]+=Math.sin(t*2.2)*u*.12}
  else if(P==='sit-write'){hands=[[x+d*(4.2*u+Math.sin(t*2.6)*.7*u),dk],[x+d*3.3*u,dk]]}
  else if(P==='sit-drink'){const sv=o.rd?1:clamp(.5+.95*Math.sin(t*1.3),0,1),ss2=sv*sv*(3-2*sv),mg=[o.mx!=null?o.mx:x+d*5.6*u,dk-.25*u],mo=[hd[0]+d*.9*u,hd[1]+.7*u];hands=[[x+d*3.6*u,dk],[mg[0]+(mo[0]-mg[0])*ss2,mg[1]+(mo[1]-mg[1])*ss2]];cup=hands[1]}
  else if(P==='sit-think'){hands=[[x+d*3.4*u,dk],[hd[0]+d*.5*u,hd[1]+1.3*u]];hd[0]+=d*.3*u}
  else if(P==='sit-sad'){hd=[sh[0]+d*.9*u,sh[1]-1*u];hands=[[x+d*1.6*u,hip[1]-.2*u],[x+d*1.2*u,hip[1]-.1*u]]}
  else hands=[[x+d*4.5*u,dk],[x+d*4.9*u,dk]]}
 else{let hy=gy-4.2*u+bob,lean=0,jump=0;
  if(P==='plant'){lean=o.bend}if(P==='cheer'&&!o.rd)jump=-Math.abs(Math.sin(t*6))*u*1.1;
  hip=[x,hy+jump];sh=[x+d*lean*2.6*u,hip[1]-3*u*(1-.5*lean)];hd=[sh[0]+d*(.3+lean*.9)*u,sh[1]-1.5*u*(1-.2*lean)];
  const s=Math.sin(ph),cs=Math.cos(ph);
  if(P==='walk'||P==='carry'){feet=[[x+s*1.7*u,gy-Math.max(0,cs)*.9*u],[x-s*1.7*u,gy-Math.max(0,-cs)*.9*u]];hip[1]+=-Math.abs(cs)*u*.12;sh[1]=hip[1]-3*u;hd[1]=sh[1]-1.5*u;
   hands=P==='carry'?[[sh[0]+d*1.9*u,sh[1]+2.5*u],[sh[0]+d*s*.9*u,sh[1]+2.8*u]]:[[sh[0]+d*s*1.6*u,sh[1]+2.8*u],[sh[0]-d*s*1.6*u,sh[1]+2.8*u]];if(P==='carry')can=[hands[0],.05]}
  else{feet=[[x-.6*u,gy],[x+.6*u,gy]];
   if(P==='think')hands=[[hd[0]+d*.5*u,hd[1]+1.3*u],[sh[0]+d*1.1*u,sh[1]+2.1*u]];
   else if(P==='stretch'){const k=o.rd?0:Math.sin(t*1.5);hands=[[sh[0]-.9*u,sh[1]-3.2*u+k*.4*u],[sh[0]+.9*u,sh[1]-3.2*u-k*.4*u]];sh[0]+=k*.3*u;hd[0]+=k*.4*u}
   else if(P==='scratch')hands=[[hd[0]+d*.2*u,hd[1]-1.4*u+Math.sin(t*12)*.25*u],[sh[0]+d*.2*u,sh[1]+2.8*u]];
   else if(P==='write'||P==='point'){const j=o.rd||P==='point'?0:1;hands=[[o.hx+Math.sin(t*13)*.22*u*j,o.hy+Math.sin(t*17+1)*.25*u*j],[sh[0]-d*.3*u,sh[1]+2.8*u]];hd[0]+=d*.5*u;hd[1]+=0}
   else if(P==='look')hands=[[hd[0]+d*1.4*u,hd[1]-.2*u],[sh[0]+d*.3*u,sh[1]+2.8*u]];
   else if(P==='sip'){const sv=o.rd?1:clamp(.5+.95*Math.sin(t*1.2),0,1),ss2=sv*sv*(3-2*sv),lo=[sh[0]+d*1.5*u,sh[1]+2.2*u],mo=[hd[0]+d*.9*u,hd[1]+.7*u];hands=[[sh[0]-d*.3*u,sh[1]+2.8*u],[lo[0]+(mo[0]-lo[0])*ss2,lo[1]+(mo[1]-lo[1])*ss2]];cup=hands[1]}
   else if(P==='throw'){const p=o.tp||0,a=p<.45?p/.45:1,b=p<.45?0:clamp((p-.45)/.3,0,1),bk=[sh[0]-d*1.7*u,sh[1]-.4*u],fr=[sh[0]+d*2.6*u,sh[1]-2.6*u];hands=[[bk[0]+(fr[0]-bk[0])*b*b,bk[1]+(fr[1]-bk[1])*b*b-(1-a)*0],[sh[0]+d*.9*u,sh[1]+1.4*u]];sh[0]+=d*(b*.5-a*.2)*u}
   else if(P==='dance'){const k=o.rd?0:t,sn=Math.sin(k*5),b=Math.abs(sn),v=Math.floor(k/6)%3;hip[0]+=Math.sin(k*2.5)*u*.8;hip[1]-=b*u*.45;sh[0]=hip[0]+Math.sin(k*2.5+1)*u*.5*(v===1?2:1);sh[1]=hip[1]-3*u;hd=[sh[0]+sn*.35*u,sh[1]-1.5*u];
    hands=v===0?[[sh[0]-2.3*u,sh[1]-(1.2+1.9*(.5+.5*sn))*u],[sh[0]+2.3*u,sh[1]-(1.2+1.9*(.5-.5*sn))*u]]:v===1?[[sh[0]-2.6*u,sh[1]+.2*u+sn*.8*u],[sh[0]+2.6*u,sh[1]+.2*u-sn*.8*u]]:[[sh[0]-1.6*u,sh[1]-3.4*u],[sh[0]+1.6*u,sh[1]-3.4*u+Math.sin(k*10)*.5*u]];
    feet=[[hip[0]-1.3*u+sn*.5*u,gy-Math.max(0,sn)*.9*u],[hip[0]+1.3*u+sn*.5*u,gy-Math.max(0,-sn)*.9*u]]}
   else if(P==='wave'){const k=o.rd?0:Math.sin(t*9);hands=[[sh[0]+d*1.6*u+k*.5*u,sh[1]-2.4*u],[sh[0]-d*.3*u,sh[1]+2.8*u]]}
   else if(P==='cheer')hands=[[sh[0]-2.2*u,sh[1]-3.2*u-Math.abs(Math.sin(t*7))*.6*u],[sh[0]+2.2*u,sh[1]-3.2*u-Math.abs(Math.sin(t*7+1))*.6*u]];
   else if(P==='plant')hands=[[o.hx,o.py!=null?o.py:gy-.2*u],[sh[0]+d*1.2*u,sh[1]+2.2*u]];
   else if(P==='pour'){hands=[[sh[0]+d*2.2*u,sh[1]+1.8*u],[sh[0]+d*1.3*u,sh[1]+2.4*u]];can=[hands[0],o.tilt]}
   else{const k=o.rd?0:Math.sin(t*1.3);hands=[[sh[0]+d*.5*u+k*.2*u,sh[1]+2.8*u],[sh[0]-d*.3*u,sh[1]+2.8*u]]}}}
 const L=(a,b,m)=>{c.beginPath();c.moveTo(a[0],a[1]);c.lineTo(m[0],m[1]);c.lineTo(b[0],b[1]);c.stroke()};
 {const T=o.T,raw=[hip,sh,hd,hands[0],hands[1],feet[0],feet[1]],key=P+d;
  if(T.pk!==key){T.jfrom=T.jc?T.jc.map(q=>q.slice()):null;T.bt=0;T.pk=key}T.bt+=o.dt||.016;
  const x0=clamp(T.bt/.38,0,1),bl=T.jfrom&&!o.rd?x0*x0*(3-2*x0):1;
  const cur=raw.map((q,i)=>bl>=1?q:[T.jfrom[i][0]+(q[0]-T.jfrom[i][0])*bl,T.jfrom[i][1]+(q[1]-T.jfrom[i][1])*bl]);T.jc=cur;
  hip=cur[0];sh=cur[1];hd=cur[2];hands=[cur[3],cur[4]];feet=[cur[5],cur[6]];if(cup)cup=hands[1]}
 feet.forEach(f=>{const r=trIK(hip,f,2.1*u,2.1*u,pk);L(hip,r[1],r[0])});
 c.beginPath();c.moveTo(hip[0],hip[1]);c.lineTo(sh[0],sh[1]);c.stroke();
 hands.forEach(hh=>{const r=trIK(sh,hh,1.65*u,1.65*u,pe);L(sh,r[1],r[0])});
 c.beginPath();c.arc(hd[0],hd[1],u*1.15,0,6.283);c.fill();
 if(cup){c.fillStyle='#e8c9a0';c.fillRect(cup[0]-.45*u,cup[1]-.5*u,.9*u,.9*u)}
 if(o.brick){const bh=hands[0];c.shadowBlur=0;c.fillStyle='#e0873f';c.fillRect(bh[0]-.9*u,bh[1]-.5*u,1.8*u,.9*u)}
 let tip=null;if(can){c.shadowBlur=0;tip=trCan(c,hands[0][0],hands[0][1],d,u,can[1])}
 c.restore();return tip}
/* desk, chair and laptop at the left; a small can waits beside it */
function trDesk(x,gy,u,t,rd,canHere){const c=cx;c.save();c.lineCap='round';c.lineJoin='round';
 c.strokeStyle='rgba(206,176,138,.95)';c.lineWidth=Math.max(2,u*.35);
 c.beginPath();c.moveTo(x-1.2*u,gy-5.8*u);c.lineTo(x-1.2*u,gy-2.3*u);c.lineTo(x+1.1*u,gy-2.3*u);c.moveTo(x-.1*u,gy-2.3*u);c.lineTo(x-.1*u,gy);c.moveTo(x-1.2*u,gy);c.lineTo(x+.9*u,gy);c.stroke();
 c.beginPath();c.moveTo(x+3.2*u,gy-4.2*u);c.lineTo(x+9*u,gy-4.2*u);c.moveTo(x+3.6*u,gy-4.2*u);c.lineTo(x+3.6*u,gy);c.moveTo(x+8.6*u,gy-4.2*u);c.lineTo(x+8.6*u,gy);c.stroke();
 const lx=x+5.6*u,ly=gy-4.2*u;c.strokeStyle='rgba(235,240,255,.85)';c.lineWidth=Math.max(1.4,u*.2);c.beginPath();c.moveTo(lx,ly);c.lineTo(lx+2*u,ly);c.stroke();
 c.fillStyle='rgba(150,205,255,.2)';c.beginPath();c.moveTo(lx+2*u,ly);c.lineTo(lx+2.7*u,ly-3*u);c.lineTo(lx+3.2*u,ly-3*u);c.lineTo(lx+2.5*u,ly);c.closePath();c.fill();c.stroke();
 if(!rd){c.fillStyle='rgba(150,205,255,.55)';for(let i=0;i<3;i++){const a=.5+.5*Math.sin(t*2+i*2);c.globalAlpha=.3+a*.5;c.fillRect(lx+2.2*u+i*.1*u,ly-2.6*u+i*.8*u,.35*u,.12*u)}c.globalAlpha=1}
 if(canHere){c.save();c.translate(x+10.4*u,gy);c.scale(.8,.8);trCan(c,0,-1.3*u,1,u,0);c.restore()}
 c.restore()}
/* the plant. f is growth 0..1. Returns the tips so fruit and blossom can sit on them */
/* branch ids per level, same recursion as the tree draws, so a missed day can be pinned to a real branch */
const TRIDS=(()=>{const a=[[],[],[],[],[]];const w=(lv,id)=>{a[lv].push(id);if(lv<4){const n=(id%3===0&&lv>=1)?3:2;for(let i=0;i<n;i++)w(lv+1,id*3+i+1)}};w(0,1);return a})();
function trWeak(g){if(!g||isB(g))return null;return memo(g,'trwk',()=>{const t=todayKey(),L=Math.max(1,lenDays(g)),set={},n=Math.min(diffD(g.start,t),L);let c=0;for(let j=0;j<n;j++){const r=isOpp(g,addD(g.start,j),t);if(r.o&&!r.d){const pj=j/L,lv=clamp(Math.round((pj-.04)/.15),1,4),ids=TRIDS[lv];set[ids[Math.floor(trR(j*3.7+1)*ids.length)]]=1;c++}}return c?set:null})}
function trPlant(px,gy,Hm,f,t,wilt,rd,sw,wkSet){const c=cx,tips=[],sway=rd?0:1,lc=['#3fae4a','#2f9a43','#6fcf6a','#58bd52'],wl=x=>mix(x,'#c8a23a',wilt*.8);
 const L0=Hm*.76*(.12+.27*clamp(f/.6,0,1))*clamp(f/.1,0,1),wid0=clamp(1.6+Hm*.05*f,1.6,Hm*.05),gl=l=>clamp((f-.08-l*.13)/.17,0,1);
 c.lineCap='round';
 const leaf=(x,y,a,s,col)=>{c.save();c.translate(x,y);c.rotate(a);c.fillStyle=col;c.beginPath();c.ellipse(s*.5,0,s*.62,s*.3,0,0,6.283);c.fill();c.restore()};
 const sz=Hm*(.032+.022*f);
 const br=(x,y,ang,len,wid,lv,id,wkd)=>{const g=lv===0?clamp(f/.12,0,1):gl(lv);if(g<=0)return;wkd=wkd||(wkSet&&wkSet[id]&&lv>=1);if(wkd){len*=.8;wid*=.6}const l=len*g,a=ang+(wkd?(ang>=0?.28:-.28):0)+Math.sin(t*.8+id*.7)*.02*(lv+1)*sway*(sw||1),x2=x+Math.sin(a)*l,y2=y-Math.cos(a)*l;
  c.strokeStyle=lv===0?mix('#8a5a34','#4f8a3c',clamp(1-f*2.2,0,1)):wkd?'#a38a66':'#8a5a34';c.lineWidth=Math.max(1,wid);c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();
  if(lv<4){const n=(id%3===0&&lv>=1)?3:2;for(let i=0;i<n;i++){br(x2,y2,a+(i-(n-1)/2)*(.62+.3*trR(id+i))+ (trR(id)-.5)*.2,len*.74,wid*.66,lv+1,id*3+i+1,wkd)}}
  if(lv>=1&&g>.4){if(wkd){for(let j=0;j<2;j++){const r=trR(id*7+j);leaf(x2,y2,a-1.57+(r-.5)*3.6+j*2.2,sz*g*.7,'#b99a45')}c.strokeStyle='rgba(60,40,25,.9)';c.lineWidth=1;c.beginPath();c.moveTo(x+(x2-x)*.5-2,y+(y2-y)*.5-1);c.lineTo(x+(x2-x)*.5+2,y+(y2-y)*.5+2);c.stroke()}else{const nl=lv>=3?5:3;for(let j=0;j<nl;j++){const r=trR(id*7+j);leaf(x2,y2,a-1.57+(r-.5)*3.6+j*1.2,sz*g*(.8+r*.5)*(lv>=3?1:.8),wl(lc[(id+j)%4]))}tips.push([x2,y2,g,lv])}}};
 /* sapling leaf pairs along the stem and the first two round seed leaves */
 br(px,gy,0,L0,wid0,0,1);
 const sa=1-clamp((f-.45)/.3,0,1);
 if(f>.03&&sa>0){const np=1+Math.floor(5*clamp(f/.5,0,1));c.globalAlpha=sa;for(let i=0;i<np;i++){const yy=gy-L0*(.25+.7*i/Math.max(1,np-1)*(i?1:0)+(i?0:0)),sd=i%2?1:-1,ls=Hm*(.05+.03*clamp(f/.3,0,1))*(1-i*.06);if(f<.2&&i===0){leaf(px,gy-L0,-2.7,ls*.9,wl('#6fcf6a'));leaf(px,gy-L0,-.45,ls*.9,wl('#58bd52'))}else leaf(px,yy,sd>0?-.5:-2.65,ls,wl(lc[i%4]))}c.globalAlpha=1}
 /* canopy fill once it is dense */
 if(f>.45){const ca=clamp((f-.45)/.3,0,.85);c.fillStyle=wl('#2f9a43');c.globalAlpha=ca*.8;tips.forEach(p=>{if(p[3]>=3){c.beginPath();c.arc(p[0],p[1],sz*1.9*p[2],0,6.283);c.fill()}});c.globalAlpha=1;
  c.fillStyle=wl('#58bd52');c.globalAlpha=ca*.55;tips.forEach((p,i)=>{if(p[3]>=3&&i%2){c.beginPath();c.arc(p[0]-sz*.4,p[1]-sz*.5,sz*1.2,0,6.283);c.fill()}});c.globalAlpha=1;
  tips.forEach((p,i)=>{if(p[3]>=3){for(let j=0;j<3;j++){const r=trR(i*5+j);leaf(p[0]+(r-.5)*sz*2.4,p[1]+(trR(i+j*3)-.5)*sz*2,r*6.28,sz*(1+r*.5),wl(lc[(i+j)%4]))}}})}
 /* blossom */
 if(f>.5&&f<.9){const ba=Math.sin(clamp((f-.5)/.4,0,1)*3.1416);tips.forEach((p,i)=>{if(p[3]<2||i%2)return;c.globalAlpha=ba;c.fillStyle='#fff';for(let j=0;j<5;j++){const a=j*1.2566+i;c.beginPath();c.arc(p[0]+Math.cos(a)*sz*.45,p[1]+Math.sin(a)*sz*.45,sz*.3,0,6.283);c.fill()}c.fillStyle='#ffd23f';c.beginPath();c.arc(p[0],p[1],sz*.2,0,6.283);c.fill()});c.globalAlpha=1}
 /* fruit */
 if(f>.8){const n=Math.floor(clamp((f-.8)/.2,0,1)*Math.min(14,tips.length)),fr=sz*.62*clamp((f-.8)/.15,.3,1);for(let i=0;i<n;i++){const p=tips[(i*5+2)%tips.length],red=i%3!==1;c.fillStyle=red?'#e5383b':'#8cc63f';c.beginPath();c.arc(p[0],p[1]+sz*.8,fr,0,6.283);c.fill();c.fillStyle='rgba(255,255,255,.55)';c.beginPath();c.arc(p[0]-fr*.3,p[1]+sz*.8-fr*.3,fr*.22,0,6.283);c.fill()}}
 return {tips,top:gy-L0}}
function trRoots(px,gy,sd,f,wet,t){const c=cx;if(f<=0)return;c.lineCap='round';
 const rb=(x,y,a,len,wid,lv,id)=>{const g=clamp((f*1.05+.08-lv*.2)/.3,0,1);if(g<=0)return;const l=len*g,x2=x+Math.sin(a)*l,y2=y+Math.cos(a)*l;c.strokeStyle=wet>.05?mix('#c79a6a','#9ed0ff',wet*.7):'#c79a6a';c.lineWidth=Math.max(.8,wid);c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();if(lv<3)for(let i=0;i<2+(id%2);i++)rb(x2,y2,a+(i-.5)*(.7+.5*trR(id+i))+(trR(id*2)-.5)*.3,len*.7,wid*.65,lv+1,id*3+i+1)};
 const base=sd*.55*Math.min(1,.3+f);for(let i=0;i<5;i++)rb(px,gy,(i-2)*.42+(trR(i)-.5)*.2,base,Math.max(.9,1+f*2.6),i%2?1:0,i*7+3)}
function drawTree(now,dt){const t=now*.001,g=focusG(),rd=reduced();BHIT=[];
 if(!g){cx.fillStyle='rgba(235,240,255,.7)';cx.font='600 15px Bricolage Grotesque,system-ui,sans-serif';cx.textAlign='center';cx.fillText('Add a goal to plant a seed',W/2,H/2);return}
 cx.save();cx.translate(W/2+SH.x,H/2+SH.y);cx.scale(SH.s,SH.s);cx.translate(-W/2,-H/2);
 const P=pathStat(g),N=P.N,k=P.k,q=P.q,col=g.color,fe=PF&&PF.g===g.id?(performance.now()-PF.t0)/1000:99;
 const gy=H*.62,sd=H*.17,Hm=Math.min(H*.46,W*(W<500?.6:.7)),mh=clamp(H*.19,60,118),u=mh/10,px=W*(W<500?.63:.62),seatX=W*(W<500?.15:.2),waterX=px-5.2*u;
 let T=TRE[g.id];if(!T)T=TRE[g.id]={k,gr:k/N,planted:k>0,phase:'idle',sit:true,sub:'type',pt:3,tx:seatX,x:seatX,d:1,ph:0,wet:0,drops:[],fl:[],sad:0,cheer:0,wilt:0,fullcel:k>=N,cap:null,seedY:0,wonly:false,fast:1,gd:false,N};
 T.N=N;const inst=rd||PV.m;
 if(PF&&PF.g===g.id&&!PF.tre){PF.tre=true;if(PF.kind==='slip'){T.sad=3.6;T.wilt=1;T.phase='idle';T.sit=true;T.x=seatX;T.d=1;for(let i=0;i<14&&!rd;i++)T.fl.push({x:px+(Math.random()-.5)*Hm*.5,y:gy-Hm*(.25+Math.random()*.3),vx:(Math.random()-.5)*25,vy:10+Math.random()*30,r:Math.random()*6,vr:(Math.random()-.5)*5,l:1,c:'#c8a23a',s:3+Math.random()*3})}else if(k<=T.k)T.wonly=true}
 if(PF&&PF.g===g.id&&fe>4.5)PF=null;
 if(k<T.k){T.k=k;T.gr=Math.min(T.gr,k/N+.05);T.fullcel=k>=N}
 if(inst&&T.k!==k){T.k=k;T.gr=k/N;T.planted=k>0;T.phase='idle';T.sit=true;T.x=seatX;T.fullcel=k>=N;T.wonly=false}
 if(inst){T.gr=k/N;T.planted=k>0}
 const spd=mh*1.6;let moving=false;
 const mv=(tx,sp)=>{const dx=tx-T.x,ad=Math.abs(dx);if(ad<1.5){T.v=0;return false}T.d=Math.sign(dx);const tv=Math.sign(dx)*Math.min(sp,ad*4+8);T.v=(T.v||0)+(tv-(T.v||0))*Math.min(1,dt*6);let st=T.v*dt;if(Math.abs(st)>ad)st=dx;T.x+=st;T.ph+=Math.abs(st)/(1.25*u)*3.1416;return Math.abs(T.v)>mh*.12};
 let pose='sit-type',tilt=0,bend=0,hx=px;
 if(T.sad>0){T.sad-=dt;pose='sit-sad';T.sit=true;T.x=seatX;T.d=1;T.phase='idle'}
 else if(T.phase==='idle'){
  if(!inst&&(k>T.k||T.wonly)){T.phase='toPlant';T.fast=clamp((k-T.k)/2,1,6);T.sit=false;T.gd=false}
  else if(T.sit){pose='sit-'+T.sub;T.pt-=dt;if(T.pt<=0){if(Math.random()<.3&&!rd){T.sit=false;T.sub=trPick(['stretch','think','scratch','pace','look']);T.pt=3+Math.random()*3;T.tx=T.sub==='pace'?seatX+trPick([-1,1])*2.4*u:T.sub==='look'?(seatX+waterX)/2:seatX;T.pc=1.2}else{T.sub=trPick(['type','type','write','drink','think']);T.pt=3+Math.random()*4}}}
  else{moving=mv(T.tx,spd*.6);pose=moving?'walk':T.sub==='back'?'stand':T.sub;if(!moving){if(T.sub==='back'){T.sit=true;T.x=seatX;T.d=1;T.sub='type';T.pt=3}else{if(T.sub==='look')T.d=1;T.pt-=dt;if(T.sub==='pace'){T.pc-=dt;if(T.pc<=0){T.pc=1.2;T.tx=seatX+(T.tx>seatX?-1:1)*2.4*u}}if(T.pt<=0){T.tx=seatX;T.sub='back'}}}}}
 if(T.phase==='toPlant'){const f2=T.fast;moving=mv(waterX,spd*Math.min(3.5,f2));pose='carry';if(!moving){T.d=1;T.phase=T.planted?'water':'plant';T.pt=0}}
 else if(T.phase==='plant'){T.pt+=dt*T.fast;const dur=1.9;bend=Math.sin(clamp(T.pt/dur,0,1)*3.1416)*.85;pose='plant';hx=px;if(T.pt>.95&&!T.planted){T.planted=true;T.seedY=0;sfx('tick')}if(T.pt>=dur){T.phase='water';T.pt=0}}
 else if(T.phase==='water'){T.pt+=dt*T.fast;const dur=2.3;pose='pour';tilt=clamp(T.pt/.5,0,1)*(T.pt>dur-.4?clamp((dur-T.pt)/.4,0,1):1)*.95;
  if(T.pt>.45&&T.pt<dur-.35)T._dr=(T._dr||0)+dt*T.fast;
  if(T.pt>.9&&!T.gd){T.gd=true;T.wet=1;if(k>T.k)T.k++;T.wonly=false;sfx('tick');const day=Math.max(1,gStats(g).done);T.cap={t0:now,txt:q?'Clean day '+day+'. Watered.':'Day '+day+'. Watered.'}}
  if(T.pt>=dur){if(k>T.k){T.pt=0;T.gd=false}else if(T.k>=N&&!T.fullcel){T.phase='cheer';T.pt=0;T.fullcel=true;sfx('fire')}else{T.phase='toDesk'}}}
 else if(T.phase==='cheer'){T.pt+=dt;pose='cheer';if(!rd&&Math.random()<dt*30)T.fl.push({x:px+(Math.random()-.5)*Hm*.6,y:gy-Hm*(.5+Math.random()*.4),vx:(Math.random()-.5)*40,vy:15+Math.random()*30,r:Math.random()*6,vr:(Math.random()-.5)*6,l:1,c:trPick(['#ff9ab0','#fff','#ffd23f','#6fcf6a']),s:2+Math.random()*3});if(T.pt>3.2)T.phase='toDesk'}
 else if(T.phase==='toDesk'){moving=mv(seatX,spd*Math.min(3.5,T.fast));pose='carry';if(!moving){T.phase='idle';T.sit=true;T.x=seatX;T.d=1;T.sub='type';T.pt=3}}
 if(moving&&T.phase==='idle')pose='walk';
 /* growth and soil */
 T.gr+=(T.k/N-T.gr)*Math.min(1,dt*1.4);T.wet=Math.max(0,T.wet-dt*.3);T.wilt=Math.max(0,T.wilt-dt*.12);const f=clamp(T.gr,0,1);
 /* scene */
 const rgb=rgbOf(col);glow(px,gy-Hm*.35,Hm*.9,rgb,.1+.1*f);
 const bg=cx.createLinearGradient(0,gy,0,H);bg.addColorStop(0,'rgba(70,110,50,.28)');bg.addColorStop(1,'rgba(70,110,50,0)');cx.fillStyle=bg;cx.fillRect(0,gy,W,H-gy);
 cx.strokeStyle='rgba(120,190,100,.55)';cx.lineWidth=2;cx.beginPath();cx.moveTo(0,gy);cx.lineTo(W,gy);cx.stroke();
 cx.strokeStyle='rgba(120,190,100,.5)';cx.lineWidth=1.3;for(let i=0;i<46;i++){const gx=trR(i+4)*W;if(Math.abs(gx-px)<W*.12)continue;const hh=3+trR(i)*6;cx.beginPath();cx.moveTo(gx,gy);cx.lineTo(gx-1.5,gy-hh);cx.moveTo(gx,gy);cx.lineTo(gx+2,gy-hh*.8);cx.stroke()}
 const cw=clamp(W*.05+W*.11*f,W*.06,W*.2);
 /* cutaway soil bowl */
 cx.save();cx.beginPath();cx.moveTo(px-cw,gy);cx.bezierCurveTo(px-cw,gy+sd*1.1,px-cw*.35,gy+sd,px,gy+sd);cx.bezierCurveTo(px+cw*.35,gy+sd,px+cw,gy+sd*1.1,px+cw,gy);cx.closePath();
 const sg=cx.createLinearGradient(0,gy,0,gy+sd);sg.addColorStop(0,'#8a5a33');sg.addColorStop(1,'#5b3a21');cx.fillStyle=sg;cx.fill();
 if(T.wet>.02){cx.fillStyle=`rgba(60,120,220,${.32*T.wet})`;cx.fill()}
 cx.clip();cx.fillStyle='rgba(0,0,0,.18)';for(let i=0;i<22;i++){cx.beginPath();cx.arc(px+(trR(i*3)-.5)*cw*1.8,gy+trR(i*5)*sd,1+trR(i)*2.4,0,6.283);cx.fill()}
 if(T.planted){const sy=gy+sd*.22;if(f<.12){cx.fillStyle='#b98a52';cx.beginPath();cx.ellipse(px,sy,5.5,8,0,0,6.283);cx.fill();cx.fillStyle='rgba(255,255,255,.35)';cx.beginPath();cx.ellipse(px-1.6,sy-2.5,1.5,3,0,0,6.283);cx.fill()}trRoots(px,gy,sd,f,T.wet,t)}
 cx.restore();cx.strokeStyle='rgba(60,36,20,.9)';cx.lineWidth=2;cx.beginPath();cx.moveTo(px-cw,gy);cx.bezierCurveTo(px-cw,gy+sd*1.1,px-cw*.35,gy+sd,px,gy+sd);cx.bezierCurveTo(px+cw*.35,gy+sd,px+cw,gy+sd*1.1,px+cw,gy);cx.stroke();
 /* the seed that waits on the ground for day one */
 if(!T.planted){const by=rd?0:Math.sin(t*2)*2;glow(px,gy-9+by,26,'255,210,120',.3);cx.fillStyle='#b98a52';cx.beginPath();cx.ellipse(px,gy-8+by,6,9,.3,0,6.283);cx.fill();cx.fillStyle='rgba(255,255,255,.4)';cx.beginPath();cx.ellipse(px-2,gy-11+by,1.7,3.4,.3,0,6.283);cx.fill()}
 else{const pl=trPlant(px,gy,Hm,f,t,T.wilt,rd,1,PV.m?null:trWeak(g))}
 const pm=T.planted?gy-Hm*(.1+.9*f):gy-14;HITS.push({g,x:px,y:gy-Hm*(.1+.4*f),r:Math.max(22,Hm*(.1+.28*f)),z:1,s:1});
 /* desk and the man */
 trDesk(seatX,gy,u,t,rd,!(T.phase==='toPlant'||T.phase==='plant'||T.phase==='water'||T.phase==='cheer'||T.phase==='toDesk'));
 const glw=glow;glw(T.x,gy-mh*.5,mh*1.1,rgb,.18+(T.wet>.5?.15:0));
 const tip=trMan(T.x,gy,mh,{pose,ph:T.ph,t,d:T.d,rd,tilt,bend,hx,T,dt});HITS.push({g,x:T.x,y:gy-mh*.5,r:mh*.6,z:2,s:1});
 /* water */
 if(tip&&pose==='pour'&&T._dr>0){const n=Math.floor(T._dr*(rd?0:26));T._dr-=n/26;for(let i=0;i<n;i++)T.drops.push({x:tip[0],y:tip[1],vx:T.d*(22+Math.random()*18),vy:10+Math.random()*30,l:1})}
 for(let i=T.drops.length-1;i>=0;i--){const p=T.drops[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=520*dt;cx.fillStyle='rgba(150,205,255,.9)';cx.beginPath();cx.arc(p.x,p.y,1.8,0,6.283);cx.fill();if(p.y>=gy){if(Math.random()<.5&&!rd)T.fl.push({x:p.x,y:gy,vx:(Math.random()-.5)*50,vy:-20-Math.random()*40,r:0,vr:0,l:.5,c:'#9ed0ff',s:1.6});T.drops.splice(i,1)}}
 if(T.drops.length>240)T.drops.splice(0,T.drops.length-240);
 for(let i=T.fl.length-1;i>=0;i--){const p=T.fl[i];p.x+=p.vx*dt+Math.sin(now*.003+i)*.3;p.y+=p.vy*dt;p.vy+=(p.c==='#9ed0ff'?300:40)*dt;p.r+=p.vr*dt;p.l-=dt*(p.c==='#9ed0ff'?1.6:.28);if(p.l<=0||p.y>H){T.fl.splice(i,1);continue}cx.save();cx.globalAlpha=clamp(p.l*1.5,0,1);cx.translate(p.x,p.y);cx.rotate(p.r);cx.fillStyle=p.c;cx.fillRect(-p.s,-p.s*.5,p.s*2,p.s);cx.restore()}
 /* captions */
 const stg=!T.planted?'A seed, waiting for day one':f<.06?'Seed in the soil':f<.2?'Sprout':f<.42?'Seedling':f<.6?'Sapling':f<.8?'Young tree in blossom':f<.97?'Fruit is forming':'Fully grown, in fruit';
 cx.textAlign='center';cx.fillStyle='rgba(235,240,255,.92)';cx.font='600 '+clamp(W*.03,12,17)+'px Bricolage Grotesque,system-ui,sans-serif';const yy=H-Math.min(H*.14,96);
 cx.fillText(stg+' · '+T.k+' of '+N+' days watered'+(P.per>1?' ('+P.per+' days each)':''),W/2,yy);
 const day=clamp(diffD(g.start,todayKey())+1,0,P.L);cx.fillStyle='rgba(235,240,255,.6)';cx.font='500 '+clamp(W*.024,11,14)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(g.name+' · day '+day+' of '+P.L+(W>600?(q?' · every clean day waters the tree, a slip makes it drop leaves':' · every day you show up, he waters it and it grows'):''),W/2,yy+20);
 if(T.cap){const a=(now-T.cap.t0)/1000;if(a>3.2)T.cap=null;else{cx.globalAlpha=clamp(Math.min(a/.3,(3.2-a)/.6),0,1);cx.fillStyle=g.color;cx.font='700 '+clamp(W*.036,13,19)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText(T.cap.txt,px,Math.max(78,gy-Hm-14));cx.globalAlpha=1}}
 if(T.sad>0){cx.fillStyle='#ff9aa8';cx.font='700 '+clamp(W*.034,13,18)+'px Bricolage Grotesque,system-ui,sans-serif';cx.fillText('Slip logged. The tree is still here.',W/2,Math.max(78,gy-Hm-14))}
 cx.restore();
 const mx=x=>W/2+SH.x+(x-W/2)*SH.s,my=y=>H/2+SH.y+(y-H/2)*SH.s;HITS.forEach(h=>{if(h.g===g&&h.z>=1&&!h._m){h._m=1;h.x=mx(h.x);h.y=my(h.y);h.r*=SH.s}})}

Object.assign(GI,{vm_trace:'M4 6h9M4 12h13M4 18h7M15 4v16',vm_universe:'M12 9.5a2.5 2.5 0 1 0 0 5a2.5 2.5 0 1 0 0-5zM3 12c0-2.2 4-4 9-4s9 1.8 9 4s-4 4-9 4s-9-1.8-9-4z',vm_synapse:'M5 19l5-6l4 3l5-10M4.5 18.5a1.2 1.2 0 1 0 .01 0M18.5 5.5a1.2 1.2 0 1 0 .01 0M10 13a1.2 1.2 0 1 0 .01 0',vm_path:'M3 19h5v-4h5v-4h5V7h3',vm_ladder:'M8 3v18M16 3v18M8 7h8M8 12h8M8 17h8',vm_tree:'M12 21v-7M12 14c-4 0-6-3-5-6c1-3 3-4 5-4s4 1 5 4c1 3-1 6-5 6z',vm_house:'M3 11l9-7l9 7M5 10v10h14V10M10 20v-6h4v6',vm_wall:'M3 4h18v12H3zM8 20h8M12 16v4M6.5 8.5h6M6.5 12h9'});
