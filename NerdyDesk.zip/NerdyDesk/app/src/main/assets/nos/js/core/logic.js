/* ===== schedule, streaks, strength, stats ===== */
let CACHE={rev:-1,day:'',m:new Map()};
function memo(g,name,fn){const t=todayKey();if(CACHE.rev!==REV||CACHE.day!==t){CACHE={rev:REV,day:t,m:new Map()}}const key=g.id+'|'+name;if(CACHE.m.has(key))return CACHE.m.get(key);const v=fn();CACHE.m.set(key,v);return v}
const lenDays=g=>diffD(g.start,g.end)+1;
const isDoneL=l=>!!l&&!l.slip&&!l.skip;
const isFlex=g=>!isB(g)&&(g.sched.t==='weekly'||g.sched.t==='monthly');
function sched(g,k){
 if(k<g.start||k>g.end)return false;if(isB(g))return true;const s=g.sched;
 if(s.t==='daily')return true;if(s.t==='days')return s.days.includes(dow(k));
 if(s.t==='every')return diffD(g.start,k)%Math.max(1,s.every||1)===0;return null}
function periodRange(g,k){if(g.sched.t==='weekly'){const a=weekStart(k);return[a,addD(a,6)]}const a=monthStart(k);return[a,monthEnd(k)]}
function periodCount(g,k){const r=periodRange(g,k);let n=0;const a=r[0]>g.start?r[0]:g.start,b=r[1]<g.end?r[1]:g.end;for(let d=a;d<=b;d=addD(d,1))if(isDoneL(g.logs[d]))n++;return n}
function dueState(g,k){k=k||todayKey();
 if(g.paused)return{s:'paused'};if(k<g.start)return{s:'notstarted',in:diffD(k,g.start)};if(k>g.end)return{s:'ended'};
 const l=g.logs[k];
 if(isFlex(g)){const q=g.sched.n||1,c=periodCount(g,k),per=periodRange(g,k),last=per[1]<g.end?per[1]:g.end,rd=diffD(k,last)+1;
  if(isDoneL(l))return{s:'done',c,q,flex:true};if(l&&l.skip)return{s:'skipped',c,q,flex:true};
  if(c>=q)return{s:'rest',c,q,flex:true,met:true};const need=q-c;return{s:rd<=need?'due':'optional',c,q,flex:true,urgent:rd<=need,left:rd}}
 if(l){if(l.slip)return{s:'slip'};if(l.skip)return{s:'skipped'};return{s:'done'}}
 return sched(g,k)?{s:'due'}:{s:'rest'}}
function expectedBetween(g,a,b){
 if(b>g.end)b=g.end;if(a<g.start)a=g.start;if(b<a)return 0;const len=diffD(a,b)+1;
 if(isB(g)||g.sched.t==='daily')return len;
 if(g.sched.t==='days'){let n=0;for(let d=a;d<=b;d=addD(d,1))if(g.sched.days.includes(dow(d)))n++;return n}
 if(g.sched.t==='every'){const e=Math.max(1,g.sched.every||1);let n=0;for(let d=a;d<=b;d=addD(d,1))if(diffD(g.start,d)%e===0)n++;return n}
 if(g.sched.t==='weekly')return Math.max(len>=3?1:0,Math.round((g.sched.n||1)*len/7));
 return Math.max(len>=7?1:0,Math.round((g.sched.n||1)*len/30.4))}
const expectedTotal=g=>memo(g,'expT',()=>Math.max(1,expectedBetween(g,g.start,g.end)));
function skipsTo(g,to){if(isFlex(g))return 0;let n=0;for(const k in g.logs){const l=g.logs[k];if(l&&l.skip&&k<=to&&k>=g.start)n++}return n}
const doneCount=g=>memo(g,'done',()=>{let n=0;for(const k in g.logs)if(isDoneL(g.logs[k]))n++;return n});
const slipCount=g=>memo(g,'slips',()=>{let n=0;for(const k in g.logs)if(g.logs[k]&&g.logs[k].slip)n++;return n});
const progOf=g=>clamp(doneCount(g)/expectedTotal(g),0,1);
function elapsedKey(g){const t=todayKey();if(t>g.end)return g.end;const l=g.logs[t];if(l||!sched(g,t))return t;return addD(t,-1)}
function expectedSoFar(g){const e=elapsedKey(g);return Math.max(0,expectedBetween(g,g.start,e)-skipsTo(g,e))}
function adherence(g){const ex=expectedSoFar(g);if(ex<=0)return null;let d=0;const e=elapsedKey(g);for(const k in g.logs)if(isDoneL(g.logs[k])&&k<=e)d++;return clamp(d/ex,0,1)}
function streakInfo(g){return memo(g,'streak',()=>{const t=todayKey();
 if(isFlex(g)){const unit=g.sched.t==='weekly'?'wk':'mo',q=g.sched.n||1;let n=0,k=t;
  const step=kk=>unit==='wk'?addD(weekStart(kk),-1):addD(monthStart(kk),-1);
  if(periodCount(g,k)>=q)n++;k=step(k);
  for(let i=0;i<150;i++){if(periodRange(g,k)[1]<g.start)break;if(periodCount(g,k)>=q)n++;else break;k=step(k)}
  return{n,unit}}
 let n=0;for(let k=t<g.end?t:g.end;k>=g.start;k=addD(k,-1)){if(!sched(g,k))continue;const l=g.logs[k];
  if(isDoneL(l)){n++;continue}if(l&&l.skip)continue;if(k===t)continue;break}
 return{n,unit:'d'}})}
function bestStreak(g){return memo(g,'best',()=>{const t=todayKey(),to=t<g.end?t:g.end;let best=0,cur=0;
 if(isFlex(g)){const q=g.sched.n||1;let k=g.sched.t==='weekly'?weekStart(g.start):monthStart(g.start);
  while(k<=to){const r=periodRange(g,k);if(periodCount(g,k)>=q){cur++;best=Math.max(best,cur)}else if(r[1]<to)cur=0;k=addD(r[1],1)}return best}
 for(let k=g.start;k<=to;k=addD(k,1)){if(!sched(g,k))continue;const l=g.logs[k];
  if(isDoneL(l)){cur++;best=Math.max(best,cur)}else if(l&&l.skip){}else if(k<to||l)cur=0}
 return best})}
function strengthSeries(g){return memo(g,'series',()=>{const t=todayKey(),to=t<g.end?t:g.end,out=[];if(to<g.start)return out;
 if(isB(g)){let P=1;const dec=Math.pow(.5,1/21);
  for(let k=g.start;k<=to;k=addD(k,1)){const l=g.logs[k];if(l&&l.slip)P=Math.min(1,P+.15);else if(isDoneL(l))P*=dec;else if(k<t)P=Math.min(1,P+.01);out.push({k,v:P})}return out}
 if(isFlex(g)){const q=g.sched.n||1,m=Math.pow(.5,g.sched.t==='weekly'?1/4:1/2);let s=0;
  for(let k=g.start;k<=to;k=addD(k,1)){const r=periodRange(g,k);out.push({k,v:s});
   if(k===r[1]||k===g.end){s=s*m+Math.min(1,periodCount(g,k)/q)*(1-m)}}
  const last=out[out.length-1];const r=periodRange(g,to);if(to<r[1]&&periodCount(g,to)>=q&&last)last.v=s*m+(1-m);else if(last)last.v=s;return out}
 let s=0;const m=Math.pow(.5,1/14);
 for(let k=g.start;k<=to;k=addD(k,1)){if(sched(g,k)){const l=g.logs[k];if(!(l&&l.skip)&&!(k===t&&!l))s=s*m+(isDoneL(l)?1:0)*(1-m)}out.push({k,v:s})}
 return out})}
const strengthOf=g=>{const s=strengthSeries(g);return s.length?s[s.length-1].v:(isB(g)?1:0)};
const PV={m:null};
const RP={on:false,t0:0,dur:7000};
function rpP(){if(!RP.on)return 1;const p=clamp((performance.now()-RP.t0)/RP.dur,0,1);if(p>=1){RP.on=false;return 1}return p*p*(3-2*p)}
const progAdj=real=>PV.m==='start'?0:PV.m==='done'?1:real*rpP();
const levelReal=g=>isB(g)?clamp(strengthOf(g),.1,1):clamp(.12+.88*(.6*strengthOf(g)+.4*progOf(g)),.12,1);
const urgeLv=g=>{const n=streakInfo(g).n||0;return clamp(1-.72*clamp(n/14,0,1)+.5*(1-levelReal(g)),.28,1)};
const levelOf=g=>{const q=isB(g),real=q?urgeLv(g):levelReal(g);if(PV.m)return PV.m==='start'?(q?1:.12):(q?.28:1);if(RP.on){const p=rpP();return q?1+(real-1)*p:.12+(real-.12)*p}return real};
function gStats(g){return memo(g,'stats',()=>{
 let min=0,prep=0,qs=[],urges=0,last=null,lastH=[];const keys=Object.keys(g.logs).sort();
 for(const k of keys){const l=g.logs[k];if(!l)continue;if(isDoneL(l)){last=k;min+=+l.min||0;prep+=+l.prep||0;if(l.q>0)qs.push(l.q)}urges+=+l.urges||0}
 const done=doneCount(g),expT=expectedTotal(g),ex=expectedSoFar(g),st=streakInfo(g),t=todayKey(),e=elapsedKey(g);
 const delta=done-ex;let pace=delta>=1?'ahead':delta>-1?'on pace':'behind';
 let eta=null;if(done>0&&done<expT){const el=Math.max(1,diffD(g.start,e)+1),rate=done/el,days=Math.ceil((expT-done)/rate);eta=addD(t,days)}
 return{done,expT,ex,adh:adherence(g),streak:st.n,unit:st.unit,best:bestStreak(g),strength:strengthOf(g),level:levelOf(g),prog:progOf(g),min,prep,hours:min/60,q:qs.length?avg(qs):0,urges,last,gap:last?diffD(last,t):null,slips:slipCount(g),delta:Math.round(delta),pace,eta,len:lenDays(g)}})}
function primaryField(g){return g.fields.find(f=>f.primary&&f.type==='number')||g.fields.find(f=>f.type==='number')||null}
function fieldSeries(g,f){const out=[];Object.keys(g.logs).sort().forEach(k=>{const l=g.logs[k];if(l&&l.f&&l.f[f.id]!==undefined&&l.f[f.id]!==''&&!isNaN(+l.f[f.id]))out.push({k,v:+l.f[f.id]})});return out}
function weekTotal(g,f,k){const a=weekStart(k||todayKey()),b=addD(a,6);let n=0;for(let d=a;d<=b;d=addD(d,1)){const l=g.logs[d];if(l&&isDoneL(l)&&l.f&&!isNaN(+l.f[f.id]))n+=+l.f[f.id]}return n}
function winState(g){if(!g.win)return null;const m=mins(hm()),a=mins(g.win[0]),b=mins(g.win[1]);return m<a?{s:'soon',in:a-m}:m<=b?{s:'now',left:b-m}:{s:'past'}}
const RANK={due:0,optional:1,done:2,skipped:3,slip:3,rest:4,notstarted:5,paused:6,ended:7};
function todayItems(k){k=k||todayKey();return S.goals.map(g=>({g,st:dueState(g,k)})).sort((a,b)=>(RANK[a.st.s]-RANK[b.st.s])||(PRI[b.g.priority].w-PRI[a.g.priority].w)||((a.g.win?mins(a.g.win[0]):1e4)-(b.g.win?mins(b.g.win[0]):1e4))||a.g.name.localeCompare(b.g.name))}
function nextUp(){let best=null,bs=-1;S.goals.forEach(g=>{const st=dueState(g);if(st.s!=='due'&&!(st.s==='optional'&&PRI[g.priority].w>=3))return;
 let sc=PRI[g.priority].w*10+(st.urgent?15:0),w=winState(g);if(w){if(w.s==='now')sc+=25;else if(w.s==='past')sc+=12;else sc+=Math.max(0,8-w.in/30)}
 const s=streakInfo(g);if(s.n>=3)sc+=6;if(isB(g))sc-=4;if(sc>bs){bs=sc;best={g,st,w}}});return best}
function dayStat(k){let opp=0,done=0,slip=0,items=[];S.goals.forEach(g=>{const st=dueState(g,k);if(['paused','notstarted','ended','skipped'].includes(st.s))return;
 let o=false;if(st.s==='done'){o=true;done++}else if(st.s==='slip'){o=true;slip++}else if(st.s==='due'&&(!st.flex||st.urgent)){o=k<=todayKey()}
 if(o)opp++;if(st.s!=='rest'||st.met)items.push({g,st})});return{opp,done,slip,items}}
function rateBetween(a,b,gs){let o=0,d=0;(gs||S.goals).forEach(g=>{for(let k=a;k<=b;k=addD(k,1)){const st=dueState(g,k);if(['paused','notstarted','ended','skipped'].includes(st.s))continue;
 if(st.s==='done'){d++;o++}else if(st.s==='slip')o++;else if(st.s==='due'&&k<todayKey()&&(!st.flex||st.urgent))o++}});return o?d/o:null}
function overallStrength(){const gs=S.goals.filter(g=>!g.paused&&g.start<=todayKey()&&g.end>=todayKey());if(!gs.length)return 0;let w=0,t=0;gs.forEach(g=>{const p=PRI[g.priority].w;w+=p;t+=p*(isB(g)?1-strengthOf(g):strengthOf(g))});return w?t/w:0}
const schedText=g=>{if(isB(g))return g.limit!=null&&g.limit>0?'Daily, limit '+g.limit:'Daily, stay clean';const s=g.sched;
 if(s.t==='daily')return 'Every day';if(s.t==='days')return s.days.length===7?'Every day':s.days.slice().sort((a,b)=>((a+6)%7)-((b+6)%7)).map(d=>WD[d]).join(' ');
 if(s.t==='weekly')return s.n+(s.n===1?' time':' times')+' a week';if(s.t==='every')return 'Every '+(s.every===1?'day':s.every+' days');return s.n+(s.n===1?' time':' times')+' a month'};

