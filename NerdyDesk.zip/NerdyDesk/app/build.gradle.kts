plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nerdy.desk"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nerdyintruder.nerdydesk"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    // One fixed key kept in the repo, so every new build installs OVER the old one.
    signingConfigs {
        create("nerdy") {
            storeFile = file("../keystore/nerdydesk.jks")
            storePassword = "nerdydesk"
            keyAlias = "nerdydesk"
            keyPassword = "nerdydesk"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("nerdy")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nerdy")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
