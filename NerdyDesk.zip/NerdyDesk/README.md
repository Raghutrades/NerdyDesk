# NerdyDesk

A Windows-style desktop launcher for Android: taskbar, start menu, draggable/resizable windows,
tabbed browser, file explorer, notepad, settings. Works with touch and with mouse + keyboard.

## Build the APK on GitHub (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (keep `.github/workflows/build-apk.yml`).
2. Open the repo's **Actions** tab -> **Build NerdyDesk APK** -> **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download **NerdyDesk-debug-apk** at the bottom.
4. Unzip, install `app-debug.apk` on your phone (allow "install unknown apps").

## First run
- Open NerdyDesk, tap **Allow** in File Explorer to grant all-files access.
- Start menu -> power icon -> *Choose default home app* -> NerdyDesk, so Home opens your desktop.
- Plug in a monitor/mouse/keyboard and use: Win = Start, Win+E, Win+D, Win+I, Alt+F4.
