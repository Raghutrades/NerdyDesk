# NerdyDesk 2.0

A desktop PC experience for Android: boot animation + lock screen, real window manager
(drag, resize, snap, Alt+Tab, task view), taskbar with pinned apps, Windows-style start menu,
action centre, and built-in windowed apps:

Browser (tabs, ad/tracker shield, bookmarks, history, downloads, find, reader, private tabs),
File Explorer, Photos, Video Player, Music, PDF Reader, Neuro Orbit habit tracker,
Notepad, Calculator, Task Manager, Settings.

## Build (GitHub, no Android Studio)
1. Upload `NerdyDesk.zip` to your repo (replace the old one) and put `build.yml` at `.github/workflows/build.yml`.
2. Actions -> Build NerdyDesk APK -> Run workflow.
3. Download the APK from the Releases page (or the run's Artifacts).
The APK is signed with the key in `keystore/`, so every future build installs over the previous one.
