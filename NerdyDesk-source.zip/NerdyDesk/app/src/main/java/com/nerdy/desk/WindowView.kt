package com.nerdy.desk

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView

/** A draggable, resizable, snappable window with a Windows-style title bar. */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class WindowView(val act: MainActivity, val kind: AppKind, val app: App) : FrameLayout(act) {
    companion object {
        const val SNAP_NONE = 0
        const val SNAP_LEFT = 1
        const val SNAP_RIGHT = 2
        const val SNAP_MAX = 3
        const val SNAP_TL = 4
        const val SNAP_TR = 5
        const val SNAP_BL = 6
        const val SNAP_BR = 7
        const val SNAP_TOP = 8
        const val SNAP_BOTTOM = 9
    }

    var minimized = false
    var maximized = false
    var snap = SNAP_NONE
    var desk = 0
    var chromeHidden = false
    private val exitFs = TextView(act)
    private var active = false
    private var nx = 0
    private var ny = 0
    private var nw = 0
    private var nh = 0
    private val bar = LinearLayout(act)
    private val titleView = TextView(act)
    private val iconBox = FrameLayout(act)
    private var maxBtn: TextView? = null
    private val grip = TextView(act)
    private val edgeR = View(act)
    private val edgeB = View(act)
    private var lastBarUp = 0L
    private val body = FrameLayout(act)

    init {
        elevation = dp(14).toFloat()
        applyBg()

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL

        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val tile = Ui.tileFor(act, kind, 20, 10f)
        iconBox.addView(tile, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        iconBox.setPadding(dp(10), 0, dp(8), 0)
        bar.addView(iconBox, LinearLayout.LayoutParams(dp(38), MATCH))
        titleView.text = app.title
        titleView.textSize = 12f
        titleView.setSingleLine()
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        bar.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(winBtn("\u26F6", false) { act.setWindowFullscreen(this, true) }, LinearLayout.LayoutParams(dp(42), MATCH))
        bar.addView(winBtn("\u2014", false) { act.minimizeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        val mb = winBtn("\u25A2", false) { toggleMax() }
        mb.setOnLongClickListener { snapMenu(mb); true }
        mb.setOnContextClickListener { snapMenu(mb); true }
        maxBtn = mb
        bar.addView(mb, LinearLayout.LayoutParams(dp(46), MATCH))
        bar.addView(winBtn("\u2715", true) { act.closeWindow(this) }, LinearLayout.LayoutParams(dp(46), MATCH))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(36)))

        body.addView(app.build(), FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        addView(edgeR, FrameLayout.LayoutParams(dp(7), MATCH, Gravity.END))
        addView(edgeB, FrameLayout.LayoutParams(MATCH, dp(7), Gravity.BOTTOM))
        grip.text = "\u25E2"
        grip.textSize = 12f
        grip.gravity = Gravity.BOTTOM or Gravity.END
        grip.setPadding(0, 0, dp(3), dp(1))
        addView(grip, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.END))

        exitFs.text = "\u26F6  Exit full screen"
        exitFs.textSize = 11.5f
        exitFs.setTextColor(0xFFFFFFFF.toInt())
        exitFs.setPadding(dp(12), dp(6), dp(12), dp(6))
        exitFs.background = Ui.rect(0x99000000.toInt(), dp(14).toFloat())
        exitFs.visibility = View.GONE
        exitFs.setOnClickListener { act.setWindowFullscreen(this, false) }
        val el = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        el.setMargins(0, dp(6), dp(8), 0)
        addView(exitFs, el)
        restyle()
        setActive(false)
        setupDrag()
        setupResize(grip, true, true)
        setupResize(edgeR, true, false)
        setupResize(edgeB, false, true)
    }

    fun restyle() {
        grip.setTextColor(Ui.textDim)
        applyBg()
        bar.setBackgroundColor(if (active) Ui.barActive else Ui.bar)
        titleView.setTextColor(if (active) Ui.text else Ui.textDim)
        for (i in 0 until bar.childCount) {
            val v = bar.getChildAt(i)
            if (v is TextView && v !== titleView) v.setTextColor(Ui.text)
        }
    }

    private fun applyBg() {
        val r = if (maximized || chromeHidden) 0f else dp(10).toFloat()
        background = Ui.rect(Ui.bgDark, r, if (active) Ui.accent else Ui.border, if (active) 2 else 1)
        clipToOutline = true
        outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
    }

    private fun winBtn(label: String, isClose: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(0f, 0, if (isClose) c(0xFFE81123) else Ui.hover, Ui.press, Ui.hover)
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    fun setTitle(t: String) {
        titleView.text = t
        act.taskbar.refresh()
    }

    fun title(): String = titleView.text.toString()

    /** Hide / show the title bar. The small "Exit full screen" pill stays so you can always get back. */
    fun setChromeHidden(on: Boolean) {
        chromeHidden = on
        bar.visibility = if (on) View.GONE else View.VISIBLE
        exitFs.visibility = if (on) View.VISIBLE else View.GONE
        if (on) exitFs.bringToFront()
        applyBg()
    }

    fun setActive(a: Boolean) {
        active = a
        restyle()
    }

    fun minimize() {
        minimized = true
        animate().alpha(0f).translationY(dp(40).toFloat()).setDuration(130).withEndAction {
            if (minimized) visibility = View.GONE
        }.start()
    }

    fun restore() {
        minimized = false
        visibility = View.VISIBLE
        translationY = dp(30).toFloat()
        alpha = 0f
        animate().alpha(1f).translationY(0f).setDuration(150).start()
    }

    fun popIn() {
        alpha = 0f
        scaleX = 0.93f
        scaleY = 0.93f
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).start()
    }

    fun popOut(end: () -> Unit) {
        if (visibility != View.VISIBLE) { end(); return }
        animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(120).withEndAction { end() }.start()
    }

    fun rect(): IntArray {
        val p = layoutParams as FrameLayout.LayoutParams
        return intArrayOf(p.leftMargin, p.topMargin, p.width, p.height)
    }

    /** Position and size in desktop pixels. */
    fun frame(x: Int, y: Int, w: Int, h: Int) {
        val p = layoutParams as FrameLayout.LayoutParams
        p.leftMargin = x
        p.topMargin = y
        p.width = w
        p.height = h
        layoutParams = p
    }

    private fun rememberNormal() {
        if (!maximized && snap == SNAP_NONE) {
            val r = rect()
            nx = r[0]; ny = r[1]; nw = r[2]; nh = r[3]
        }
    }

    fun setNormalRect(x: Int, y: Int, w: Int, h: Int) {
        nx = x; ny = y; nw = w; nh = h
    }

    fun applySnap(mode: Int) {
        val dw = (parent as View).width
        val dh = (parent as View).height
        if (mode == SNAP_NONE) {
            restoreNormal()
            return
        }
        rememberNormal()
        val hw = dw / 2
        val hh = dh / 2
        when (mode) {
            SNAP_MAX -> { frame(0, 0, dw, dh); maximized = true; snap = SNAP_NONE }
            SNAP_LEFT -> { frame(0, 0, hw, dh); snap = mode; maximized = false }
            SNAP_RIGHT -> { frame(hw, 0, dw - hw, dh); snap = mode; maximized = false }
            SNAP_TOP -> { frame(0, 0, dw, hh); snap = mode; maximized = false }
            SNAP_BOTTOM -> { frame(0, hh, dw, dh - hh); snap = mode; maximized = false }
            SNAP_TL -> { frame(0, 0, hw, hh); snap = mode; maximized = false }
            SNAP_TR -> { frame(hw, 0, dw - hw, hh); snap = mode; maximized = false }
            SNAP_BL -> { frame(0, hh, hw, dh - hh); snap = mode; maximized = false }
            SNAP_BR -> { frame(hw, hh, dw - hw, dh - hh); snap = mode; maximized = false }
        }
        afterModeChange()
    }

    fun restoreNormal() {
        if (nw <= 0) return
        val dw = (parent as View).width
        val dh = (parent as View).height
        frame(nx.coerceIn(0, maxOf(0, dw - nw)), ny.coerceIn(0, maxOf(0, dh - dp(40))), minOf(nw, dw), minOf(nh, dh))
        maximized = false
        snap = SNAP_NONE
        afterModeChange()
    }

    private fun afterModeChange() {
        val fullish = maximized || snap != SNAP_NONE
        grip.visibility = if (maximized) View.GONE else View.VISIBLE
        edgeR.visibility = if (maximized) View.GONE else View.VISIBLE
        edgeB.visibility = if (maximized) View.GONE else View.VISIBLE
        maxBtn?.text = if (maximized || snap != SNAP_NONE) "\u2750" else "\u25A2"
        applyBg()
        if (fullish) bringToFront()
    }

    fun toggleMax() {
        if (maximized || snap != SNAP_NONE) restoreNormal() else applySnap(SNAP_MAX)
    }

    private fun snapMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Maximize")
        m.menu.add(0, 2, 1, "Snap left half")
        m.menu.add(0, 3, 2, "Snap right half")
        m.menu.add(0, 4, 3, "Snap top half")
        m.menu.add(0, 5, 4, "Snap bottom half")
        m.menu.add(0, 6, 5, "Top-left quarter")
        m.menu.add(0, 7, 6, "Top-right quarter")
        m.menu.add(0, 8, 7, "Bottom-left quarter")
        m.menu.add(0, 9, 8, "Bottom-right quarter")
        m.menu.add(0, 10, 9, "Restore")
        m.menu.add(0, 11, 10, "Full screen (F11)")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> applySnap(SNAP_MAX)
                2 -> applySnap(SNAP_LEFT)
                3 -> applySnap(SNAP_RIGHT)
                4 -> applySnap(SNAP_TOP)
                5 -> applySnap(SNAP_BOTTOM)
                6 -> applySnap(SNAP_TL)
                7 -> applySnap(SNAP_TR)
                8 -> applySnap(SNAP_BL)
                9 -> applySnap(SNAP_BR)
                10 -> restoreNormal()
                11 -> act.setWindowFullscreen(this, true)
            }
            true
        }
        m.show()
    }

    private fun snapFor(rx: Float, ry: Float): Int {
        val loc = IntArray(2)
        (parent as View).getLocationOnScreen(loc)
        val x = rx - loc[0]
        val y = ry - loc[1]
        val dw = (parent as View).width
        val dh = (parent as View).height
        val edge = dp(16)
        val corner = dp(90)
        val left = x < edge
        val right = x > dw - edge
        val top = y < edge
        val bottom = y > dh - edge
        return when {
            top && left && y < corner && x < corner -> SNAP_TL
            top && right && x > dw - corner -> SNAP_TR
            bottom && left && x < corner -> SNAP_BL
            bottom && right && x > dw - corner -> SNAP_BR
            left -> SNAP_LEFT
            right -> SNAP_RIGHT
            top -> SNAP_MAX
            else -> SNAP_NONE
        }
    }

    private fun setupDrag() {
        var sx = 0f
        var sy = 0f
        var sl = 0
        var st = 0
        var moved = false
        var pending = SNAP_NONE
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    val p = layoutParams as FrameLayout.LayoutParams
                    sx = e.rawX; sy = e.rawY; sl = p.leftMargin; st = p.topMargin
                    moved = false
                    pending = SNAP_NONE
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5))) {
                        moved = true
                        if (maximized || snap != SNAP_NONE) {
                            // pull a maximised / snapped window loose, under the finger
                            val par = parent as View
                            val ow = nw
                            val loc = IntArray(2)
                            par.getLocationOnScreen(loc)
                            val relX = ((e.rawX - loc[0]) / par.width.toFloat()).coerceIn(0f, 1f)
                            val newL = (e.rawX - loc[0] - relX * ow).toInt().coerceIn(0, maxOf(0, par.width - ow))
                            restoreNormal()
                            val p = layoutParams as FrameLayout.LayoutParams
                            p.leftMargin = newL
                            p.topMargin = 0
                            layoutParams = p
                            sx = e.rawX; sy = e.rawY; sl = newL; st = 0
                        }
                    }
                    if (moved && !maximized) {
                        val ddx = e.rawX - sx
                        val ddy = e.rawY - sy
                        val par = parent as View
                        val p = layoutParams as FrameLayout.LayoutParams
                        p.leftMargin = (sl + ddx).toInt().coerceIn(-width + dp(90), par.width - dp(90))
                        p.topMargin = (st + ddy).toInt().coerceIn(0, par.height - dp(36))
                        layoutParams = p
                        val s = snapFor(e.rawX, e.rawY)
                        if (s != pending) {
                            pending = s
                            act.showSnapPreview(s)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    act.hideSnapPreview()
                    if (moved && pending != SNAP_NONE && e.actionMasked == MotionEvent.ACTION_UP) {
                        rememberNormalFromDrag()
                        applySnap(pending)
                    } else if (!moved && e.actionMasked == MotionEvent.ACTION_UP) {
                        if (e.eventTime - lastBarUp < 350) {
                            toggleMax()
                            lastBarUp = 0
                        } else {
                            lastBarUp = e.eventTime
                        }
                    }
                    pending = SNAP_NONE
                }
            }
            true
        }
    }

    private fun rememberNormalFromDrag() {
        val r = rect()
        // keep the pre-snap size, but the place where it was dropped
        if (nw <= 0) { nx = r[0]; ny = r[1]; nw = r[2]; nh = r[3] } else { nx = r[0]; ny = r[1] }
    }

    private fun setupResize(handle: View, resizeW: Boolean, resizeH: Boolean) {
        var sx = 0f
        var sy = 0f
        var sw = 0
        var sh = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    act.focusWindow(this)
                    sx = e.rawX; sy = e.rawY; sw = width; sh = height
                }
                MotionEvent.ACTION_MOVE -> {
                    val par = parent as View
                    val p = layoutParams as FrameLayout.LayoutParams
                    if (resizeW) p.width = (sw + e.rawX - sx).toInt().coerceIn(dp(300), par.width - p.leftMargin)
                    if (resizeH) p.height = (sh + e.rawY - sy).toInt().coerceIn(dp(200), par.height - p.topMargin)
                    layoutParams = p
                    if (snap != SNAP_NONE) { snap = SNAP_NONE; afterModeChange() }
                }
                MotionEvent.ACTION_UP -> {
                    val r = rect()
                    nx = r[0]; ny = r[1]; nw = r[2]; nh = r[3]
                }
            }
            true
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && act.focused !== this) act.focusWindow(this)
        return false
    }
}
