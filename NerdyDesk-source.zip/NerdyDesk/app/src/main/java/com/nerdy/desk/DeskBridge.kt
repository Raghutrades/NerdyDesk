package com.nerdy.desk

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.os.Vibrator
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.location.Location
import android.location.LocationManager
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** window.Desk inside the built-in web apps. Every method is called from a background thread. */
class DeskBridge(private val act: MainActivity, private val app: WebApp?) {
    private val store = act.getSharedPreferences("webapps", Context.MODE_PRIVATE)

    private fun ui(r: () -> Unit) = act.runOnUiThread { try { r() } catch (e: Exception) {} }

    @JavascriptInterface
    fun version(): String = "2.0.0"

    @JavascriptInterface
    fun theme(): String = if (Ui.light) "light" else "dark"

    @JavascriptInterface
    fun toast(s: String) = ui { act.toast(s) }

    @JavascriptInterface
    fun setTitle(t: String) = ui { app?.window?.setTitle(t) }

    @JavascriptInterface
    fun openApp(name: String, arg: String) = ui { act.openByName(name, if (arg.isEmpty()) null else arg) }

    @JavascriptInterface
    fun openUrl(url: String) = ui { act.open(AppKind.BROWSER, url) }

    @JavascriptInterface
    fun openFile(path: String) = ui { act.openFileSmart(path) }

    @JavascriptInterface
    fun openExternal(path: String) = ui { act.openFileExternal(path) }

    @JavascriptInterface
    fun share(path: String) = ui { act.shareFile(path) }

    @JavascriptInterface
    fun maximize(on: Boolean) = ui {
        val w = app?.window
        if (w != null && w.maximized != on) w.toggleMax()
    }

    @JavascriptInterface
    fun fullscreen(on: Boolean) = ui { act.applyImmersive(on) }

    @JavascriptInterface
    fun closeSelf() = ui { app?.window?.let { act.closeWindow(it) } }

    @JavascriptInterface
    fun get(k: String): String = store.getString(app?.kind?.name + "." + k, "") ?: ""

    @JavascriptInterface
    fun set(k: String, v: String) {
        store.edit().putString(app?.kind?.name + "." + k, v).apply()
    }

    @JavascriptInterface
    fun clipGet(): String {
        var out = ""
        val latch = java.util.concurrent.CountDownLatch(1)
        act.runOnUiThread {
            try {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val it = cm.primaryClip
                if (it != null && it.itemCount > 0) out = it.getItemAt(0).coerceToText(act).toString()
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        latch.await(1, java.util.concurrent.TimeUnit.SECONDS)
        return out
    }

    @JavascriptInterface
    fun clipSet(s: String) = ui {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("NerdyDesk", s))
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun vibrate(ms: Int) {
        try {
            (act.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(ms.toLong())
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ files

    @JavascriptInterface
    fun list(dir: String): String {
        val a = JSONArray()
        val d = File(dir)
        val fs = d.listFiles() ?: return a.toString()
        for (f in fs.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))) {
            val o = JSONObject()
            o.put("n", f.name)
            o.put("p", f.absolutePath)
            o.put("d", f.isDirectory)
            o.put("s", if (f.isDirectory) 0L else f.length())
            o.put("m", f.lastModified())
            a.put(o)
        }
        return a.toString()
    }

    @JavascriptInterface
    fun roots(): String {
        val a = JSONArray()
        a.put(Environment.getExternalStorageDirectory().absolutePath)
        return a.toString()
    }

    @JavascriptInterface
    fun readText(path: String): String = try {
        val f = File(path)
        if (f.length() > 2_000_000) "" else f.readText()
    } catch (e: Exception) {
        ""
    }

    @JavascriptInterface
    fun delete(path: String): Boolean = try {
        val f = File(path)
        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
        if (ok) MediaScannerConnection.scanFile(act, arrayOf(path), null, null)
        ok
    } catch (e: Exception) {
        false
    }

    @JavascriptInterface
    fun rename(path: String, newName: String): String = try {
        val f = File(path)
        val t = File(f.parentFile, newName)
        if (!t.exists() && f.renameTo(t)) {
            MediaScannerConnection.scanFile(act, arrayOf(path, t.absolutePath), null, null)
            t.absolutePath
        } else ""
    } catch (e: Exception) {
        ""
    }

    @JavascriptInterface
    fun saveBase64(name: String, mime: String, b64: String): String {
        return try {
            val dir = if (mime.startsWith("image/"))
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NerdyDesk")
            else Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            var f = File(dir, name)
            var n = 1
            while (f.exists()) {
                val base = name.substringBeforeLast('.', name)
                val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
                f = File(dir, "$base ($n)$ext")
                n++
            }
            f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
            MediaScannerConnection.scanFile(act, arrayOf(f.absolutePath), null, null)
            ui { act.toast("Saved to " + f.parentFile?.name + "/" + f.name) }
            f.absolutePath
        } catch (e: Exception) {
            ui { act.toast("Could not save the file") }
            ""
        }
    }

    @JavascriptInterface
    fun hasAccess(): Boolean = act.hasStorage()

    @JavascriptInterface
    fun requestAccess() = ui { act.requestStorage() }

    private fun scanFolders(kind: String, out: JSONArray) {
        val exts = when (kind) {
            "video" -> MainActivity.videoExts
            "audio" -> MainActivity.audioExts
            else -> MainActivity.imageExts
        }
        val root = Environment.getExternalStorageDirectory()
        val list = ArrayList<File>()
        try {
            val walk = root.walkTopDown().maxDepth(6).onEnter { !it.name.startsWith(".") && it.name != "Android" && it.name != "cache" }
            for (f in walk) {
                if (f.isFile && f.extension.lowercase() in exts && f.length() > 2048) list.add(f)
                if (list.size > 12000) break
            }
        } catch (e: Exception) {
        }
        list.sortByDescending { it.lastModified() }
        for ((i, f) in list.withIndex()) {
            val o = JSONObject()
            o.put("i", i.toLong())
            o.put("n", f.name)
            o.put("p", f.absolutePath)
            o.put("s", f.length())
            o.put("m", f.lastModified())
            o.put("b", f.parentFile?.name ?: "")
            if (kind == "audio") { o.put("a", ""); o.put("al", f.parentFile?.name ?: ""); o.put("t", f.nameWithoutExtension) }
            out.put(o)
        }
    }

    @JavascriptInterface
    fun media(kind: String): String {
        val uri = when (kind) {
            "video" -> android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val cols = ArrayList<String>()
        cols.add("_id"); cols.add("_display_name"); cols.add("_data"); cols.add("_size"); cols.add("date_modified")
        if (kind == "video" || kind == "audio") cols.add("duration")
        if (kind == "audio") { cols.add("artist"); cols.add("album"); cols.add("title") } else cols.add("bucket_display_name")
        val out = JSONArray()
        try {
            val cur = act.contentResolver.query(uri, cols.toTypedArray(), null, null, "date_modified DESC")
            if (cur != null) {
                var n = 0
                while (cur.moveToNext() && n < 15000) {
                    val o = JSONObject()
                    val p = cur.getString(2) ?: continue
                    o.put("i", cur.getLong(0))
                    o.put("n", cur.getString(1) ?: File(p).name)
                    o.put("p", p)
                    o.put("s", cur.getLong(3))
                    o.put("m", cur.getLong(4) * 1000L)
                    if (kind == "video") {
                        o.put("d", cur.getLong(5)); o.put("b", cur.getString(6) ?: "")
                    } else if (kind == "audio") {
                        o.put("d", cur.getLong(5)); o.put("a", cur.getString(6) ?: ""); o.put("al", cur.getString(7) ?: ""); o.put("t", cur.getString(8) ?: "")
                    } else {
                        o.put("b", cur.getString(5) ?: "")
                    }
                    out.put(o)
                    n++
                }
                cur.close()
            }
        } catch (e: Exception) {
        }
        if (out.length() == 0) scanFolders(kind, out)
        return out.toString()
    }

    @JavascriptInterface
    fun meta(path: String): String {
        val o = JSONObject()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            o.put("title", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: "")
            o.put("artist", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "")
            o.put("album", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "")
            o.put("duration", (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLongOrNull() ?: 0L)
            o.put("w", (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "0").toIntOrNull() ?: 0)
            o.put("h", (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "0").toIntOrNull() ?: 0)
            o.put("bitrate", (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: "0").toLongOrNull() ?: 0L)
            o.put("year", r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR) ?: "")
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        return o.toString()
    }

    @JavascriptInterface
    fun exif(path: String): String {
        val o = JSONObject()
        try {
            val f = File(path)
            o.put("name", f.name)
            o.put("size", f.length())
            o.put("modified", f.lastModified())
            val ex = ExifInterface(path)
            fun put(k: String, tag: String) {
                val v = ex.getAttribute(tag)
                if (v != null) o.put(k, v)
            }
            put("make", ExifInterface.TAG_MAKE); put("model", ExifInterface.TAG_MODEL)
            put("date", ExifInterface.TAG_DATETIME); put("exposure", ExifInterface.TAG_EXPOSURE_TIME)
            put("fnumber", ExifInterface.TAG_F_NUMBER); put("iso", ExifInterface.TAG_ISO)
            put("focal", ExifInterface.TAG_FOCAL_LENGTH); put("w", ExifInterface.TAG_IMAGE_WIDTH)
            put("h", ExifInterface.TAG_IMAGE_LENGTH); put("flash", ExifInterface.TAG_FLASH)
            val ll = FloatArray(2)
            if (ex.getLatLong(ll)) { o.put("lat", ll[0].toDouble()); o.put("lon", ll[1].toDouble()) }
        } catch (e: Exception) {
        }
        return o.toString()
    }

    @JavascriptInterface
    fun setWallpaper(path: String) = ui { act.setWallpaperPhoto(path) }


    // ------------------------------------------------------------ explorer operations

    private fun post(job: String, o: JSONObject) {
        act.runOnUiThread {
            try {
                app?.web?.evaluateJavascript("window.__job&&window.__job(" + JSONObject.quote(job) + "," + o.toString() + ")", null)
            } catch (e: Exception) {
            }
        }
    }

    private fun uniqueIn(dir: File, name: String, copyWord: Boolean): File {
        val first = File(dir, name)
        if (!first.exists()) return first
        val hasExt = name.contains('.') && !first.isDirectory && !name.startsWith(".")
        val base = if (hasExt) name.substringBeforeLast('.') else name
        val ext = if (hasExt) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (true) {
            val cand = File(dir, base + (if (copyWord) " - Copy" else "") + (if (n > 1) " ($n)" else "") + ext)
            if (!cand.exists()) return cand
            n++
        }
    }

    private fun sizeOf(f: File): Long {
        if (!f.isDirectory) return f.length()
        var t = 0L
        val l = f.listFiles() ?: return 0L
        for (c in l) t += sizeOf(c)
        return t
    }

    private fun copyRec(src: File, dst: File, prog: (Long) -> Unit) {
        if (src.isDirectory) {
            dst.mkdirs()
            val l = src.listFiles()
            if (l != null) for (c in l) copyRec(c, File(dst, c.name), prog)
        } else {
            src.inputStream().use { i ->
                dst.outputStream().use { o ->
                    val b = ByteArray(65536)
                    while (true) {
                        val n = i.read(b)
                        if (n < 0) break
                        o.write(b, 0, n)
                        prog(n.toLong())
                    }
                }
            }
            dst.setLastModified(src.lastModified())
        }
    }

    private fun binDir(): File {
        val f = File(Environment.getExternalStorageDirectory(), ".NerdyBin")
        f.mkdirs()
        return f
    }

    private fun binIndex(): JSONObject = try {
        JSONObject(File(binDir(), ".index.json").readText())
    } catch (e: Exception) {
        JSONObject()
    }

    private fun saveBinIndex(o: JSONObject) {
        File(binDir(), ".index.json").writeText(o.toString())
    }

    private fun trashOne(src: File) {
        val id = System.currentTimeMillis().toString(36) + (Math.random() * 1000).toInt()
        val t = File(binDir(), id)
        val isDir = src.isDirectory
        if (!src.renameTo(t)) {
            copyRec(src, t) { _ -> }
            src.deleteRecursively()
        }
        val idx = binIndex()
        idx.put(id, JSONObject().put("n", src.name).put("o", src.absolutePath).put("t", System.currentTimeMillis()).put("d", isDir))
        saveBinIndex(idx)
    }

    private fun zipRec(f: File, base: String, z: java.util.zip.ZipOutputStream, tick: (Long) -> Unit) {
        if (f.isDirectory) {
            val l = f.listFiles()
            z.putNextEntry(java.util.zip.ZipEntry("$base/"))
            z.closeEntry()
            if (l != null) for (c in l) zipRec(c, "$base/" + c.name, z, tick)
        } else {
            z.putNextEntry(java.util.zip.ZipEntry(base))
            f.inputStream().use { i ->
                val b = ByteArray(65536)
                while (true) {
                    val n = i.read(b)
                    if (n < 0) break
                    z.write(b, 0, n)
                    tick(n.toLong())
                }
            }
            z.closeEntry()
        }
    }

    /** copy | move | delete | trash | zip | unzip -- runs in the background and reports back with window.__job(id, {...}). */
    @JavascriptInterface
    fun fileOp(job: String, op: String, srcsJson: String, dstDir: String) {
        Thread {
            val srcs = ArrayList<File>()
            try {
                val a = JSONArray(srcsJson)
                for (i in 0 until a.length()) srcs.add(File(a.getString(i)))
            } catch (e: Exception) {
            }
            val touched = ArrayList<String>()
            try {
                val dst = File(dstDir)
                var total = 0L
                for (s in srcs) total += if (op == "copy" || op == "move" || op == "zip") sizeOf(s) else 1L
                var done = 0L
                var last = 0L
                val tick = { n: Long ->
                    done += n
                    val now = SystemClock.uptimeMillis()
                    if (now - last > 120) {
                        last = now
                        post(job, JSONObject().put("p", if (total > 0) done * 100 / total else 0L))
                    }
                }
                if (op == "zip") {
                    val out = uniqueIn(dst, (if (srcs.size == 1) srcs[0].nameWithoutExtension else "Archive") + ".zip", false)
                    java.util.zip.ZipOutputStream(out.outputStream().buffered()).use { z ->
                        for (s in srcs) zipRec(s, s.name, z, tick)
                    }
                    touched.add(out.absolutePath)
                } else if (op == "unzip") {
                    val zf = srcs[0]
                    val target = uniqueIn(dst, zf.nameWithoutExtension, false)
                    target.mkdirs()
                    java.util.zip.ZipInputStream(zf.inputStream().buffered()).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            val f = File(target, e.name)
                            if (!f.canonicalPath.startsWith(target.canonicalPath)) continue
                            if (e.isDirectory) f.mkdirs() else {
                                f.parentFile?.mkdirs()
                                f.outputStream().use { o -> z.copyTo(o) }
                            }
                        }
                    }
                    touched.add(target.absolutePath)
                } else {
                    for (src in srcs) {
                        when (op) {
                            "copy", "move" -> {
                                if (op == "move" && src.parentFile?.canonicalPath == dst.canonicalPath) continue
                                if (src.isDirectory && (dst.canonicalPath == src.canonicalPath || dst.canonicalPath.startsWith(src.canonicalPath + "/")))
                                    throw IllegalStateException("A folder can't be copied into itself")
                                val target = if (File(dst, src.name).exists()) uniqueIn(dst, src.name, op == "copy") else File(dst, src.name)
                                if (op == "move") {
                                    val sz = sizeOf(src)
                                    if (src.renameTo(target)) tick(sz) else {
                                        copyRec(src, target, tick)
                                        src.deleteRecursively()
                                    }
                                    touched.add(src.absolutePath)
                                } else {
                                    copyRec(src, target, tick)
                                }
                                touched.add(target.absolutePath)
                            }
                            "delete" -> {
                                if (src.isDirectory) src.deleteRecursively() else src.delete()
                                touched.add(src.absolutePath)
                                tick(1L)
                            }
                            "trash" -> {
                                trashOne(src)
                                touched.add(src.absolutePath)
                                tick(1L)
                            }
                        }
                    }
                }
                if (touched.isNotEmpty()) MediaScannerConnection.scanFile(act, touched.take(300).toTypedArray(), null, null)
                post(job, JSONObject().put("done", true))
            } catch (e: Exception) {
                post(job, JSONObject().put("done", true).put("err", e.message ?: "The operation failed"))
            }
        }.start()
    }

    @JavascriptInterface
    fun create(dir: String, name: String, isDir: Boolean, text: String): String = try {
        val f = uniqueIn(File(dir), name, false)
        if (isDir) f.mkdirs() else f.writeText(text)
        MediaScannerConnection.scanFile(act, arrayOf(f.absolutePath), null, null)
        f.absolutePath
    } catch (e: Exception) {
        ""
    }

    @JavascriptInterface
    fun exists(path: String): Boolean = File(path).exists()

    @JavascriptInterface
    fun stat(path: String): String {
        val f = File(path)
        val o = JSONObject()
        o.put("dir", f.isDirectory)
        o.put("size", if (f.isDirectory) 0L else f.length())
        o.put("modified", f.lastModified())
        o.put("name", f.name)
        o.put("hidden", f.name.startsWith("."))
        return o.toString()
    }

    @JavascriptInterface
    fun dirSize(job: String, path: String) {
        Thread {
            var size = 0L
            var files = 0
            var dirs = 0
            try {
                for (f in File(path).walkTopDown()) {
                    if (f.isDirectory) dirs++ else { files++; size += f.length() }
                }
                if (dirs > 0) dirs--
            } catch (e: Exception) {
            }
            post(job, JSONObject().put("done", true).put("size", size).put("files", files).put("dirs", dirs))
        }.start()
    }

    @JavascriptInterface
    fun search(job: String, dir: String, q: String) {
        Thread {
            val out = JSONArray()
            val ql = q.lowercase()
            var n = 0
            try {
                val walk = File(dir).walkTopDown().onEnter { !it.name.startsWith(".") && it.name != "Android" }
                for (f in walk) {
                    if (f.name.lowercase().contains(ql) && f.absolutePath != dir) {
                        val o = JSONObject()
                        o.put("n", f.name); o.put("p", f.absolutePath); o.put("d", f.isDirectory)
                        o.put("s", if (f.isDirectory) 0L else f.length()); o.put("m", f.lastModified())
                        out.put(o)
                        n++
                        if (n % 30 == 0) post(job, JSONObject().put("items", out))
                        if (n >= 600) break
                    }
                }
            } catch (e: Exception) {
            }
            post(job, JSONObject().put("done", true).put("items", out))
        }.start()
    }

    @JavascriptInterface
    fun storages(): String {
        val a = JSONArray()
        try {
            val primary = Environment.getExternalStorageDirectory()
            val roots = ArrayList<File>()
            roots.add(primary)
            File("/storage").listFiles()?.forEach { if (it.name != "emulated" && it.name != "self" && it.canRead()) roots.add(it) }
            for (r in roots) {
                val st = StatFs(r.path)
                val o = JSONObject()
                o.put("name", if (r == primary) "Internal storage" else "SD card / USB (" + r.name + ")")
                o.put("path", r.absolutePath)
                o.put("total", st.totalBytes)
                o.put("free", st.availableBytes)
                a.put(o)
            }
        } catch (e: Exception) {
        }
        return a.toString()
    }

    @JavascriptInterface
    fun fileClipSet(json: String, cut: Boolean) {
        act.fileClip = json
        act.fileClipCut = cut
    }

    @JavascriptInterface
    fun fileClipGet(): String {
        val o = JSONObject()
        try { o.put("paths", JSONArray(act.fileClip)) } catch (e: Exception) { o.put("paths", JSONArray()) }
        o.put("cut", act.fileClipCut)
        return o.toString()
    }

    @JavascriptInterface
    fun binList(): String {
        val out = JSONArray()
        val idx = binIndex()
        for (k in idx.keys()) {
            val e = idx.getJSONObject(k)
            val f = File(binDir(), k)
            if (!f.exists()) continue
            val o = JSONObject()
            o.put("id", k); o.put("n", e.optString("n")); o.put("o", e.optString("o")); o.put("t", e.optLong("t"))
            o.put("d", e.optBoolean("d")); o.put("p", f.absolutePath); o.put("s", if (f.isDirectory) 0L else f.length()); o.put("m", e.optLong("t"))
            out.put(o)
        }
        return out.toString()
    }

    @JavascriptInterface
    fun binRestore(idsJson: String): Int {
        var n = 0
        try {
            val ids = JSONArray(idsJson)
            val idx = binIndex()
            for (i in 0 until ids.length()) {
                val id = ids.getString(i)
                val e = idx.optJSONObject(id) ?: continue
                val src = File(binDir(), id)
                val orig = File(e.optString("o"))
                orig.parentFile?.mkdirs()
                val target = uniqueIn(orig.parentFile ?: binDir(), orig.name, false)
                if (!src.renameTo(target)) {
                    copyRec(src, target) { _ -> }
                    src.deleteRecursively()
                }
                idx.remove(id)
                n++
            }
            saveBinIndex(idx)
        } catch (e: Exception) {
        }
        return n
    }

    @JavascriptInterface
    fun binDelete(idsJson: String) {
        try {
            val ids = JSONArray(idsJson)
            val idx = binIndex()
            for (i in 0 until ids.length()) {
                val id = ids.getString(i)
                File(binDir(), id).deleteRecursively()
                idx.remove(id)
            }
            saveBinIndex(idx)
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun binEmpty() {
        try {
            val l = binDir().listFiles()
            if (l != null) for (f in l) if (f.name != ".index.json") f.deleteRecursively()
            saveBinIndex(JSONObject())
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ apps & system

    @JavascriptInterface
    fun apps(): String {
        val a = JSONArray()
        try {
            val pm = act.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
            val seen = HashSet<String>()
            for (ri in list) {
                val pkg = ri.activityInfo.packageName
                if (!seen.add(pkg)) continue
                val o = JSONObject()
                o.put("n", ri.loadLabel(pm).toString())
                o.put("p", pkg)
                a.put(o)
            }
        } catch (e: Exception) {
        }
        return a.toString()
    }

    @JavascriptInterface
    fun launch(pkg: String) = ui { act.launchPackage(pkg) }

    @JavascriptInterface
    fun appInfo(pkg: String) = ui {
        act.startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun uninstall(pkg: String) = ui {
        act.startSafely(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface
    fun windows(): String {
        val a = JSONArray()
        val latch = java.util.concurrent.CountDownLatch(1)
        act.runOnUiThread {
            try {
                for ((i, w) in act.windows.withIndex()) {
                    val o = JSONObject()
                    o.put("id", i)
                    o.put("title", w.app.title)
                    o.put("icon", w.kind.icon)
                    o.put("kind", w.kind.name)
                    o.put("min", w.minimized)
                    a.put(o)
                }
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        latch.await(1, java.util.concurrent.TimeUnit.SECONDS)
        return a.toString()
    }

    @JavascriptInterface
    fun closeWindowAt(id: Int) = ui {
        val w = act.windows.getOrNull(id)
        if (w != null) act.closeWindow(w)
    }

    @JavascriptInterface
    fun focusWindowAt(id: Int) = ui {
        val w = act.windows.getOrNull(id)
        if (w != null) act.focusWindow(w)
    }

    @JavascriptInterface
    fun sys(): String {
        val o = JSONObject()
        try {
            val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            o.put("ramTotal", mi.totalMem)
            o.put("ramFree", mi.availMem)
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            o.put("diskTotal", st.totalBytes)
            o.put("diskFree", st.availableBytes)
            val dm = Debug.MemoryInfo()
            Debug.getMemoryInfo(dm)
            o.put("selfPss", dm.totalPss.toLong() * 1024L)
            o.put("cores", Runtime.getRuntime().availableProcessors())
            o.put("uptime", SystemClock.elapsedRealtime())
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL)
            o.put("android", Build.VERSION.RELEASE)
            o.put("sdk", Build.VERSION.SDK_INT)
            o.put("kernel", System.getProperty("os.version") ?: "")
            o.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "")
            val b = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                o.put("battery", if (lvl >= 0) lvl * 100 / sc else -1)
                o.put("charging", b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0)
                o.put("temp", b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0)
            }
            val cm = act.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            o.put(
                "net",
                when {
                    caps == null -> "Offline"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                    else -> "Online"
                }
            )
            val fr = JSONArray()
            for (i in 0 until Runtime.getRuntime().availableProcessors()) {
                try {
                    val t = File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").readText().trim().toLong()
                    fr.put(t)
                } catch (e: Exception) {
                    fr.put(-1)
                }
            }
            o.put("freq", fr)
            val dmx = act.resources.displayMetrics
            o.put("screen", dmx.widthPixels.toString() + " x " + dmx.heightPixels)
            o.put("dpi", dmx.densityDpi)
        } catch (e: Exception) {
        }
        return o.toString()
    }

    @JavascriptInterface
    fun shell(cmd: String): String {
        return try {
            val pb = ProcessBuilder("sh", "-c", cmd)
            pb.redirectErrorStream(true)
            pb.directory(File(Environment.getExternalStorageDirectory().absolutePath))
            val pr = pb.start()
            val sb = StringBuilder()
            val th = Thread {
                try {
                    val r = pr.inputStream.bufferedReader()
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        if (sb.length < 200000) sb.append(buf, 0, n)
                    }
                } catch (e: Exception) {
                }
            }
            th.start()
            th.join(12000)
            if (th.isAlive) {
                pr.destroy()
                sb.append("\n[timed out after 12 s]")
            }
            sb.toString()
        } catch (e: Exception) {
            "error: " + e.message
        }
    }

    /** Fetch a web address from the phone itself (no browser CORS limits). Returns the body text. */
    @JavascriptInterface
    fun http(url: String): String {
        return try {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            c.setRequestProperty("Accept", "application/json,text/plain,*/*")
            val t = c.inputStream.bufferedReader().use { it.readText() }
            if (t.length > 3_000_000) t.substring(0, 3_000_000) else t
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun locate(): String {
        return try {
            val perm = android.Manifest.permission.ACCESS_COARSE_LOCATION
            if (act.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
                ui { act.requestPermissions(arrayOf(perm, android.Manifest.permission.ACCESS_FINE_LOCATION), 77) }
                return ""
            }
            val lm = act.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.accuracy < best.accuracy) best = l
            }
            if (best == null) "" else String.format(Locale.US, "%.4f,%.4f", best.latitude, best.longitude)
        } catch (e: Exception) {
            ""
        }
    }
}
