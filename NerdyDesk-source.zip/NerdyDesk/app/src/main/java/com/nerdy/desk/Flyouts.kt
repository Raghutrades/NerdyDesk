package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.AudioManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** A pop-up layer above the desktop. Tapping outside it closes it. */
@SuppressLint("ViewConstructor")
abstract class Flyout(protected val act: MainActivity) : FrameLayout(act) {
    var isOpen = false
        private set
    protected val panel = LinearLayout(act)

    init {
        visibility = View.GONE
        isClickable = true
        setOnClickListener { close() }
        panel.orientation = LinearLayout.VERTICAL
        panel.isClickable = true
        panel.elevation = dp(18).toFloat()
    }

    protected fun stylePanel(radius: Int = 14) {
        panel.background = Ui.rect(Ui.panel, dp(radius).toFloat(), Ui.border, 1)
    }

    open fun beforeOpen() {}

    open fun open() {
        act.closeFlyouts(this)
        beforeOpen()
        visibility = View.VISIBLE
        isOpen = true
        panel.alpha = 0f
        panel.translationY = dp(16).toFloat()
        panel.animate().alpha(1f).translationY(0f).setDuration(160).start()
        act.onFlyoutChanged()
    }

    open fun close() {
        if (!isOpen) return
        isOpen = false
        visibility = View.GONE
        act.onFlyoutChanged()
    }

    fun toggle() {
        if (isOpen) close() else open()
    }
}

// ================================================================= Quick settings

@SuppressLint("ViewConstructor")
class QuickPanel(act: MainActivity) : Flyout(act) {
    private val tiles = LinearLayout(act)

    init {
        stylePanel(16)
        panel.setPadding(dp(16), dp(16), dp(16), dp(12))
        val lpp = FrameLayout.LayoutParams(dp(344), WRAP, Gravity.BOTTOM or Gravity.END)
        lpp.setMargins(dp(8), dp(8), dp(10), dp(8))
        addView(panel, lpp)
    }

    private fun tile(emoji: String, label: String, on: Boolean, click: (View) -> Unit): View {
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(dp(4), dp(10), dp(4), dp(8))
        l.background = Ui.rect(if (on) Ui.accent else Ui.tint, dp(10).toFloat())
        val e = TextView(act)
        e.text = emoji
        e.textSize = 20f
        e.gravity = Gravity.CENTER
        l.addView(e, lp(MATCH, WRAP))
        val t = TextView(act)
        t.text = label
        t.textSize = 11f
        t.gravity = Gravity.CENTER
        t.setSingleLine()
        t.setTextColor(if (on) 0xFFFFFFFF.toInt() else Ui.text)
        l.addView(t, lp(MATCH, WRAP))
        l.isClickable = true
        l.setOnClickListener { click(it) }
        l.hand()
        return l
    }

    private fun settings(action: String) {
        close()
        act.startSafely(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun slider(icon: String, value: Int, max: Int, change: (Int) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val ic = TextView(act)
        ic.text = icon
        ic.textSize = 16f
        ic.gravity = Gravity.CENTER
        row.addView(ic, lp(dp(30), dp(36)))
        val sb = SeekBar(act)
        sb.max = max
        sb.progress = value
        sb.progressTintList = ColorStateList.valueOf(Ui.accent)
        sb.thumbTintList = ColorStateList.valueOf(Ui.accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) change(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, lp(0, dp(36), 1f))
        return row
    }

    override fun beforeOpen() {
        panel.removeAllViews()
        val grid = GridLayout(act)
        grid.columnCount = 3
        val items = ArrayList<View>()
        items.add(tile("\uD83D\uDCF6", "Wi-Fi", true) { settings(Settings.ACTION_WIFI_SETTINGS) })
        items.add(tile("\uD83D\uDD35", "Bluetooth", false) { settings(Settings.ACTION_BLUETOOTH_SETTINGS) })
        items.add(tile("\u2708\uFE0F", "Airplane", false) { settings(Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
        val rot = act.prefs.getString("orient", "landscape") ?: "landscape"
        items.add(tile("\uD83D\uDD04", if (rot == "landscape") "Landscape" else if (rot == "portrait") "Portrait" else "Auto-rotate", rot != "auto") {
            val next = when (rot) { "landscape" -> "auto"; "auto" -> "portrait"; else -> "landscape" }
            act.setOrientationPref(next)
            beforeOpen()
        })
        items.add(tile(if (Ui.light) "\u2600\uFE0F" else "\uD83C\uDF19", if (Ui.light) "Light" else "Dark", !Ui.light) {
            close()
            act.setLightTheme(!Ui.light)
        })
        items.add(tile("\uD83D\uDD0B", "Battery saver", false) { settings(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
        for (v in items) {
            val g = GridLayout.LayoutParams()
            g.width = dp(100)
            g.height = WRAP
            g.setMargins(dp(3), dp(3), dp(3), dp(3))
            grid.addView(v, g)
        }
        panel.addView(grid, lp(MATCH, WRAP))

        val br = act.prefs.getInt("bright", 80)
        panel.addView(slider("\u2600\uFE0F", br, 100) { act.setBrightness(it) }, lp(MATCH, dp(40)))
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        panel.addView(slider("\uD83D\uDD0A", am.getStreamVolume(AudioManager.STREAM_MUSIC), mx) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
        }, lp(MATCH, dp(40)))

        val foot = LinearLayout(act)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.setPadding(0, dp(6), 0, 0)
        val who = TextView(act)
        who.text = "@NerdyIntruder"
        who.textSize = 12f
        who.setTextColor(Ui.textDim)
        foot.addView(who, lp(0, WRAP, 1f))
        foot.addView(Ui.button(act, "\u2699\uFE0F  All settings") { close(); act.open(AppKind.SETTINGS, null) }, lp(WRAP, WRAP))
        panel.addView(foot, lp(MATCH, WRAP))
    }
}

// ================================================================= Calendar / clock

@SuppressLint("ViewConstructor")
class CalendarPanel(act: MainActivity) : Flyout(act) {
    private val cal = Calendar.getInstance()
    private val head = TextView(act)
    private val grid = GridLayout(act)
    private val bigTime = TextView(act)
    private val bigDate = TextView(act)

    init {
        stylePanel(16)
        panel.setPadding(dp(18), dp(16), dp(18), dp(14))
        val lpp = FrameLayout.LayoutParams(dp(344), WRAP, Gravity.BOTTOM or Gravity.END)
        lpp.setMargins(dp(8), dp(8), dp(10), dp(8))
        addView(panel, lpp)

        bigTime.textSize = 40f
        bigTime.setTextColor(Ui.text)
        bigTime.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
        panel.addView(bigTime, lp(MATCH, WRAP))
        bigDate.textSize = 13f
        bigDate.setTextColor(Ui.textDim)
        panel.addView(bigDate, lp(MATCH, WRAP))

        val nav = LinearLayout(act)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        nav.setPadding(0, dp(12), 0, dp(4))
        head.textSize = 15f
        head.setTextColor(Ui.text)
        nav.addView(head, lp(0, WRAP, 1f))
        nav.addView(Ui.button(act, "\u2039") { cal.add(Calendar.MONTH, -1); fill() }, lp(dp(40), dp(34)))
        nav.addView(Ui.button(act, "\u203A") { cal.add(Calendar.MONTH, 1); fill() }, lp(dp(40), dp(34)))
        panel.addView(nav, lp(MATCH, WRAP))
        grid.columnCount = 7
        panel.addView(grid, lp(MATCH, WRAP))

        val foot = LinearLayout(act)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.setPadding(0, dp(10), 0, 0)
        foot.addView(Ui.button(act, "\uD83D\uDCC5 Calendar") { close(); act.open(AppKind.CALENDAR, null) }, lp(0, WRAP, 1f))
        val sp = View(act)
        foot.addView(sp, lp(dp(8), 1))
        foot.addView(Ui.button(act, "\u23F1 Timer") { close(); act.open(AppKind.CALENDAR, "timer") }, lp(0, WRAP, 1f))
        panel.addView(foot, lp(MATCH, WRAP))
    }

    override fun beforeOpen() {
        cal.time = Date()
        fill()
    }

    private fun fill() {
        val now = Date()
        bigTime.text = SimpleDateFormat(if (act.prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm a", Locale.getDefault()).format(now)
        bigDate.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)
        head.text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        grid.removeAllViews()
        val days = arrayOf("S", "M", "T", "W", "T", "F", "S")
        for (d in days) grid.addView(cell(d, false, true))
        val first = cal.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = first.get(Calendar.DAY_OF_WEEK) - 1
        for (i in 0 until offset) grid.addView(cell("", false, false))
        val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = Calendar.getInstance()
        for (d in 1..dim) {
            val isToday = today.get(Calendar.YEAR) == cal.get(Calendar.YEAR) &&
                today.get(Calendar.MONTH) == cal.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) == d
            grid.addView(cell(d.toString(), isToday, false))
        }
    }

    private fun cell(s: String, today: Boolean, dim: Boolean): View {
        val t = TextView(act)
        t.text = s
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setTextColor(if (today) 0xFFFFFFFF.toInt() else if (dim) Ui.textDim else Ui.text)
        if (today) t.background = Ui.rect(Ui.accent, dp(17).toFloat())
        val g = GridLayout.LayoutParams()
        g.width = dp(44)
        g.height = dp(34)
        t.layoutParams = g
        return t
    }
}

// ================================================================= Task view

@SuppressLint("ViewConstructor")
class TaskView(act: MainActivity) : Flyout(act) {
    private val deskRow = LinearLayout(act)
    private val grid = GridLayout(act)
    private val scroll = ScrollView(act)

    init {
        setBackgroundColor(Ui.withAlpha(0xFF101826.toInt(), 175))
        panel.background = null
        panel.setPadding(dp(18), dp(14), dp(18), dp(10))
        panel.elevation = 0f
        addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))
        val hs = HorizontalScrollView(act)
        hs.isHorizontalScrollBarEnabled = false
        deskRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(deskRow, FrameLayout.LayoutParams(WRAP, WRAP))
        panel.addView(hs, lp(MATCH, dp(46)))
        grid.columnCount = 3
        scroll.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
        panel.addView(scroll, lp(MATCH, 0, 1f))
    }

    private fun snapshot(w: WindowView): Bitmap? {
        return try {
            if (w.width <= 0 || w.height <= 0) return null
            val k = 0.34f
            val b = Bitmap.createBitmap(maxOf(1, (w.width * k).toInt()), maxOf(1, (w.height * k).toInt()), Bitmap.Config.RGB_565)
            val cv = Canvas(b)
            cv.scale(k, k)
            w.draw(cv)
            b
        } catch (e: Throwable) {
            null
        }
    }

    override fun beforeOpen() {
        rebuild()
    }

    private fun white(s: String, size: Float): TextView {
        val t = TextView(act)
        t.text = s
        t.textSize = size
        t.setTextColor(0xFFFFFFFF.toInt())
        t.gravity = Gravity.CENTER_VERTICAL
        return t
    }

    fun rebuild() {
        deskRow.removeAllViews()
        for (i in 0 until act.deskCount) {
            val chip = white("  Desktop " + (i + 1) + "  ", 13f)
            chip.background = Ui.rect(if (i == act.curDesk) Ui.accent else 0x44FFFFFF, dp(8).toFloat())
            chip.isClickable = true
            chip.setOnClickListener { act.switchDesk(i); rebuild() }
            chip.setOnLongClickListener {
                if (act.deskCount > 1) { act.removeDesk(i); rebuild() }
                true
            }
            val l = lp(WRAP, dp(34))
            l.rightMargin = dp(8)
            deskRow.addView(chip, l)
        }
        if (act.deskCount < 4) {
            val add = white("  +  New desktop  ", 13f)
            add.background = Ui.rect(0x33FFFFFF, dp(8).toFloat())
            add.isClickable = true
            add.setOnClickListener { act.addDesk(); rebuild() }
            deskRow.addView(add, lp(WRAP, dp(34)))
        }
        grid.removeAllViews()
        val list = act.windows.filter { it.desk == act.curDesk }
        if (list.isEmpty()) {
            val e = white("No open windows on this desktop", 15f)
            e.setPadding(dp(8), dp(40), 0, 0)
            grid.addView(e)
        }
        val cw = maxOf(dp(150), (act.desktop.width - dp(60)) / 3)
        for (w in list) {
            val card = LinearLayout(act)
            card.orientation = LinearLayout.VERTICAL
            card.background = Ui.rect(Ui.bgDark, dp(10).toFloat(), if (w === act.focused) Ui.accent else Ui.border, 2)
            card.isClickable = true
            card.setOnClickListener { close(); act.focusWindow(w) }
            card.setOnLongClickListener {
                val m = PopupMenu(act, card)
                for (d in 0 until act.deskCount) if (d != w.desk) m.menu.add(0, d, d, "Move to Desktop " + (d + 1))
                m.menu.add(0, 99, 99, "Close")
                m.setOnMenuItemClickListener { mi ->
                    if (mi.itemId == 99) act.closeWindow(w) else act.moveToDesk(w, mi.itemId)
                    rebuild()
                    true
                }
                m.show()
                true
            }
            val top = LinearLayout(act)
            top.gravity = Gravity.CENTER_VERTICAL
            top.setPadding(dp(8), dp(4), dp(4), dp(4))
            top.addView(Ui.tile(act, w.kind.icon, w.kind.color, 20, 10f), lp(dp(20), dp(20)))
            val tt = TextView(act)
            tt.text = "  " + w.title()
            tt.textSize = 12f
            tt.setSingleLine()
            tt.ellipsize = android.text.TextUtils.TruncateAt.END
            tt.setTextColor(Ui.text)
            top.addView(tt, lp(0, WRAP, 1f))
            val x = TextView(act)
            x.text = "\u2715"
            x.gravity = Gravity.CENTER
            x.setTextColor(Ui.text)
            x.isClickable = true
            x.background = Ui.stateBg(dp(6).toFloat(), 0, 0xFFE81123.toInt())
            x.setOnClickListener { act.closeWindow(w); rebuild() }
            top.addView(x, lp(dp(32), dp(28)))
            card.addView(top, lp(MATCH, WRAP))
            val iv = ImageView(act)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = if (w.minimized) null else snapshot(w)
            if (bmp != null) iv.setImageBitmap(bmp) else iv.setBackgroundColor(Ui.bar)
            card.addView(iv, lp(MATCH, (cw * 0.62f).toInt()))
            val g = GridLayout.LayoutParams()
            g.width = cw - dp(12)
            g.height = WRAP
            g.setMargins(dp(6), dp(6), dp(6), dp(6))
            grid.addView(card, g)
        }
    }
}

// ================================================================= Widgets

@SuppressLint("ViewConstructor", "SetJavaScriptEnabled", "AddJavascriptInterface")
class WidgetsPanel(act: MainActivity) : Flyout(act) {
    private var web: WebView? = null

    init {
        stylePanel(16)
        val lpp = FrameLayout.LayoutParams(dp(390), MATCH, Gravity.START)
        lpp.setMargins(dp(10), dp(10), dp(8), dp(8))
        addView(panel, lpp)
    }

    override fun beforeOpen() {
        if (web == null) {
            val w = WebView(act)
            val s = w.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.allowFileAccess = false
            w.setBackgroundColor(0)
            w.addJavascriptInterface(DeskBridge(act, null), "Desk")
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    Local.handle(act, request.url, request.requestHeaders)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (request.url.host == Local.HOST) return false
                    close()
                    act.open(AppKind.BROWSER, request.url.toString())
                    return true
                }
            }
            w.webChromeClient = WebChromeClient()
            panel.addView(w, lp(MATCH, MATCH))
            web = w
            w.loadUrl(Local.BASE + "/assets/apps/widgets/index.html?theme=" + (if (Ui.light) "light" else "dark") +
                "&accent=" + android.net.Uri.encode(String.format("#%06X", Ui.accent and 0xFFFFFF)))
        } else {
            web?.evaluateJavascript("window.__refresh&&window.__refresh()", null)
        }
    }

    fun applyTheme() {
        stylePanel(16)
        val hex = String.format("#%06X", Ui.accent and 0xFFFFFF)
        web?.evaluateJavascript("window.__setTheme&&window.__setTheme('" + (if (Ui.light) "light" else "dark") + "','" + hex + "')", null)
    }
}

// ================================================================= Run

@SuppressLint("ViewConstructor")
class RunDialog(act: MainActivity) : Flyout(act) {
    private val input = EditText(act)

    init {
        setBackgroundColor(0x55000000)
        stylePanel(14)
        panel.setPadding(dp(18), dp(16), dp(18), dp(14))
        val lpp = FrameLayout.LayoutParams(dp(440), WRAP, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
        lpp.topMargin = dp(70)
        addView(panel, lpp)
        val t = TextView(act)
        t.text = "Run"
        t.textSize = 16f
        t.setTextColor(Ui.text)
        panel.addView(t, lp(MATCH, WRAP))
        val d = TextView(act)
        d.text = "Type an app name, a web address, a folder path or a command."
        d.textSize = 12f
        d.setTextColor(Ui.textDim)
        d.setPadding(0, dp(2), 0, dp(10))
        panel.addView(d, lp(MATCH, WRAP))
        input.setSingleLine()
        input.textSize = 15f
        input.setTextColor(Ui.text)
        input.setHintTextColor(Ui.textDim)
        input.hint = "e.g. calc, youtube.com, /sdcard/Download, ls"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.imeOptions = EditorInfo.IME_ACTION_GO
        input.background = Ui.rect(Ui.field, dp(8).toFloat(), Ui.border, 1)
        input.setPadding(dp(12), dp(8), dp(12), dp(8))
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO || id == EditorInfo.IME_NULL) { run(); true } else false
        }
        panel.addView(input, lp(MATCH, dp(44)))
        val row = LinearLayout(act)
        row.gravity = Gravity.END
        row.setPadding(0, dp(12), 0, 0)
        row.addView(Ui.button(act, "Cancel") { close() }, lp(WRAP, WRAP))
        val ok = Ui.button(act, "OK") { run() }
        ok.background = Ui.rect(Ui.accent, dp(6).toFloat())
        ok.setTextColor(0xFFFFFFFF.toInt())
        val ol = lp(WRAP, WRAP)
        ol.leftMargin = dp(8)
        row.addView(ok, ol)
        panel.addView(row, lp(MATCH, WRAP))
    }

    override fun beforeOpen() {
        input.setText("")
        input.post {
            input.requestFocus()
            (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, 0)
        }
    }

    private fun run() {
        val q = input.text.toString().trim()
        close()
        if (q.isNotEmpty()) act.runCommand(q)
    }
}
