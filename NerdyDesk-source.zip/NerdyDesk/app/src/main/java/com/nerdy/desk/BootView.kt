package com.nerdy.desk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Windows-style start-up: a bright blue bloom, the four-pane logo assembling, the orbiting-dots
 * spinner and the @NerdyIntruder handle; then (optionally) a lock screen you tap to sign in.
 */
class BootView(ctx: Context, private val withLock: Boolean, private val onDone: () -> Unit) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = SystemClock.uptimeMillis()
    private var running = true
    private var leaving = false
    private var leaveAt = 0L
    private var finished = false
    private val bootMs = 3300L
    private val leaveMs = 520L

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init {
        isClickable = true
        isFocusable = true
        Choreographer.getInstance().postFrameCallback(cb)
    }

    val locked: Boolean
        get() = withLock && !leaving && SystemClock.uptimeMillis() - t0 > bootMs

    /** Sign in / skip. Before the boot animation ends this simply fast-forwards it. */
    fun dismiss() {
        if (leaving) return
        val now = SystemClock.uptimeMillis()
        if (withLock && now - t0 < bootMs) return
        leaving = true
        leaveAt = now
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) dismiss()
        return true
    }

    private fun ease(x: Float): Float {
        val v = x.coerceIn(0f, 1f)
        return 1f - (1f - v) * (1f - v) * (1f - v)
    }

    private fun easeIO(x: Float): Float {
        val v = x.coerceIn(0f, 1f)
        return if (v < 0.5f) 4f * v * v * v else 1f - Math.pow((-2.0 * v + 2.0), 3.0).toFloat() / 2f
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val now = SystemClock.uptimeMillis()
        val t = (now - t0) / 1000f

        var lift = 0f
        var fade = 1f
        if (leaving) {
            val k = ((now - leaveAt).toFloat() / leaveMs).coerceIn(0f, 1f)
            lift = easeIO(k) * h * (if (withLock) 1f else 0f)
            fade = if (withLock) 1f else 1f - ease(k)
            if (k >= 1f && !finished) {
                finished = true
                running = false
                post { onDone() }
            }
        }
        canvas.save()
        canvas.translate(0f, -lift)
        canvas.saveLayerAlpha(0f, 0f, w, h, (255 * fade).toInt())

        // background: Windows-11-ish bloom
        p.shader = LinearGradient(0f, 0f, w, h, c(0xFF0B63CE), c(0xFF3DA5FF), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        val r = maxOf(w, h)
        val sway = Math.sin(t * 0.7).toFloat()
        p.shader = RadialGradient(w * (0.25f + 0.04f * sway), h * 0.2f, r * 0.7f, c(0x99FFFFFF), c(0x00FFFFFF), Shader.TileMode.CLAMP)
        canvas.drawCircle(w * (0.25f + 0.04f * sway), h * 0.2f, r * 0.7f, p)
        p.shader = RadialGradient(w * 0.85f, h * (0.85f - 0.03f * sway), r * 0.6f, c(0x887CF5FF), c(0x007CF5FF), Shader.TileMode.CLAMP)
        canvas.drawCircle(w * 0.85f, h * (0.85f - 0.03f * sway), r * 0.6f, p)
        p.shader = null

        val cx = w / 2f
        val unit = minOf(w, h)
        val bootK = if (withLock) (1f - ease((t - (bootMs / 1000f - 0.5f)) / 0.5f)) else 1f

        if (bootK > 0.01f) {
            canvas.saveLayerAlpha(0f, 0f, w, h, (255 * bootK).toInt())
            // logo: four panes appear one after another
            val cy = h * 0.40f
            val s = unit * 0.20f
            val g = s * 0.06f
            val panes = arrayOf(
                floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f), floatArrayOf(-1f, 1f), floatArrayOf(1f, 1f)
            )
            for (i in 0 until 4) {
                val k = ease((t - 0.15f - i * 0.18f) / 0.55f)
                if (k <= 0f) continue
                val pw = s * (0.82f + 0.18f * k)
                val px = cx + panes[i][0] * (g + pw / 2f) * (1.25f - 0.25f * k)
                val py = cy + panes[i][1] * (g + pw / 2f) * (1.25f - 0.25f * k)
                p.color = Ui.withAlpha(Color.WHITE, (255 * k).toInt())
                canvas.drawRect(px - pw / 2f, py - pw / 2f, px + pw / 2f, py + pw / 2f, p)
            }

            // title + handle
            val kText = ease((t - 1.0f) / 0.7f)
            p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            p.textAlign = Paint.Align.CENTER
            p.color = Ui.withAlpha(Color.WHITE, (255 * kText).toInt())
            p.textSize = unit * 0.075f
            canvas.drawText("NerdyDesk", cx, cy + s * 1.55f + (1f - kText) * 14f, p)
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = unit * 0.034f
            p.color = Ui.withAlpha(Color.WHITE, (210 * kText).toInt())
            canvas.drawText("@NerdyIntruder", cx, cy + s * 1.55f + unit * 0.065f + (1f - kText) * 14f, p)

            // orbiting dots spinner
            val sy = h * 0.80f
            val sr = unit * 0.035f
            val dotR = unit * 0.0075f
            val kSp = ease((t - 0.8f) / 0.5f)
            for (i in 0 until 5) {
                val ph = ((t - i * 0.11f) % 2.0f + 2.0f) % 2.0f / 2.0f
                val ang = easeIO(ph) * 2f * Math.PI.toFloat() * 1.0f - Math.PI.toFloat() / 2f
                val vis = if (ph < 0.92f) 1f else 0f
                p.color = Ui.withAlpha(Color.WHITE, (255 * kSp * vis).toInt())
                canvas.drawCircle(cx + Math.cos(ang.toDouble()).toFloat() * sr, sy + Math.sin(ang.toDouble()).toFloat() * sr, dotR, p)
            }
            p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            p.textSize = unit * 0.026f
            p.color = Ui.withAlpha(Color.WHITE, (190 * ease((t - 1.4f) / 0.8f)).toInt())
            canvas.drawText("Nerdy Trading Way", cx, h * 0.93f, p)
            canvas.restore()
        }

        if (withLock && t > bootMs / 1000f - 0.4f) {
            val k = ease((t - (bootMs / 1000f - 0.4f)) / 0.7f)
            canvas.saveLayerAlpha(0f, 0f, w, h, (255 * k).toInt())
            val d = Date()
            p.textAlign = Paint.Align.CENTER
            p.color = Color.WHITE
            p.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            p.textSize = unit * 0.20f
            canvas.drawText(SimpleDateFormat("h:mm", Locale.getDefault()).format(d), cx, h * 0.30f, p)
            p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            p.textSize = unit * 0.045f
            canvas.drawText(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(d), cx, h * 0.30f + unit * 0.075f, p)

            // avatar + handle
            val ay = h * 0.62f
            val ar = unit * 0.095f
            p.shader = LinearGradient(cx - ar, ay - ar, cx + ar, ay + ar, c(0xFFFFFFFF), c(0xFFBFE3FF), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, ay, ar, p)
            p.shader = null
            p.color = Ui.accent
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.textSize = ar * 1.05f
            canvas.drawText("N", cx, ay + ar * 0.36f, p)
            p.color = Color.WHITE
            p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            p.textSize = unit * 0.05f
            canvas.drawText("@NerdyIntruder", cx, ay + ar + unit * 0.075f, p)
            val pulse = 0.55f + 0.45f * Math.sin(t * 3.0).toFloat()
            p.textSize = unit * 0.03f
            p.color = Ui.withAlpha(Color.WHITE, (230 * pulse).toInt())
            canvas.drawText("Tap or press any key to sign in", cx, h * 0.90f, p)
            canvas.restore()
        }

        canvas.restore()
        canvas.restore()
    }
}
