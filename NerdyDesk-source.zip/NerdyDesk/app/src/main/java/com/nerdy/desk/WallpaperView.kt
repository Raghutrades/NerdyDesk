package com.nerdy.desk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.Choreographer
import android.view.View

/** Bright, layered "bloom" wallpapers drawn in code, optionally drifting slowly. Or a picture of your own. */
class WallpaperView(ctx: Context) : View(ctx) {
    companion object {
        val names = listOf(
            "Azure Bloom", "Sunrise", "Mint Aurora", "Orchid Dream",
            "Ocean Glass", "Sakura", "Citrus", "Slate Paper"
        )
        // each: base top, base bottom, blob1, blob2, blob3
        private val sets = listOf(
            longArrayOf(0xFFBFE3FF, 0xFF3D8BFF, 0xFFFFFFFF, 0xFF7CF5FF, 0xFF6C5CE7),
            longArrayOf(0xFFFFE3C2, 0xFFFF7F6B, 0xFFFFFFFF, 0xFFFFD36B, 0xFFE5338B),
            longArrayOf(0xFFD8FFF0, 0xFF1FB59A, 0xFFFFFFFF, 0xFFA5F3FF, 0xFF3D7BFF),
            longArrayOf(0xFFF2DCFF, 0xFF8E5BFF, 0xFFFFFFFF, 0xFFFF9BD8, 0xFF4B6BFF),
            longArrayOf(0xFFCFF3FF, 0xFF0B6FA8, 0xFFFFFFFF, 0xFF5BE3C8, 0xFF2B4BCB),
            longArrayOf(0xFFFFE6F0, 0xFFFF86B1, 0xFFFFFFFF, 0xFFFFC9A6, 0xFFB46BFF),
            longArrayOf(0xFFFFF7C2, 0xFFFFA21F, 0xFFFFFFFF, 0xFFB6F36B, 0xFF18B88A),
            longArrayOf(0xFFF4F5F7, 0xFFC9CED8, 0xFFFFFFFF, 0xFFDCE3F0, 0xFF9FB0CF)
        )
    }

    var style = 0
        set(v) { field = v.coerceIn(0, sets.size - 1); invalidate() }
    var animated = false
        set(v) { field = v; if (v) start() else stop() }
    var photo: Bitmap? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var running = false
    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            t += 0.0035f
            invalidate()
            Choreographer.getInstance().postFrameCallbackDelayed(this, 33)
        }
    }

    fun setPhotoPath(path: String?) {
        photo?.recycle()
        photo = null
        if (path != null) {
            try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(path, o)
                var s = 1
                while (o.outWidth / s > 2400) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                photo = BitmapFactory.decodeFile(path, o2)
            } catch (e: Throwable) {
            }
        }
        invalidate()
    }

    private fun start() {
        if (running) return
        running = true
        Choreographer.getInstance().postFrameCallback(cb)
    }

    private fun stop() {
        running = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (animated) start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val ph = photo
        if (ph != null) {
            // centre-crop
            val sc = maxOf(w / ph.width, h / ph.height)
            val dw = ph.width * sc
            val dh = ph.height * sc
            val l = (w - dw) / 2f
            val tp = (h - dh) / 2f
            canvas.save()
            canvas.translate(l, tp)
            canvas.scale(sc, sc)
            canvas.drawBitmap(ph, 0f, 0f, null)
            canvas.restore()
            return
        }
        val s = sets[style]
        p.shader = LinearGradient(0f, 0f, w * 0.4f, h, c(s[0]), c(s[1]), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        val r = maxOf(w, h)
        val dx = Math.sin(t.toDouble()).toFloat()
        val dy = Math.cos((t * 1.3f).toDouble()).toFloat()
        blob(canvas, w * (0.25f + 0.06f * dx), h * (0.25f + 0.08f * dy), r * 0.55f, c(s[2]), 0.85f)
        blob(canvas, w * (0.78f - 0.07f * dy), h * (0.30f + 0.06f * dx), r * 0.50f, c(s[3]), 0.75f)
        blob(canvas, w * (0.55f + 0.08f * dx), h * (0.85f - 0.05f * dy), r * 0.62f, c(s[4]), 0.70f)
        // soft "window" ribbon, a nod to the Windows 11 bloom
        p.shader = null
        p.color = Ui.withAlpha(c(0xFFFFFFFF), 38)
        canvas.save()
        canvas.rotate(-18f, w / 2f, h / 2f)
        canvas.drawRoundRect(w * 0.10f, h * 0.42f, w * 0.90f, h * 0.58f, h * 0.08f, h * 0.08f, p)
        canvas.restore()
    }

    private fun blob(cv: Canvas, x: Float, y: Float, rad: Float, col: Int, a: Float) {
        val inner = Ui.withAlpha(col, (255 * a).toInt())
        val outer = Ui.withAlpha(col, 0)
        p.shader = RadialGradient(x, y, rad, inner, outer, Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, rad, p)
        p.shader = null
    }
}
