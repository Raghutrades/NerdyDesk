package com.nerdy.desk

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.util.Locale

/**
 * Serves the app pages from assets and your own files (with HTTP Range, so video seeks) to the
 * built-in web apps, all under one private address:  https://appassets.androidplatform.net/
 *   /assets/...        app pages
 *   /f?p=<path>        a file on the phone (ranged)
 *   /t?p=<path>&s=256  a thumbnail (picture, video frame, album art)
 *   /i?p=<package>     an installed app's icon
 */
object Local {
    const val HOST = "appassets.androidplatform.net"
    const val BASE = "https://appassets.androidplatform.net"

    private class Limited(inp: InputStream, private var left: Long) : FilterInputStream(inp) {
        override fun read(): Int {
            if (left <= 0) return -1
            val b = super.read()
            if (b >= 0) left--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
    }

    fun mime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "html", "htm" -> "text/html"
            "js", "mjs" -> "application/javascript"
            "css" -> "text/css"
            "json", "webmanifest" -> "application/json"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "ico" -> "image/x-icon"
            "woff2" -> "font/woff2"
            "woff" -> "font/woff"
            "ttf" -> "font/ttf"
            "txt" -> "text/plain"
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "3gp" -> "video/3gpp"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "flac" -> "audio/flac"
            "ogg", "oga", "opus" -> "audio/ogg"
            "wav" -> "audio/wav"
            "heic", "heif" -> "image/heic"
            "avif" -> "image/avif"
            "bmp" -> "image/bmp"
            "pdf" -> "application/pdf"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun heads(extra: Map<String, String>? = null): HashMap<String, String> {
        val h = HashMap<String, String>()
        h["Access-Control-Allow-Origin"] = "*"
        h["Cache-Control"] = "no-cache"
        if (extra != null) h.putAll(extra)
        return h
    }

    private fun err(code: Int, why: String): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", code, why, heads(), ByteArrayInputStream(why.toByteArray()))

    /** Only the phone's shared storage and our own folders may be served. */
    fun allowed(f: File, act: MainActivity): Boolean {
        return try {
            val p = f.canonicalPath
            val roots = ArrayList<String>()
            roots.add(Environment.getExternalStorageDirectory().canonicalPath)
            roots.add("/storage")
            roots.add(act.cacheDir.canonicalPath)
            roots.add(act.filesDir.canonicalPath)
            roots.any { p == it || p.startsWith("$it/") }
        } catch (e: Exception) {
            false
        }
    }

    fun handle(act: MainActivity, uri: Uri, reqHeaders: Map<String, String>?): WebResourceResponse? {
        if (uri.host != HOST) return null
        val path = uri.path ?: return null
        try {
            if (path.startsWith("/assets/")) {
                val rel = path.substring(8)
                if (rel.contains("..")) return err(403, "Forbidden")
                val inp = act.assets.open(rel)
                return WebResourceResponse(mime(rel), "utf-8", 200, "OK", heads(), inp)
            }
            if (path == "/f") {
                val f = File(uri.getQueryParameter("p") ?: return err(400, "Bad request"))
                if (!f.isFile || !allowed(f, act)) return err(404, "Not found")
                return ranged(f, mime(f.name), reqHeaders)
            }
            if (path == "/t") {
                val f = File(uri.getQueryParameter("p") ?: return err(400, "Bad request"))
                if (!f.isFile || !allowed(f, act)) return err(404, "Not found")
                val s = (uri.getQueryParameter("s") ?: "320").toIntOrNull() ?: 320
                val jpg = thumb(act, f, s.coerceIn(64, 1600)) ?: return err(404, "No thumbnail")
                val h = heads()
                h["Cache-Control"] = "max-age=86400"
                return WebResourceResponse("image/jpeg", null, 200, "OK", h, ByteArrayInputStream(jpg))
            }
            if (path == "/i") {
                val pkg = uri.getQueryParameter("p") ?: return err(400, "Bad request")
                val d = act.packageManager.getApplicationIcon(pkg)
                val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                val cv = Canvas(bmp)
                d.setBounds(0, 0, 96, 96)
                d.draw(cv)
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
                val h = heads()
                h["Cache-Control"] = "max-age=3600"
                return WebResourceResponse("image/png", null, 200, "OK", h, ByteArrayInputStream(bo.toByteArray()))
            }
        } catch (e: Exception) {
            return err(404, "Not found")
        }
        return err(404, "Not found")
    }

    private fun ranged(f: File, mime: String, req: Map<String, String>?): WebResourceResponse {
        val total = f.length()
        var range: String? = null
        if (req != null) {
            for ((k, v) in req) if (k.equals("Range", true)) range = v
        }
        var start = 0L
        var end = total - 1
        var partial = false
        if (range != null && range.startsWith("bytes=")) {
            val spec = range.substring(6).trim().substringBefore(',')
            val a = spec.substringBefore('-')
            val b = spec.substringAfter('-', "")
            try {
                if (a.isEmpty()) {
                    val n = b.toLong()
                    start = maxOf(0L, total - n)
                } else {
                    start = a.toLong()
                    if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1)
                }
                partial = true
            } catch (e: NumberFormatException) {
                partial = false
                start = 0
                end = total - 1
            }
        }
        if (start >= total && total > 0) {
            val h = heads()
            h["Content-Range"] = "bytes */$total"
            return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, ByteArrayInputStream(ByteArray(0)))
        }
        val len = end - start + 1
        val fis = FileInputStream(f)
        if (start > 0) fis.channel.position(start)
        val h = heads()
        h["Accept-Ranges"] = "bytes"
        h["Content-Length"] = len.toString()
        if (partial) {
            h["Content-Range"] = "bytes $start-$end/$total"
            return WebResourceResponse(mime, null, 206, "Partial Content", h, Limited(fis, len))
        }
        return WebResourceResponse(mime, null, 200, "OK", h, Limited(fis, len))
    }

    private fun scaleTo(src: Bitmap, side: Int): Bitmap {
        val m = maxOf(src.width, src.height)
        if (m <= side) return src
        val k = side.toFloat() / m
        return Bitmap.createScaledBitmap(src, maxOf(1, (src.width * k).toInt()), maxOf(1, (src.height * k).toInt()), true)
    }

    fun thumb(act: MainActivity, f: File, side: Int): ByteArray? {
        val dir = File(act.cacheDir, "th")
        dir.mkdirs()
        val key = (f.absolutePath + "|" + f.lastModified() + "|" + side).hashCode().toString(16)
        val cached = File(dir, "$key.jpg")
        if (cached.isFile && cached.length() > 0) return cached.readBytes()
        val ext = f.extension.lowercase(Locale.ROOT)
        var bmp: Bitmap? = null
        try {
            val m = mime(f.name)
            if (m.startsWith("image/") && ext != "svg") {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.absolutePath, o)
                var s = 1
                while (o.outWidth / (s * 2) >= side && o.outHeight / (s * 2) >= side) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                var b = BitmapFactory.decodeFile(f.absolutePath, o2)
                if (b != null) {
                    try {
                        val ex = ExifInterface(f.absolutePath)
                        val deg = when (ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                            6 -> 90f
                            3 -> 180f
                            8 -> 270f
                            else -> 0f
                        }
                        if (deg != 0f) {
                            val mx = Matrix()
                            mx.postRotate(deg)
                            b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, mx, true)
                        }
                    } catch (e: Exception) {
                    }
                    bmp = scaleTo(b, side)
                }
            } else if (m.startsWith("video/") || m.startsWith("audio/")) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.absolutePath)
                    if (m.startsWith("video/")) {
                        val dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLongOrNull() ?: 0L
                        val at = if (dur > 4000) minOf(dur / 10, 8000L) * 1000L else 0L
                        val fr = r.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (fr != null) bmp = scaleTo(fr, side)
                    } else {
                        val art = r.embeddedPicture
                        if (art != null) {
                            val b = BitmapFactory.decodeByteArray(art, 0, art.size)
                            if (b != null) bmp = scaleTo(b, side)
                        }
                    }
                } finally {
                    try { r.release() } catch (e: Exception) {}
                }
            }
        } catch (e: Throwable) {
            return null
        }
        val out = bmp ?: return null
        val bo = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 84, bo)
        val bytes = bo.toByteArray()
        try {
            cached.writeBytes(bytes)
        } catch (e: Exception) {
        }
        return bytes
    }
}
