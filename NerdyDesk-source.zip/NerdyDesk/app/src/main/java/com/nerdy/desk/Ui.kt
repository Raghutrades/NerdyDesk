package com.nerdy.desk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

fun c(v: Long): Int = v.toInt()

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

/** Theme palette. Light (bright, Windows 11 style) is the default; Dark is optional. */
object Ui {
    var light = true

    // window body / surfaces
    var bgDark = c(0xFFF7F8FA)      // window body
    var bar = c(0xFFEDEFF3)         // toolbars, inactive title bars
    var barActive = c(0xFFFFFFFF)   // active title bar
    var side = c(0xFFEEF0F5)        // side panels, status bars
    var field = c(0xFFFFFFFF)       // text inputs
    var panel = c(0xF2FFFFFF)       // start menu / flyouts (glass)
    var taskbar = c(0xE8F3F5FA)     // taskbar glass
    var text = c(0xFF1B1B1F)
    var textDim = c(0xFF5F6670)
    var border = c(0xFFD3D8E0)
    var hover = c(0x1A000000)
    var press = c(0x0F000000)
    var selected = c(0x26000000)
    var tint = c(0x14000000)        // subtle overlay on surfaces
    var warn = c(0xFFFFF1CC)
    var accent = c(0xFF0A74DA)

    val accents = listOf(
        c(0xFF0A74DA), c(0xFF0F9D58), c(0xFFE5334B), c(0xFF8E44AD),
        c(0xFFFF7A00), c(0xFF00A7B5), c(0xFFE91E8C), c(0xFF5B6CFF)
    )
    val accentNames = listOf("Azure", "Emerald", "Ruby", "Orchid", "Tangerine", "Teal", "Rose", "Indigo")

    fun applyTheme(isLight: Boolean) {
        light = isLight
        if (isLight) {
            bgDark = c(0xFFF7F8FA); bar = c(0xFFEDEFF3); barActive = c(0xFFFFFFFF); side = c(0xFFEEF0F5)
            field = c(0xFFFFFFFF); panel = c(0xF2FFFFFF); taskbar = c(0xE8F3F5FA)
            text = c(0xFF1B1B1F); textDim = c(0xFF5F6670); border = c(0xFFD3D8E0)
            hover = c(0x1A000000); press = c(0x0F000000); selected = c(0x26000000); tint = c(0x14000000)
            warn = c(0xFFFFF1CC)
        } else {
            bgDark = c(0xFF202328); bar = c(0xFF2B2F36); barActive = c(0xFF353A43); side = c(0xFF1B1E23)
            field = c(0xFF16181C); panel = c(0xF2262A31); taskbar = c(0xE61C1F25)
            text = c(0xFFF4F5F7); textDim = c(0xFFAAB0BA); border = c(0xFF3A404A)
            hover = c(0x30FFFFFF); press = c(0x18FFFFFF); selected = c(0x44FFFFFF); tint = c(0x22FFFFFF)
            warn = c(0xFF5A3A00)
        }
    }

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rect(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun stateBg(
        radius: Float,
        normal: Int = 0,
        hov: Int = hover,
        prs: Int = press,
        sel: Int = selected
    ): StateListDrawable {
        fun shape(col: Int) = GradientDrawable().apply { setColor(col); cornerRadius = radius }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(prs))
            addState(intArrayOf(android.R.attr.state_selected), shape(sel))
            addState(intArrayOf(android.R.attr.state_hovered), shape(hov))
            addState(intArrayOf(), shape(normal))
        }
    }

    fun button(ctx: Context, label: String, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(Ui.text)
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            background = stateBg(dp(ctx, 6).toFloat(), Ui.tint)
            isClickable = true
            setOnClickListener { onClick() }
            hand()
        }

    /** A rounded, coloured app tile with an emoji on it. */
    fun tile(ctx: Context, emoji: String, color: Int, sizeDp: Int, textSp: Float): TextView =
        TextView(ctx).apply {
            text = emoji
            textSize = textSp
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(lighten(color, 0.22f), color)
            ).apply { cornerRadius = dp(ctx, sizeDp / 4 + 2).toFloat() }
        }

    fun lighten(col: Int, f: Float): Int {
        val r = Color.red(col) + ((255 - Color.red(col)) * f).toInt()
        val g = Color.green(col) + ((255 - Color.green(col)) * f).toInt()
        val b = Color.blue(col) + ((255 - Color.blue(col)) * f).toInt()
        return Color.rgb(r, g, b)
    }

    fun withAlpha(col: Int, a: Int): Int = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))
}

fun Context.dp(v: Int): Int = Ui.dp(this, v)
fun View.dp(v: Int): Int = Ui.dp(context, v)

fun View.hand() {
    if (Build.VERSION.SDK_INT >= 24) {
        pointerIcon = PointerIcon.getSystemIcon(context, PointerIcon.TYPE_HAND)
    }
}

/** Touch: single tap runs the action. Mouse: single click selects, double click runs it. */
fun View.activate(onSelect: () -> Unit = {}, action: () -> Unit) {
    var tool = MotionEvent.TOOL_TYPE_FINGER
    var last = 0L
    isClickable = true
    setOnTouchListener { _, e ->
        if (e.actionMasked == MotionEvent.ACTION_DOWN) tool = e.getToolType(0)
        false
    }
    setOnClickListener {
        if (tool == MotionEvent.TOOL_TYPE_MOUSE) {
            val now = SystemClock.uptimeMillis()
            if (now - last < 450) {
                last = 0
                action()
            } else {
                last = now
                onSelect()
                isSelected = true
            }
        } else {
            action()
        }
    }
}

class WinLogo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var color: Int = Color.WHITE
    var scale: Float = 0.40f

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) * scale
        val g = s * 0.05f
        val cx = width / 2f
        val cy = height / 2f
        val h = s / 2f
        p.color = color
        canvas.drawRect(cx - h, cy - h, cx - g, cy - g, p)
        canvas.drawRect(cx + g, cy - h, cx + h, cy - g, p)
        canvas.drawRect(cx - h, cy + g, cx - g, cy + h, p)
        canvas.drawRect(cx + g, cy + g, cx + h, cy + h, p)
    }
}
