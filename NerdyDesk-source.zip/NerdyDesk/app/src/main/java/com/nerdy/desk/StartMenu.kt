package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class StartMenu(private val act: MainActivity) : FrameLayout(act) {

    class Entry(
        val label: String,
        val icon: Drawable?,
        val kind: AppKind? = null,
        val pkg: String? = null,
        val action: () -> Unit
    )

    var isOpen = false
        private set
    private var panel = LinearLayout(act)
    private var search = EditText(act)
    private var content = LinearLayout(act)
    private var allApps = false
    private var installed: List<Entry> = emptyList()
    private var firstResult: (() -> Unit)? = null

    init {
        visibility = View.GONE
        isClickable = true
        setOnClickListener { close() }
        buildPanel()
    }

    fun restyle() {
        removeAllViews()
        buildPanel()
        if (isOpen) { place(); refill("") }
    }

    private fun buildPanel() {
        panel = LinearLayout(act)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = Ui.rect(Ui.panel, dp(14).toFloat(), Ui.border, 1)
        panel.setPadding(dp(18), dp(16), dp(18), dp(10))
        panel.isClickable = true
        panel.elevation = dp(20).toFloat()

        search = EditText(act)
        search.hint = "\uD83D\uDD0D  Search apps, files, the web \u2014 or type a sum"
        search.setHintTextColor(Ui.textDim)
        search.setTextColor(Ui.text)
        search.textSize = 14f
        search.setSingleLine()
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = Ui.rect(Ui.field, dp(20).toFloat(), Ui.border, 1)
        search.setPadding(dp(16), 0, dp(16), 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refill(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val f = firstResult
            if (f != null) {
                close()
                f()
            }
            true
        }
        panel.addView(search, lp(MATCH, dp(40)))

        val sv = ScrollView(act)
        content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        sv.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        val sl = lp(MATCH, 0, 1f)
        sl.topMargin = dp(10)
        panel.addView(sv, sl)

        val bottom = LinearLayout(act)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(0, dp(8), 0, 0)
        val av = TextView(act)
        av.text = "N"
        av.textSize = 14f
        av.gravity = Gravity.CENTER
        av.setTextColor(0xFFFFFFFF.toInt())
        av.background = Ui.rect(Ui.accent, dp(16).toFloat())
        bottom.addView(av, lp(dp(32), dp(32)))
        val name = TextView(act)
        name.text = "  @NerdyIntruder"
        name.textSize = 13f
        name.setTextColor(Ui.text)
        bottom.addView(name, lp(0, WRAP, 1f))
        bottom.addView(iconBtn("\u2699\uFE0F") { close(); act.open(AppKind.SETTINGS, null) }, lp(dp(42), dp(38)))
        bottom.addView(iconBtn("\u23FB") { showPower(it) }, lp(dp(42), dp(38)))
        panel.addView(bottom, lp(MATCH, WRAP))

        addView(panel, FrameLayout.LayoutParams(dp(580), dp(580), Gravity.BOTTOM or Gravity.START))
    }

    private fun iconBtn(label: String, onClick: (View) -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(dp(6).toFloat())
        t.setOnClickListener { onClick(it) }
        t.hand()
        return t
    }

    private fun showPower(anchor: View) {
        val m = PopupMenu(act, anchor)
        m.menu.add(0, 1, 0, "Lock")
        m.menu.add(0, 2, 1, "Restart desktop")
        m.menu.add(0, 3, 2, "Choose default home app")
        m.menu.add(0, 4, 3, "Android settings")
        m.menu.add(0, 5, 4, "Close NerdyDesk")
        m.setOnMenuItemClickListener {
            close()
            when (it.itemId) {
                1 -> act.lock()
                2 -> act.recreate()
                3 -> act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                4 -> act.startSafely(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                5 -> act.finish()
            }
            true
        }
        m.show()
    }

    // ---------------------------------------------------------------- data

    private fun loadApps() {
        val pm = act.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        installed = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != act.packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                Entry(ri.loadLabel(pm).toString(), ri.loadIcon(pm), null, pkg) { act.launchPackage(pkg) }
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun builtins(): List<Entry> = AppKind.values().map { k ->
        Entry(k.title, null, k) { act.open(k, null) }
    }

    private fun section(title: String, right: String?, onRight: (() -> Unit)?): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(4))
        val t = TextView(act)
        t.text = title
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        row.addView(t, lp(0, WRAP, 1f))
        if (right != null && onRight != null) {
            row.addView(Ui.button(act, right) { onRight() }, lp(WRAP, dp(32)))
        }
        return row
    }

    private fun refill(filter: String) {
        val q = filter.trim()
        content.removeAllViews()
        firstResult = null
        if (q.isEmpty()) {
            if (allApps) {
                content.addView(section("All apps", "\u2039 Back") { allApps = false; refill("") })
                var letter = ' '
                for (e in builtins() + installed) {
                    val l = e.label.firstOrNull()?.uppercaseChar() ?: '#'
                    if (l != letter) {
                        letter = l
                        val h = TextView(act)
                        h.text = l.toString()
                        h.textSize = 12f
                        h.setTextColor(Ui.accent)
                        h.setPadding(dp(8), dp(8), 0, dp(2))
                        content.addView(h)
                    }
                    content.addView(listRow(e))
                }
            } else {
                content.addView(section("Pinned", "All apps \u203A") { allApps = true; refill("") })
                val grid = GridLayout(act)
                grid.columnCount = 6
                val entries = ArrayList<Entry>()
                entries.addAll(builtins())
                val pins = (act.prefs.getString("startpins", "") ?: "").split(",").filter { it.isNotEmpty() }
                for (p in pins) installed.firstOrNull { it.pkg == p }?.let { entries.add(it) }
                for (e in entries) grid.addView(tileCell(e))
                content.addView(grid)
                val rec = recent()
                if (rec.isNotEmpty()) {
                    content.addView(section("Recent", null, null))
                    val rg = GridLayout(act)
                    rg.columnCount = 6
                    for (e in rec) rg.addView(tileCell(e))
                    content.addView(rg)
                }
            }
            return
        }
        val ql = q.lowercase()
        // calculator
        val calc = Calc.eval(q)
        if (calc != null) {
            content.addView(infoRow("\uD83E\uDDEE", Calc.fmt(calc), "Calculator  \u2022  tap to copy") {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("result", Calc.fmt(calc)))
                act.toast("Copied")
            })
        }
        val apps = (builtins() + installed).filter { it.label.lowercase().contains(ql) }
        if (apps.isNotEmpty()) {
            content.addView(section("Apps", null, null))
            for (e in apps.take(8)) content.addView(listRow(e))
            if (firstResult == null) firstResult = apps[0].action
        }
        if (q.length >= 2) {
            val files = searchFiles(q)
            if (files.isNotEmpty()) {
                content.addView(section("Files", null, null))
                for (f in files) {
                    content.addView(infoRow(if (f.isDirectory) "\uD83D\uDCC1" else "\uD83D\uDCC4", f.name, f.parent ?: "") { act.openFileSmart(f.absolutePath) })
                }
                if (firstResult == null) firstResult = { act.openFileSmart(files[0].absolutePath) }
            }
        }
        content.addView(section("Web", null, null))
        content.addView(infoRow("\uD83C\uDF10", "Search the web for \"$q\"", "Nerdy Browser") { act.open(AppKind.BROWSER, q) })
        if (firstResult == null) firstResult = { act.runCommand(q) }
    }

    private fun recent(): List<Entry> {
        val out = ArrayList<Entry>()
        for (k in (act.prefs.getString("recent", "") ?: "").split(",")) {
            if (k.startsWith("p:")) installed.firstOrNull { it.pkg == k.substring(2) }?.let { out.add(it) }
            else if (k.startsWith("k:")) {
                val kind = try { AppKind.valueOf(k.substring(2)) } catch (e: Exception) { null }
                if (kind != null) out.add(Entry(kind.title, null, kind) { act.open(kind, null) })
            }
            if (out.size >= 6) break
        }
        return out
    }

    private fun searchFiles(q: String): List<File> {
        val out = ArrayList<File>()
        try {
            val cur = act.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                arrayOf("_data"),
                "_display_name LIKE ?",
                arrayOf("%$q%"),
                "date_modified DESC"
            )
            if (cur != null) {
                while (cur.moveToNext() && out.size < 6) {
                    val p = cur.getString(0) ?: continue
                    val f = File(p)
                    if (f.exists()) out.add(f)
                }
                cur.close()
            }
        } catch (e: Exception) {
        }
        return out
    }

    // ---------------------------------------------------------------- cells

    private fun iconView(e: Entry, size: Int, textSp: Float): View {
        if (e.icon != null) {
            val iv = ImageView(act)
            iv.setImageDrawable(e.icon)
            return iv
        }
        val k = e.kind
        return Ui.tile(act, k?.icon ?: "?", k?.color ?: Ui.accent, size, textSp)
    }

    private fun tileCell(e: Entry): View {
        val cell = LinearLayout(act)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(2), dp(8), dp(2), dp(6))
        cell.isClickable = true
        cell.background = Ui.stateBg(dp(8).toFloat())
        cell.addView(iconView(e, 40, 20f), lp(dp(40), dp(40)))
        val l = TextView(act)
        l.text = e.label
        l.textSize = 10.5f
        l.setTextColor(Ui.text)
        l.gravity = Gravity.CENTER
        l.maxLines = 2
        l.ellipsize = android.text.TextUtils.TruncateAt.END
        l.setPadding(0, dp(4), 0, 0)
        cell.addView(l, lp(MATCH, WRAP))
        cell.setOnClickListener { close(); runEntry(e) }
        cell.setOnLongClickListener { entryMenu(cell, e); true }
        cell.setOnContextClickListener { entryMenu(cell, e); true }
        cell.hand()
        val g = GridLayout.LayoutParams()
        g.width = dp(86)
        g.height = dp(88)
        cell.layoutParams = g
        return cell
    }

    private fun listRow(e: Entry): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(5), dp(8), dp(5))
        row.isClickable = true
        row.background = Ui.stateBg(dp(8).toFloat())
        row.addView(iconView(e, 30, 15f), lp(dp(30), dp(30)))
        val t = TextView(act)
        t.text = "   " + e.label
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.setSingleLine()
        row.addView(t, lp(0, WRAP, 1f))
        row.setOnClickListener { close(); runEntry(e) }
        row.setOnLongClickListener { entryMenu(row, e); true }
        row.setOnContextClickListener { entryMenu(row, e); true }
        row.hand()
        return row
    }

    private fun infoRow(emoji: String, title: String, sub: String, action: () -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(6), dp(8), dp(6))
        row.isClickable = true
        row.background = Ui.stateBg(dp(8).toFloat())
        val e = TextView(act)
        e.text = emoji
        e.textSize = 20f
        e.gravity = Gravity.CENTER
        row.addView(e, lp(dp(34), dp(34)))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), 0, 0, 0)
        val t = TextView(act)
        t.text = title
        t.textSize = 13f
        t.setTextColor(Ui.text)
        t.setSingleLine()
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(t)
        val s = TextView(act)
        s.text = sub
        s.textSize = 10.5f
        s.setTextColor(Ui.textDim)
        s.setSingleLine()
        s.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        col.addView(s)
        row.addView(col, lp(0, WRAP, 1f))
        row.setOnClickListener { close(); action() }
        row.hand()
        return row
    }

    private fun runEntry(e: Entry) {
        if (e.kind != null) act.rememberRecent("k:" + e.kind.name)
        e.action()
    }

    private fun entryMenu(anchor: View, e: Entry) {
        val m = PopupMenu(act, anchor)
        val key = if (e.kind != null) "k:" + e.kind.name else "p:" + e.pkg
        m.menu.add(0, 1, 0, if (act.taskbar.isPinned(key)) "Unpin from taskbar" else "Pin to taskbar")
        if (e.pkg != null) {
            val pins = (act.prefs.getString("startpins", "") ?: "").split(",").filter { it.isNotEmpty() }
            m.menu.add(0, 2, 1, if (pins.contains(e.pkg)) "Unpin from Start" else "Pin to Start")
            m.menu.add(0, 3, 2, "App info")
            m.menu.add(0, 4, 3, "Uninstall")
        }
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> act.taskbar.togglePin(key)
                2 -> {
                    val pins = (act.prefs.getString("startpins", "") ?: "").split(",").filter { x -> x.isNotEmpty() }.toMutableList()
                    if (!pins.remove(e.pkg)) pins.add(e.pkg!!)
                    act.prefs.edit().putString("startpins", pins.joinToString(",")).apply()
                    refill(search.text.toString())
                }
                3 -> { close(); act.startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                4 -> { close(); act.startSafely(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            true
        }
        m.show()
    }

    // ---------------------------------------------------------------- open / close

    private fun place() {
        val par = parent as? View ?: return
        val lpn = panel.layoutParams as FrameLayout.LayoutParams
        lpn.height = minOf(dp(580), par.height - dp(16))
        lpn.width = minOf(dp(580), par.width - dp(16))
        val centered = act.prefs.getString("tbstyle", "center") == "center"
        lpn.gravity = Gravity.BOTTOM or (if (centered) Gravity.CENTER_HORIZONTAL else Gravity.START)
        lpn.leftMargin = dp(8)
        lpn.bottomMargin = dp(8)
        panel.layoutParams = lpn
    }

    fun open() {
        place()
        loadApps()
        allApps = false
        search.setText("")
        refill("")
        visibility = View.VISIBLE
        isOpen = true
        panel.alpha = 0f
        panel.translationY = dp(18).toFloat()
        panel.animate().alpha(1f).translationY(0f).setDuration(170).start()
        search.requestFocus()
        act.onStartToggled()
    }

    fun focusSearch2() {
        search.requestFocus()
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    fun close() {
        if (!isOpen) return
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
        visibility = View.GONE
        isOpen = false
        act.onStartToggled()
    }
}

/** Tiny safe calculator for the search box. */
object Calc {
    fun fmt(v: Double): String {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
    }

    fun eval(s: String): Double? {
        val t = s.replace(" ", "").replace("x", "*").replace("\u00D7", "*").replace("\u00F7", "/")
        if (t.isEmpty() || !t.any { it in "+-*/^%" } || !t.all { it.isDigit() || it in "+-*/^%().," }) return null
        return try {
            val p = P(t.replace(",", ""))
            val v = p.expr()
            if (p.pos != t.replace(",", "").length || v.isNaN() || v.isInfinite()) null else v
        } catch (e: Exception) {
            null
        }
    }

    private class P(val s: String) {
        var pos = 0
        fun expr(): Double {
            var v = term()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val o = s[pos++]
                val r = term()
                v = if (o == '+') v + r else v - r
            }
            return v
        }

        fun term(): Double {
            var v = pow()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/' || s[pos] == '%')) {
                val o = s[pos++]
                val r = pow()
                v = when (o) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }

        fun pow(): Double {
            val b = unary()
            if (pos < s.length && s[pos] == '^') {
                pos++
                return Math.pow(b, pow())
            }
            return b
        }

        fun unary(): Double {
            if (pos < s.length && s[pos] == '-') { pos++; return -unary() }
            if (pos < s.length && s[pos] == '+') { pos++; return unary() }
            if (pos < s.length && s[pos] == '(') {
                pos++
                val v = expr()
                if (pos < s.length && s[pos] == ')') pos++ else throw IllegalStateException()
                return v
            }
            val st = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (st == pos) throw IllegalStateException()
            return s.substring(st, pos).toDouble()
        }
    }
}
