package com.nerdy.desk

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsApp(act: MainActivity) : App(act) {
    override val title = "Settings"
    override val icon = "\u2699\uFE0F"
    private lateinit var col: LinearLayout

    override fun build(): View {
        val sv = ScrollView(act)
        sv.setBackgroundColor(Ui.bgDark)
        col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(act.dp(20), act.dp(14), act.dp(20), act.dp(24))
        sv.addView(col, lp(MATCH, WRAP))
        fill()
        return sv
    }

    private fun fill() {
        (col.parent as? View)?.setBackgroundColor(Ui.bgDark)
        col.removeAllViews()
        col.addView(header("Personalization"))
        col.addView(label("Theme"))
        col.addView(chips(listOf("Light", "Dark"), if (Ui.light) 0 else 1) { act.setLightTheme(it == 0); fill() })
        col.addView(label("Background"))
        val wr = LinearLayout(act)
        wr.orientation = LinearLayout.HORIZONTAL
        val hs = android.widget.HorizontalScrollView(act)
        WallpaperView.names.forEachIndexed { i, n ->
            val sw = WallpaperView(act)
            sw.style = i
            val box = LinearLayout(act)
            box.orientation = LinearLayout.VERTICAL
            box.addView(sw, lp(act.dp(92), act.dp(56)))
            val t = TextView(act)
            t.text = n
            t.textSize = 10f
            t.setTextColor(Ui.textDim)
            t.gravity = Gravity.CENTER
            box.addView(t, lp(act.dp(92), WRAP))
            box.isClickable = true
            box.setOnClickListener { act.setWallpaper(i) }
            box.hand()
            val l = lp(WRAP, WRAP)
            l.setMargins(0, act.dp(6), act.dp(10), act.dp(6))
            wr.addView(box, l)
        }
        hs.addView(wr)
        col.addView(hs)
        col.addView(toggle("Animated wallpaper (drifting colours)", "wallanim", false) { act.applyWallpaper() })
        col.addView(Ui.button(act, "\uD83D\uDDBC  Use my own picture as background\u2026") {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
            try { act.startActivityForResult(i, MainActivity.REQ_WALL) } catch (e: Exception) { act.toast("No picture picker found") }
        })
        col.addView(label("Accent colour"))
        val ar = LinearLayout(act)
        ar.orientation = LinearLayout.HORIZONTAL
        Ui.accents.forEachIndexed { i, colr ->
            val sw = View(act)
            sw.background = Ui.rect(colr, act.dp(8).toFloat(), if (colr == Ui.accent) Ui.text else 0, 3)
            sw.isClickable = true
            sw.setOnClickListener { act.setAccent(i); fill() }
            sw.hand()
            val l = lp(act.dp(38), act.dp(38))
            l.setMargins(0, act.dp(6), act.dp(8), act.dp(6))
            ar.addView(sw, l)
        }
        col.addView(ar)

        col.addView(header("Taskbar & Start"))
        col.addView(label("Taskbar style"))
        val tb = act.prefs.getString("tbstyle", "center") ?: "center"
        col.addView(chips(listOf("Windows 11 (centred)", "Windows 10 (left)"), if (tb == "center") 0 else 1) {
            act.prefs.edit().putString("tbstyle", if (it == 0) "center" else "left").apply()
            act.taskbar.rebuild()
        })
        col.addView(toggle("24-hour clock", "clock24", false) { act.taskbar.updateTray() })
        col.addView(Ui.button(act, "Reset taskbar pins") { act.prefs.edit().remove("pinned").apply(); act.taskbar.refresh() })

        col.addView(header("Display"))
        col.addView(toggle("Hide Android bars (full screen)", "fullscreen", true) { act.applyDisplayPrefs() })
        col.addView(label("Screen rotation"))
        val o = act.prefs.getString("orient", "landscape") ?: "landscape"
        col.addView(chips(listOf("Landscape", "Auto-rotate", "Portrait"), when (o) { "landscape" -> 0; "auto" -> 1; else -> 2 }) {
            act.setOrientationPref(listOf("landscape", "auto", "portrait")[it])
        })
        col.addView(label("Desktop icon size"))
        val sz = act.prefs.getString("iconsize", "medium") ?: "medium"
        col.addView(chips(listOf("Small", "Medium", "Large"), when (sz) { "small" -> 0; "medium" -> 1; else -> 2 }) {
            act.prefs.edit().putString("iconsize", listOf("small", "medium", "large")[it]).apply()
            act.applyWallpaper()
        })
        col.addView(toggle("Show desktop icons", "showicons", true) { act.applyWallpaper() })

        col.addView(header("Start-up"))
        val bm = act.prefs.getString("boot", "full") ?: "full"
        col.addView(chips(listOf("Boot + lock screen", "Boot only", "None"), when (bm) { "full" -> 0; "boot" -> 1; else -> 2 }) {
            act.prefs.edit().putString("boot", listOf("full", "boot", "off")[it]).apply()
        })
        col.addView(Ui.button(act, "\u25B6  Preview start-up animation") { act.lock() })

        col.addView(header("Phone apps"))
        col.addView(toggle("Open phone apps as floating windows (if your phone supports it)", "freeform", true) {})
        col.addView(Ui.button(act, "Make NerdyDesk my Home app") { act.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        col.addView(Ui.button(act, "Allow access to all files") {
            val u = Uri.parse("package:" + act.packageName)
            if (Build.VERSION.SDK_INT >= 30) act.startSafely(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else act.startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        col.addView(Ui.button(act, "Android settings") { act.startSafely(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })

        col.addView(header("About"))
        val ab = TextView(act)
        ab.text = "NerdyDesk 2.0 \u2022 a PC desktop for your phone\nMade by @NerdyIntruder \u2022 Nerdy Trading Way\n\n" +
            "Win = Start, Win+E files, Win+D desktop, Win+Tab task view, Win+R run, Win+L lock,\n" +
            "Win+A quick settings, Win+W widgets, Win+Arrows snap windows, Ctrl+Win+Left/Right switch desktops,\n" +
            "Ctrl+Shift+Esc task manager, Alt+F4 close."
        ab.textSize = 12f
        ab.setTextColor(Ui.textDim)
        col.addView(ab)
    }

    private fun header(s: String): View {
        val t = TextView(act)
        t.text = s
        t.textSize = 17f
        t.setTextColor(Ui.text)
        t.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        t.setPadding(0, act.dp(20), 0, act.dp(4))
        return t
    }

    private fun label(s: String): View {
        val t = TextView(act)
        t.text = s
        t.textSize = 12f
        t.setTextColor(Ui.textDim)
        t.setPadding(0, act.dp(8), 0, act.dp(2))
        return t
    }

    private fun chips(names: List<String>, sel: Int, pick: (Int) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        names.forEachIndexed { i, n ->
            val t = TextView(act)
            t.text = n
            t.textSize = 12.5f
            t.gravity = Gravity.CENTER
            t.setPadding(act.dp(14), act.dp(8), act.dp(14), act.dp(8))
            t.setTextColor(if (i == sel) Color.WHITE else Ui.text)
            t.background = Ui.rect(if (i == sel) Ui.accent else Ui.tint, act.dp(8).toFloat())
            t.isClickable = true
            t.setOnClickListener { pick(i); if (i != sel) fillChips() }
            t.hand()
            val l = lp(WRAP, WRAP)
            l.setMargins(0, act.dp(4), act.dp(8), act.dp(4))
            row.addView(t, l)
        }
        return row
    }

    private fun fillChips() {
        // theme change rebuilds the window; other changes just refresh the labels
        if (::col.isInitialized) col.post { fill() }
    }

    private fun toggle(text: String, key: String, def: Boolean, changed: () -> Unit): View {
        val s = Switch(act)
        s.text = text
        s.textSize = 13f
        s.setTextColor(Ui.text)
        s.isChecked = act.prefs.getBoolean(key, def)
        s.setPadding(0, act.dp(8), 0, act.dp(8))
        s.setOnCheckedChangeListener { _, v ->
            act.prefs.edit().putBoolean(key, v).apply()
            changed()
        }
        return s
    }
}
