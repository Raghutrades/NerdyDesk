package com.nerdy.desk

import android.view.KeyEvent
import android.view.View

abstract class App(val act: MainActivity) {
    var window: WindowView? = null
    abstract val title: String
    abstract val icon: String
    abstract fun build(): View
    open fun onClose() {}
    open fun onResume() {}
    open fun onShortcut(e: KeyEvent): Boolean = false
    open fun onBack(): Boolean = false
    /** Called when something (a file, a link) is handed to an already open window. */
    open fun onOpenArg(arg: String) {}
    /** What to reopen this window with after a theme change (a folder, a file, a web address). */
    open fun currentArg(): String? = null
}

/**
 * Every built-in app. web = the page under assets/apps/<id>/index.html, hosted by WebApp.
 * w/h are fractions of the desktop; max = open maximised.
 */
enum class AppKind(
    val title: String,
    val icon: String,
    val color: Int,
    val web: String?,
    val w: Float,
    val h: Float,
    val max: Boolean
) {
    FILES("File Explorer", "\uD83D\uDCC1", c(0xFFF2B01E), null, 0.74f, 0.82f, false),
    BROWSER("Nerdy Browser", "\uD83C\uDF10", c(0xFF0A74DA), null, 0.88f, 0.92f, false),
    NEURO("Neuro Orbit", "\uD83E\uDDE0", c(0xFF6C3FD1), "neuro", 0.92f, 0.94f, true),
    PHOTOS("Photos", "\uD83D\uDDBC\uFE0F", c(0xFFE5334B), "photos", 0.86f, 0.9f, false),
    VIDEO("Video Player", "\uD83C\uDFAC", c(0xFFE8590C), "video", 0.84f, 0.88f, false),
    MUSIC("Music", "\uD83C\uDFB5", c(0xFFE91E8C), "music", 0.78f, 0.88f, false),
    NOTEPAD("Notepad", "\uD83D\uDCDD", c(0xFF3B82F6), null, 0.6f, 0.78f, false),
    CALC("Calculator", "\uD83E\uDDEE", c(0xFF2F9E44), "calc", 0.34f, 0.9f, false),
    TERMINAL("Terminal", "\u2328\uFE0F", c(0xFF343A40), "terminal", 0.7f, 0.76f, false),
    PAINT("Paint", "\uD83C\uDFA8", c(0xFFFF7A00), "paint", 0.86f, 0.9f, false),
    CALENDAR("Calendar & Clock", "\uD83D\uDCC5", c(0xFF1C7ED6), "calendar", 0.72f, 0.88f, false),
    WEATHER("Weather", "\u26C5", c(0xFF00A7B5), "weather", 0.5f, 0.86f, false),
    TRADEDESK("Trade Desk", "\uD83D\uDCC8", c(0xFF12B886), "tradedesk", 0.92f, 0.94f, true),
    TASKMGR("Task Manager", "\uD83D\uDCCA", c(0xFF5B6CFF), "taskmgr", 0.8f, 0.86f, false),
    SETTINGS("Settings", "\u2699\uFE0F", c(0xFF6B7280), null, 0.68f, 0.86f, false);

    fun create(act: MainActivity, arg: String?): App = when (this) {
        FILES -> FileApp(act, arg)
        BROWSER -> BrowserApp(act, arg)
        NOTEPAD -> NotepadApp(act, arg)
        SETTINGS -> SettingsApp(act)
        else -> WebApp(act, this, arg)
    }
}
