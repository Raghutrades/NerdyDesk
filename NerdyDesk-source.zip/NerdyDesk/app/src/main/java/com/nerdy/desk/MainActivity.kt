package com.nerdy.desk

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import java.io.File

@SuppressLint("ClickableViewAccessibility")
class MainActivity : Activity() {
    companion object {
        const val REQ_FILE = 42
        const val REQ_WALL = 43
        const val TASKBAR_DP = 52
        val imageExts = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
        val videoExts = setOf("mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "ts", "flv")
        val audioExts = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav", "wma")
        val textExts = setOf("txt", "md", "log", "json", "xml", "csv", "ini", "conf", "py", "js", "java", "kt", "html", "css", "yml", "yaml", "sh", "gradle", "properties", "pine")
        val singles = setOf(AppKind.SETTINGS, AppKind.TASKMGR, AppKind.NEURO, AppKind.TRADEDESK, AppKind.WEATHER, AppKind.CALENDAR, AppKind.MUSIC, AppKind.VIDEO)
    }

    lateinit var prefs: SharedPreferences
    lateinit var desktop: FrameLayout
    lateinit var startMenu: StartMenu
    lateinit var taskbar: Taskbar
    private lateinit var wall: WallpaperView
    private lateinit var rootLayout: FrameLayout
    private lateinit var iconGrid: GridLayout
    private lateinit var snapBox: View
    private lateinit var quick: QuickPanel
    private lateinit var calendarPanel: CalendarPanel
    private lateinit var taskView: TaskView
    private lateinit var widgets: WidgetsPanel
    private lateinit var runDialog: RunDialog
    private val flyouts = ArrayList<Flyout>()

    val windows = ArrayList<WindowView>()
    var focused: WindowView? = null
    var filePathCallback: ValueCallback<Array<Uri>>? = null
    var curDesk = 0
    var deskCount = 1

    private var boot: BootView? = null
    private var fsOverlay: FrameLayout? = null
    private var fsCallback: WebChromeClient.CustomViewCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private var cascade = 0
    private var winUsed = false
    private var lastX = 0
    private var lastY = 0
    private var lastRows = -1
    private var immersive = false

    private val tick = object : Runnable {
        override fun run() {
            taskbar.updateTray()
            handler.postDelayed(this, 20000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nerdydesk", MODE_PRIVATE)
        Ui.applyTheme(prefs.getBoolean("light", true))
        Ui.accent = Ui.accents[prefs.getInt("accent", 0).coerceIn(0, Ui.accents.size - 1)]
        buildUi()
        applyDisplayPrefs()
        val bootMode = prefs.getString("boot", "full") ?: "full"
        if (savedInstanceState == null && bootMode != "off") {
            val b = BootView(this, bootMode == "full") {
                rootLayout.removeView(boot)
                boot = null
            }
            boot = b
            rootLayout.addView(b, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        desktop.post { handleIntent(intent) }
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Ui.bgDark)
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        desktop = FrameLayout(this)
        desktop.isClickable = true
        desktop.setOnTouchListener { _, e ->
            lastX = e.x.toInt()
            lastY = e.y.toInt()
            false
        }
        desktop.setOnClickListener { clearIconSelection(); closeFlyouts(null) }
        desktop.setOnContextClickListener { desktopMenu(); true }
        desktop.setOnLongClickListener { desktopMenu(); true }

        wall = WallpaperView(this)
        desktop.addView(wall, FrameLayout.LayoutParams(MATCH, MATCH))

        iconGrid = GridLayout(this)
        iconGrid.orientation = GridLayout.VERTICAL
        iconGrid.setPadding(dp(8), dp(10), dp(8), dp(8))
        desktop.addView(iconGrid, FrameLayout.LayoutParams(WRAP, MATCH))
        desktop.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop || lastRows < 0) buildIcons()
        }

        snapBox = View(this)
        snapBox.visibility = View.GONE
        snapBox.background = Ui.rect(Ui.withAlpha(Ui.accent, 70), dp(10).toFloat(), Ui.accent, 3)
        desktop.addView(snapBox, FrameLayout.LayoutParams(10, 10))

        column.addView(desktop, lp(MATCH, 0, 1f))
        taskbar = Taskbar(this)
        column.addView(taskbar, lp(MATCH, dp(TASKBAR_DP)))
        rootLayout.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        startMenu = StartMenu(this)
        quick = QuickPanel(this)
        calendarPanel = CalendarPanel(this)
        taskView = TaskView(this)
        widgets = WidgetsPanel(this)
        runDialog = RunDialog(this)
        flyouts.clear()
        flyouts.addAll(listOf(quick, calendarPanel, taskView, widgets, runDialog))
        val sl = FrameLayout.LayoutParams(MATCH, MATCH)
        sl.bottomMargin = dp(TASKBAR_DP)
        rootLayout.addView(startMenu, sl)
        for (f in flyouts) {
            val fl = FrameLayout.LayoutParams(MATCH, MATCH)
            fl.bottomMargin = dp(TASKBAR_DP)
            rootLayout.addView(f, fl)
        }
        setContentView(rootLayout)
        applyWallpaper()
        taskbar.refresh()
    }

    private fun iconDefs(): List<Triple<AppKind?, String, () -> Unit>> = listOf(
        Triple(AppKind.FILES, "This PC", { open(AppKind.FILES, null) }),
        Triple(AppKind.FILES, "Downloads", { open(AppKind.FILES, "/storage/emulated/0/Download") }),
        Triple(AppKind.BROWSER, "Nerdy Browser", { open(AppKind.BROWSER, null) }),
        Triple(AppKind.NEURO, "Neuro Orbit", { open(AppKind.NEURO, null) }),
        Triple(AppKind.TRADEDESK, "Trade Desk", { open(AppKind.TRADEDESK, null) }),
        Triple(AppKind.PHOTOS, "Photos", { open(AppKind.PHOTOS, null) }),
        Triple(AppKind.VIDEO, "Videos", { open(AppKind.VIDEO, null) }),
        Triple(AppKind.MUSIC, "Music", { open(AppKind.MUSIC, null) }),
        Triple(AppKind.NOTEPAD, "Notepad", { open(AppKind.NOTEPAD, null) }),
        Triple(AppKind.TERMINAL, "Terminal", { open(AppKind.TERMINAL, null) }),
        Triple(AppKind.SETTINGS, "Settings", { open(AppKind.SETTINGS, null) })
    )

    private fun buildIcons() {
        val h = desktop.height
        if (h <= 0) return
        val size = when (prefs.getString("iconsize", "medium")) { "small" -> 72; "large" -> 104; else -> 88 }
        iconGrid.removeAllViews()
        if (!prefs.getBoolean("showicons", true)) {
            lastRows = 0
            return
        }
        val rows = maxOf(1, (h - dp(18)) / dp(size + 6))
        lastRows = rows
        iconGrid.rowCount = rows
        val light = wallIsLight()
        for ((kind, label, action) in iconDefs()) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(6), dp(2), dp(4))
            cell.background = Ui.stateBg(dp(8).toFloat(), 0, Ui.withAlpha(Color.WHITE, 60), Ui.withAlpha(Color.WHITE, 90), Ui.withAlpha(Color.WHITE, 90))
            val tileSize = size * 5 / 9
            val tile = Ui.tile(this, kind?.icon ?: "?", kind?.color ?: Ui.accent, tileSize, (tileSize * 0.42f))
            cell.addView(tile, lp(dp(tileSize), dp(tileSize)).also { it.bottomMargin = dp(4) })
            val t = TextView(this)
            t.text = label
            t.textSize = 11.5f
            t.setTextColor(if (light) 0xFF1B1B1F.toInt() else Color.WHITE)
            if (!light) t.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            cell.addView(t, lp(MATCH, WRAP))
            cell.activate(onSelect = { clearIconSelection() }) { action() }
            cell.setOnLongClickListener { true }
            cell.hand()
            val g = GridLayout.LayoutParams()
            g.width = dp(size)
            g.height = dp(size + 4)
            iconGrid.addView(cell, g)
        }
    }

    private fun wallIsLight(): Boolean {
        if (prefs.getString("wallphoto", null) != null) return false
        return prefs.getInt("wall", 0) in setOf(5, 6, 7)
    }

    private fun clearIconSelection() {
        for (i in 0 until iconGrid.childCount) iconGrid.getChildAt(i).isSelected = false
    }

    fun applyWallpaper() {
        val photo = prefs.getString("wallphoto", null)
        if (photo != null && File(photo).exists()) wall.setPhotoPath(photo) else wall.setPhotoPath(null)
        wall.style = prefs.getInt("wall", 0)
        wall.animated = prefs.getBoolean("wallanim", false)
        lastRows = -1
        if (desktop.height > 0) buildIcons()
    }

    fun setWallpaper(i: Int) {
        prefs.edit().putInt("wall", i).remove("wallphoto").apply()
        applyWallpaper()
    }

    fun setWallpaperPhoto(path: String) {
        try {
            val dst = File(filesDir, "wallpaper_" + System.currentTimeMillis() + ".jpg")
            File(path).copyTo(dst, true)
            val old = prefs.getString("wallphoto", null)
            if (old != null) File(old).delete()
            prefs.edit().putString("wallphoto", dst.absolutePath).apply()
            applyWallpaper()
        } catch (e: Exception) {
            toast("Could not use that picture")
        }
    }

    fun setAccent(i: Int) {
        prefs.edit().putInt("accent", i).apply()
        Ui.accent = Ui.accents[i]
        restyleShell()
    }

    fun setLightTheme(light: Boolean) {
        prefs.edit().putBoolean("light", light).apply()
        Ui.applyTheme(light)
        restyleShell()
        // native apps keep their old colours, so reopen them in the new theme
        val redo = windows.filter { it.kind == AppKind.FILES }.map { Triple(it.kind, it.app.currentArg(), it.rect()) }
        windows.filter { it.kind == AppKind.FILES }.forEach { closeWindow(it) }
        for ((k, a, r) in redo) {
            val w = open(k, a)
            w.frame(r[0], r[1], r[2], r[3])
        }
        windows.forEach { (it.app as? WebApp)?.applyTheme() }
    }

    private fun restyleShell() {
        rootLayout.setBackgroundColor(Ui.bgDark)
        snapBox.background = Ui.rect(Ui.withAlpha(Ui.accent, 70), dp(10).toFloat(), Ui.accent, 3)
        taskbar.rebuild()
        startMenu.restyle()
        quick.close(); calendarPanel.close()
        widgets.applyTheme()
        windows.forEach { it.restyle() }
        lastRows = -1
        buildIcons()
    }

    @Suppress("DEPRECATION")
    fun applyDisplayPrefs() {
        requestedOrientation = when (prefs.getString("orient", "landscape")) {
            "auto" -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        setImmersive(prefs.getBoolean("fullscreen", true))
        val b = prefs.getInt("bright", 80)
        if (prefs.getBoolean("brightset", false)) setBrightness(b)
        taskbar.updateTray()
    }

    @Suppress("DEPRECATION")
    fun setImmersive(on: Boolean) {
        immersive = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    fun setOrientationPref(v: String) {
        prefs.edit().putString("orient", v).apply()
        applyDisplayPrefs()
    }

    fun setBrightness(pct: Int) {
        prefs.edit().putInt("bright", pct).putBoolean("brightset", true).apply()
        val lpw = window.attributes
        lpw.screenBrightness = maxOf(0.03f, pct / 100f)
        window.attributes = lpw
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersive) setImmersive(true)
    }

    // ---------------------------------------------------------------- menus

    private fun desktopMenu() {
        popupAt(lastX, lastY, listOf(
            "Open File Explorer", "Open Nerdy Browser", "Open Terminal", "Personalize (next wallpaper)",
            if (prefs.getBoolean("showicons", true)) "Hide desktop icons" else "Show desktop icons",
            "Icon size: small / medium / large", "Refresh", "Settings"
        )) {
            when (it) {
                0 -> open(AppKind.FILES, null)
                1 -> open(AppKind.BROWSER, null)
                2 -> open(AppKind.TERMINAL, null)
                3 -> setWallpaper((prefs.getInt("wall", 0) + 1) % WallpaperView.names.size)
                4 -> { prefs.edit().putBoolean("showicons", !prefs.getBoolean("showicons", true)).apply(); lastRows = -1; buildIcons() }
                5 -> {
                    val next = when (prefs.getString("iconsize", "medium")) { "small" -> "medium"; "medium" -> "large"; else -> "small" }
                    prefs.edit().putString("iconsize", next).apply(); lastRows = -1; buildIcons()
                }
                6 -> { lastRows = -1; buildIcons() }
                7 -> open(AppKind.SETTINGS, null)
            }
        }
    }

    private fun popupAt(x: Int, y: Int, items: List<String>, onPick: (Int) -> Unit) {
        val anchor = View(this)
        val l = FrameLayout.LayoutParams(1, 1)
        l.leftMargin = x
        l.topMargin = y
        desktop.addView(anchor, l)
        val m = PopupMenu(this, anchor)
        items.forEachIndexed { i, s -> m.menu.add(0, i, i, s) }
        m.setOnMenuItemClickListener {
            onPick(it.itemId)
            true
        }
        m.setOnDismissListener { desktop.removeView(anchor) }
        m.show()
    }

    // ---------------------------------------------------------------- flyouts

    fun closeFlyouts(except: Flyout?) {
        for (f in flyouts) if (f !== except) f.close()
        if (startMenu.isOpen) startMenu.close()
    }

    fun onFlyoutChanged() {
        taskbar.refresh()
    }

    fun toggleStart() {
        if (startMenu.isOpen) startMenu.close() else {
            closeFlyouts(null)
            startMenu.open()
        }
    }

    fun openSearch() {
        closeFlyouts(null)
        if (!startMenu.isOpen) startMenu.open()
        startMenu.focusSearch2()
    }

    fun onStartToggled() {
        taskbar.refresh()
    }

    fun toggleQuick() = quick.toggle()
    fun toggleCalendar() = calendarPanel.toggle()
    fun toggleWidgets() = widgets.toggle()
    fun toggleTaskView() = taskView.toggle()
    fun openRun() = runDialog.open()

    /** Text from the Run box or the search box. */
    fun runCommand(q: String) {
        val l = q.lowercase().trim()
        for (k in AppKind.values()) {
            if (l == k.title.lowercase() || l == k.name.lowercase() || l == (k.web ?: "")) {
                open(k, null)
                return
            }
        }
        when (l) {
            "cmd", "powershell", "bash", "shell" -> { open(AppKind.TERMINAL, null); return }
            "calc" -> { open(AppKind.CALC, null); return }
            "explorer", "files" -> { open(AppKind.FILES, null); return }
            "taskmgr" -> { open(AppKind.TASKMGR, null); return }
            "control", "settings", "ms-settings:" -> { open(AppKind.SETTINGS, null); return }
        }
        if (q.startsWith("/")) {
            val f = File(q)
            if (f.isDirectory) open(AppKind.FILES, q) else if (f.exists()) openFileSmart(q) else toast("Not found: $q")
            return
        }
        if (q.startsWith("http://") || q.startsWith("https://") || (q.contains(".") && !q.contains(" "))) {
            open(AppKind.BROWSER, q)
            return
        }
        open(AppKind.BROWSER, q)
    }

    // ---------------------------------------------------------------- windows

    fun open(kind: AppKind, arg: String?): WindowView {
        closeFlyouts(null)
        if (kind in singles) {
            val ex = windows.firstOrNull { it.kind == kind }
            if (ex != null) {
                if (ex.desk != curDesk) moveToDesk(ex, curDesk)
                focusWindow(ex)
                if (arg != null) ex.app.onOpenArg(arg)
                return ex
            }
        }
        rememberRecent("k:" + kind.name)
        val app = kind.create(this, arg)
        val w = WindowView(this, kind, app)
        w.desk = curDesk
        app.window = w
        val dw = desktop.width
        val dh = desktop.height
        val ww = minOf((dw * kind.w).toInt(), dp(1100))
        val wh = minOf((dh * kind.h).toInt(), dp(760))
        val x = minOf(dp(24) + cascade * dp(28), maxOf(0, dw - ww))
        val y = minOf(dp(12) + cascade * dp(24), maxOf(0, dh - wh))
        cascade = (cascade + 1) % 6
        val l = FrameLayout.LayoutParams(ww, wh)
        l.leftMargin = x
        l.topMargin = y
        desktop.addView(w, l)
        w.setNormalRect(x, y, ww, wh)
        windows.add(w)
        if (kind.max || dw < dp(560)) w.applySnap(WindowView.SNAP_MAX)
        w.popIn()
        focusWindow(w)
        return w
    }

    fun openByName(name: String, arg: String?) {
        val k = AppKind.values().firstOrNull { it.name.equals(name, true) || (it.web ?: "").equals(name, true) || it.title.equals(name, true) }
        if (k != null) open(k, arg) else toast("Unknown app: $name")
    }

    fun openFileSmart(path: String) {
        val f = File(path)
        if (f.isDirectory) { open(AppKind.FILES, path); return }
        val ext = f.extension.lowercase()
        when {
            ext in imageExts -> open(AppKind.PHOTOS, path)
            ext in videoExts -> open(AppKind.VIDEO, path)
            ext in audioExts -> open(AppKind.MUSIC, path)
            ext in textExts -> open(AppKind.NOTEPAD, path)
            ext == "html" || ext == "htm" -> openFileExternal(path)
            else -> openFileExternal(path)
        }
    }

    fun openFileExternal(path: String) {
        val f = File(path)
        val uri = Uri.Builder().scheme("content").authority("$packageName.files").path(f.absolutePath).build()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!startSafely(i)) toast("No app can open this file")
    }

    fun shareFile(path: String) {
        val f = File(path)
        val uri = Uri.Builder().scheme("content").authority("$packageName.files").path(f.absolutePath).build()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startSafely(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Start a phone app. With "Open phone apps in windows" on, it is asked to appear as a floating window (works on phones/tablets that support freeform windows). */
    fun launchPackage(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        closeFlyouts(null)
        rememberRecent("p:$pkg")
        if (prefs.getBoolean("freeform", true) && Build.VERSION.SDK_INT >= 24) {
            try {
                val dw = desktop.width
                val dh = desktop.height
                val loc = IntArray(2)
                desktop.getLocationOnScreen(loc)
                val ww = (dw * 0.6f).toInt()
                val wh = (dh * 0.86f).toInt()
                val x = loc[0] + (dw - ww) / 2
                val y = loc[1] + dp(12)
                val o = ActivityOptions.makeBasic()
                o.setLaunchBounds(Rect(x, y, x + ww, y + wh))
                startActivity(i, o.toBundle())
                return true
            } catch (e: Exception) {
            }
        }
        return startSafely(i)
    }

    fun rememberRecent(key: String) {
        val l = (prefs.getString("recent", "") ?: "").split(",").filter { it.isNotEmpty() && it != key }.toMutableList()
        l.add(0, key)
        prefs.edit().putString("recent", l.take(12).joinToString(",")).apply()
    }

    fun focusWindow(w: WindowView?) {
        if (startMenu.isOpen) startMenu.close()
        if (w != null) {
            if (w.desk != curDesk) switchDesk(w.desk)
            if (w.minimized) w.restore()
            windows.remove(w)
            windows.add(w)
            if (desktop.indexOfChild(w) != desktop.childCount - 1) w.bringToFront()
            snapBox.bringToFront()
            snapBox.visibility = View.GONE
        }
        focused = w
        windows.forEach { it.setActive(it === w) }
        taskbar.refresh()
    }

    fun minimizeWindow(w: WindowView) {
        w.minimize()
        if (focused === w) focusWindow(windows.lastOrNull { !it.minimized && it.desk == curDesk }) else taskbar.refresh()
    }

    fun closeWindow(w: WindowView) {
        try {
            w.app.onClose()
        } catch (e: Exception) {
        }
        w.popOut {
            desktop.removeView(w)
        }
        windows.remove(w)
        if (focused === w) focused = null
        focusWindow(windows.lastOrNull { !it.minimized && it.desk == curDesk })
    }

    fun showDesktop() {
        val here = windows.filter { it.desk == curDesk }
        if (here.any { !it.minimized }) {
            here.forEach { it.minimize() }
            focusWindow(null)
        } else {
            here.forEach { it.restore() }
            focusWindow(here.lastOrNull())
        }
    }

    // ---- snap helpers
    fun showSnapPreview(mode: Int) {
        if (mode == WindowView.SNAP_NONE) { snapBox.visibility = View.GONE; return }
        val dw = desktop.width
        val dh = desktop.height
        val hw = dw / 2
        val hh = dh / 2
        val r = when (mode) {
            WindowView.SNAP_LEFT -> intArrayOf(0, 0, hw, dh)
            WindowView.SNAP_RIGHT -> intArrayOf(hw, 0, dw - hw, dh)
            WindowView.SNAP_TL -> intArrayOf(0, 0, hw, hh)
            WindowView.SNAP_TR -> intArrayOf(hw, 0, dw - hw, hh)
            WindowView.SNAP_BL -> intArrayOf(0, hh, hw, dh - hh)
            WindowView.SNAP_BR -> intArrayOf(hw, hh, dw - hw, dh - hh)
            else -> intArrayOf(0, 0, dw, dh)
        }
        val l = snapBox.layoutParams as FrameLayout.LayoutParams
        l.leftMargin = r[0] + dp(4); l.topMargin = r[1] + dp(4); l.width = r[2] - dp(8); l.height = r[3] - dp(8)
        snapBox.layoutParams = l
        snapBox.visibility = View.VISIBLE
        snapBox.bringToFront()
    }

    fun hideSnapPreview() {
        snapBox.visibility = View.GONE
    }

    // ---- virtual desktops
    fun addDesk() {
        if (deskCount < 4) deskCount++
        taskbar.refresh()
    }

    fun removeDesk(i: Int) {
        if (deskCount <= 1) return
        for (w in windows) {
            if (w.desk == i) w.desk = if (i == 0) 1 else i - 1
            if (w.desk > i) w.desk -= 1
        }
        deskCount--
        if (curDesk >= deskCount) curDesk = deskCount - 1
        switchDesk(curDesk)
    }

    fun switchDesk(i: Int) {
        if (i < 0 || i >= deskCount) return
        curDesk = i
        for (w in windows) {
            if (w.desk == i) {
                if (!w.minimized) w.visibility = View.VISIBLE
            } else {
                w.visibility = View.GONE
            }
        }
        val top = windows.lastOrNull { it.desk == i && !it.minimized }
        focused = top
        windows.forEach { it.setActive(it === top) }
        taskbar.refresh()
    }

    fun moveToDesk(w: WindowView, i: Int) {
        w.desk = i
        w.visibility = if (i == curDesk && !w.minimized) View.VISIBLE else View.GONE
        taskbar.refresh()
    }

    // ---- full-screen video from web pages
    fun showFullscreenView(v: View, cb: WebChromeClient.CustomViewCallback?) {
        hideFullscreenView()
        val o = FrameLayout(this)
        o.setBackgroundColor(Color.BLACK)
        o.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        rootLayout.addView(o, FrameLayout.LayoutParams(MATCH, MATCH))
        fsOverlay = o
        fsCallback = cb
    }

    fun hideFullscreenView() {
        val o = fsOverlay ?: return
        o.removeAllViews()
        rootLayout.removeView(o)
        fsOverlay = null
        try { fsCallback?.onCustomViewHidden() } catch (e: Exception) {}
        fsCallback = null
    }

    // ---------------------------------------------------------------- helpers

    fun focusedTitle(app: App, t: String) {
        app.window?.setTitle(t + " - " + app.title)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun startSafely(i: Intent): Boolean = try {
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    fun lock() {
        if (boot != null) return
        closeFlyouts(null)
        val b = BootView(this, true) {
            rootLayout.removeView(boot)
            boot = null
        }
        boot = b
        rootLayout.addView(b, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------------------------------------------------------------- input

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val b = boot
        if (b != null) {
            if (e.action == KeyEvent.ACTION_UP) b.dismiss()
            return true
        }
        val code = e.keyCode
        if (code == KeyEvent.KEYCODE_META_LEFT || code == KeyEvent.KEYCODE_META_RIGHT) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) winUsed = false
            if (e.action == KeyEvent.ACTION_UP && !winUsed) toggleStart()
            return true
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.isMetaPressed) {
                winUsed = true
                when (code) {
                    KeyEvent.KEYCODE_E -> { open(AppKind.FILES, null); return true }
                    KeyEvent.KEYCODE_D -> { showDesktop(); return true }
                    KeyEvent.KEYCODE_M -> { windows.filter { it.desk == curDesk }.forEach { it.minimize() }; focusWindow(null); return true }
                    KeyEvent.KEYCODE_I -> { open(AppKind.SETTINGS, null); return true }
                    KeyEvent.KEYCODE_R -> { openRun(); return true }
                    KeyEvent.KEYCODE_L -> { lock(); return true }
                    KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_Q -> { openSearch(); return true }
                    KeyEvent.KEYCODE_A -> { toggleQuick(); return true }
                    KeyEvent.KEYCODE_W -> { toggleWidgets(); return true }
                    KeyEvent.KEYCODE_TAB -> { toggleTaskView(); return true }
                    KeyEvent.KEYCODE_T -> { open(AppKind.TERMINAL, null); return true }
                    KeyEvent.KEYCODE_B -> { open(AppKind.BROWSER, null); return true }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        if (e.isCtrlPressed) switchDesk(curDesk - 1) else focused?.applySnap(WindowView.SNAP_LEFT)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (e.isCtrlPressed) switchDesk(curDesk + 1) else focused?.applySnap(WindowView.SNAP_RIGHT)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> { focused?.applySnap(WindowView.SNAP_MAX); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        val f = focused
                        if (f != null) { if (f.maximized || f.snap != WindowView.SNAP_NONE) f.restoreNormal() else minimizeWindow(f) }
                        return true
                    }
                }
            }
            if (e.isCtrlPressed && e.isShiftPressed && code == KeyEvent.KEYCODE_ESCAPE) {
                open(AppKind.TASKMGR, null)
                return true
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_F4) {
                focused?.let { closeWindow(it) }
                return true
            }
            if (e.isAltPressed && code == KeyEvent.KEYCODE_TAB) {
                val here = windows.filter { it.desk == curDesk }
                if (here.size > 1) focusWindow(here.first())
                return true
            }
            val f = focused
            if (f != null && !f.minimized && !startMenu.isOpen && f.app.onShortcut(e)) return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (fsOverlay != null) { hideFullscreenView(); return }
        if (boot != null) return
        if (startMenu.isOpen) { startMenu.close(); return }
        if (flyouts.any { it.isOpen }) { closeFlyouts(null); return }
        focused?.app?.onBack()
        // As a launcher, Back never leaves the desktop.
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            filePathCallback = null
        } else if (requestCode == REQ_WALL && resultCode == RESULT_OK && data?.data != null) {
            try {
                val tmp = File(cacheDir, "wallpick.jpg")
                contentResolver.openInputStream(data.data!!)?.use { ins -> tmp.outputStream().use { o -> ins.copyTo(o) } }
                setWallpaperPhoto(tmp.absolutePath)
            } catch (e: Exception) {
                toast("Could not read that picture")
            }
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val d = i.data
        if (i.action == Intent.ACTION_VIEW && d != null) {
            val s = d.scheme ?: ""
            if (s == "http" || s == "https") open(AppKind.BROWSER, d.toString())
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeFlyouts(null)
        if (startMenu.isOpen) startMenu.close()
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        applyDisplayPrefs()
        handler.post(tick)
        windows.toList().forEach { it.app.onResume() }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
