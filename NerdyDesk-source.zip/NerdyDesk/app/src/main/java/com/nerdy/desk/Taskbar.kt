package com.nerdy.desk

import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("ViewConstructor")
class Taskbar(private val act: MainActivity) : LinearLayout(act) {
    private val group = LinearLayout(act)
    private val items = LinearLayout(act)
    private val startBtn = FrameLayout(act)
    private val clock = TextView(act)
    private val tray = TextView(act)
    private val deskBadge = TextView(act)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        elevation = dp(10).toFloat()
        build()
    }

    private fun build() {
        removeAllViews()
        background = Ui.rect(Ui.taskbar, 0f, Ui.border, 0)
        setBackgroundColor(Ui.taskbar)
        val centered = act.prefs.getString("tbstyle", "center") == "center"

        group.removeAllViews()
        group.orientation = HORIZONTAL
        group.gravity = Gravity.CENTER_VERTICAL or (if (centered) Gravity.CENTER_HORIZONTAL else Gravity.START)

        startBtn.removeAllViews()
        startBtn.isClickable = true
        startBtn.background = Ui.stateBg(dp(6).toFloat())
        val logo = WinLogo(act)
        logo.color = Ui.accent
        logo.scale = 0.46f
        startBtn.addView(logo, FrameLayout.LayoutParams(MATCH, MATCH))
        startBtn.setOnClickListener { act.toggleStart() }
        startBtn.hand()
        group.addView(startBtn, lp(dp(50), MATCH))

        if (centered) {
            group.addView(iconBtn("\uD83D\uDD0D") { act.openSearch() }, lp(dp(44), MATCH))
        } else {
            val search = TextView(act)
            search.text = "\uD83D\uDD0D  Type here to search"
            search.textSize = 12f
            search.setTextColor(Ui.textDim)
            search.gravity = Gravity.CENTER_VERTICAL
            search.setPadding(dp(14), 0, dp(14), 0)
            search.background = Ui.stateBg(dp(17).toFloat(), Ui.tint)
            search.isClickable = true
            search.setOnClickListener { act.openSearch() }
            search.hand()
            val sl = lp(dp(180), dp(34))
            sl.setMargins(dp(2), 0, dp(8), 0)
            group.addView(search, sl)
        }
        group.addView(iconBtn("\u25A3") { act.toggleTaskView() }, lp(dp(44), MATCH))
        group.addView(iconBtn("\uD83D\uDDD7") { act.toggleWidgets() }, lp(dp(44), MATCH))
        items.removeAllViews()
        items.orientation = HORIZONTAL
        group.addView(items, lp(WRAP, MATCH))
        addView(group, lp(0, MATCH, 1f))

        deskBadge.textSize = 11f
        deskBadge.setTextColor(Ui.text)
        deskBadge.gravity = Gravity.CENTER
        deskBadge.setPadding(dp(8), 0, dp(8), 0)
        deskBadge.isClickable = true
        deskBadge.background = Ui.stateBg(dp(6).toFloat())
        deskBadge.setOnClickListener { act.toggleTaskView() }
        addView(deskBadge, lp(WRAP, MATCH))

        tray.textSize = 12f
        tray.setTextColor(Ui.text)
        tray.gravity = Gravity.CENTER
        tray.setPadding(dp(10), 0, dp(10), 0)
        tray.isClickable = true
        tray.background = Ui.stateBg(dp(6).toFloat())
        tray.setOnClickListener { act.toggleQuick() }
        tray.hand()
        addView(tray, lp(WRAP, MATCH))

        clock.textSize = 11f
        clock.setTextColor(Ui.text)
        clock.gravity = Gravity.CENTER
        clock.setPadding(dp(10), 0, dp(10), 0)
        clock.isClickable = true
        clock.background = Ui.stateBg(dp(6).toFloat())
        clock.setOnClickListener { act.toggleCalendar() }
        clock.hand()
        addView(clock, lp(WRAP, MATCH))

        val sliver = View(act)
        sliver.isClickable = true
        sliver.background = Ui.stateBg(0f, Ui.tint)
        sliver.setOnClickListener { act.showDesktop() }
        addView(sliver, lp(dp(8), MATCH))
        refresh()
        updateTray()
    }

    fun rebuild() = build()

    private fun iconBtn(label: String, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = label
        t.textSize = 17f
        t.setTextColor(Ui.text)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.background = Ui.stateBg(dp(6).toFloat())
        t.setOnClickListener { onClick() }
        t.hand()
        return t
    }

    // ---------------------------------------------------------------- pinned + running

    private class Item(val key: String, val kind: AppKind?, val pkg: String?)

    fun pinned(): MutableList<String> {
        val raw = act.prefs.getString("pinned", null)
            ?: "k:FILES,k:BROWSER,k:NEURO,k:PHOTOS,k:VIDEO,k:MUSIC,k:TRADEDESK,k:TERMINAL"
        return raw.split(",").filter { it.isNotEmpty() }.toMutableList()
    }

    fun setPinned(l: List<String>) {
        act.prefs.edit().putString("pinned", l.joinToString(",")).apply()
        refresh()
    }

    fun isPinned(key: String) = pinned().contains(key)

    fun togglePin(key: String) {
        val l = pinned()
        if (!l.remove(key)) l.add(key)
        setPinned(l)
    }

    fun refresh() {
        items.removeAllViews()
        val list = ArrayList<Item>()
        for (k in pinned()) {
            if (k.startsWith("k:")) {
                val kind = try { AppKind.valueOf(k.substring(2)) } catch (e: Exception) { null }
                if (kind != null) list.add(Item(k, kind, null))
            } else if (k.startsWith("p:")) {
                list.add(Item(k, null, k.substring(2)))
            }
        }
        for (w in act.windows) {
            val key = "k:" + w.kind.name
            if (list.none { x -> x.key == key }) list.add(Item(key, w.kind, null))
        }
        for (item in list) items.addView(cell(item), lp(dp(48), MATCH))
        deskBadge.text = if (act.deskCount > 1) "\u25A6 " + (act.curDesk + 1) else ""
        deskBadge.visibility = if (act.deskCount > 1) View.VISIBLE else View.GONE
    }

    private fun cell(item: Item): View {
        val ws = if (item.kind != null) act.windows.filter { w -> w.kind == item.kind && w.desk == act.curDesk } else emptyList()
        val anyDesk = if (item.kind != null) act.windows.any { w -> w.kind == item.kind } else false
        val cell = FrameLayout(act)
        cell.isClickable = true
        cell.background = Ui.stateBg(dp(6).toFloat())
        cell.isSelected = ws.isNotEmpty() && ws.any { w -> w === act.focused }
        if (item.kind != null) {
            cell.addView(Ui.tile(act, item.kind.icon, item.kind.color, 30, 15f), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        } else {
            val iv = ImageView(act)
            try {
                iv.setImageDrawable(act.packageManager.getApplicationIcon(item.pkg!!))
            } catch (e: Exception) {
                iv.setImageDrawable(null)
            }
            cell.addView(iv, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        }
        if (ws.isNotEmpty() || anyDesk) {
            val u = View(act)
            u.background = Ui.rect(Ui.accent, dp(2).toFloat())
            val w = if (ws.any { w -> w === act.focused }) dp(18) else dp(7)
            cell.addView(u, FrameLayout.LayoutParams(w, dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { lp -> lp.bottomMargin = dp(2) })
        }
        if (ws.size > 1) {
            val n = TextView(act)
            n.text = ws.size.toString()
            n.textSize = 9f
            n.setTextColor(0xFFFFFFFF.toInt())
            n.background = Ui.rect(Ui.accent, dp(7).toFloat())
            n.gravity = Gravity.CENTER
            cell.addView(n, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END).also { lp -> lp.topMargin = dp(5); lp.rightMargin = dp(3) })
        }
        cell.setOnClickListener { click(item) }
        cell.setOnLongClickListener { menu(cell, item); true }
        cell.setOnContextClickListener { menu(cell, item); true }
        cell.hand()
        return cell
    }

    private fun click(item: Item) {
        if (item.pkg != null) {
            act.launchPackage(item.pkg)
            return
        }
        val kind = item.kind ?: return
        val ws = act.windows.filter { w -> w.kind == kind && w.desk == act.curDesk }
        when {
            ws.isEmpty() -> act.open(kind, null)
            ws.size == 1 -> {
                val w = ws[0]
                if (!w.minimized && act.focused === w) act.minimizeWindow(w) else act.focusWindow(w)
            }
            else -> {
                val idx = ws.indexOf(act.focused)
                act.focusWindow(ws[(idx + 1) % ws.size])
            }
        }
    }

    private fun menu(anchor: View, item: Item) {
        val m = PopupMenu(act, anchor)
        val ws = if (item.kind != null) act.windows.filter { w -> w.kind == item.kind } else emptyList()
        var id = 100
        for (w in ws) m.menu.add(0, id++, 0, "\u25B8 " + w.title())
        m.menu.add(1, 1, 1, if (item.kind != null) "New " + item.kind.title + " window" else "Open")
        m.menu.add(1, 2, 2, if (isPinned(item.key)) "Unpin from taskbar" else "Pin to taskbar")
        if (ws.isNotEmpty()) m.menu.add(1, 3, 3, "Close all windows")
        m.setOnMenuItemClickListener { mi ->
            when {
                mi.itemId >= 100 -> act.focusWindow(ws[mi.itemId - 100])
                mi.itemId == 1 -> if (item.kind != null) act.open(item.kind, null) else act.launchPackage(item.pkg!!)
                mi.itemId == 2 -> togglePin(item.key)
                mi.itemId == 3 -> ws.forEach { w -> act.closeWindow(w) }
            }
            true
        }
        m.show()
    }

    // ---------------------------------------------------------------- tray

    fun updateTray() {
        val now = Date()
        val tf = if (act.prefs.getBoolean("clock24", false)) "HH:mm" else "h:mm a"
        clock.text = SimpleDateFormat(tf, Locale.getDefault()).format(now) + "\n" +
            SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(now)
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val plug = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val bat = if (lvl >= 0 && sc > 0) (if (plug) "\u26A1" else "\uD83D\uDD0B") + " " + (lvl * 100 / sc) + "%" else ""
        tray.text = "\uD83D\uDCF6  \uD83D\uDD0A  " + bat
    }
}
