(function () {
  var q = new URLSearchParams(location.search);
  var root = document.documentElement;
  function setTheme(t, acc) {
    root.setAttribute('data-theme', t);
    if (acc) root.style.setProperty('--accent', acc);
    if (window.onTheme) window.onTheme(t, acc);
  }
  window.__setTheme = setTheme;
  setTheme(q.get('theme') || 'light', q.get('accent') || '#0a74da');
  var D = window.D = {
    has: !!window.Desk,
    arg: q.get('arg') || '',
    call: function (n) {
      try { var a = Array.prototype.slice.call(arguments, 1); return window.Desk[n].apply(window.Desk, a); } catch (e) { return ''; }
    },
    json: function (n) {
      try { var a = Array.prototype.slice.call(arguments); var r = D.call.apply(D, a); return JSON.parse(r || 'null'); } catch (e) { return null; }
    },
    furl: function (p) { return '/f?p=' + encodeURIComponent(p); },
    turl: function (p, s) { return '/t?p=' + encodeURIComponent(p) + '&s=' + (s || 320); },
    iurl: function (pkg) { return '/i?p=' + encodeURIComponent(pkg); },
    get: function (k, d) {
      try { var v = D.has ? window.Desk.get(k) : localStorage.getItem('nd.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; }
    },
    set: function (k, v) {
      try { var s = JSON.stringify(v); if (D.has) window.Desk.set(k, s); else localStorage.setItem('nd.' + k, s); } catch (e) {}
    },
    esc: function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); },
    size: function (b) {
      if (!b) return '0 B'; var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = Math.min(4, Math.floor(Math.log(b) / Math.log(1024)));
      return (b / Math.pow(1024, i)).toFixed(i ? 1 : 0) + ' ' + u[i];
    },
    time: function (sec) {
      sec = Math.max(0, Math.floor(sec || 0)); var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
      return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s).padStart(2, '0');
    },
    date: function (ms) { return new Date(ms).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' }); },
    toast: function (t) {
      var e = document.querySelector('.toast');
      if (!e) { e = document.createElement('div'); e.className = 'toast'; document.body.appendChild(e); }
      e.textContent = t; e.classList.add('show'); clearTimeout(e._t); e._t = setTimeout(function () { e.classList.remove('show'); }, 1800);
    },
    debounce: function (f, ms) { var t; return function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { f.apply(s, a); }, ms); }; },
    base: function (p) { return String(p).split('/').pop(); },
    dir: function (p) { return String(p).split('/').slice(0, -1).join('/'); },
    http: function (url) { return D.has ? window.Desk.http(url) : ''; },
    fetchJson: function (url) {
      if (D.has) { try { return Promise.resolve(JSON.parse(window.Desk.http(url))); } catch (e) { return Promise.reject(e); } }
      return fetch(url).then(function (r) { return r.json(); });
    }
  };
})();
