/* NeuroOrbitSynapse service worker.
   Strategy: network first (so an upload to GitHub is picked up at once), cache as the offline fallback.
   VERSION and SHELL are maintained by tools/sync.py. Bump VERSION on every release. */
const VERSION = 'nos-v7.4.0';
/*SHELL:start*/
const SHELL = [
  './',
  'index.html',
  'manifest.webmanifest',
  'css/base.css',
  'css/layout.css',
  'css/goals.css',
  'css/inspector.css',
  'css/map-controls.css',
  'css/today.css',
  'css/shell.css',
  'css/trading.css',
  'css/plan-guide.css',
  'css/brand-splash.css',
  'css/drawer-plus.css',
  'js/core/util.js',
  'js/core/icons.js',
  'js/core/data.js',
  'js/core/state.js',
  'js/core/logic.js',
  'js/audio/sound.js',
  'js/audio/music.js',
  'js/services/notify.js',
  'js/visuals/scene.js',
  'js/visuals/universe.js',
  'js/visuals/synapse.js',
  'js/visuals/path.js',
  'js/visuals/ladder.js',
  'js/visuals/tree.js',
  'js/visuals/board.js',
  'js/visuals/board-focus.js',
  'js/visuals/house.js',
  'js/visuals/fx.js',
  'js/ui/events.js',
  'js/ui/home.js',
  'js/ui/drawer.js',
  'js/ui/drawer-plus.js',
  'js/ui/form.js',
  'js/ui/focus.js',
  'js/features/mind/breath.js',
  'js/features/train/train.js',
  'js/features/train/train2.js',
  'js/features/train/cardio.js',
  'js/views/goals.js',
  'js/views/calendar.js',
  'js/views/insights-legacy.js',
  'js/features/journal/journal.js',
  'js/features/journal/journal2.js',
  'js/features/journal/studio.js',
  'js/views/records.js',
  'js/views/constellation.js',
  'js/views/inspector.js',
  'js/features/mind/pulse.js',
  'js/views/board-stats.js',
  'js/features/games/games.js',
  'js/features/games/decode.js',
  'js/features/games/games2.js',
  'js/features/games/games3.js',
  'js/views/progress.js',
  'js/views/trace.js',
  'js/services/backup.js',
  'js/views/settings-legacy.js',
  'js/views/guide-data.js',
  'js/views/about-legacy.js',
  'js/ui/board-actions.js',
  'js/ui/shell.js',
  'js/views/insights.js',
  'js/features/mind/mind.js',
  'js/features/train/metrics.js',
  'js/features/trading/model.js',
  'js/features/trading/desk.js',
  'js/features/trading/offday.js',
  'js/features/trading/insights.js',
  'js/views/plan.js',
  'js/views/settings.js',
  'js/views/guide.js',
  'js/views/about.js',
  'js/ui/brand.js',
  'js/app/init.js',
  'js/app/splash-scene.js',
  'js/app/splash.js',
  'js/app/boot.js',
  'icons/nos7-icon-192.png',
  'icons/nos7-icon-512.png',
  'icons/nos7-badge-96.png',
  'icons/nos7-icon.svg'
];
/*SHELL:end*/

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const u = new URL(e.request.url);
  e.respondWith(
    fetch(e.request).then(r => {
      if (r && r.ok && u.origin === location.origin) { const cp = r.clone(); caches.open(VERSION).then(c => c.put(e.request, cp)).catch(() => {}); }
      return r;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }).then(m => m || caches.match('./index.html')))
  );
});

/* notification buttons: Done logs the goal, tapping opens it */
self.addEventListener('notificationclick', e => {
  const n = e.notification, d = n.data || {}, act = e.action; n.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => {
    if (cs.length) { const c = cs[0]; if (act === 'done' && d.goal) c.postMessage({ type: 'done', goal: d.goal }); else if (d.goal) c.postMessage({ type: 'open', goal: d.goal }); return c.focus(); }
    const q = act === 'done' && d.goal ? '?done=' + encodeURIComponent(d.goal) : (d.goal ? '?goal=' + encodeURIComponent(d.goal) : '');
    return self.clients.openWindow('./' + q);
  }));
});

/* focus-timer alert while the page is hidden */
self.addEventListener('message', e => {
  const d = e.data || {};
  if (d.type !== 'focusTimer') return;
  const w = Math.max(0, d.at - Date.now());
  e.waitUntil(new Promise(res => setTimeout(() => {
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => {
      if (cs.some(c => c.visibilityState === 'visible')) return res();
      self.registration.showNotification(d.title, { body: d.body, tag: d.tag, icon: 'icons/nos7-icon-192.png', badge: 'icons/nos7-badge-96.png', requireInteraction: true, vibrate: [300, 120, 300], data: {} }).then(res, res);
    }, res);
  }, Math.min(w, 5 * 3600 * 1000))));
});
