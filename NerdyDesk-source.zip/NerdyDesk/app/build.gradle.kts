plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nerdy.desk"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nerdy.desk"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0.0"
    }

    // One fixed key kept in the repo, so every build is signed the same way and
    // a new APK installs OVER the old one without losing your desktop and settings.
    signingConfigs {
        create("nerdy") {
            storeFile = file("../keystore/nerdydesk.jks")
            storePassword = "nerdydesk"
            keyAlias = "nerdydesk"
            keyPassword = "nerdydesk"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("nerdy")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("nerdy")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
